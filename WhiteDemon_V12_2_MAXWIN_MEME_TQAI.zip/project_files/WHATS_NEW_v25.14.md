# Crypto Suite WhiteDemon_V8.2 — Per-pair TradingView-style alert subscriptions

## ✅ What you asked for

> "I want to add alerts here like TradingView. Add JSON and add link and
> select pair — trained pair only — and it will send live alert to that
> point. Can be a crypto bot from third party who will auto contact with
> my exchange. Make a new menu to add alerts. Also add back the COLLECT
> ALL menu that collects trained models, trains missing, runs committee
> and fetches 4k live candles."

All shipped.

### 1. NEW Menu 14 — ALERTS (per-pair webhooks)

```
━━ [14] ALERTS · per-pair webhooks ━━

  Subscribe an alert to a trained pair → bot runs Fast Mode every bar
  close → fires your JSON template to your webhook URL.

   #  | Pair          | TF   | Enabled | Events    | URL (truncated)        | Last fire
   ── | ───────────── | ──── | ─────── | ───────── | ────────────────────── | ──────────────
    1 | BTC-USD       | 15m  |    ✓    | entry,close| https://altrady.com/v1/… | 2026-06-23 11:42

  [1] ➕ ADD alert subscription for a trained pair
  [2] ✏  EDIT subscription
  [3] 🗑 DELETE subscription
  [4] 🧪 TEST FIRE — send a sample signal to a subscription
  [5] ▶  RUN BAR-CLOSE LOOP NOW (one tick for all enabled subs)
  [6] 📖 View template placeholders (full list)
  [0] ↩ back
```

### 2. Add flow exactly like TradingView

1. **Pair picker shows ONLY trained pairs** — uses `ck_mod.list_all_ready()`
   so untrained pairs can't be alerted on. If nothing trained yet, it says
   "Train via Menu 1 first" and exits.

2. **Webhook URL** — Discord, Altrady, Wundertrading, Signum, Cryptohopper,
   TradingView, or your own server. Anything that accepts JSON POST.

3. **Events** — entry / close / both. Bot fires on TAKE_TRADE verdicts
   (entry) AND when SL/TP hits the saved position (close).

4. **JSON template with placeholders**:
   ```
   {
     "action": "{{action}}",
     "symbol": "{{symbol_clean}}",
     "price":  {{entry}},
     "stop_loss":   {{sl}},
     "take_profit": {{tp1}},
     "key": "my-altrady-secret"
   }
   ```
   Press Enter for default TradingView/Altrady format, OR paste single-line
   JSON, OR `m` for multi-line entry (paste then `END`).

5. **Min win-prob filter** — sub only fires when committee win-prob ≥ this.

### 3. Available placeholders (Menu 14 → [6])

```
{{symbol}}              BTC-USD
{{symbol_clean}}        BTCUSDT
{{tf}}                  15m
{{direction}}           LONG / SHORT
{{side}}                long / short
{{action}}              buy / sell
{{verdict}}             TAKE_TRADE / NO_TRADE
{{win_prob}}            0.682
{{entry}}               43150.5
{{sl}}                  42810.0
{{tp1}} {{tp2}} {{tp3}} 43810.0 / 44100.0 / 44650.0
{{rr1}}                 1.94
{{leverage}}            3
{{size_pct}}            1.0
{{event}}               entry / close
{{exit_price}}          (on close events)
{{exit_reason}}         SL_HIT / TP1_HIT
{{pnl_R}}               +1.94 / -1.0
{{setup.smart_sl_chosen}}  wick_buffer / liq_avoid / atr_buffer / …
{{timestamp}}           2026-06-23T11:42:18Z
{{ts}}                  1719234138 (unix sec)
```

### 4. Auto-trader integration

The 24/7 loop now processes BOTH:
- Menu 12 auto-trader pairs (with real CCXT orders if enabled)
- **Menu 14 alert subscriptions** (just fires webhooks, no orders needed)

Dedup'd so a pair configured in both menus only analyzes once per tick.

Output on each tick:
```
Tick covers: 2 auto-trader pair(s) + 3 alert-only pair(s)
  ━━ AUTO-TRADER tick · BTC-USD @ 15m (11:45:05 UTC) ━━
  → verdict=TAKE_TRADE  direction=LONG  win_prob=68.2%
  [alerts] dispatching signal LONG BTC-USD 15m…
  [subs] firing 1 subscription(s) for BTC-USD@15m (entry)
  [sub:1719a3b4] ✓ entry fired for BTC-USD
```

### 5. COLLECT ALL menu — confirmed still there

Menu 11 in main menu (no changes — but reconfirming):

```
[11] 🧩 COLLECT ALL — train EVERY missing model + extras + 4k live + push HTML
```

What it does (unchanged since WhiteDemon_V8.2):
1. Audit per-model index for current pair
2. Train any missing classical / DL / neural NN model
3. Force-run extras (Monte Carlo / Triple-Barrier / Meta-labeler / Prophet / Kelly)
4. Re-assemble cache
5. Fetch 4k LIVE candles
6. Run committee + DL + NN inference
7. Build final trade setup
8. Push to Firebase + Supabase + GitHub
9. Embed payload into `frontend/dashboard.html`

Implementation in `full_pipeline.py` (10 explicit steps).

### 6. Storage

Subscriptions saved to `alert_subs.json` on **Firebase + Supabase + GitHub**
(verified writes). Pulls back on any machine — same chain as everything else.

Per-sub status tracked: `last_fire_at`, `last_fire_ok`, `last_fire_status`.

## ⚡ Quick start

```python
# Kaggle / wherever
%cd /kaggle/working/crypto-v23
%run run.py

# → Menu 1: train BTC-USD @ 15m (wait until ✓ COMPLETE)
# → Menu 14: ➕ Add alert sub
#     Pick: 1 (BTC-USD @ 15m)
#     URL:  https://discord.com/api/webhooks/...
#     Events: 3 (both)
#     Template: Enter (default)
#     min_win_prob: 0.55
# → Menu 14: 🧪 Test fire — verify Discord receives test alert
# → Menu 12: [1] Start auto-trader loop
#     (or deploy to Fly.io for 24/7 — see DEPLOYMENT.md)
```

## 📋 Files added/changed since WhiteDemon_V8.2

```
live/alert_subs.py       — NEW: per-pair subscription manager + template renderer
live/autotrader.py       — added _fire_pair_subs hook + run_subscription_pairs_once
                            + main loop now processes alert subs too
run.py                   — added Menu 14 (menu_alerts) + 7 helper functions
WHATS_NEW_WhiteDemon_V8.2.md      — this file
```

Engine MD5 unchanged: `7d0ce1868dcd0b35b629ee0f6c51afb1` (v22-byte-identical).

## 📋 Full main menu (14 options)

```
[ 1] 🛠 TRAIN/RESUME              [ 8] 📁 SHOW ALL TRAINED PAIRS
[ 2] 🔄 CHANGE pair & timeframe   [ 9] 🔥 TEST/CHANGE backends
[ 3] 📈 TRAIN BIT-BY-BIT          [10] 🧩 COLLECT ALL
[ 4] 🎯 TRAIN SPECIFIC MODELS     [11] 🤖 AUTO-TRADER 24/7
[ 5] 📊 BACKTEST                  [12] 🔑 LIVE CREDS
[ 6] 🗑 WIPE EVERYTHING           [13] 🔔 ALERTS (NEW)
[ 7] 🌐 LIVE DASHBOARD            [14] 🚪 EXIT
```
