# WhiteDemon V8.5 — Analyze Error Fixes

## Fixed errors from analyze output

### 1) Monte Carlo skipped error
Fixed:
```text
monte_carlo_robustness() got an unexpected keyword argument 'n_runs'
```
Changes:
- `_engine.monte_carlo_robustness()` now accepts backwards-compatible aliases:
  - `n_runs`
  - `initial_capital`
- `analyze.py` and `collect_all.py` now call it with the correct current arguments.

### 2) Position sizing skipped error
Fixed:
```text
calc_position_size() got an unexpected keyword argument 'risk_per_trade'
```
Changes:
- `_engine.calc_position_size()` now accepts `risk_per_trade` as an alias.
- `risk_per_trade=0.01` is converted to `max_risk_pct=1.0`.
- `analyze.py` and `collect_all.py` now use `max_risk_pct=1.0` directly.

### 3) HTML embed skipped error
Fixed:
```text
HTML embed skipped: bad escape \u at position ...
```
Cause:
- `re.sub()` treated JSON unicode escapes as replacement-string escapes.

Fix:
- Replaced direct replacement string with `lambda _m: inject`, so JSON is inserted safely.

### 4) Always switching to SHORT setup
Improved direction fallback logic.

Old behavior:
- If chosen direction setup was invalid, code could switch to the opposite side just because that setup geometry was valid.
- This could make the app appear to always suggest SHORT.

New behavior:
- It only switches LONG ↔ SHORT if the alternate side is also supported by committee probability:
  - alternate probability >= 55%, and
  - alternate probability is at least 2% better than original.
- Otherwise it keeps the original direction and lets the guard/decision block the trade.

## Notes
Messages like these are not code errors:
```text
confidence < threshold – BLOCKED
Stop too wide – BLOCKED
```
Those are risk guard blocks. They mean the trade was rejected safely.
