"""
train_incremental.py — Bit-by-bit training with RESUME, EXTEND and NEW modes.

Modes
─────
  RESUME : continue an interrupted training (Colab disconnected, crash, etc.)
           - Same candle count as last time, picks up at the last completed stage.
  EXTEND : add MORE candles on top of what was already trained.
           - e.g. last time 10k → this time fetch the NEXT 10k → train on combined 20k.
  NEW    : wipe everything and start fresh.

USAGE
  python train_incremental.py 10000           # interactive: asks resume/extend/new
  python train_incremental.py 10000 --resume  # force resume
  python train_incremental.py 10000 --extend  # force extend
  python train_incremental.py 10000 --new     # force fresh
  python train_incremental.py                 # fully interactive
"""
from __future__ import annotations
import os, sys, argparse, datetime

# Parse args BEFORE importing core (which mutates sys.argv)
ap = argparse.ArgumentParser()
ap.add_argument("candles", type=int, nargs="?", default=None,
                help="number of candles to train on")
mode = ap.add_mutually_exclusive_group()
mode.add_argument("--resume", action="store_true", help="resume interrupted training")
mode.add_argument("--extend", action="store_true", help="add MORE candles on top")
mode.add_argument("--new",    action="store_true", help="wipe and start fresh")
ap.add_argument("--skip-advanced", action="store_true")
args = ap.parse_args()

from core.config        import SYMBOL, TF_LABEL, CFG
from core.colors        import RESET, BOLD, CYAN, GREEN, YELLOW, RED, ORANGE, GREY
from core               import checkpoint as ck_mod
from core.storage       import STORE
from train_pipeline     import train_with_checkpoint


def _pick_candles(last_size: int, last_ts: str) -> int:
    print(f"\n{BOLD}{CYAN}━━ INCREMENTAL TRAINING · {SYMBOL} @ {TF_LABEL} ━━{RESET}\n")
    if last_size:
        print(f"  Last training: {last_size:,} candles on {last_ts}")
    else:
        print(f"  No previous training for this pair/TF.")
    print(f"\n  Pick a candle count:")
    print(f"    [1]  10,000 candles  (~3 min  · quick test)")
    print(f"    [2]  30,000 candles  (~7 min  · decent baseline)")
    print(f"    [3]  60,000 candles  (~12 min · solid)")
    print(f"    [4] 100,000 candles  (~18 min · production)")
    print(f"    [5] 200,000 candles  (~30 min · max history)")
    print(f"    [c]  custom (type the number)")
    print(f"    [0]  cancel")
    choice = input(f"\n{BOLD}Pick [1-5/c/0]: {RESET}").strip().lower()
    preset = {"1": 10_000, "2": 30_000, "3": 60_000, "4": 100_000, "5": 200_000}
    if choice == "0":
        print("  cancelled."); sys.exit(0)
    if choice == "c":
        try: return int(input(f"  Custom candle count: ").strip())
        except ValueError: print(f"{RED}invalid number{RESET}"); sys.exit(1)
    if choice in preset:
        return preset[choice]
    print(f"{RED}invalid choice{RESET}"); sys.exit(1)


def _pick_mode(last_size: int, want_size: int, ck_progress: str) -> str:
    """Return 'resume' | 'extend' | 'new'."""
    if not last_size:
        return "new"

    same_size = want_size == last_size
    print(f"\n{BOLD}{YELLOW}━━ Training already exists ━━{RESET}")
    print(f"  Last training : {last_size:,} candles")
    print(f"  Progress      : {ck_progress}")
    print(f"  You requested : {want_size:,} candles")
    print()
    if same_size:
        print(f"  [r]  RESUME — continue where it left off (recommended if last run crashed)")
        print(f"  [e]  EXTEND — fetch NEXT {want_size:,} fresh candles and train on combined {last_size + want_size:,}")
        print(f"  [n]  NEW    — wipe everything and start fresh (loses last training)")
    else:
        print(f"  [r]  RESUME — finish the {last_size:,}-candle run first (current pending stages)")
        print(f"  [e]  EXTEND — fetch ADDITIONAL {want_size:,} candles → train on combined {last_size + want_size:,}")
        print(f"  [n]  NEW    — wipe everything and retrain only on {want_size:,}")
    print(f"  [0]  cancel")
    ans = input(f"\n{BOLD}Mode [r/e/n/0]: {RESET}").strip().lower()
    if ans == "0": print("  cancelled."); sys.exit(0)
    if ans in ("r", "resume"): return "resume"
    if ans in ("e", "extend"): return "extend"
    if ans in ("n", "new"):    return "new"
    print(f"{RED}invalid choice{RESET}"); sys.exit(1)


# ── Load existing state ──────────────────────────────────────────────
ck       = ck_mod.load(SYMBOL, TF_LABEL)
last_sz  = ck.get("trained_candles", 0)
last_ts  = (ck.get("last_update") or ck.get("trained_at") or "—")[:16]
progress = ck_mod.progress_summary(ck) if last_sz else "not started"

# ── Pick candle count ────────────────────────────────────────────────
want_sz = args.candles if args.candles is not None else _pick_candles(last_sz, last_ts)

# ── Pick mode ────────────────────────────────────────────────────────
if args.resume: mode = "resume"
elif args.extend: mode = "extend"
elif args.new:    mode = "new"
else:             mode = _pick_mode(last_sz, want_sz, progress)

# ── Compute final candle count based on mode ─────────────────────────
if mode == "extend" and last_sz:
    final_target = last_sz + want_sz
    print(f"\n{BOLD}{GREEN}→ EXTEND: {last_sz:,} + {want_sz:,} = {final_target:,} candles{RESET}\n")
    # Extend = wipe checkpoint, fetch combined size from scratch (engine
    # caches data internally and will reuse already-fetched bars).
    ck_mod.reset(SYMBOL, TF_LABEL)
elif mode == "new":
    final_target = want_sz
    print(f"\n{BOLD}{GREEN}→ NEW: training fresh on {final_target:,} candles{RESET}\n")
    print(f"  [ckpt] wiping previous checkpoint …")
    ck_mod.reset(SYMBOL, TF_LABEL)
else:  # resume
    final_target = last_sz or want_sz
    print(f"\n{BOLD}{GREEN}→ RESUME: continuing {final_target:,}-candle run "
          f"(pending stages will start where they stopped){RESET}\n")

# ── Run ──────────────────────────────────────────────────────────────
CFG["target_total_candles"] = final_target
ck_final = train_with_checkpoint(force=False,            # never wipe — we already did if needed
                                   skip_advanced=args.skip_advanced,
                                   target_candles=final_target)

# ── Stamp the candle count + timestamp so menu shows it next time ────
ck_final["trained_candles"] = final_target
ck_final["trained_at"]      = datetime.datetime.utcnow().isoformat() + "Z"
ck_mod.save(ck_final)

print(f"\n{BOLD}{GREEN}✅ Done — {SYMBOL} @ {TF_LABEL} trained on {final_target:,} candles{RESET}")
print(f"   Run this again anytime to RESUME, EXTEND or start NEW.\n")
