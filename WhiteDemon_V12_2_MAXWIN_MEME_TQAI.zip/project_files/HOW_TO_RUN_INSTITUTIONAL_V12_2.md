# WhiteDemon V12.2 MAX WIN — Institutional — How to Run

## 1-click start
```bash
python run_institutional.py
# or
INSTITUTIONAL_AUTO=1 python run.py
```

Open browser:
- Dashboard: http://localhost:5000/
- **Trade Journal (NEW): http://localhost:5000/journal**
- Mobile: http://localhost:5000/mobile
- API health: http://localhost:5000/healthz

## 17-coin profiles (auto)
BTC ETH SOL BNB XRP ADA DOGE AVAX LINK LTC DOT MATIC
+ MEME: PEPE SHIB FLOKI WIF BONK (+TRUMP)

Symbol auto-detected from engine_context — no manual config.

Example:
```python
from core.engine_patches import engine_context, apply_engine_patches
apply_engine_patches()
with engine_context("SOLUSDT","15m","LONG",200000):
    import _engine as eng
    committee = eng.run_ml_committee(df, sentiment, cutoff, None, "LONG")
    # committee['coin_profile'] == 'SOL'
    # committee['tuning']['meta_threshold'] == 0.67
```

## Trade Outcome Learning — NEW V12.2

Mark trades WIN/LOSS — feeds Trade Quality AI:

**Web UI:**
http://localhost:5000/journal
- Lists all recent trades
- Click **WIN ✓** or **LOSS ✗**
- Auto-saves to GitHub via `core.storage.put_json("institutional/trade_outcomes_v12.json")`
- TQAI instantly re-scores next signal

**API:**
```
POST /api/trade_feedback
{
  "symbol":"SOLUSDT",
  "direction":"LONG",
  "entry_price": 142.3,
  "exit_price": 146.1,
  "meta_prob_live": 0.71,
  "stack_bull": 0.68,
  "regime": "TRENDING",
  "outcome": "WIN",
  "pnl_pct": 2.67,
  "note": "manual close"
}
→ {"ok":true, "saved":{...}, "trade_id":"tq_..."}
```

**View analytics:**
```
GET /api/tqai/performance
→ {
  "n_trades": 127,
  "winrate": 0.740,
  "by_regime": {"TRENDING":0.78,"RANGING":0.69},
  "by_confidence": {"high":0.76,"elite":0.81},
  "by_hour": {"14":0.74, ...}
}
```

**Score a live signal before firing:**
```
POST /api/tqai/score
{ "stack_bull":0.66, "meta_prob_live":0.71, "regime":"TRENDING", "symbol":"SOLUSDT" }
→ { "tqai_quality_adj":1.12, "learned_winrate":0.74, "meta_prob_live_tq":0.73, ... }
```

## Backtest — SOLUSDT 15m
See: `BACKTEST_SOLUSDT_15m_V12_1.md`
- Win 74.6%, PF 2.18, DD -2.9%
- +0.68%/day, double ~92 trading days
- $1,000 → $19,470 in 29 months (backtest)

## Risk — real money
- Start $300–$1,000 paper 14 days
- Position 4–8% (Kelly auto)
- Daily DD circuit breaker 3.5%
- Stop if: 2 daily losses in a row OR 7 days zero trades
- Scale up after: 60 trades, PF≥1.8, WR≥68%
