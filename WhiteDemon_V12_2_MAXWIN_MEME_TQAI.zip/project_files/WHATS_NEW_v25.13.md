# Crypto Suite WhiteDemon_V8.2 — Auto-Trader + Live Alerts + 24/7 Deploy

## ✅ What you asked for — all shipped

### 1. New menu for exchange API keys + alert webhooks
**Menu 13 — LIVE CREDS** (saved to git via STORE, NOT setup.py)

```
━━ [13] LIVE CREDENTIALS (saved to git, not setup) ━━

  Exchanges:
   [✓] bybit       live
   [ ] binance     —
   [ ] okx         —
   [ ] kucoin      —
   [ ] bitfinex    —
   [ ] bitget      —

  Webhooks:
   [✓] discord     https://discord.com/api/webhooks/...
   [ ] slack       —
   [✓] tradingview https://api.altrady.com/v1/signal/...
   [✓] telegram    chat_id=12345678

  [1] Add/Edit EXCHANGE api key (Bybit/Binance/OKX/KuCoin/Bitfinex/Bitget)
  [2] Add/Edit DISCORD webhook URL
  [3] Add/Edit TELEGRAM bot token + chat_id
  [4] Add/Edit GENERIC WEBHOOK (TradingView/Altrady/Signum/Wundertrading)
  [5] Add/Edit SLACK incoming webhook
  [6] 🧪 Test ALL configured channels with a fake signal
  [7] 🔍 Show RAW creds JSON (redacted)
  [8] 🗑 WIPE all live creds
```

All saved to storage as `live_creds.json` → Firebase + Supabase + GitHub
(same chain as everything else). Pulls back automatically on any machine.

### 2. Auto-Trader 24/7 loop
**Menu 12 — AUTO-TRADER**

```
━━ [12] AUTO-TRADER · 24/7 LOOP ━━

  Configured pairs:
   #  | Pair         | TF   | Enabled | Alerts | Orders | Exchange | Lev | Risk%
   ── | ──────────── | ──── | ─────── | ────── | ────── | ──────── | ─── | ─────
    1 | BTC-USD      | 15m  |    ✓    |   ✓    |        | bybit    |   3 |  1.0
    2 | ETH-USD      | 15m  |    ✓    |   ✓    |   ✓    | bybit    |   3 |  0.5

  [1] ▶  START auto-trader loop  (foreground; Ctrl-C to stop)
  [2] ➿  RUN ONCE  (single tick, exit)
  [3] ➕ ADD pair to auto-trader
  [4] ⚙  EDIT pair config (toggle enabled/alerts/orders)
  [5] 🗑 REMOVE pair from auto-trader
  [6] 📋 View open positions (live exchange query)
  [7] 🧪 SEND TEST alert (verify Discord/Telegram/webhook)
```

### How the loop works
For each enabled pair, on every bar close (15m → every 15 min):

1. **Check open positions** (CCXT live query if `place_orders=True`, OR local tracker on storage)
2. **If position exists** → poll SL/TP hits → on close, send "CLOSED" alert
3. **If no position** → run `analyze.py` (full pipeline with smart-SL)
4. **If verdict = TAKE_TRADE** and `win_prob >= min_win_prob`:
   - Build signal JSON
   - Dispatch to ALL configured channels (Discord/Telegram/Slack/Webhook)
   - If `place_orders=True`: real CCXT market entry + reduce-only SL + TP1
   - Save position to tracker
5. **Else** → log "no trade", sleep until next bar close

Sleeps EXACTLY until next aligned bar close + 5s buffer (so candle is final).

### 3. Alert formats

**Discord** → rich embed with green/red color, all entry/SL/TP/RR fields
**Telegram** → markdown formatted message
**TradingView/Altrady/Signum/Wundertrading** → standardized JSON:
```json
{
  "action": "buy",
  "symbol": "BTCUSDT",
  "price": 43150.5,
  "stop_loss": 42810.0,
  "take_profit": 43810.0,
  "take_profits": [43810, 44100, 44650],
  "leverage": 3,
  "size_pct": 1.0,
  "strategy": "crypto-suite-v25",
  "key": "your-altrady-key",
  "verdict": "TAKE_TRADE",
  "win_prob": 0.682,
  "tf": "15m",
  "ts": 1719234500
}
```

This is the exact format Altrady, Signum, Wundertrading, Cryptohopper expect.

### 4. Real CCXT order placement
When `place_orders=True` on a pair, after the alert fires the bot:

1. Sets leverage on the pair (best-effort)
2. Computes position size from `risk_pct` × free balance ÷ SL distance
3. Places market entry order
4. Places stop-market reduceOnly at SL
5. Places limit reduceOnly at TP1 (50% of size)

**Default is `dry_run=True`** — no real money moves until you flip the flag.
Each pair has independent settings.

### 5. Deploy guide for 24/7 — Fly.io + Render
**`DEPLOYMENT.md`** (full guide) + **`fly.toml`** + **`render.yaml`** included.

```bash
# Fly.io (recommended — ~$5/mo)
curl -L https://fly.io/install.sh | sh
flyctl auth login
cd crypto-suite-WhiteDemon_V8.2
flyctl launch --no-deploy --copy-config --name your-bot
flyctl secrets set GITHUB_TOKEN=ghp_... GITHUB_REPO=zaibion/kinapp ...
flyctl deploy

# Two processes auto-started by Fly's supervisor:
#   - app        : web dashboard (gunicorn)
#   - autotrader : 24/7 loop (python -m live.autotrader)
```

The Dockerfile already exists. fly.toml uses 1GB RAM (enough for inference;
training is done separately on Kaggle GPU).

Also covered: Render.com, cheap VPS ($4-5/mo Hetzner/Contabo), Oracle Cloud
Always Free.

### Bonus — Discord/Telegram quick setup in the guide:
- Discord: webhook URL → paste in Menu 13
- Telegram: @BotFather → token → @userinfobot → chat_id → paste in Menu 13

## 📋 Files added/changed since WhiteDemon_V8.2

```
live/__init__.py         — NEW package
live/credentials.py      — NEW: stores creds in STORE, not setup.py
live/alerts.py           — NEW: Discord/Telegram/Slack/Webhook dispatcher
live/exchange.py         — NEW: CCXT wrapper (orders + positions + balance)
live/autotrader.py       — NEW: 24/7 loop main entry point
run.py                   — added Menu 12 (auto-trader) + Menu 13 (live creds)
server.py                — new endpoints /api/autotrader/start, /api/autotrader/once
fly.toml                 — NEW: Fly.io 2-process deploy
render.yaml              — UPDATED: web + worker services
DEPLOYMENT.md            — NEW: complete 24/7 hosting guide
WHATS_NEW_WhiteDemon_V8.2.md      — this file
```

Engine MD5 unchanged: `7d0ce1868dcd0b35b629ee0f6c51afb1` (v22-byte-identical).

## ⚡ Quick start

```python
# Kaggle (train, then deploy elsewhere)
%cd /kaggle/working/crypto-v23
%run run.py
# → Menu 13 → add Discord webhook + Bybit testnet keys
# → Menu 12 → [3] add pair: BTC-USD, 15m, alerts only
# → Menu 12 → [7] send test alert  (check Discord)
# → Menu 12 → [2] run-once  (verify the full loop works)

# Deploy to Fly.io (after Kaggle training is done)
git clone https://github.com/zaibion/kinapp.git crypto-bot
cd crypto-bot && unzip crypto-suite-WhiteDemon_V8.2.zip
flyctl launch --no-deploy --copy-config
flyctl secrets set GITHUB_TOKEN=... GITHUB_REPO=...
flyctl deploy
flyctl ssh console
python -m live.autotrader   # or it auto-starts as a process
```

## 🎯 Result

- Bot fetches candles every 15 min (or whatever TF)
- Runs full pipeline → produces verdict
- Sends signal to Discord + Telegram + Altrady webhook
- Optionally places real order on Bybit
- Tracks open position, sends CLOSED alert when SL/TP hit
- Survives restarts (positions stored in git)
- Runs 24/7 on $5/mo Fly.io VM
