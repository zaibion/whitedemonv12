# Crypto Suite WhiteDemon_V8.2 — Server fix + FULL-pipeline analyze + HTML auto-embed

## 🔥 Three crash/bug fixes shipped

### 1. `server.py` crashed on startup with `TypeError: a bytes-like object is required, not 'str'`
**Root cause:** Flask's startup banner calls `click.echo(..., file=stdout)` which writes RAW BYTES. My `TeeStdout` wrapper assumed `str`.

**Fix:**
- `TeeStdout.write()` now accepts both `bytes` AND `str`, decodes UTF-8 with `errors="replace"`.
- Added `isatty()`, `fileno()`, `encoding`, `buffer` shims so other libs probing the stream work.
- `server.py` now bypasses Flask's banner entirely by calling `werkzeug.serving.run_simple` directly (Flask wraps this anyway). Falls back to `app.run()` with stdout restored if Werkzeug import fails.

### 2. `analyze.py` was only loading cached `stack_bull` scores — no neural NN, no Monte Carlo, no Triple-Barrier, no position sizing
**Root cause:** Old analyze.py was a thin "FAST MODE" reader that just grabbed slim metadata JSONs and stubbed `monte_carlo:{available:False}`. The ML committee, DL ensemble, and 4 specialised NNs never ran during analysis.

**Fix — `analyze.py` is now the FULL pipeline:**
- Calls `_engine.run_ml_committee(df, sentiment, train_cutoff, direction)` for BOTH LONG and SHORT directions.
- Inside the committee, the engine trains:
  - 9 classical (LR/KNN/RF/ET/XGB/LGB/Cat/HGB/MLP)
  - 14 DL nets (LSTM/BiLSTM/GRU/TCN/WaveNet/Transformer/CNN1D/NBeats/Mamba/PatchTST/iTransformer/FreTS/TFT/Mamba-PDF)
  - 4 specialised NNs (PriceRegressionNN, RL Agent, SentimentNN, RegimeDetectorNN)
  - Triple-Barrier, Meta-labeler, stacker
- **Cached weights load instantly** via `per_model_cache.load_dl/load_classical` (DL nets via patched `DLEnsemble.train`). So if you already trained the pair, analysis takes seconds, not minutes.
- Then computes:
  - **Monte Carlo robustness** — 2,000 bootstrap simulations on cached backtest trades.
  - **Position Sizing** (Kelly + fractional) — `_engine.calc_position_size(win_prob, rr, equity, risk)`.
  - Surfaces `tb_models.available = True` and `backtest_results.available = True`.
- All dashboard tabs (especially Monte Carlo, Position Sizing, Triple-Barrier, Backtest) now show real data instead of "available: false".

### 3. HTML wasn't auto-updating after analysis
**Fix:**
- `analyze.py` now writes `dashboard_data.json` locally AND
- Embeds the full payload into `frontend/dashboard.html` as
  `window.__EMBED_DASHBOARD_DATA__` so opening the HTML file with `file://…`
  shows the latest setup with **zero credential entry**.
- Also pushes the HTML to your storage (Firebase/Supabase/GitHub) as
  `dashboard_<rid>.html` — share the GitHub raw URL with anyone.

## ⚡ How to use

```bash
# Kaggle
%cd /kaggle/working/crypto-v23

# Option A — full pipeline analyze + HTML auto-update
%run analyze.py

# Option B — train any missing model + analyze + HTML
%run collect_all.py

# Option C — start web server (now actually works)
%run server.py
# → http://localhost:8000  (or your Kaggle tunnel)
```

## 🖥 Dashboard usage on your laptop

1. Download `frontend/dashboard.html` from your GitHub repo (or the whole project).
2. Double-click → opens in browser → **all 20 tabs populated** from the embedded payload.
3. To switch pairs, enter your storage creds in the overlay, then use the
   "📂 View Saved Analyses" picker to load any pair's saved setup.
4. Or run `python server.py` for live 30-second auto-refresh.

## 📋 Files changed since WhiteDemon_V8.2

```
analyze.py           — full rewrite: now runs entire pipeline + extras + HTML embed
server.py            — TeeStdout accepts bytes, werkzeug.run_simple bypass
collect_all.py       — uses subprocess for analyze (cleaner)
frontend/dashboard.html — defensive readJson for non-object Firebase results
WHATS_NEW_WhiteDemon_V8.2.md   — this file
```
