"""
train_all.py — Train EVERYTHING and push to storage.

Trains LONG + SHORT committees + DL ensemble + 4 specialised NNs
on the configured pair/timeframe, then uploads each result as a
JSON blob to Firebase/GitHub so analyze.py and the dashboard can
read them back without retraining.

Run with:   python train_all.py
            python train_all.py --pair SOL-USD --tf 30m
"""
from __future__ import annotations
import os, sys, time, argparse, pickle, base64, gzip, json, datetime

import numpy as np
import pandas as pd

from core.gpu_setup import enable_gpu; enable_gpu(verbose=True)
from core.config import CFG, SYMBOL, TF_LABEL, PAIR, TF, apply_selection
from core.colors import RESET, BOLD, CYAN, GREEN, YELLOW, ORANGE
from core.storage import STORE

from data.fetcher_ccxt   import fetch_ohlcv_stitched_v23
from data.fetcher_sentiment import FinBERTSentiment, fetch_sentiment
from data.fetcher_derivatives import fetch_derivatives
from data.fetcher_macro  import fetch_macro_context, attach_macro_features

from indicators.basic     import calc_rsi, calc_atr, calc_vwap, calc_cvd, calc_macd
from indicators.structure import (zigzag, sr_from_zigzag, sr_from_rolling_pivots,
                                    sr_from_volume_profile, merge_all_sr,
                                    detect_bos_choch, mtf_trends, detect_market_regime)
from indicators.smc       import find_sd_zones, find_order_blocks, find_fvgs
from indicators.fibonacci import fibonacci
from indicators.hunting   import detect_stop_loss_hunting
from indicators.patterns  import pattern_scan

from ml_models.committee  import run_ml_committee


def _slim(cm: dict) -> dict:
    """Drop un-picklable model handles so the JSON serializes."""
    skip = {"models", "fitted", "scaler", "calibrator", "dl_models"}
    out = {}
    for k, v in (cm or {}).items():
        if k in skip:
            continue
        try:
            json.dumps(v, default=str)
            out[k] = v
        except Exception:
            try: out[k] = str(v)[:500]
            except Exception: pass
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--target", type=int, default=int(CFG.get("target_total_candles", 200_000)))
    ap.add_argument("--fast",   action="store_true", help="skip DL retrain (use cached if exists)")
    ap.add_argument("--force",  action="store_true", help="retrain even if cache exists")
    ap.add_argument("--skip-advanced", action="store_true",
                    help="skip Prophet + OFI + order book features (saves ~30s)")
    args = ap.parse_args()

    # Cache check
    from core.cache_manager import is_trained, get_cache_info
    if not args.force and is_trained(SYMBOL, TF_LABEL):
        info = get_cache_info(SYMBOL, TF_LABEL)
        print(f"\n{YELLOW}⚠️  Models for {SYMBOL} @ {TF_LABEL} already trained "
              f"({info.get('age_hours','?')}h ago).{RESET}")
        print(f"   Use {BOLD}--force{RESET} to retrain, or run analyze.py to refresh from cache.\n")
        return

    print(f"\n{BOLD}{CYAN}══ TRAIN ALL · {SYMBOL} @ {TF_LABEL} ══{RESET}\n")
    apply_selection(PAIR, TF)

    # ── 1. fetch + indicators + structure ─────────────────────────────
    print(f"{BOLD}[1/5] Fetching {args.target:,} stitched candles …{RESET}")
    df, src = fetch_ohlcv_stitched_v23(SYMBOL, TF_LABEL, args.target)
    print(f"  ✓ {len(df):,} candles from {src}\n")

    df["rsi"]   = calc_rsi(df["close"])
    df["atr"]   = calc_atr(df)
    df["vwap"]  = calc_vwap(df)
    df["cvd"]   = calc_cvd(df)
    _, _, df["macd_h"] = calc_macd(df["close"])

    try:
        end_dt = pd.Timestamp(df["open_time"].iloc[-1]).to_pydatetime()
        if end_dt.tzinfo: end_dt = end_dt.replace(tzinfo=None)
        span = (df["open_time"].iloc[-1] - df["open_time"].iloc[0]).days
        macro = fetch_macro_context(end_dt, days_back=max(60, span + 14))
        df = attach_macro_features(df, macro)
    except Exception as e:
        print(f"  {ORANGE}macro fetch failed (non-fatal): {e}{RESET}")
        df = attach_macro_features(df, pd.DataFrame())

    # ── 1b. NEW: blend advanced features ──────────────────────────────
    advanced_feats = {}
    if not args.skip_advanced:
        print(f"\n{BOLD}[1b/5] Computing advanced features (Prophet · OFI · OB · Funding · Liq) …{RESET}")
        try:
            from advanced.feature_blender import blend_advanced_features
            t0 = time.time()
            advanced_feats = blend_advanced_features(df, SYMBOL, skip_live=False)
            print(f"  ✓ {len(advanced_feats)} advanced features in {time.time()-t0:.1f}s")
            for k in ("prophet_forecast_24h_pct", "ofi_z", "ob_imbalance",
                       "funding_8ex_avg", "liq_imbalance"):
                if k in advanced_feats:
                    print(f"     {k:<28} {advanced_feats[k]}")
        except Exception as e:
            print(f"  {ORANGE}advanced features failed (non-fatal): {e}{RESET}")

    CFG["trade_window"] = 2000
    train_cutoff = len(df) - CFG["trade_window"]
    if train_cutoff < 5000:
        train_cutoff = int(len(df) * 0.85)
        CFG["trade_window"] = len(df) - train_cutoff
    print(f"  data split: train={train_cutoff:,}  analysis={CFG['trade_window']:,}\n")

    nlp   = fetch_sentiment(FinBERTSentiment())
    deriv = fetch_derivatives()
    regime_info = detect_market_regime(df)
    CFG["_current_regime"] = regime_info.get("regime", "RANGING")
    print(f"  regime={regime_info['regime']}  sentiment={nlp['sentiment']} ({nlp['score']:+.2f})\n")

    # Pre-compute structure on analysis window
    tdf = df.tail(CFG["trade_window"]).copy().reset_index(drop=True)
    pivots_zz, _, _ = zigzag(tdf.tail(CFG["zz_lookback"]), CFG["zz_dev_pct"])
    sr_levels = merge_all_sr(
        sr_from_zigzag(pivots_zz, CFG["sr_tol_pct"]),
        sr_from_rolling_pivots(tdf),
        sr_from_volume_profile(tdf),
        float(df["close"].iloc[-1]), tol_pct=0.3)
    demand_zones, supply_zones = find_sd_zones(tdf)
    bull_obs, bear_obs = find_order_blocks(tdf)
    fvgs    = find_fvgs(tdf)
    bos     = detect_bos_choch(tdf, [{**p, "idx": p["idx"]} for p in pivots_zz])
    hunting = detect_stop_loss_hunting(tdf, sr_levels)
    fib     = fibonacci(tdf)
    ltf, h1, h4, _ = mtf_trends(df)
    patterns = pattern_scan(df, train_cutoff)

    # ── 2. Train LONG + SHORT committees in parallel ──────────────────
    print(f"{BOLD}[2/5] Training LONG + SHORT committees (parallel) …{RESET}")
    from concurrent.futures import ThreadPoolExecutor
    t0 = time.time()
    with ThreadPoolExecutor(max_workers=2) as ex:
        fut_long  = ex.submit(run_ml_committee, df, nlp["score"], train_cutoff,
                                None, "LONG")
        fut_short = ex.submit(run_ml_committee, df, nlp["score"], train_cutoff,
                                None, "SHORT")
        cm_long  = fut_long.result()
        cm_short = fut_short.result()
    print(f"  ✓ done in {time.time()-t0:.0f}s  "
          f"P(LONG)={cm_long['stack_bull']*100:.1f}%  "
          f"P(SHORT)={cm_short['stack_bull']*100:.1f}%\n")

    # ── 3. Push everything to storage ─────────────────────────────────
    rid = f"{SYMBOL.replace('-','_')}_{TF_LABEL}"
    print(f"{BOLD}[3/5] Saving to storage backend = {STORE.backend_name} …{RESET}")
    STORE.put_json(f"long_{rid}",  {"result": _slim(cm_long)},  message=f"train long {rid}")
    STORE.put_json(f"short_{rid}", {"result": _slim(cm_short)}, message=f"train short {rid}")

    # Save full raw data bundle as a blob for analyze.py to reuse
    raw_blob = pickle.dumps({
        "df": df, "train_cutoff": train_cutoff,
        "nlp": nlp, "deriv": deriv, "regime_info": regime_info,
        "sr_levels": sr_levels, "demand_zones": demand_zones,
        "supply_zones": supply_zones, "bull_obs": bull_obs,
        "bear_obs": bear_obs, "fvgs": fvgs, "bos": bos, "hunting": hunting,
        "fib": fib,
        "mtf":      [ltf, h1, h4],            # list form for engine
        "mtf_dict": {"ltf": ltf, "h1": h1, "h4": h4},   # dict form for HTML
        "patterns": patterns,
    })
    STORE.put_blob(f"raw_{rid}.pkl", raw_blob, message=f"raw data {rid}")

    # ── 4. Build final dashboard JSON ─────────────────────────────────
    print(f"{BOLD}[4/5] Building dashboard payload …{RESET}")
    from strategy.setup_builder import build_setup
    from strategy.tp_sl_prob    import calculate_tp_sl_probability
    from strategy.confluence    import compute_confluence_score, decide_trade
    from strategy.forecast      import algo_forecast_next_n, predict_next_candle
    from strategy.reasoning     import build_trade_reasoning

    price = float(df["close"].iloc[-1])
    atr_val = float(df["atr"].iloc[-1])
    p_l = float(cm_long.get("stack_bull",  0.5))
    p_s = float(cm_short.get("stack_bull", 0.5))
    direction = "LONG" if p_l >= p_s else "SHORT"
    committee = cm_long if direction == "LONG" else cm_short

    setup = build_setup(direction, price, sr_levels, demand_zones, supply_zones, atr_val)
    if not setup["valid"]:
        alt = "SHORT" if direction == "LONG" else "LONG"
        alt_setup = build_setup(alt, price, sr_levels, demand_zones, supply_zones, atr_val)
        if alt_setup["valid"]:
            setup, direction = alt_setup, alt
    tp_sl_prob = calculate_tp_sl_probability(df, setup, train_cutoff)

    ctx = {
        "symbol": SYMBOL, "name": PAIR["name"], "tf_label": TF_LABEL,
        "price": price, "n_total": len(df), "train_cutoff": train_cutoff,
        "trade_window": CFG["trade_window"],
        "newest": str(df["open_time"].iloc[-1]),
        "oldest": str(df["open_time"].iloc[0]),
        "advanced_features": advanced_feats,
        "nlp": nlp, "deriv": deriv, "direction": direction,
        "setup": setup, "tp_sl_prob": tp_sl_prob,
        "committee": committee, "cm_long": _slim(cm_long), "cm_short": _slim(cm_short),
        "tb_models": {"long_win_prob": p_l, "short_win_prob": p_s,
                       "historical_long_winrate":  cm_long.get("baseline_win_rate", 0.5),
                       "historical_short_winrate": cm_short.get("baseline_win_rate", 0.5)},
        "regime": regime_info.get("regime"), "regime_info": regime_info,
        "monte_carlo": {"available": False},
        "mtf":      [ltf, h1, h4],
        "mtf_dict": {"ltf": ltf, "h1": h1, "h4": h4},
        "patterns": patterns,
        "order_blocks": {"bull": bull_obs, "bear": bear_obs},
        "supply_zones": supply_zones, "demand_zones": demand_zones,
        "fvgs": fvgs, "fib_lvls": fib, "hunting": hunting, "bos": bos,
        "sr_levels": sr_levels,
        "algo_forecast": algo_forecast_next_n(df, n=10, atr_value=atr_val),
        "pred_next": predict_next_candle(df, nlp["score"], train_cutoff),
        "elapsed": 0.0,
        "backtest_results": {"available": False},
    }
    decision = decide_trade(ctx)
    ctx["decision"] = decision
    try: ctx["reasoning"] = build_trade_reasoning(ctx, decision)
    except Exception: ctx["reasoning"] = {}

    # Save dashboard data
    dashboard = {"ctx": _slim(ctx), "decision": decision,
                  "saved_at": datetime.datetime.utcnow().isoformat() + "Z"}
    STORE.put_json("dashboard_data", dashboard, message=f"dashboard refresh {rid}")
    STORE.put_json(f"final_{rid}", {
        "symbol": SYMBOL, "tf_label": TF_LABEL, "price": price,
        "direction": direction, "verdict": decision.get("verdict"),
        "verdict_text": decision.get("verdict_text"),
        "confluence": decision.get("chosen_score"),
        "win_prob": decision.get("chosen_win_prob"),
        "long_conviction": p_l, "short_conviction": p_s,
        "setup": setup, "tp_sl_prob": tp_sl_prob,
        "vetoes": decision.get("chosen_vetoes", []),
    }, message=f"final {rid}")
    # Local copies too
    with open("dashboard_data.json", "w") as f:
        json.dump(dashboard, f, default=str, indent=2)

    print(f"\n{GREEN}{BOLD}✅ TRAIN ALL DONE  ·  VERDICT = {decision.get('verdict')}  ·  "
          f"{direction} @ {decision.get('chosen_score',0)*100:.0f}% confluence{RESET}\n")


if __name__ == "__main__":
    main()
