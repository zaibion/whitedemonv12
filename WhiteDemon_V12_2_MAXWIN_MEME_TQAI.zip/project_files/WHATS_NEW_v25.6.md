# Crypto Suite WhiteDemon_V8.2 — What's New

## Big changes (per user request, 2026-06-21)

### 1. Fully re-structured 10-menu system
Old menu (15+ confusing options) → REMOVED. New menu:

| # | Menu | What it does |
|---|------|--------------|
| 1 | TRAIN / RESUME (current pair) | Shows "TRAIN" if fresh, "RESUME" if mid-job. Trains ALL models step-by-step, saves each to storage. **Sub-menu appears ONLY when all models are trained**: [1] Re-train all from scratch, [2] FAST MODE (4k live candles, use saved models, show setup, optionally train missing). |
| 2 | CHANGE pair & timeframe | Lists **100+ pairs**, picks pair+TF, **probes availability** (CCXT exchanges first → Yahoo fallback → warns if neither has data). Forwards back to main menu where user picks Train/Resume. |
| 3 | TRAIN BIT-BY-BIT | Submenu: [1] specific candle count, [2] train NEXT batch (going further back from previous batch), [3] resume a previous batch, [4] WIPE incremental. Shows previously trained batches. |
| 4 | TRAIN SPECIFIC MODELS | Big submenu with: train CLASSICAL (long+short), train ALL DL (long+short), train LONG/SHORT only, train NEURAL nets, train EXTRAS (Monte Carlo / Triple-Barrier / Meta-labeler / Prophet), pick-and-mix specific. **Also contains the RUN COMPLETE ANALYSIS sub-sub-menu**: start, start-again, FAST mode (no training), analysis-only-on-trained. **WIPE ALL / WIPE SOME** at bottom. |
| 5 | BACKTEST | Submenu: [1] specific model + specific candles, [2] all models / pick years, [3] **BIT-BY-BIT (10 steps)** — each step runs in its own Colab/Kaggle cell and saves progress to storage; [4] wipe backtest data. |
| 6 | WIPE EVERYTHING | **Triple-safety**: y/N → y/N AGAIN → type DELETE (uppercase). Wipes ALL pairs/TFs from storage. |
| 7 | LIVE DASHBOARD | Builds dashboard HTML from latest analyses, pushes to storage, optionally starts local server. |
| 8 | SHOW ALL TRAINED PAIRS | Lists every pair/TF in storage, shows complete vs partial + # missing. Pick one → switches pair → trains missing (optional) → runs analysis on 4k live candles. |
| 9 | TEST / CHANGE backends | Pings Firebase + Supabase + GitHub round-trip. Option to re-run setup. GPU/CUDA check. |
| 10 | EXIT (save all) | Clean exit. |

### 2. Supabase added as second storage backend
- **Chain order**: Firebase → **Supabase** → GitHub.
- **WRITES go to ALL configured backends** — so GitHub remains canonical backup.
- **READS try in priority order**, first hit wins (Firebase fastest reads).
- New file `db/supabase_schema.sql` — paste into Supabase SQL Editor, creates:
  - `public.kv_json` table with proper RLS policies (anon r/w).
  - `cryptosuite` storage bucket with anon r/w policies.
- Setup prompts for `SUPABASE_URL` + `SUPABASE_KEY` + bucket name; tests connectivity by hitting `/rest/v1/kv_json?limit=1`.

### 3. Firebase permission-denied — root cause + fix
- Setup now **prints the EXACT JSON rules** you need to paste into Realtime DB Rules and Storage Rules, with direct URLs to the rules pages.
- Storage backend smoke-tests Firebase on init — fails FAST if rules block writes (so you don't see vague errors mid-training).

### 4. LLM providers — focus on free / supported ones
- Setup now prompts in this order: **OpenRouter** (sk-or-v1-…) → **Mistral** (Magistral / mistral-large-latest) → **Groq** (gsk_…), then OpenAI/Anthropic/Gemini/DeepSeek.
- New `call_llm(prompt)` helper in `core/llm_keys.py` — tries providers in order until one works.
- **Groq models verified as supported (2026-06)**: `llama-3.3-70b-versatile`, `llama-3.1-8b-instant`, `mixtral-8x7b-32768`, `gemma2-9b-it`. (Spelled GROQ, NOT Grok — different company.)

### 5. 100+ trading pairs (CCXT-backed)
- `core/pairs_ext.py` adds **89 extra pairs** (id 19 → 107): UNI, AAVE, ALGO, FIL, ICP, VET, SAND, MANA, AXS, FTM, GRT, EGLD, HBAR, FLOW, XLM, XTZ, EOS, MKR, COMP, SUSHI, CRV, YFI, SNX, 1INCH, DYDX, GMX, RUNE, INJ, SUI, APT, SEI, TIA, STRK, JTO, PYTH, JUP, WLD, ORDI, ENS, LDO, RPL, STX, PEPE, WIF, BONK, FLOKI, BOME, XMR, ZEC, DASH, BCH, ETC, BSV, QNT, RNDR, FET, AGIX, OCEAN, IMX, GALA, CHZ, ENJ, BAT, ZIL, IOTA, NEO, WAVES, KSM, ROSE, ZRX, ANKR, BAND, REN, STORJ, OMG, KAVA, CELO, GLMR, ASTR, ID, BLUR, ARKM, MEME, DOGS, NOT, HMSTR, TON, KAS, RAY.
- Menu 2 has **availability probe**: tries Binance/Bybit/OKX/KuCoin via CCXT → falls back to Yahoo → if both fail, asks user to pick another pair.

### 6. Bug fixes & polish
- Removed all references to confusing old 15+ option menu.
- All `input()` calls protected with try/except for EOFError (Kaggle stdin).
- Backtest now accepts `--bbb-step stepN` flag for multi-cell parallel backtesting.
- "Wipe per pair" never touches GitHub backup of OTHER pairs.
- LLM provider chain: OpenRouter → Mistral → Groq → OpenAI → Anthropic → Gemini → DeepSeek. Silently falls through if one fails.

---

## ⚠ Migration notes

Your **GitHub training data is untouched** — WhiteDemon_V8.2 reads existing checkpoints exactly like WhiteDemon_V8.2. The only NEW thing is that writes now ALSO go to Supabase (if configured).

If you only want GitHub: leave `SUPABASE_URL` blank in setup, leave Firebase fields blank — the chain just collapses to `[github]`.

---

## How to run on Kaggle (no change from WhiteDemon_V8.2)

```python
# Cell 1 — first time only
!cp /kaggle/input/cryptosuite/crypto-suite-WhiteDemon_V8.2.zip /kaggle/working/
%cd /kaggle/working
!unzip -o crypto-suite-WhiteDemon_V8.2.zip
%cd crypto-v23
%run setup.py     # ← asks Firebase + Supabase + GitHub + LLM keys + pair

# Cell 2 — every session
%cd /kaggle/working/crypto-v23
%run run.py       # ← shows the new 10-menu
```
