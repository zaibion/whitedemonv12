"""
setup.py — Bootstrap on first run (Firebase + Supabase + GitHub + LLM keys).

  python setup.py

WhiteDemon_V8.2 changes:
  • Adds Supabase (URL + KEY + bucket) — save chain is FB → Supabase → GitHub
  • Adds OpenRouter + Mistral + Groq prompts with the EXACT supported model names
  • Prints the EXACT Firebase Rules JSON to paste (fixes Permission Denied)
  • Asks once, writes to .setup_state.json (all paths) AND legacy config.py
"""
import os, sys, requests, json

CONFIG_PATH = "config.py"

try:
    from core.colors import RESET, BOLD, CYAN, GREEN, RED, YELLOW, ORANGE, GREY
except Exception:
    RESET=BOLD=CYAN=GREEN=RED=YELLOW=ORANGE=GREY=""

def hr():    print(CYAN + "─" * 64 + RESET)
def title(t):print(f"\n{BOLD}{CYAN}{t}{RESET}")
def ok(t):   print(f"  {GREEN}✓{RESET} {t}")
def bad(t):  print(f"  {RED}✗{RESET} {t}")
def info(t): print(f"  {GREY}{t}{RESET}")

print()
hr()
print(f"  {BOLD}{CYAN}⚡ CRYPTO SUITE WhiteDemon_V8.2 — Interactive Setup{RESET}")
hr()

# ── Existing setup state? ───────────────────────────────────────────────
_STATE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".setup_state.json")
_existing_state = None
if os.path.exists(_STATE_PATH):
    try:
        with open(_STATE_PATH) as _f:
            _existing_state = json.load(_f)
    except Exception:
        _existing_state = None

if _existing_state:
    print(f"\n  ℹ️  Existing setup found "
          f"({_existing_state.get('TARGET_CANDLES',0):,} candles · "
          f"PAIR_ID={_existing_state.get('PAIR_ID')} TF_ID={_existing_state.get('TF_ID')})")
    print(f"     [k] keep existing  |  [Enter] re-run setup")
    try:
        ans = input(f"     > ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        ans = "k"
    if ans == "k":
        print(f"\n  Keeping existing settings.")
        print(f"  Run:  {BOLD}python run.py{RESET}\n")
        sys.exit(0)
elif os.path.exists(CONFIG_PATH):
    print(f"\n  ℹ️  Old {CONFIG_PATH} found (legacy) — will be replaced.")


def _ask(prompt: str, default: str = "") -> str:
    try:
        v = input(prompt).strip()
        return v if v else default
    except (EOFError, KeyboardInterrupt):
        return default


# ════════════════════════════════════════════════════════════════════════
# 1. FIREBASE (Web SDK) — PRIMARY
# ════════════════════════════════════════════════════════════════════════
title("STEP 1 — Firebase Web SDK (PRIMARY storage)")
print(f"""
  Firebase saves checkpoints, dashboard JSON and small per-model indexes.

  Get keys (2 min):
    1. https://console.firebase.google.com/project/_/settings/general
    2. Scroll to "Your apps" → click the </> (Web) app
    3. Copy the "firebaseConfig {{ … }}" block

  ⚠ {BOLD}{RED}PERMISSION-DENIED FIX (paste these EXACT rules){RESET}:

    Realtime DB Rules
      → https://console.firebase.google.com/project/_/database/_default-rtdb/rules
      → Paste this and click PUBLISH:

        {{
          "rules": {{
            ".read": true,
            ".write": true
          }}
        }}

    Storage Rules
      → https://console.firebase.google.com/project/_/storage/_/rules
      → Paste this and click PUBLISH:

        rules_version = '2';
        service firebase.storage {{
          match /b/{{bucket}}/o {{
            match /{{allPaths=**}} {{
              allow read, write: if true;
            }}
          }}
        }}

  Leave any field empty to skip Firebase.
""")

fb_api    = _ask(f"  {BOLD}apiKey{RESET}              (AIzaSy…): ")
fb_proj = fb_auth = fb_dburl = fb_bucket = fb_app = fb_msg = fb_creds = ""

if fb_api:
    fb_proj    = _ask(f"  {BOLD}projectId{RESET}           (e.g. gen-lang-client-0703468344): ")
    default_auth   = f"{fb_proj}.firebaseapp.com" if fb_proj else ""
    default_db     = f"https://{fb_proj}-default-rtdb.firebaseio.com" if fb_proj else ""
    default_bucket = f"{fb_proj}.firebasestorage.app" if fb_proj else ""
    fb_auth   = _ask(f"  {BOLD}authDomain{RESET}          [default {default_auth}]: ", default_auth)
    fb_dburl  = _ask(f"  {BOLD}databaseURL{RESET}         [default {default_db}]: ",   default_db)
    fb_bucket = _ask(f"  {BOLD}storageBucket{RESET}       [default {default_bucket}]: ", default_bucket)
    fb_app    = _ask(f"  {BOLD}appId{RESET}               (can be blank): ")
    fb_msg    = _ask(f"  {BOLD}messagingSenderId{RESET}   (can be blank): ")

    print(f"\n  Testing Firebase Web SDK …")
    try:
        import pyrebase
        cfg = {
            "apiKey": fb_api, "authDomain": fb_auth, "databaseURL": fb_dburl,
            "storageBucket": fb_bucket, "projectId": fb_proj,
            "appId": fb_app, "messagingSenderId": fb_msg,
            "serviceAccount": None,
        }
        _app = pyrebase.initialize_app(cfg)
        _db  = _app.database()
        _db.child("_setup_ping").set({"ok": True, "ts": "setup.py"})
        ok(f"Firebase RTDB reachable ({fb_dburl})")
    except ImportError:
        print(f"  {ORANGE}⚠ pyrebase4 not installed — run: pip install pyrebase4{RESET}")
    except Exception as e:
        msg = str(e)[:200]
        bad(f"Firebase test failed: {msg}")
        if "permission" in msg.lower() or "401" in msg or "denied" in msg.lower():
            print(f"     {YELLOW}→ This means rules block writes. Paste the rules JSON shown above and click PUBLISH.{RESET}")
        if _ask("\n     Save anyway? [y/N]: ").lower() != "y":
            fb_api = fb_auth = fb_dburl = fb_bucket = fb_proj = fb_app = fb_msg = ""
            print(f"     {YELLOW}Firebase skipped.{RESET}")
else:
    info("Firebase skipped.")


# ════════════════════════════════════════════════════════════════════════
# 2. SUPABASE (secondary, SQL-backed)
# ════════════════════════════════════════════════════════════════════════
title("STEP 2 — Supabase (secondary storage)")
print(f"""
  Supabase = Postgres + Storage. Used as 2nd backup of checkpoints + JSONs.

  Get keys (1 min):
    1. https://supabase.com/dashboard/project/_/settings/api
    2. Copy {BOLD}Project URL{RESET}  (https://xxxxx.supabase.co)
    3. Copy the {BOLD}service_role{RESET} key (preferred — works through RLS)
       OR the anon/public key (fine if you ran the SQL with anon policies)

  {BOLD}{RED}BEFORE saving keys you MUST run the SQL{RESET}:
    Dashboard → SQL Editor → New query → paste the file
       {GREEN}db/supabase_schema.sql{RESET}  (included in this project)
    → Run.  Creates `kv_json` table + `cryptosuite` storage bucket + RLS.

  Leave URL blank to skip Supabase.
""")
sb_url    = _ask(f"  {BOLD}SUPABASE_URL{RESET}    (https://xxxxx.supabase.co): ")
sb_key    = ""
sb_bucket = "cryptosuite"
if sb_url:
    sb_key    = _ask(f"  {BOLD}SUPABASE_KEY{RESET}    (service_role recommended): ")
    sb_bucket = _ask(f"  {BOLD}SUPABASE_BUCKET{RESET} [default cryptosuite]: ", "cryptosuite")
    if sb_key:
        print(f"\n  Testing Supabase …")
        try:
            r = requests.get(f"{sb_url.rstrip('/')}/rest/v1/kv_json?select=key&limit=1",
                             headers={"apikey": sb_key, "Authorization": f"Bearer {sb_key}"},
                             timeout=15)
            if r.status_code == 200:
                ok(f"Supabase kv_json reachable")
            elif r.status_code == 404:
                bad("kv_json table not found — paste db/supabase_schema.sql in SQL Editor first")
            else:
                bad(f"HTTP {r.status_code}: {r.text[:200]}")
        except Exception as e:
            bad(f"Supabase test failed: {str(e)[:200]}")
else:
    info("Supabase skipped.")


# ════════════════════════════════════════════════════════════════════════
# 3. GITHUB
# ════════════════════════════════════════════════════════════════════════
title("STEP 3 — GitHub (canonical backup, recommended ALWAYS)")
print(f"""
  GitHub holds the canonical copy. NEVER wiped unless you click Menu 6
  WIPE ALL twice + type DELETE.

  Get token:  https://github.com/settings/tokens  → 'repo' scope → ghp_…
""")

gh_token = _ask(f"  {BOLD}GITHUB_TOKEN{RESET} (ghp_…): ")
gh_repo = gh_branch = ""
if gh_token:
    gh_repo   = _ask(f"  {BOLD}GITHUB_REPO{RESET} (owner/repo, NO .git): ")
    gh_branch = _ask(f"  {BOLD}GITHUB_BRANCH{RESET} [default main]: ", "main")
    print(f"\n  Testing GitHub access …")
    try:
        r = requests.get(f"https://api.github.com/repos/{gh_repo}",
                         headers={"Authorization": f"Bearer {gh_token}"}, timeout=15)
        if r.status_code == 200:
            ok(f"GitHub repo '{gh_repo}' accessible")
        elif r.status_code == 401:
            bad("Token rejected — regenerate at https://github.com/settings/tokens")
        elif r.status_code == 404:
            bad("Repo not found — check name or create at https://github.com/new")
        else:
            bad(f"HTTP {r.status_code}: {r.text[:200]}")
    except Exception as e:
        bad(f"GitHub test failed: {e}")
else:
    info("GitHub skipped (NOT RECOMMENDED — you lose canonical backup).")


# ════════════════════════════════════════════════════════════════════════
# 4. Trading pair / timeframe
# ════════════════════════════════════════════════════════════════════════
title("STEP 4 — What to trade")
print(f"""
  PAIRS (built-in 1-18, extra 19-107 require ccxt + Binance/Bybit access):
       1=BTC   2=ETH   3=SOL   4=BNB   5=XRP   6=LTC   7=ADA   8=DOGE
       9=AVAX 10=DOT  11=MATIC 12=LINK 13=TRX 14=ATOM 15=NEAR
      16=ARB  17=OP   18=SHIB ... up to 107 (run 'python run.py' → Menu 2 to browse)
  TFs:  1=1m   2=3m   3=5m   4=15m   5=30m   6=1h   7=4h   8=1d
""")
pid    = _ask(f"  {BOLD}PAIR_ID{RESET} [default 7 = ADA]: ", "7")
tid    = _ask(f"  {BOLD}TF_ID{RESET}   [default 4 = 15m]: ", "4")
target = _ask(f"  {BOLD}TARGET_CANDLES{RESET} [default 100000]: ", "100000")
fast   = _ask(f"  {BOLD}FAST_CANDLES{RESET} for refresh [default 4000]: ", "4000")

# WhiteDemon_V8.2 — Smart-SL aggressiveness
print(f"\n  {BOLD}Smart-SL aggressiveness{RESET} (helps avoid stop-loss hunts):")
print(f"    [1] conservative   +0.5×ATR buffer, lighter widening")
print(f"    [2] balanced       +1.0×ATR + wick + volume profile + liq clusters (RECOMMENDED)")
print(f"    [3] aggressive     +1.5×ATR + Bayesian SL NN if trained")
print(f"    [4] off            use raw engine SL (NOT recommended on 15m crypto)")
_sl_choice = _ask(f"  Pick [1-4, default 2]: ", "2")
SL_MAP = {"1":"conservative", "2":"balanced", "3":"aggressive", "4":"off"}
sl_aggro = SL_MAP.get(_sl_choice, "balanced")
print(f"     → smart_sl_aggressiveness = {sl_aggro}")


# ════════════════════════════════════════════════════════════════════════
# 5. LLM API KEYS (OpenRouter + Mistral + Groq emphasized)
# ════════════════════════════════════════════════════════════════════════
title("STEP 5 — LLM API keys (all optional)")
print(f"""
  Used for sentiment / reasoning enhancements during analysis.

  {BOLD}{GREEN}RECOMMENDED FREE PROVIDERS{RESET}:
    • {BOLD}OpenRouter{RESET}  https://openrouter.ai/keys   (sk-or-v1-…)
        - many free models: 'mistralai/mistral-7b-instruct:free',
                            'meta-llama/llama-3.3-70b-instruct:free'
    • {BOLD}Mistral{RESET}     https://console.mistral.ai/  (Magistral, Mistral Large)
        - models: 'mistral-large-latest', 'magistral-medium-latest',
                  'mistral-small-latest', 'open-mistral-7b'
    • {BOLD}Groq{RESET}        https://console.groq.com/keys (gsk_…)
        - SUPPORTED models (verified 2026-06): 'llama-3.3-70b-versatile',
                                'llama-3.1-8b-instant',
                                'mixtral-8x7b-32768',
                                'gemma2-9b-it'
""")
openrouter_key= _ask(f"  {BOLD}OPENROUTER_API_KEY{RESET}  (sk-or-v1-…, Enter skip): ")
mistral_key   = _ask(f"  {BOLD}MISTRAL_API_KEY{RESET}     (Enter skip): ")
groq_key      = _ask(f"  {BOLD}GROQ_API_KEY{RESET}        (gsk_…, Enter skip): ")
openai_key    = _ask(f"  {BOLD}OPENAI_API_KEY{RESET}      (sk-…, Enter skip): ")
anthropic_key = _ask(f"  {BOLD}ANTHROPIC_API_KEY{RESET}   (sk-ant-…, Enter skip): ")
gemini_key    = _ask(f"  {BOLD}GEMINI_API_KEY{RESET}      (AIza…, Enter skip): ")
deepseek_key  = _ask(f"  {BOLD}DEEPSEEK_API_KEY{RESET}    (sk-…, Enter skip): ")


# ════════════════════════════════════════════════════════════════════════
# 6. WRITE config.py + .setup_state.json (to 6 paths)
# ════════════════════════════════════════════════════════════════════════
config = f'''"""auto-generated by setup.py — edit carefully or re-run setup.py"""

# ─── What to trade ─────────────────────────────────
PAIR_ID = {pid}
TF_ID   = {tid}
TARGET_CANDLES = {target}
FAST_CANDLES   = {fast}

# ─── Firebase Web SDK (PRIMARY — leave blank to skip) ─
FIREBASE_API_KEY              = "{fb_api}"
FIREBASE_AUTH_DOMAIN          = "{fb_auth}"
FIREBASE_DATABASE_URL         = "{fb_dburl}"
FIREBASE_STORAGE_BUCKET       = "{fb_bucket}"
FIREBASE_PROJECT_ID           = "{fb_proj}"
FIREBASE_APP_ID               = "{fb_app}"
FIREBASE_MESSAGING_SENDER_ID  = "{fb_msg}"
FIREBASE_CREDENTIALS = "{fb_creds}"
FIREBASE_BUCKET      = "{fb_bucket}"

# ─── Supabase (SECONDARY) ──
SUPABASE_URL    = "{sb_url}"
SUPABASE_KEY    = "{sb_key}"
SUPABASE_BUCKET = "{sb_bucket}"

# ─── GitHub (CANONICAL) ──
GITHUB_TOKEN  = "{gh_token}"
GITHUB_REPO   = "{gh_repo}"
GITHUB_BRANCH = "{gh_branch or 'main'}"

# ─── LLM API keys ──
OPENROUTER_API_KEY = "{openrouter_key}"
MISTRAL_API_KEY    = "{mistral_key}"
GROQ_API_KEY       = "{groq_key}"
OPENAI_API_KEY     = "{openai_key}"
ANTHROPIC_API_KEY  = "{anthropic_key}"
GEMINI_API_KEY     = "{gemini_key}"
DEEPSEEK_API_KEY   = "{deepseek_key}"
TOGETHER_API_KEY   = ""
HUGGINGFACE_API_KEY = ""
'''

_project_root = os.path.dirname(os.path.abspath(__file__))
_state_dict = {
    "PAIR_ID":        int(pid or 1),
    "TF_ID":          int(tid or 4),
    "TARGET_CANDLES": int(target or 100000),
    "smart_sl_aggressiveness": sl_aggro,
    "FAST_CANDLES":   int(fast or 4000),
    "FIREBASE_API_KEY":             fb_api,
    "FIREBASE_AUTH_DOMAIN":         fb_auth,
    "FIREBASE_DATABASE_URL":        fb_dburl,
    "FIREBASE_STORAGE_BUCKET":      fb_bucket,
    "FIREBASE_PROJECT_ID":          fb_proj,
    "FIREBASE_APP_ID":              fb_app,
    "FIREBASE_MESSAGING_SENDER_ID": fb_msg,
    "FIREBASE_CREDENTIALS":         fb_creds,
    "FIREBASE_BUCKET":              fb_bucket,
    "SUPABASE_URL":                 sb_url,
    "SUPABASE_KEY":                 sb_key,
    "SUPABASE_BUCKET":              sb_bucket,
    "GITHUB_TOKEN":                 gh_token,
    "GITHUB_REPO":                  gh_repo,
    "GITHUB_BRANCH":                gh_branch or "main",
    "OPENROUTER_API_KEY":           openrouter_key,
    "MISTRAL_API_KEY":              mistral_key,
    "GROQ_API_KEY":                 groq_key,
    "OPENAI_API_KEY":               openai_key,
    "ANTHROPIC_API_KEY":            anthropic_key,
    "GEMINI_API_KEY":               gemini_key,
    "DEEPSEEK_API_KEY":             deepseek_key,
}
_paths_written = []
for _dir in (_project_root, os.getcwd(),
             "/kaggle/working/crypto-v23", "/kaggle/working",
             "/content/crypto-v23", "/content"):
    if not os.path.isdir(_dir):
        continue
    try:
        with open(os.path.join(_dir, ".setup_state.json"), "w") as f:
            json.dump(_state_dict, f, indent=2)
        _paths_written.append(os.path.join(_dir, ".setup_state.json"))
    except Exception: pass
    try:
        with open(os.path.join(_dir, CONFIG_PATH), "w") as f:
            f.write(config)
        _paths_written.append(os.path.join(_dir, CONFIG_PATH))
    except Exception: pass

for _p in _paths_written:
    ok(f"saved → {_p}")

print()
hr()
print(f"\n  {GREEN}{BOLD}✅ Setup complete.{RESET}\n")
print(f"  Active storage chain:")
if fb_api:  print(f"     1. Firebase  ({fb_proj or '—'})")
if sb_url:  print(f"     2. Supabase  ({sb_url})")
if gh_token: print(f"     3. GitHub    ({gh_repo})  ← canonical backup")
if not (fb_api or sb_url or gh_token):
    print(f"     {RED}NONE — checkpoints won't survive restart!{RESET}")
print(f"\n  Next:  {BOLD}python run.py{RESET}\n")
hr()
print()
