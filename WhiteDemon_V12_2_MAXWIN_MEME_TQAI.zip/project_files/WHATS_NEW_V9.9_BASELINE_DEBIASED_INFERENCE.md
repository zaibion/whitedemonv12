# WhiteDemon V9.9 — Baseline-Debiased Live Inference

## Problem addressed
A model trained in a long-heavy period can learn a high LONG baseline and keep saying LONG even when current market conditions are not actually better than that baseline.

Example:
- historical LONG baseline = 60%
- live LONG model probability = 57%

Raw 57% looks bullish, but it is actually **below** that model's own training baseline.

## New logic
The system now compares live probability against the model's training baseline:

```text
live_edge_over_baseline = live_probability - baseline_win_rate
```

A setup must now beat its own historical baseline by default:

```text
live edge over baseline >= +3%
```

This means models use previous training as reference, but they must still prove that today's 4k-candle conditions are actually better than their baseline.

## Direction selection improved
Committee direction and committee stack vote are now based on:

```text
LONG edge over LONG baseline
vs
SHORT edge over SHORT baseline
```

not only raw LONG/SHORT probabilities.

## Output now shows

```text
selected committee win-prob=56.9% · baseline=60.0% · live edge over baseline=-3.1%
```

This makes it clear if a model is only repeating its training bias.

## Why this helps
It reduces cases where models say LONG/SHORT simply because training data had more wins on that side. The live setup must be better than the model's own historical baseline.

## Checks
- compileall passed
- tabnanny passed
- pyflakes syntax/undefined-name scan passed
