# WhiteDemon V10.8 — Smart Analysis Recommended

## Decision
The best default mode is **Smart Analysis**.

## Why

### Full Pipeline
Good for training/refreshing missing components, but slower and can use legacy paths.

### Fast Mode
Good for quick cached inference when everything is already trained/bundled, but weaker if cache/bundles are incomplete.

### Smart Analysis
Best default because it combines both:

1. checks cache/model/bundle status
2. trains only missing pieces if needed
3. skips already trained models
4. runs the unified `analyze.py` final analyzer

## Menu added
Menu 4 → 8 now has:

```text
[1] FULL PIPELINE
[2] FULL PIPELINE AGAIN
[3] FAST MODE
[4] CACHE-ONLY ANALYZE
[5] SMART ANALYSIS  (RECOMMENDED)
```

## Recommendation
For live trading preparation, use:

```text
Menu 4 → 8 → 5 Smart Analysis
```

Only use Full Pipeline when intentionally retraining/rebuilding.
Only use Fast Mode when you are sure models and bundles are complete.

## Direct command

```bash
python run.py --pair SOL-USDT --tf 15m fast
```

The direct `fast` command uses Smart Analysis.

## Checks
- compileall passed
- tabnanny passed
- pyflakes syntax/undefined-name scan passed
