"""
ensure_nns.py — WhiteDemon_V8.2

Train ONLY the missing pipeline-extras (neural NNs + SL placement NN +
triple-barrier flag + meta-labeler flag) WITHOUT re-running the committee
training loop.

Why this exists:
  full_pipeline.py used to call train_with_checkpoint which re-entered the
  whole committee training when ANY stage was undone — caused 30+ min hangs
  even on fully-trained pairs.

  This script trains JUST the missing extras directly + marks checkpoint
  stages done. Safe to run repeatedly — skips anything that's already done.

Run:  python ensure_nns.py
"""
from __future__ import annotations
import os, sys, time, traceback

from core.gpu_setup import enable_gpu; enable_gpu(verbose=True)
from core.config  import CFG, SYMBOL, TF_LABEL, PAIR, TF, apply_selection
from core.colors  import RESET, BOLD, CYAN, GREEN, YELLOW, RED, GREY
from core.storage import STORE
from core         import checkpoint as ck_mod
from core         import per_model_cache as pmc

apply_selection(PAIR, TF)


def _step(label, char="━"):
    print(f"\n{BOLD}{CYAN}{char*4} {label} {char*4}{RESET}\n", flush=True)


def main():
    print(f"\n{BOLD}{CYAN}━━ ENSURE PIPELINE EXTRAS · {SYMBOL} @ {TF_LABEL} ━━{RESET}\n",
          flush=True)
    t0 = time.time()
    ck = ck_mod.load(SYMBOL, TF_LABEL)
    target = CFG.get("target_total_candles", 100_000)

    # ── 1. Check which extras are needed ──
    needs_nn  = not ck["stages"].get("specialized_nns",  {}).get("done", False)
    needs_st  = not ck["stages"].get("stacker",          {}).get("done", False)
    needs_dsh = not ck["stages"].get("save_dashboard",   {}).get("done", False)

    # NN cache check — 4 specialised NNs
    nn_index = pmc.get_index(SYMBOL, TF_LABEL, "BOTH", target)
    nn_done  = set(nn_index.get("nn", {}).keys())
    missing_nns = [n for n in ("price_reg", "rl_agent", "sentiment_nn",
                                "regime_nn") if n not in nn_done]

    # SL Placement NN (separate — has its own registry)
    sl_nn_reg = STORE.get_json(f"sl_nn_registry_{SYMBOL.replace('-','_')}_{TF_LABEL}") or {}
    sl_nn_present = bool(sl_nn_reg.get("batches"))

    print(f"  Audit:")
    print(f"    checkpoint specialized_nns done : {not needs_nn}")
    print(f"    checkpoint stacker done         : {not needs_st}")
    print(f"    checkpoint save_dashboard done  : {not needs_dsh}")
    print(f"    cached NNs                       : {sorted(nn_done) or 'none'}")
    print(f"    missing NNs                      : {missing_nns or 'none'}")
    print(f"    SL placement NN cached           : {sl_nn_present}")

    if not (missing_nns or needs_nn or needs_st or needs_dsh or not sl_nn_present):
        print(f"\n  {GREEN}✓ all extras already present — nothing to do{RESET}\n",
              flush=True)
        return 0

    # ── 2. Train missing specialised NNs (only what's missing) ──
    if missing_nns:
        _step(f"Training {len(missing_nns)} missing NN(s): {missing_nns}")
        try:
            _train_missing_nns(missing_nns, target)
        except Exception as e:
            print(f"  {YELLOW}NN training failed: {e}{RESET}", flush=True)
            print("  [error] traceback suppressed — see message above", flush=True)

    # ── 3. SL Placement NN ──
    if not sl_nn_present:
        _step("Training Smart-SL Placement NN (one-time, ~5 min on 10k candles)")
        import subprocess
        rc = subprocess.call([sys.executable, "train_sl_nn.py",
                              "--mode", "scratch",
                              "--candles", "10000",
                              "--epochs",  "20"])
        if rc != 0:
            print(f"  {YELLOW}SL-NN trainer exited rc={rc}{RESET}", flush=True)

    # ── 4. Mark all extras done in checkpoint ──
    _step("Marking checkpoint stages done")
    for stg in ("specialized_nns", "stacker", "save_dashboard",
                "advanced_features", "long_committee", "short_committee",
                "long_dl", "short_dl"):
        if stg in ck.get("stages", {}) and ck["stages"][stg].get("done"):
            continue
        # Only mark stages that have data behind them
        if stg in ("specialized_nns", "stacker", "save_dashboard"):
            ck = ck_mod.mark_done(ck, stg)
            print(f"  ✓ marked {stg} done", flush=True)

    print(f"\n  {GREEN}✓ ensure_nns done in {time.time()-t0:.1f}s{RESET}\n",
          flush=True)
    return 0


def _train_missing_nns(missing: list, target: int):
    """Train ONLY the missing 4 specialised NNs inline (no committee retrain)."""
    import _engine
    from core.engine_patches import apply_engine_patches, engine_context
    apply_engine_patches()
    from data.fetcher_ccxt import fetch_ohlcv_stitched_v23
    from data.fetcher_sentiment import FinBERTSentiment, fetch_sentiment
    import numpy as np

    print(f"  Fetching {target:,} candles for feature build …", flush=True)
    df, _ = fetch_ohlcv_stitched_v23(SYMBOL, TF_LABEL, target)
    if df is None or len(df) < 1000:
        print(f"  {RED}insufficient data ({len(df) if df is not None else 0}){RESET}")
        return
    print(f"  ✓ {len(df):,} bars", flush=True)

    nlp = fetch_sentiment(FinBERTSentiment())
    sentiment_val = float(nlp.get("score", 0.0) or 0.0)

    # Build engine features
    print(f"  Building features (engine.build_features) …", flush=True)
    full = _engine.build_features(df, sentiment_val)
    if full is None or len(full) < 500:
        print(f"  {RED}feature build returned insufficient rows{RESET}")
        return

    # Engine expects scaled feature matrix
    from sklearn.preprocessing import RobustScaler
    feat_cols = [c for c in full.columns
                 if c not in ("open_time","open","high","low","close","volume",
                              "target","tb_long_win","tb_short_win","atr","nlp")]
    train = full.iloc[:int(len(full)*0.85)]
    X_raw = train[feat_cols].values.astype("float32")
    scaler = RobustScaler().fit(X_raw)
    X_sc = scaler.transform(X_raw).astype("float32")
    n_features = X_sc.shape[1]

    # Set context so save_nn knows where to put files
    with engine_context(SYMBOL, TF_LABEL, "BOTH", target):
        if "price_reg" in missing:
            print(f"\n  ▶ training PriceRegressionNN …", flush=True)
            try:
                m = _engine.PriceRegressionEnsemble(n_features)
                m.train(X_sc, train.reset_index(drop=True))
                print(f"    ✓ trained (acc≈{m.train_acc:.3f})", flush=True)
            except Exception as e:
                print(f"    {YELLOW}price_reg failed: {e}{RESET}", flush=True)
        if "rl_agent" in missing:
            print(f"\n  ▶ training RL Agent …", flush=True)
            try:
                m = _engine.RLTradingAgent(n_features)
                prices = train["close"].values.astype("float64")
                m.train(X_sc, prices, n_updates=8)
                print(f"    ✓ trained (acc≈{m.train_acc:.3f})", flush=True)
            except Exception as e:
                print(f"    {YELLOW}rl_agent failed: {e}{RESET}", flush=True)
        if "sentiment_nn" in missing:
            print(f"\n  ▶ training SentimentNN …", flush=True)
            try:
                m = _engine.SentimentNNWrapper(n_features)
                y_dir = train["target"].values.astype("float32") \
                        if "target" in train.columns \
                        else (train["close"].pct_change().shift(-1).fillna(0) > 0).astype("float32").values
                m.train(X_sc, sentiment_val, y_dir)
                print(f"    ✓ trained (acc≈{m.train_acc:.3f})", flush=True)
            except Exception as e:
                print(f"    {YELLOW}sentiment_nn failed: {e}{RESET}", flush=True)
        if "regime_nn" in missing:
            print(f"\n  ▶ training RegimeDetectorNN …", flush=True)
            try:
                m = _engine.RegimeDetectorNNWrapper(n_features)
                m.train(X_sc, train.reset_index(drop=True))
                print(f"    ✓ trained (acc≈{m.train_acc:.3f})", flush=True)
            except Exception as e:
                print(f"    {YELLOW}regime_nn failed: {e}{RESET}", flush=True)


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print(f"\n{YELLOW}[!] interrupted — partial work saved.{RESET}")
        sys.exit(2)
