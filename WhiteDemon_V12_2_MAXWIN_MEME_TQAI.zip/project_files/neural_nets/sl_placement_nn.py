"""
sl_placement_nn.py — WhiteDemon_V8.2

Bayesian SL Placement Neural Network.

Inputs (per setup, computed from df at entry bar):
  • entry_atr_ratio         (ATR / price)
  • recent_wick_size_atr    (mean wick beyond swing/ATR over last 50 bars)
  • dist_to_nearest_SR_atr  (how close is the nearest SR level in ATR units)
  • vp_density_norm         (normalized volume profile density at entry)
  • dist_to_nearest_liq_atr (distance to nearest liquidation cluster in ATR)
  • hour_of_day_sin/cos     (cyclic encoding of UTC hour)
  • day_of_week_sin/cos     (cyclic encoding of weekday)
  • volatility_regime       (low/mid/high → 0/0.5/1)
  • direction_flag          (1=LONG, 0=SHORT)

Output:
  • optimal_sl_atr_multiplier  (continuous, 0.5–4.5)

Training data:
  For each historical entry signal, simulate forward N bars to find the
  TIGHTEST SL that would have SURVIVED without being hit AND still allowed
  the trade to hit TP1 within N bars. That's the "perfect SL" label.

Cached as: per_model_cache → nn/sl_placement.bundle.gz  (shared across pairs)
"""
from __future__ import annotations
import os, math, numpy as np, pandas as pd
from typing import Optional, List, Tuple

try:
    import torch
    import torch.nn as nn
    HAS_TORCH = True
except Exception:
    HAS_TORCH = False


N_FEATURES = 11


# ──────────────────────────────────────────────────────────────────────────
# Model architecture
# ──────────────────────────────────────────────────────────────────────────
if HAS_TORCH:
    class SLPlacementNet(nn.Module):
        def __init__(self, n_features: int = N_FEATURES, hidden: int = 64):
            super().__init__()
            self.net = nn.Sequential(
                nn.Linear(n_features, hidden), nn.ReLU(), nn.Dropout(0.2),
                nn.Linear(hidden, hidden), nn.ReLU(), nn.Dropout(0.2),
                nn.Linear(hidden, 1), nn.Sigmoid(),     # 0-1 → scale to [0.5, 4.5]
            )
        def forward(self, x):
            raw = self.net(x).squeeze(-1)
            return 0.5 + raw * 4.0


# ──────────────────────────────────────────────────────────────────────────
# Feature builder (used at train + inference)
# ──────────────────────────────────────────────────────────────────────────
def build_features(df: pd.DataFrame, direction: str, sr_levels: List = None,
                   liq_clusters: List = None) -> Optional[np.ndarray]:
    """Single-row feature vector for the LATEST bar of df.
    Returns numpy array shape (N_FEATURES,) or None if not enough data."""
    if df is None or len(df) < 60:
        return None
    last = df.iloc[-1]
    price = float(last["close"])
    if price <= 0:
        return None
    # ATR proxy
    atr = float(df["atr"].iloc[-1]) if "atr" in df.columns else \
          float(df["close"].rolling(14).std().iloc[-1] or price * 0.01)
    atr = max(atr, price * 1e-5)

    # 1. entry_atr_ratio
    f0 = atr / price

    # 2. recent_wick_size_atr (mean wick over last 50 bars / atr)
    tail = df.tail(60)
    if direction == "LONG":
        wicks = (tail[["open", "close"]].min(axis=1) - tail["low"]).clip(lower=0)
    else:
        wicks = (tail["high"] - tail[["open", "close"]].max(axis=1)).clip(lower=0)
    f1 = float(wicks.mean()) / atr

    # 3. dist_to_nearest_SR_atr
    if sr_levels:
        sr_prices = [s["price"] for s in sr_levels if "price" in s]
        if sr_prices:
            dists = [abs(p - price) for p in sr_prices]
            f2 = min(dists) / atr
        else:
            f2 = 5.0
    else:
        f2 = 5.0

    # 4. vp_density_norm — fraction of vol traded within 0.5×ATR of current price
    if "volume" in df.columns:
        local_mask = (tail["close"] > price - 0.5 * atr) & (tail["close"] < price + 0.5 * atr)
        f3 = float(tail.loc[local_mask, "volume"].sum() / max(1, tail["volume"].sum()))
    else:
        f3 = 0.1

    # 5. dist_to_nearest_liq_atr
    if liq_clusters:
        prices = [c.get("price", 0) for c in liq_clusters if c.get("price", 0) > 0]
        if prices:
            f4 = min(abs(p - price) for p in prices) / atr
        else:
            f4 = 10.0
    else:
        f4 = 10.0

    # 6-7. hour cyclic
    if "open_time" in df.columns:
        ts = pd.to_datetime(df["open_time"].iloc[-1])
        hour = ts.hour
        dow  = ts.dayofweek
    else:
        hour, dow = 12, 2
    f5 = math.sin(2 * math.pi * hour / 24)
    f6 = math.cos(2 * math.pi * hour / 24)

    # 8-9. day cyclic
    f7 = math.sin(2 * math.pi * dow / 7)
    f8 = math.cos(2 * math.pi * dow / 7)

    # 10. volatility regime
    if "atr" in df.columns:
        atr_series = df["atr"].tail(200).dropna()
        if len(atr_series) > 20:
            current_atr_z = (atr - atr_series.mean()) / max(atr_series.std(), 1e-9)
            f9 = max(0.0, min(1.0, (current_atr_z + 2) / 4))   # map to [0,1]
        else:
            f9 = 0.5
    else:
        f9 = 0.5

    # 11. direction flag
    f10 = 1.0 if direction == "LONG" else 0.0

    return np.array([f0, f1, f2, f3, f4, f5, f6, f7, f8, f9, f10],
                    dtype=np.float32)


# ──────────────────────────────────────────────────────────────────────────
# Training data builder
# ──────────────────────────────────────────────────────────────────────────
def build_training_data(df: pd.DataFrame, horizon: int = 96,
                         max_sl_atr: float = 4.0,
                         step: int = 5,
                         sample_limit: int = 5000) -> Tuple[np.ndarray, np.ndarray]:
    """For each bar (every `step` bars to avoid label leakage), compute the
    "optimal SL" label by simulating forward.

    Label = tightest SL multiplier (in ATR units) that would have SURVIVED
            without being hit during the next `horizon` bars, while the
            trade also reached at least +1×ATR profit at some point.

    Returns: (X, y) — features matrix, target multipliers
    """
    if df is None or len(df) < horizon + 100:
        return np.zeros((0, N_FEATURES), dtype=np.float32), \
               np.zeros((0,), dtype=np.float32)
    if "atr" not in df.columns:
        # compute simple ATR-14 proxy
        df = df.copy()
        tr = pd.concat([
            df["high"] - df["low"],
            (df["high"] - df["close"].shift()).abs(),
            (df["low"]  - df["close"].shift()).abs(),
        ], axis=1).max(axis=1)
        df["atr"] = tr.rolling(14).mean()

    X_list, y_list = [], []
    end = len(df) - horizon - 1
    indices = list(range(100, end, step))
    if len(indices) > sample_limit:
        rng = np.random.default_rng(seed=42)
        indices = sorted(rng.choice(indices, size=sample_limit, replace=False))

    for i in indices:
        try:
            entry_price = float(df["close"].iloc[i])
            atr = float(df["atr"].iloc[i]) if not np.isnan(df["atr"].iloc[i]) else 0
            if entry_price <= 0 or atr <= 0:
                continue
            # Direction = next-bar direction (proxy)
            future_close = float(df["close"].iloc[i + horizon])
            direction = "LONG" if future_close > entry_price else "SHORT"
            # Did the trade ever reach +1 ATR profit?
            future_window = df.iloc[i + 1: i + 1 + horizon]
            if direction == "LONG":
                max_profit = float(future_window["high"].max() - entry_price)
                worst_drawdown = float(entry_price - future_window["low"].min())
            else:
                max_profit = float(entry_price - future_window["low"].min())
                worst_drawdown = float(future_window["high"].max() - entry_price)
            if max_profit < atr * 0.8:
                # not a real opportunity → skip
                continue
            # Optimal SL = worst_drawdown + 0.2×ATR (small safety margin)
            optimal_sl_atr = (worst_drawdown / atr) + 0.20
            optimal_sl_atr = min(max(optimal_sl_atr, 0.5), max_sl_atr)
            # Build feature vector at entry bar
            feats = build_features(df.iloc[: i + 1], direction)
            if feats is None:
                continue
            X_list.append(feats)
            y_list.append(optimal_sl_atr)
        except Exception:
            continue

    if not X_list:
        return np.zeros((0, N_FEATURES), dtype=np.float32), \
               np.zeros((0,), dtype=np.float32)
    return np.array(X_list, dtype=np.float32), \
           np.array(y_list, dtype=np.float32)


# ──────────────────────────────────────────────────────────────────────────
# Trainable wrapper
# ──────────────────────────────────────────────────────────────────────────
class SLPlacementWrapper:
    def __init__(self, n_features: int = N_FEATURES):
        self.enabled = HAS_TORCH
        self.n_features = n_features
        self.seq_len    = 0          # not sequential — point model
        self.trained    = False
        self.train_acc  = 0.5
        self.model      = SLPlacementNet(n_features, hidden=64) if HAS_TORCH else None
        self.scaler     = None
        self.device     = (torch.device("cuda" if HAS_TORCH and torch.cuda.is_available()
                                          else "cpu") if HAS_TORCH else None)
        if self.model is not None and self.device is not None:
            self.model.to(self.device)

    def train(self, df: pd.DataFrame, epochs: int = 30,
              batch_size: int = 64, lr: float = 1e-3, val_split: float = 0.15):
        if not self.enabled or self.model is None:
            print("  [sl-nn] torch not available — skipping training")
            return
        print(f"  [sl-nn] building training data from {len(df):,} bars …")
        X, y = build_training_data(df)
        if len(X) < 100:
            print(f"  [sl-nn] insufficient training samples ({len(X)}) — skip")
            return
        print(f"  [sl-nn] training on {len(X)} (feature, target) pairs")
        # Scale features
        from sklearn.preprocessing import RobustScaler
        self.scaler = RobustScaler().fit(X)
        Xs = self.scaler.transform(X)
        # Split
        n_val = max(20, int(len(Xs) * val_split))
        rng = np.random.default_rng(seed=42)
        perm = rng.permutation(len(Xs))
        val_idx = perm[:n_val]
        tr_idx  = perm[n_val:]
        Xtr_t = torch.tensor(Xs[tr_idx]).to(self.device)
        ytr_t = torch.tensor(y[tr_idx]).to(self.device)
        Xv_t  = torch.tensor(Xs[val_idx]).to(self.device)
        yv_t  = torch.tensor(y[val_idx]).to(self.device)
        opt = torch.optim.AdamW(self.model.parameters(), lr=lr, weight_decay=1e-4)
        loss_fn = torch.nn.HuberLoss(delta=0.5)
        best_val = float("inf"); best_state = None
        self.model.train()
        for ep in range(epochs):
            self.model.train()
            perm2 = torch.randperm(len(Xtr_t))
            tot_loss = 0; n_bat = 0
            for s in range(0, len(perm2), batch_size):
                idx = perm2[s:s+batch_size]
                opt.zero_grad()
                pred = self.model(Xtr_t[idx])
                loss = loss_fn(pred, ytr_t[idx])
                loss.backward()
                opt.step()
                tot_loss += float(loss.item())
                n_bat += 1
            # Val
            self.model.eval()
            with torch.no_grad():
                vp = self.model(Xv_t)
                vloss = float(loss_fn(vp, yv_t).item())
            if vloss < best_val:
                best_val = vloss
                best_state = {k: v.detach().cpu().clone() for k, v in self.model.state_dict().items()}
            if ep % 5 == 0 or ep == epochs - 1:
                print(f"  [sl-nn] ep {ep+1:>2}/{epochs}  tr_loss={tot_loss/n_bat:.4f}  val_loss={vloss:.4f}")
        # Restore best
        if best_state is not None:
            self.model.load_state_dict(best_state)
        # Mark trained — "accuracy" approximated as 1 - normalized val loss
        self.train_acc = max(0.0, min(1.0, 1.0 - best_val / 2.0))
        self.trained   = True
        print(f"  [sl-nn] ✓ trained · val_loss={best_val:.4f} · train_acc≈{self.train_acc:.3f}")

    @classmethod
    def load_latest_for(cls, symbol: str, tf_label: str):
        """Load the most-recent SL-NN batch saved for this pair/TF, or None.
        Reads sl_nn_registry_<sym>_<tf> on storage to find the latest count."""
        try:
            from core.storage import STORE
            from core import per_model_cache as pmc
            reg_key = f"sl_nn_registry_{symbol.replace('-','_')}_{tf_label}"
            reg = STORE.get_json(reg_key) or {}
            batches = reg.get("batches", [])
            if not batches:
                return None
            # Try latest batch first, then walk back
            for b in reversed(batches):
                cnt = b.get("n_candles") or 0
                if cnt <= 0:
                    continue
                w = cls()
                if pmc.load_nn(symbol, tf_label, cnt, "sl_placement", w):
                    return w
            return None
        except Exception:
            return None

    def predict(self, df: pd.DataFrame, direction: str,
                 sr_levels: List = None, liq_clusters: List = None) -> Optional[float]:
        if not self.trained or self.model is None or not self.enabled:
            return None
        feats = build_features(df, direction, sr_levels, liq_clusters)
        if feats is None:
            return None
        if self.scaler is not None:
            feats = self.scaler.transform(feats.reshape(1, -1)).astype(np.float32)
        else:
            feats = feats.reshape(1, -1)
        try:
            self.model.eval()
            with torch.no_grad():
                x = torch.tensor(feats).to(self.device)
                out = float(self.model(x).item())
            return out
        except Exception as e:
            print(f"  [sl-nn] predict failed: {e}")
            return None
