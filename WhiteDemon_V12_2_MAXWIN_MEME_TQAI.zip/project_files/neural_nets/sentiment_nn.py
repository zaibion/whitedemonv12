"""Sentiment-aware BiLSTM with attention pooling."""
from _engine import SentimentNNWrapper
