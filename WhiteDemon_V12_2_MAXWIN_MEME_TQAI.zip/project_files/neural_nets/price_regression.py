"""Multi-target price regression NN (next return + vol + direction)."""
from _engine import PriceRegressionEnsemble
