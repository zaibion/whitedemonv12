"""4-class regime detector (TRENDING_UP/DOWN, RANGING, VOLATILE)."""
from _engine import RegimeDetectorNNWrapper
