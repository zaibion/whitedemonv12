# 🌐 Deployment guide

## 🟢 Render (recommended — easiest)

### Step 1 — Push to GitHub

```bash
unzip crypto-suite-v23.zip && cd crypto-suite-v23
git init && git add . && git commit -m "v23"
git remote add origin https://github.com/<you>/crypto-suite-v23.git
git branch -M main && git push -u origin main
```

### Step 2 — Sign up at render.com (GitHub auth)

### Step 3 — New + → **Blueprint** → pick your repo

Render reads `render.yaml`, creates 1 web service ($7/mo Singapore region).

### Step 4 — In dashboard, **Environment** tab → add secrets:

```
GITHUB_TOKEN  = ghp_...
GITHUB_REPO   = your-username/crypto-bot-data
```
(or `FIREBASE_CREDENTIALS` etc. if using Firebase)

### Step 5 — Wait 5-8 min → open the URL Render gives you

Dashboard auto-loads. Use buttons in the UI to trigger train / analyze / backtest.

---

## 🚂 Railway

1. Push to GitHub (same as above)
2. railway.app → New Project → Deploy from GitHub repo
3. Add volume mounted at `/app/.model_cache`
4. Set env vars in dashboard
5. **Settings → Networking → Generate Domain**

---

## 🐳 Local Docker

```bash
docker build -t crypto-v23 .
docker run -d --name v23 \
  -v $(pwd)/cache:/app/.model_cache \
  -e PAIR_ID=3 -e TF_ID=5 \
  -e GITHUB_TOKEN=ghp_... -e GITHUB_REPO=you/data \
  -p 8000:8000 crypto-v23
# Open http://localhost:8000
```

---

## ⚠️ Why NOT Vercel

Vercel is serverless — max 60-second execution timeouts, no background workers.
Training takes 10-15 min, so it won't work. Use Render or Railway.
