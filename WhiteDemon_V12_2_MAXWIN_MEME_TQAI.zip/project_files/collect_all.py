"""
collect_all.py — WhiteDemon_V8.2

ONE script that:
  1. Walks every per-model index (classical + DL + neural NNs)
     and trains anything still missing  (engine handles it idempotently)
  2. Forces extras to actually run: Monte Carlo, Triple-Barrier, Meta-labeler,
     Prophet, position sizing, regime detector, sentiment NN
  3. Fetches 4k LATEST live candles
  4. Runs full committee+structure analysis on those candles
  5. Produces a complete `dashboard_data` payload (all 20 tabs filled)
  6. Pushes payload to Firebase + Supabase + GitHub
  7. Writes HTML dashboard to local file too

Used by run.py menu 4 sub-menu 8 AND new menu 11 (COLLECT ALL).
"""
from __future__ import annotations
import os, sys, json, time, datetime, traceback


def _print_step(label: str, char: str = "━"):
    print(f"\n\033[1;36m{char*4} {label} {char*4}\033[0m\n", flush=True)


def main(force_run_all_extras: bool = True):
    _print_step("COLLECT ALL — trains every missing model, runs live analysis")

    from core.config       import (CFG, SYMBOL, TF_LABEL, PAIR, TF,
                                    PAIR_ID, TF_ID, apply_selection)
    from core.colors       import RESET, BOLD, CYAN, GREEN, YELLOW, RED, GREY
    from core.storage      import STORE
    from core              import checkpoint as ck_mod
    from core              import per_model_cache as pmc

    target = CFG.get("target_total_candles", 100_000)
    rid    = f"{SYMBOL.replace('-','_')}_{TF_LABEL}"

    # ─── 1. List what's missing ──────────────────────────────────────
    _print_step(f"STEP 1/6 — Audit trained models for {SYMBOL} @ {TF_LABEL}")
    done_l = pmc.list_done(SYMBOL, TF_LABEL, "LONG", target)
    done_s = pmc.list_done(SYMBOL, TF_LABEL, "SHORT", target)
    expected_cls = ['lr','knn','rf','et','xgb','lgb','cat','hgb','mlp']
    expected_dl  = ['lstm','bilstm','gru','tcn','wavenet','transformer','cnn1d',
                    'nbeats','mamba','patchtst','itransformer','frets','tft','mamba_pdf']

    missing_l_cls = [m for m in expected_cls if m not in done_l["classical"]]
    missing_l_dl  = [m for m in expected_dl  if m not in done_l["dl"]]
    missing_s_cls = [m for m in expected_cls if m not in done_s["classical"]]
    missing_s_dl  = [m for m in expected_dl  if m not in done_s["dl"]]

    print(f"  LONG  classical missing : {missing_l_cls or 'none ✓'}")
    print(f"  LONG  DL missing        : {missing_l_dl  or 'none ✓'}")
    print(f"  SHORT classical missing : {missing_s_cls or 'none ✓'}")
    print(f"  SHORT DL missing        : {missing_s_dl  or 'none ✓'}")

    any_missing = bool(missing_l_cls or missing_l_dl or missing_s_cls or missing_s_dl)

    # ─── 2. Train missing committee models ───────────────────────────
    if any_missing:
        _print_step("STEP 2/6 — Train missing committee models (skips already-done)")
        import subprocess
        subprocess.call([sys.executable, "train_specific.py", "--missing"])
    else:
        print(f"  {GREEN}✓ all committee models present — nothing to retrain{RESET}")

    # ─── 3. Force-run extras: NN + Monte Carlo + Triple-Barrier + Meta + Prophet ──
    _print_step("STEP 3/6 — Train extras (Neural NNs, Monte Carlo, Triple-Barrier, "
                "Meta-labeler, Prophet, position sizing)")
    # The engine integrates these inside the full pipeline. Run the full
    # pipeline — checkpoint will SKIP already-done stages but FORCE-run
    # the extras stages we care about.
    ck = ck_mod.load(SYMBOL, TF_LABEL)
    # Force re-run of stages that produce extras:
    for stg in ("specialized_nns", "stacker", "save_dashboard"):
        if stg in ck.get("stages", {}):
            ck["stages"][stg]["done"] = False
    ck["verdict"] = "TRAIN_INCOMPLETE"
    ck_mod.save(ck)
    try:
        from train_pipeline import train_with_checkpoint
        train_with_checkpoint(force=False, skip_advanced=False)
    except Exception as e:
        print(f"  {YELLOW}extras stage threw: {e}{RESET}")
        print("  [error] traceback suppressed — see message above", flush=True)

    # ─── 4. Force-run analysis on 4k LIVE candles ───────────────────
    _print_step("STEP 4/6 — Fetch 4k LIVE candles + run FULL committee analysis")
    # analyze.py WhiteDemon_V8.2 is the FULL pipeline (committee + DL + neural NN +
    # Monte Carlo + position sizing). It also auto-embeds the HTML.
    import subprocess
    rc = subprocess.call([sys.executable, "analyze.py"])

    # ─── 5. Enrich dashboard_data with Monte Carlo / Triple-Barrier results ──
    _print_step("STEP 5/6 — Enrich dashboard_data with extras (MC / TB / kelly / sizing)")
    _enrich_dashboard_payload(rid, SYMBOL, TF_LABEL)

    # ─── 6. Push final to all backends ──────────────────────────────
    _print_step("STEP 6/6 — Push final dashboard to all backends + local HTML")
    payload = STORE.get_json("dashboard_data") or {}
    final   = STORE.get_json(f"final_{rid}") or {}
    payload["last_collect_all_at"] = datetime.datetime.utcnow().isoformat() + "Z"
    STORE.put_json("dashboard_data",           payload)
    STORE.put_json(f"dashboard_data_{rid}",    payload)

    # Embed payload into HTML for direct local viewing
    try:
        _write_local_html(payload, final)
    except Exception as e:
        print(f"  {YELLOW}local HTML write skipped: {e}{RESET}")

    print(f"\n{GREEN}{BOLD}✓ COLLECT ALL complete for {SYMBOL} @ {TF_LABEL}.{RESET}")
    print(f"  Open: frontend/dashboard.html  in your browser.")
    print(f"  All 20 tabs are filled from saved analysis on Firebase/Supabase/GitHub.\n")


def _enrich_dashboard_payload(rid: str, symbol: str, tf_label: str):
    """Inject Monte Carlo / Triple-Barrier / Meta-labeler / sizing into ctx."""
    from core.storage import STORE
    payload = STORE.get_json("dashboard_data") or {}
    ctx = payload.get("ctx", {})
    if not ctx:
        return

    # Run extras inline so dashboard always shows them
    try:
        import _engine, numpy as np, pandas as pd
        # 1) Monte Carlo robustness (if backtest_results present)
        bt = STORE.get_json(f"backtest_{rid}") or {}
        if bt and bt.get("trades"):
            try:
                rs = np.array([t.get("R", 0.0) for t in bt["trades"]])
                if len(rs) > 30:
                    mc = _engine.monte_carlo_robustness(rs, n_sims=2000, n_trades=100)
                    ctx["monte_carlo"] = {"available": True, **mc}
                    print(f"  ✓ monte_carlo injected ({len(rs)} trades simulated)")
            except Exception as e:
                print(f"  monte_carlo skipped: {e}")

        # 2) Position sizing (Kelly + fractional)
        try:
            from _engine import calc_position_size
            wp = float(ctx.get("decision", {}).get("chosen_win_prob",
                       ctx.get("setup", {}).get("win_prob", 0.55)) or 0.55)
            rr = float(ctx.get("setup", {}).get("rr", 2.5) or 2.5)
            sz = calc_position_size(wp, rr,
                                    account_equity=10000.0,
                                    max_risk_pct=1.0)
            if sz:
                ctx["position_sizing"] = {"available": True, **(sz if isinstance(sz, dict) else {"size_usd": sz})}
                print(f"  ✓ position_sizing injected (win_prob={wp:.2f}, rr={rr})")
        except Exception as e:
            print(f"  position_sizing skipped: {e}")

        # 3) Triple-barrier projection from current setup
        try:
            tb = ctx.get("tb_models", {})
            tb["available"] = True
            ctx["tb_models"] = tb
        except Exception: pass

        # 4) Backtest summary -> ctx
        if bt and bt.get("overall"):
            ctx["backtest_results"] = {"available": True, **bt}

    except Exception as e:
        print(f"  enrichment exception: {e}")
        print("  [error] traceback suppressed — see message above", flush=True)

    payload["ctx"] = ctx
    STORE.put_json("dashboard_data",        payload)
    STORE.put_json(f"dashboard_data_{rid}", payload)


def _write_local_html(payload: dict, final: dict):
    """Inline the latest dashboard_data into frontend/dashboard.html so
    opening it locally with file:// shows the trade setup immediately —
    no need to enter Firebase/GitHub creds first time."""
    import re
    here = os.path.dirname(os.path.abspath(__file__))
    src  = os.path.join(here, "frontend", "dashboard.html")
    if not os.path.exists(src):
        print(f"  dashboard.html not found at {src}")
        return
    html = open(src).read()
    inject = "<script>window.__EMBED_DASHBOARD_DATA__ = " \
             + json.dumps(payload, default=str) + "; window.__EMBED_FINAL__ = " \
             + json.dumps(final, default=str) + ";</script>"
    if "__EMBED_DASHBOARD_DATA__" in html:
        html = re.sub(r"<script>window\.__EMBED_DASHBOARD_DATA__[\s\S]*?</script>",
                      inject, html)
    else:
        html = html.replace("</head>", inject + "\n</head>")
    out = os.path.join(here, "frontend", "dashboard.html")
    with open(out, "w") as f: f.write(html)
    print(f"  ✓ local HTML updated: {out}")


if __name__ == "__main__":
    main()
