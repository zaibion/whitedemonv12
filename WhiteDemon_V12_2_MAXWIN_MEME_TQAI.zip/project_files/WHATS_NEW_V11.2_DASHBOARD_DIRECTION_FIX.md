# WhiteDemon V11.2 — Dashboard Direction Consistency Fix

Fixes the contradiction where the main dashboard hero could show one direction (for example LONG) while Setup / Trade Setup showed the opposite direction (for example SHORT).

## Root cause

The dashboard hero used the older `_engine.decide_trade()` confluence result:

- `decision.chosen_direction`

But Setup and Trade Setup used the newer precision-arbiter output:

- `ctx.chosen_candidate.direction`
- `ctx.setup.direction`

So the page could mix two different decision layers.

## Fixed

- `analyze.py` now harmonizes the public `decision` object to the precision-arbiter selected setup.
- Legacy confluence decision is preserved under `decision.legacy_decision` for audit/debug.
- Main hero, Setup tab, and Trade Setup tab now follow the same selected setup direction/status.
- Frontend hero now prefers:
  1. `ctx.chosen_candidate.direction`
  2. `ctx.setup.direction`
  3. legacy fallback only if needed
- Model tables no longer show misleading `L/S` votes for the SHORT committee.
  - LONG committee now shows `LONG YES / LONG NO`.
  - SHORT committee now shows `SHORT YES / SHORT NO`.
- Predictions tab committee summaries also use side-positive YES/NO wording.

## Important

This does not retrain models and does not invalidate trained caches. It is a dashboard/decision-consistency fix.
