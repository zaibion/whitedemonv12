# Crypto Suite WhiteDemon_V8.2 — Audit & train ALL missing extras (no more skips)

## ✅ What you asked for

> "In Menu 4 sub 8 and Menu 10 (Collect All) — do NOT let them skip missing
> models. Train full pipeline's missing components: classical, DL, neural
> networks, monte carlo, triple-barrier, meta, prophet, etc. Then assemble.
> Then fetch candles + show trade setup. Train missing · skip trained."

Done. WhiteDemon_V8.2 ALWAYS audits and trains anything missing. Only SKIPS items
that are confirmed present in cache. No more checkpoint-flag shortcuts that
let extras slip through untrained.

## 🔄 New flow (full_pipeline.py — 6 steps with hard timeouts)

```
STEP 1 · Audit ALL pipeline components
   ↳ checks per-model cache (long_*/classical/*, long_*/dl/*, BOTH/*/nn/*)
   ↳ checks SL-NN registry
   ↳ prints exactly what's missing per direction + extras

STEP 2 · Train missing classical/DL (per-model, skips trained)
   ↳ only runs if step 1 found missing committee models
   ↳ uses train_specific.py --missing → trains ONLY the gaps,
     never retrains anything already saved

STEP 3 · Reassemble committee slim JSONs from cached per-model data

STEP 4 · Train missing extras (NEW — never skipped if anything missing)
   ↳ NEW ensure_nns.py trains JUST the missing 4 specialised NNs:
       price_reg, rl_agent, sentiment_nn, regime_nn
   ↳ Also kicks SL-placement NN training if no batches exist
   ↳ All trained inline (no full pipeline re-entry)

STEP 5 · Final reassemble + checkpoint sync
   ↳ marks stages as done in checkpoint AFTER confirming data exists

STEP 6 · Fetch 4k LIVE candles + inference-only analyze.py (~30s)
```

Every step has a **hard timeout + kill** so cells can't hang forever.
Subprocess stdout streams live so you see real-time progress.

## 🆕 NEW `ensure_nns.py`

Standalone trainer for pipeline extras. Audits the per-model cache and
trains ONLY what's missing:

```
━━ ENSURE PIPELINE EXTRAS · LTC-USD @ 15m ━━

  Audit:
    checkpoint specialized_nns done : True
    checkpoint stacker done         : True
    checkpoint save_dashboard done  : True
    cached NNs                       : ['price_reg', 'rl_agent']
    missing NNs                      : ['sentiment_nn', 'regime_nn']
    SL placement NN cached           : False

  ━━ Training 2 missing NN(s): ['sentiment_nn', 'regime_nn'] ━━
  Fetching 100,000 candles for feature build …
  ✓ 100,000 bars
  Building features (engine.build_features) …
  ▶ training SentimentNN …
    ✓ trained (acc≈0.617)
  ▶ training RegimeDetectorNN …
    ✓ trained (acc≈0.712)

  ━━ Training Smart-SL Placement NN (one-time, ~5 min on 10k candles) ━━
  ...

  ✓ ensure_nns done in 412.3s
```

Saves each NN via `per_model_cache.save_nn` → Firebase → Supabase → GitHub
chain → disk fallback. Verified writes (round-trip read confirms).

## 📋 Menus that now audit + train everything missing

| Menu                                  | What runs |
|---------------------------------------|-----------|
| **Menu 4 → 8 → [1] START ANALYSIS**   | `full_pipeline.py` (6-step audit+train+analyze) |
| **Menu 4 → 8 → [2] START AGAIN**      | `full_pipeline.py` (same — re-audits) |
| **Menu 10 COLLECT ALL**                | `full_pipeline.py` (same) |
| Menu 4 → 8 → [3] FAST MODE             | `analyze.py` (inference only, ~30s) |
| Menu 4 → 8 → [4] CACHE ONLY            | `analyze.py` (inference only) |
| Menu 1 sub-menu FAST MODE              | `analyze.py` (inference only) |

For a **fully-trained pair**: pipeline takes ~1 minute (skips 2+4, runs 3+5+6).
For a **partially-trained pair**: trains ONLY what's missing, then analyzes.
For an **untrained pair**: trains everything (hours), then analyzes.

## 🎯 Example output (fully trained pair)

```
━━━━ STEP 1/6 · Audit all pipeline components ━━━━

  LONG  classical missing : none ✓
  LONG  DL missing        : none ✓
  SHORT classical missing : none ✓
  SHORT DL missing        : none ✓
  Neural NN missing       : none ✓
  SL placement NN cached  : True

━━━━ STEP 2/6 · Train missing classical / DL ━━━━
  ✓ all 9+14 committee models present — skipping training

━━━━ STEP 3/6 · Reassemble LONG/SHORT slim committee JSONs ━━━━
  ✓ reassembly done in 4s

━━━━ STEP 4/6 · Train missing extras ━━━━
  ✓ all 4 neural NNs + SL-NN present — skipping

━━━━ STEP 5/6 · Final cache reassemble + checkpoint sync ━━━━
  ✓ done in 4s

━━━━ STEP 6/6 · Fetch 4k LIVE candles + INFERENCE-ONLY analyze.py ━━━━
  [analyze WhiteDemon_V8.2: ~25 second inference run]
  ✅ ANALYZE DONE · VERDICT = TAKE_TRADE · LONG @ 65% · $94.32

✅ FULL PIPELINE COMPLETE in 38.4s
```

## 🎯 Example output (LTC trained but missing sentiment_nn + SL-NN)

```
━━━━ STEP 1/6 · Audit ━━━━
  Neural NN missing       : ['sentiment_nn']
  SL placement NN cached  : False

━━━━ STEP 4/6 · Train missing extras ━━━━
  missing: nn=['sentiment_nn'] · sl_nn=no
  [ensure_nns trains sentiment_nn from cached features  ~3-5 min]
  [then trains SL-NN on 10k candles  ~5 min]

━━━━ STEP 5/6 · Final reassemble + checkpoint sync ━━━━
━━━━ STEP 6/6 · Inference-only analyze.py ━━━━

✅ FULL PIPELINE COMPLETE in 612.4s
```

## 📋 Files changed since WhiteDemon_V8.2

```
full_pipeline.py    — 6-step audit-driven version (was checkpoint-only)
ensure_nns.py       — NEW: inline trainer for missing extras
WHATS_NEW_WhiteDemon_V8.2.md — this file
```

Engine MD5 unchanged: `7d0ce1868dcd0b35b629ee0f6c51afb1`.

## ⚡ Try it now

```python
%cd /kaggle/working/crypto-v23
%run full_pipeline.py
# OR via menu
%run run.py    # → Menu 10 COLLECT ALL
```

Pipeline will print exactly what it's training, what it's skipping, and
finish with a trade setup. No more silent hangs.
