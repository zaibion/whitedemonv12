# WhiteDemon V10.1 — Analog Pattern Inference

## Purpose
The model should not blindly repeat a bullish/bearish training bias. During FAST MODE it should use saved training knowledge as reference, then analyze the latest 4k candles across many dimensions.

## What changed

### 1) Save training reference matrix to GitHub/storage
During training, the committee bundle now saves:

- scaled training feature matrix (`reference_X_sc`) as float16
- direction win labels (`reference_y`) as int8
- similarity profile
- fitted models
- scaler
- feature schema

This is compressed inside:

```text
committee_bundle.pkl.gz
```

and uploaded to GitHub/storage.

### 2) Multi-dimensional analog pattern check
During FAST MODE/analyze:

1. Fetch latest candles.
2. Build latest feature row.
3. Scale it with the saved scaler.
4. Compare it against saved historical training states.
5. Find nearest historical analogs across all saved features.
6. Calculate analog win rate from similar historical cases.

Output example:

```text
analog pattern check: k=200 analog_WR=63.5% ref_rows=200000 dist=1.42
```

### 3) Blend analog evidence with model prediction
The final bundle probability blends:

- trained model current prediction
- cached DL sequence prediction when available
- nearest-neighbor analog win rate from historical reference data

### 4) Trade blocking
By default, trade is blocked/warned if:

```text
analog win-rate < 58%
```

or analog reference is unavailable.

## Important
You need one V10.1 training run to create new bundles containing the reference matrix. Old bundles will not have this reference data.

## Checks
- compileall passed
- tabnanny passed
- pyflakes syntax/undefined-name scan passed
