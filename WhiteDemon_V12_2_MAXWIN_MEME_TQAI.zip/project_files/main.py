"""
main.py — interactive menu (terminal mode).
For quick local use without spinning up the web server.
"""
import sys, os, subprocess
from core.colors import RESET, BOLD, CYAN, GREEN, YELLOW

def menu():
    print(f"""
{BOLD}{CYAN}╔══════════════════════════════════════════════════════════════╗
║          ⚡  CRYPTO SUITE v23 — COMMAND CENTRE              ║
╚══════════════════════════════════════════════════════════════╝{RESET}

  {GREEN}[1]{RESET} 🛠  Train all (full re-training, ~10-15 min)
  {GREEN}[2]{RESET} ⚡ Analyze (fast — uses cached models, ~30s)
  {GREEN}[3]{RESET} 📊 Walk-forward backtest (~30-90 min)
  {GREEN}[4]{RESET} 🌐 Start web server (open dashboard in browser)
  {YELLOW}[5]{RESET} 🚪 Exit
""")

while True:
    menu()
    try:
        choice = input(f"{BOLD}Choice [1-5]: {RESET}").strip()
    except (EOFError, KeyboardInterrupt):
        break
    if choice == "1":  subprocess.run(["python", "train_all.py"])
    elif choice == "2": subprocess.run(["python", "analyze.py"])
    elif choice == "3": subprocess.run(["python", "backtest_run.py"])
    elif choice == "4": subprocess.run(["python", "server.py"])
    elif choice in ("5","q","exit","quit"): break
