# WhiteDemon V9.0 — Clean Single Setup + Model Consensus

## Main fix
The analyze output no longer shows both LONG and SHORT candidates.

It now shows only one user-facing setup:

```text
BEST SETUP: LONG/SHORT
```

The opposite side is not printed and is not included in the final setup payload, to avoid confusion.

## Why both probabilities could be high
LONG and SHORT committees are separate models:
- LONG committee estimates whether a LONG setup can hit TP before SL.
- SHORT committee estimates whether a SHORT setup can hit TP before SL.

So both can show values above 50%. V9.0 avoids confusion by showing only the selected best setup and its edge advantage.

## Model agreement fix
Fixed the agreement logic for SHORT committees.

Before, SHORT model votes could be interpreted backwards. In direction-specific committees, prediction `1` means:

```text
this committee direction wins
```

So for SHORT committee, `1` supports SHORT. This is now handled correctly.

## Output now includes model consensus
The selected setup now prints:

```text
models: 12/20 models support SHORT (classic 7/9, DL 5/11)
```

This checks the classical + DL/neural model responses before showing the setup.

## Future setup levels
Future watch areas are limited to only 2.

They are clearly labelled as non-signal watch areas:

```text
Current clean setup: NONE — only 2 non-signal watch areas:
```

They are generated only from nearby support/resistance or demand/supply with ATR buffer.

## GitHub/storage
The app still uploads:
- `dashboard_data`
- `dashboard_data_<PAIR>_<TF>`
- `final_<PAIR>_<TF>`
- `setup_watch_<PAIR>_<TF>`
- dashboard HTML blob

## Checks
- compileall passed
- tabnanny passed
- pyflakes undefined-name/syntax scan passed
