"""
Walk-forward backtest with gross + net (after-fee) metrics.
Re-uses the same engine functions as live trading.
"""
from __future__ import annotations
import time, datetime, json, traceback
from typing import Optional
import numpy as np
import pandas as pd

import _engine
from core.colors import (RESET, BOLD, CYAN, GREEN, RED, YELLOW, ORANGE, GREY)
from core.config import CFG, SYMBOL, TF_LABEL
from core.storage import STORE
from data.fetcher_ccxt import fetch_ohlcv_stitched_v23
from data.fetcher_sentiment import FinBERTSentiment, fetch_sentiment
from indicators.basic import calc_atr
from indicators.structure import zigzag, sr_from_zigzag, sr_from_rolling_pivots, \
                                  sr_from_volume_profile, merge_all_sr
from indicators.smc import find_sd_zones
from ml_models.committee import run_ml_committee
from strategy.setup_builder import build_setup
from strategy.confluence import STRICT_MIN_WIN_PROB


def _simulate(direction, entry, sl, tp1, future):
    if direction == "LONG":
        sl_d = entry - sl; tp_d = tp1 - entry
    else:
        sl_d = sl - entry; tp_d = entry - tp1
    if sl_d <= 0 or tp_d <= 0:
        return "INVALID", 0.0, 0
    rr = tp_d / sl_d
    for j, (_, bar) in enumerate(future.iterrows()):
        if direction == "LONG":
            if bar["low"]  <= sl:  return "SL_HIT", -1.0, j
            if bar["high"] >= tp1: return "TP_HIT", float(rr), j
        else:
            if bar["high"] >= sl:  return "SL_HIT", -1.0, j
            if bar["low"]  <= tp1: return "TP_HIT", float(rr), j
    return "TIMEOUT", 0.0, len(future)


def run_walk_forward_backtest(symbol: str = None, tf_label: str = None,
                                target_candles: int = 200_000,
                                step: int = 4, horizon: int = 192,
                                min_train: int = 5_000, fee_r: float = 0.30,
                                push_to_storage: bool = True) -> dict:
    """Full walk-forward backtest. Returns dict with gross + net metrics."""
    symbol   = symbol   or SYMBOL
    tf_label = tf_label or TF_LABEL
    print(f"\n{BOLD}{CYAN}═══ WALK-FORWARD BACKTEST · {symbol} @ {tf_label} ═══{RESET}\n")

    # Fetch data
    df, src = fetch_ohlcv_stitched_v23(symbol, tf_label, target_candles)
    if df is None or len(df) < min_train * 2:
        raise RuntimeError(f"only {len(df) if df is not None else 0:,} candles — need ≥ {min_train*2:,}")
    df = df.sort_values("open_time").reset_index(drop=True)
    df["year"] = pd.to_datetime(df["open_time"]).dt.year
    df["atr"]  = calc_atr(df)

    nlp = fetch_sentiment(FinBERTSentiment())

    years = sorted(df["year"].unique())
    folds = []
    for i in range(1, len(years)):
        tr_years = years[:i]; te_year = years[i]
        n_tr = int(df["year"].isin(tr_years).sum())
        n_te = int((df["year"] == te_year).sum())
        if n_tr < min_train:
            continue
        folds.append({"fold": len(folds)+1, "train_years": tr_years,
                       "test_year": te_year, "n_train": n_tr, "n_test": n_te})
    if not folds:
        raise RuntimeError("no usable folds — try higher TF")

    fold_results = []
    for fold in folds:
        print(f"\n{BOLD}── FOLD {fold['fold']}: train {fold['train_years']} → test {fold['test_year']} ──{RESET}")
        tr_mask = df["year"].isin(fold["train_years"])
        te_mask = df["year"] == fold["test_year"]
        train_df = df[tr_mask].reset_index(drop=True)
        test_df  = df[te_mask].reset_index(drop=True)
        fake_df = pd.concat([train_df, test_df.head(CFG["trade_window"])], ignore_index=True)
        train_cutoff = len(train_df)
        try:
            cm_long  = run_ml_committee(fake_df, nlp["score"], train_cutoff,
                                         llm_features=None, direction="LONG")
            cm_short = run_ml_committee(fake_df, nlp["score"], train_cutoff,
                                         llm_features=None, direction="SHORT")
        except Exception as e:
            print(f"  TRAIN FAILED: {e}")
            print("  [error] traceback suppressed — see message above", flush=True)
            fold_results.append({"fold": fold["fold"], "error": str(e)})
            continue

        trades = []
        for i in range(0, len(test_df) - horizon, step):
            bar = test_df.iloc[i]
            price = float(bar["close"])
            abs_idx = int(df.index[df["open_time"] == bar["open_time"]][0])
            sub_df = df.iloc[:abs_idx + 1]
            if len(sub_df) < 300: continue
            tdf = sub_df.tail(CFG["trade_window"]).copy().reset_index(drop=True)
            try:
                pivots_zz, _, _ = zigzag(tdf.tail(CFG["zz_lookback"]), CFG["zz_dev_pct"])
                sr = merge_all_sr(sr_from_zigzag(pivots_zz, CFG["sr_tol_pct"]),
                                   sr_from_rolling_pivots(tdf),
                                   sr_from_volume_profile(tdf), price, tol_pct=0.3)
                demand, supply = find_sd_zones(tdf)
                atr_val = float(sub_df["atr"].iloc[-1])
            except Exception:
                continue
            p_l = float(cm_long.get("stack_bull", 0.5))
            p_s = float(cm_short.get("stack_bull", 0.5))
            direction = "LONG" if p_l >= p_s else "SHORT"
            win_prob  = p_l if direction == "LONG" else p_s
            if win_prob < STRICT_MIN_WIN_PROB: continue
            setup = build_setup(direction, price, sr, demand, supply, atr_val)
            if not setup["valid"]: continue
            if setup["rr1"] < CFG.get("min_rr_ratio", 2.5): continue
            future = test_df.iloc[i+1 : i+1+horizon]
            out, r, bars = _simulate(direction, price, setup["sl"], setup["tp1"], future)
            if out == "INVALID": continue
            trades.append({"time": str(bar["open_time"]), "direction": direction,
                            "entry": price, "sl": setup["sl"], "tp1": setup["tp1"],
                            "rr1": setup["rr1"], "outcome": out, "realized_r": r,
                            "bars_to_exit": bars, "win_prob_pred": win_prob})

        if not trades:
            print(f"  no trades produced")
            fold_results.append({"fold": fold["fold"], "test_year": fold["test_year"], "n_trades": 0})
            continue
        rs = np.array([t["realized_r"] for t in trades])
        n = len(rs); wins = rs > 0
        gross_e = float(rs.mean()); gross_total = float(rs.sum())
        gross_std = float(rs.std()) if n > 1 else 0.0
        gross_sharpe = float(gross_e/gross_std*np.sqrt(252)) if gross_std > 0 else 0.0
        gross_dd = float((np.maximum.accumulate(np.cumsum(rs)) - np.cumsum(rs)).max())
        rs_net = rs - fee_r
        net_e = float(rs_net.mean()); net_total = float(rs_net.sum())
        net_std = float(rs_net.std()) if n > 1 else 0.0
        net_sharpe = float(net_e/net_std*np.sqrt(252)) if net_std > 0 else 0.0
        net_dd = float((np.maximum.accumulate(np.cumsum(rs_net)) - np.cumsum(rs_net)).max())
        wr = float(wins.mean())
        gw = float(rs[wins].sum()) if wins.any() else 0.0
        gl = float(-rs[~wins & (rs < 0)].sum()) if (rs < 0).any() else 0.0
        pf = gw/gl if gl > 0 else float("inf") if gw > 0 else 0.0
        print(f"  {GREEN}trades={n} WR={wr*100:.1f}% E_gross={gross_e:+.3f}R E_net={net_e:+.3f}R "
              f"Sharpe={gross_sharpe:.2f} PF={pf:.2f}{RESET}")
        fold_results.append({
            "fold": fold["fold"], "train_years": fold["train_years"],
            "test_year": fold["test_year"], "n_trades": n, "wins": int(wins.sum()),
            "losses": int((~wins).sum()), "win_rate": wr,
            "gross_expectancy_R": gross_e, "gross_total_R": gross_total,
            "gross_sharpe": gross_sharpe, "gross_max_dd_R": gross_dd,
            "gross_profit_factor": pf,
            "net_expectancy_R": net_e, "net_total_R": net_total,
            "net_sharpe": net_sharpe, "net_max_dd_R": net_dd,
            "fee_per_trade_R": fee_r,
        })

    # Overall summary
    valid = [f for f in fold_results if "error" not in f and f.get("n_trades", 0) > 0]
    overall = {}
    if valid:
        tot = sum(f["n_trades"] for f in valid)
        gr  = sum(f["gross_total_R"] for f in valid)
        nr  = sum(f["net_total_R"]   for f in valid)
        wn  = sum(f["wins"] for f in valid)
        overall = {
            "n_folds": len(valid), "total_trades": tot,
            "overall_wr": wn/tot, "gross_total_R": gr, "net_total_R": nr,
            "gross_expectancy_R": gr/tot, "net_expectancy_R": nr/tot,
            "profitable_gross": gr > 0, "profitable_net": nr > 0,
        }
    payload = {"symbol": symbol, "tf_label": tf_label,
                "folds": fold_results, "overall": overall,
                "step": step, "horizon": horizon, "fee_r": fee_r}
    if push_to_storage:
        STORE.put_json(f"backtest_{symbol.replace('-','_')}_{tf_label}", payload,
                        message=f"backtest {symbol} {tf_label}")
    out_path = f"backtest_{symbol.replace('-','_')}_{tf_label}.json"
    with open(out_path, "w") as f:
        json.dump(payload, f, default=str, indent=2)
    print(f"\n{GREEN}✓ results saved → {out_path}{RESET}")
    return payload
