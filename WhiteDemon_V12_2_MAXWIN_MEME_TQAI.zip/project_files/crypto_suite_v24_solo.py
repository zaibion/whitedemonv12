#!/usr/bin/env python3
"""
crypto_suite_v24_solo.py — Single-file bootstrap for Crypto Suite v24.

What this does:
  1. If the v24 codebase isn't already extracted in cwd, it extracts from
     the same zip you uploaded (path auto-detected on Kaggle/Colab/local).
  2. Installs dependencies if needed.
  3. Writes config.py from inline answers if user passes them on CLI,
     OR runs setup.py interactively if no args given.
  4. Launches the full interactive menu (run.py).

USAGE
─────
  # Kaggle (use %run, NOT !python):
  %run crypto_suite_v24_solo.py

  # Local / Colab:
  python crypto_suite_v24_solo.py

  # Non-interactive (pass everything on CLI):
  python crypto_suite_v24_solo.py --pair 7 --tf 5 --candles 30000 \\
      --github-token ghp_xxx --github-repo zaibion/kinapp

  # Just run the menu (config already exists):
  python crypto_suite_v24_solo.py --menu

This is just a launcher — all the heavy code lives in the v24 zip.
"""
from __future__ import annotations
import os, sys, argparse, subprocess, glob, shutil

# ── ANSI colors ───────────────────────────────────────────────────────
RESET="\033[0m"; BOLD="\033[1m"; CYAN="\033[96m"; GREEN="\033[92m"
RED="\033[91m"; YELLOW="\033[93m"; GREY="\033[90m"

def banner(t):
    print(f"\n{BOLD}{CYAN}{'━'*60}\n  {t}\n{'━'*60}{RESET}\n")

def ok(t):  print(f"  {GREEN}✓{RESET} {t}")
def bad(t): print(f"  {RED}✗{RESET} {t}")
def info(t):print(f"  {GREY}{t}{RESET}")


# ── CLI args (all optional) ───────────────────────────────────────────
ap = argparse.ArgumentParser(add_help=False)
ap.add_argument("--zip-path", default=None,
                help="path to crypto-suite-v24.zip (auto-detected if omitted)")
ap.add_argument("--workdir", default=None,
                help="where to extract (default: current dir)")
ap.add_argument("--menu", action="store_true",
                help="skip setup; just launch the menu")
ap.add_argument("--skip-install", action="store_true",
                help="don't run pip install")

# Non-interactive config flags (if any provided, skips interactive setup):
ap.add_argument("--pair", type=int, default=None)
ap.add_argument("--tf",   type=int, default=None)
ap.add_argument("--candles", type=int, default=None)
ap.add_argument("--fast-candles", type=int, default=4000)
ap.add_argument("--github-token", default="")
ap.add_argument("--github-repo",  default="")
ap.add_argument("--github-branch", default="main")
ap.add_argument("--firebase-api-key",    default="")
ap.add_argument("--firebase-project-id", default="")
ap.add_argument("--openai-key",    default="")
ap.add_argument("--anthropic-key", default="")
ap.add_argument("--gemini-key",    default="")
ap.add_argument("--groq-key",      default="")
ap.add_argument("--deepseek-key",  default="")
ap.add_argument("--help", "-h", action="store_true")
args, _unknown = ap.parse_known_args()

if args.help:
    print(__doc__)
    sys.exit(0)


# ── STEP 1: locate the v24 zip ───────────────────────────────────────
def find_zip():
    if args.zip_path and os.path.exists(args.zip_path):
        return args.zip_path
    candidates = [
        "crypto-suite-v24.zip", "crypto-suite-v23.18.zip", "crypto-suite-v23.17.zip",
        "/kaggle/input/cryptosuite/crypto-suite-v24.zip",
        "/kaggle/input/cryptosuite/crypto-suite-v23.18.zip",
        "/kaggle/working/crypto-suite-v24.zip",
        "/content/crypto-suite-v24.zip",
    ]
    for c in candidates:
        if os.path.exists(c):
            return c
    for pat in ("crypto-suite-v*.zip", "/kaggle/input/*/crypto-suite-v*.zip",
                 "/kaggle/working/crypto-suite-v*.zip"):
        matches = sorted(glob.glob(pat), reverse=True)   # newest first
        if matches:
            return matches[0]
    return None


# ── STEP 2: extract if not already extracted ──────────────────────────
def extract_zip(zip_path: str, workdir: str) -> str:
    """Extract zip and return the extracted folder path."""
    import zipfile
    os.makedirs(workdir, exist_ok=True)
    with zipfile.ZipFile(zip_path) as z:
        z.extractall(workdir)
    # Find the extracted folder (usually 'crypto-v23' or 'crypto-v24')
    for entry in os.listdir(workdir):
        full = os.path.join(workdir, entry)
        if os.path.isdir(full) and entry.startswith("crypto-v"):
            return full
    return workdir


# ── STEP 3: install deps ──────────────────────────────────────────────
def install_deps(project_dir: str):
    req = os.path.join(project_dir, "requirements.txt")
    if not os.path.exists(req):
        bad(f"requirements.txt not found in {project_dir}")
        return False
    info("Installing dependencies (pip install -q -r requirements.txt) …")
    rc = subprocess.call([sys.executable, "-m", "pip", "install", "-q", "-r", req])
    return rc == 0


# ── STEP 4: write config.py ───────────────────────────────────────────
def write_config_noninteractive(project_dir: str):
    PAIRS = {1:"BTC",2:"ETH",3:"SOL",4:"BNB",5:"XRP",6:"LTC",7:"ADA",8:"DOGE",
              9:"AVAX",10:"DOT",11:"MATIC",12:"LINK",13:"TRX",14:"ATOM",
              15:"NEAR",16:"ARB",17:"OP",18:"SHIB"}
    TFS = {1:"1m",2:"3m",3:"5m",4:"15m",5:"30m",6:"1h",7:"4h",8:"1d"}
    pid = args.pair    or 3
    tid = args.tf      or 5
    tgt = args.candles or 30000

    # Firebase auto-fill
    fb_proj = args.firebase_project_id
    fb_auth = f"{fb_proj}.firebaseapp.com" if fb_proj else ""
    fb_db   = f"https://{fb_proj}-default-rtdb.firebaseio.com" if fb_proj else ""
    fb_buck = f"{fb_proj}.firebasestorage.app" if fb_proj else ""

    body = f'''"""auto-generated by crypto_suite_v24_solo.py"""

PAIR_ID = {pid}
TF_ID   = {tid}
TARGET_CANDLES = {tgt}
FAST_CANDLES   = {args.fast_candles}

FIREBASE_API_KEY              = "{args.firebase_api_key}"
FIREBASE_AUTH_DOMAIN          = "{fb_auth}"
FIREBASE_DATABASE_URL         = "{fb_db}"
FIREBASE_STORAGE_BUCKET       = "{fb_buck}"
FIREBASE_PROJECT_ID           = "{fb_proj}"
FIREBASE_APP_ID               = ""
FIREBASE_MESSAGING_SENDER_ID  = ""
FIREBASE_CREDENTIALS = ""
FIREBASE_BUCKET      = "{fb_buck}"

GITHUB_TOKEN  = "{args.github_token}"
GITHUB_REPO   = "{args.github_repo}"
GITHUB_BRANCH = "{args.github_branch}"

OPENAI_API_KEY    = "{args.openai_key}"
ANTHROPIC_API_KEY = "{args.anthropic_key}"
GEMINI_API_KEY    = "{args.gemini_key}"
GROQ_API_KEY      = "{args.groq_key}"
DEEPSEEK_API_KEY  = "{args.deepseek_key}"
MISTRAL_API_KEY   = ""
TOGETHER_API_KEY  = ""
HUGGINGFACE_API_KEY = ""
'''
    cfg_path = os.path.join(project_dir, "config.py")
    with open(cfg_path, "w") as f:
        f.write(body)
    ok(f"config.py written → {cfg_path}")
    print(f"     PAIR: {PAIRS.get(pid, '?')} (id={pid})  TF: {TFS.get(tid, '?')} (id={tid})  Candles: {tgt:,}")
    return cfg_path


# ── MAIN ──────────────────────────────────────────────────────────────
banner("⚡ Crypto Suite v24 — Solo Launcher")

# 1) figure out project dir
project_dir = None
workdir = args.workdir or os.getcwd()

# Already in a crypto-v* folder?
if os.path.exists(os.path.join(workdir, "run.py")) and os.path.exists(os.path.join(workdir, "_engine.py")):
    project_dir = workdir
    ok(f"Found extracted project: {project_dir}")
else:
    # Look one level deep
    for entry in os.listdir(workdir):
        full = os.path.join(workdir, entry)
        if os.path.isdir(full) and entry.startswith("crypto-v") \
           and os.path.exists(os.path.join(full, "run.py")):
            project_dir = full
            ok(f"Found extracted project: {project_dir}")
            break

if not project_dir:
    zip_path = find_zip()
    if not zip_path:
        bad("Could not find crypto-suite-v*.zip anywhere.")
        bad("Upload the zip to your Kaggle dataset, then re-run.")
        bad("Or pass --zip-path /full/path/to/zip")
        sys.exit(1)
    info(f"Extracting {zip_path} → {workdir}")
    project_dir = extract_zip(zip_path, workdir)
    ok(f"Extracted to {project_dir}")

os.chdir(project_dir)


# 2) install deps
if not args.skip_install:
    install_deps(project_dir)


# 3) write config.py (non-interactive if --pair given, else run setup.py)
has_inline_config = any([args.pair, args.tf, args.github_token, args.firebase_api_key])
has_existing_config = os.path.exists(os.path.join(project_dir, "config.py"))

if args.menu:
    if not has_existing_config:
        bad("--menu requested but no config.py exists. Run setup first.")
        sys.exit(1)
    info("Skipping setup (--menu mode), going straight to menu …")
elif has_inline_config:
    write_config_noninteractive(project_dir)
elif has_existing_config:
    info("Existing config.py found. Re-run with --pair/--tf/etc to overwrite, or run setup.py.")
    print()
    ans = input(f"  Overwrite existing config? [y/N]: ").strip().lower()
    if ans == "y":
        # Launch interactive setup
        subprocess.call([sys.executable, "setup.py"])
else:
    info("No config.py — launching interactive setup …")
    subprocess.call([sys.executable, "setup.py"])


# 4) launch menu
banner("▶ Launching menu …")
subprocess.call([sys.executable, "run.py"])
