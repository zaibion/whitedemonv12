# WhiteDemon V10.5 — Unified Analysis Path

## Problem fixed
Different menus could call different analysis engines:

- Menu 4 → 8 → 1/2 called `full_pipeline.py`
- Menu 4 → 8 → 3/4 called `analyze.py`
- Main fast mode called `analyze.py`
- Show trained pairs could call `full_pipeline.py`

Because `full_pipeline.py` and `analyze.py` can use different paths/caches/gates, they could output different directions at the same time.

## Change
All analysis choices in Menu 4 → 8 now call the same unified analyzer:

```text
analyze.py
```

So:

```text
[1] START ANALYSIS
[2] START ANALYSIS AGAIN
[3] FAST MODE
[4] ANALYZE WITH CURRENT CACHE ONLY
```

all use the same logic and should no longer disagree because of menu path differences.

## Training separation
Analysis menu no longer triggers `full_pipeline.py` training. Training is handled only by training menu items.

## Also changed
Show trained pair analysis now uses `analyze.py` instead of `full_pipeline.py` to avoid contradictory results.

## Which output to trust
Trust the newest unified `analyze.py` / FAST MODE output, especially when it shows:

```text
[bundle-fast] TRUE ... inference
```

Do not compare older full_pipeline output against fast mode; they were different paths.

## Checks
- compileall passed
- tabnanny passed
- pyflakes syntax/undefined-name scan passed
