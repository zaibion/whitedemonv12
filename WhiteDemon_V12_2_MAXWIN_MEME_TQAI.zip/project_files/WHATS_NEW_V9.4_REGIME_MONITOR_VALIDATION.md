# WhiteDemon V9.4 — Regime Adaptation + Monitoring + Data Validation

## Added

### 1) Stronger market data validation
New module: `core/data_validation.py`

Checks and repairs:
- required OHLC columns
- timestamp parse/sort/dedupe
- invalid/NaN rows
- non-positive prices
- OHLC consistency (`high >= open/close/low`, `low <= open/close/high`)
- timestamp gaps
- extreme outlier returns
- missing/zero volume warnings

Integrated into:
- `analyze.py`
- `backtest_run.py`

### 2) Adaptive regime profile
Analyze now builds a `regime_profile` from detected regime + ATR%.

It tightens gates when regime is:
- ranging/choppy/unclear
- high volatility

This makes entries harder in dangerous market conditions.

### 3) Real-time monitoring outputs
New module: `core/monitoring.py`

Writes:
- `runtime_metrics.json`
- `runtime_metrics.prom` Prometheus text format

Optional StatsD via env:
```bash
STATSD_HOST=127.0.0.1
STATSD_PORT=8125
```

Metrics include:
- trade_allowed
- setup_score
- entry_precision_score
- committee_probability
- model agreement
- all-model majority
- data validation status
- data validation warnings
- ATR/regime risk
- setup risk percent

### 4) GitHub/storage live metrics
Analyze now uploads:
- `data/live_metrics_<PAIR>_<TF>.json`

Existing uploads remain:
- dashboard data
- final signal
- setup watch
- dashboard HTML blob

## Goal
Make the system safer and more professional by preventing bad-data trades, adapting to market conditions, and exposing runtime health metrics.
