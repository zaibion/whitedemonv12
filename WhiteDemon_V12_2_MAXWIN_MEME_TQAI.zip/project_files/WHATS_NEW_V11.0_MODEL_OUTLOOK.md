# WhiteDemon V11.0 — Setup-Agnostic Model Outlook

## Purpose
Adds a separate model outlook panel that answers:

```text
What do the models think the market may do, independent of the trade setup?
```

This does not replace the setup card. The setup card still handles entry/SL/TP and risk validation.

## New analyze payload

```text
ctx.model_market_outlook
```

It includes:
- overall model lean: LONG / SHORT / NEUTRAL
- long/short/neutral weighted shares
- direction edge
- expected move estimates for 1, 4, 10, and 20 candles where available
- model-by-model votes with source, model name, lean, confidence, and note

## New frontend tab

```text
🧠 Model Outlook
```

This tab shows:
- setup-agnostic model lean
- expected move by horizon
- all model votes one by one

## Important
This tab is not a trade setup and does not override risk guards. It is designed to reduce confusion by separating:

```text
model market opinion
```

from:

```text
valid trade setup with entry/SL/TP
```

## Checks
- compileall passed
- tabnanny passed
