# WhiteDemon V11.1 — Android On-Phone Kit

This version adds an Android/mobile path without deleting existing model logic.

## Added

- `frontend/mobile.html` — mobile-first WhiteDemon control panel.
- `/mobile` route in `server.py`.
- Mobile/API-friendly analysis endpoint:
  - `GET/POST /api/analyze?pair=SOL-USDT&tf=15m&mode=smart`
  - default mode is Smart Analysis / fast cached inference, not full retrain.
- `/api/latest_signal` endpoint for mobile UI.
- `/api/fast_analyze` now supports GET/POST and pair/tf query parameters.
- `mobile/termux_install_backend.sh` — Android Termux install attempt.
- `mobile/run_backend_on_phone.sh` — starts local backend on Android phone.
- `mobile/README_ANDROID_ON_PHONE.md` — honest install/limitations guide.
- `android/WhiteDemonMobile/` — Android Studio WebView wrapper starter project.

## Important honesty

Running the complete Python ML backend inside Android is not guaranteed. Heavy packages such as `torch`, `xgboost`, `lightgbm`, `catboost`, `shap`, and `prophet` may not install or may run too slowly on a phone.

The most reliable production architecture is still: backend on PC/VPS, Android app as UI. This kit supports the user's requested local-phone backend path, but it must be tested on the actual phone.

## Model cache

No model cache version change. Existing trained models/bundles are not invalidated.
