#!/data/data/com.termux/files/usr/bin/bash
set -u
cd "$(dirname "$0")/.." || exit 1
printf '\n=== WhiteDemon Android/Termux backend installer ===\n'
printf 'This tries to run the EXISTING trained backend on the phone.\n'
printf 'Heavy ML wheels on Android are not guaranteed. If torch/xgboost/lightgbm fail, use PC/VPS backend.\n\n'
pkg update -y
pkg install -y python clang make cmake rust git libopenblas libffi openssl pkg-config ndk-sysroot || true
python -m pip install --upgrade pip setuptools wheel
# Core runtime first: these are most likely to install on Android/Termux.
python -m pip install --upgrade numpy pandas scipy scikit-learn joblib requests flask python-dateutil pytz psutil beautifulsoup4 feedparser ccxt yfinance rich jinja2 || true
# Optional heavy packages. Do NOT stop install if Android wheels are unavailable.
python -m pip install --upgrade xgboost lightgbm catboost torch transformers shap prophet || true
printf '\nInstall attempt finished. Now run:\n  bash mobile/run_backend_on_phone.sh\nThen open:\n  http://127.0.0.1:8000/mobile\n'
