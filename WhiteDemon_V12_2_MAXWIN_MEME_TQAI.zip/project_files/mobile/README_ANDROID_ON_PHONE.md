# WhiteDemon Android-on-phone mode

This kit is for the user's requested architecture: **backend also runs inside the Android phone**.

## Honest status

This is possible only through a Python environment such as **Termux**. It is **not guaranteed** to run all trained models because Android often has no working wheels for heavy ML packages like `torch`, `xgboost`, `lightgbm`, `catboost`, `shap`, and `prophet`.

If those packages fail on your phone, the correct production architecture is: Android app UI + backend on PC/VPS.

## How to run on Android

1. Install Termux from F-Droid.
2. Copy/extract this `project_files` folder to phone storage or Termux home.
3. In Termux, go to the project folder.
4. Run:

```bash
bash mobile/termux_install_backend.sh
bash mobile/run_backend_on_phone.sh
```

5. Open on the same phone:

```text
http://127.0.0.1:8000/mobile
```

## What the mobile screen does

- Calls `/api/analyze?pair=SOL-USDT&tf=15m&mode=smart`
- Uses the existing trained WhiteDemon models/cache
- Polls `/api/status`, `/api/latest_signal`, and `/api/logs`
- Shows WAIT/BLOCKED/error if backend or model loading fails

## Android Studio wrapper

An Android WebView starter project is included in `android/WhiteDemonMobile/`. It loads:

```text
http://127.0.0.1:8000/mobile
```

Build it in Android Studio after the Termux backend is working. The wrapper is only the screen; the real backend remains the local Termux Python server.
