#!/data/data/com.termux/files/usr/bin/bash
set -u
cd "$(dirname "$0")/.." || exit 1
export PORT="${PORT:-8000}"
export PYTHONUNBUFFERED=1
export WHITDEMON_MOBILE=1
printf '\n=== Starting WhiteDemon backend on Android phone ===\n'
printf 'Backend URL: http://127.0.0.1:%s/mobile\n' "$PORT"
printf 'Stop with CTRL+C in Termux.\n\n'
python server.py
