"""Yahoo Finance fetcher — thin re-export from engine."""
from _engine import fetch_ohlcv_yahoo
