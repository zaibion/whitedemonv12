"""
fetcher_liquidations.py — WhiteDemon_V8.2

Pulls recent forced-liquidations from FREE public APIs to detect price
clusters where market-maker hunting is likely.

Sources (no API key required, public endpoints):
  1. Binance Futures /fapi/v1/forceOrders  — last 24h aggregated forced liqs
  2. Bybit V5 /v5/market/liquidation       — last 100 events per pair
  3. Coingecko /derivatives/exchanges      — fallback open-interest data

All requests have ~5-second timeout and degrade silently on failure (we
NEVER block analysis on a flaky third-party API).

In-memory cache: 5 minutes per symbol.

Public API:
    get_liquidation_clusters(symbol: str, lookback_min: int = 60) -> list
        Returns: [{"price": float, "magnitude": float (USD),
                    "side": "long"|"short", "ts": int}, ...]
"""
from __future__ import annotations
import time, json, threading
from typing import List, Dict, Optional


_cache: Dict[str, tuple] = {}     # symbol -> (timestamp, clusters)
_lock = threading.Lock()
_TTL  = 300                       # 5 min


def _yahoo_to_binance_pair(symbol: str) -> str:
    """BTC-USD → BTCUSDT"""
    base = symbol.replace("-USD", "").replace("-USDT", "").upper()
    return f"{base}USDT"


def _yahoo_to_bybit_pair(symbol: str) -> str:
    """BTC-USD → BTCUSDT (linear perpetual)"""
    base = symbol.replace("-USD", "").replace("-USDT", "").upper()
    return f"{base}USDT"


# ──────────────────────────────────────────────────────────────────────────
# Binance Futures public liquidations
# ──────────────────────────────────────────────────────────────────────────
def _fetch_binance_liqs(symbol: str, limit: int = 100) -> List[Dict]:
    """Note: /fapi/v1/forceOrders is partial-public. Some Binance regions
    require an API key. We use /fapi/v1/aggTrades + open interest as proxy."""
    try:
        import requests
        pair = _yahoo_to_binance_pair(symbol)
        # Use the AllForceOrders public stream snapshot endpoint
        # (NOTE: Binance gates this — usually returns 401 in PK. Try anyway.)
        url = f"https://fapi.binance.com/fapi/v1/allForceOrders"
        r = requests.get(url, params={"symbol": pair, "limit": limit}, timeout=5)
        if r.status_code != 200:
            return []
        rows = r.json()
        out = []
        for row in rows:
            try:
                out.append({
                    "price":     float(row.get("price", 0)),
                    "magnitude": float(row.get("origQty", 0)) * float(row.get("price", 0)),
                    "side":      "long" if row.get("side") == "SELL" else "short",
                    "ts":        int(row.get("time", 0)),
                    "source":    "binance",
                })
            except Exception:
                pass
        return out
    except Exception:
        return []


# ──────────────────────────────────────────────────────────────────────────
# Bybit V5 public liquidation feed
# ──────────────────────────────────────────────────────────────────────────
def _fetch_bybit_liqs(symbol: str, limit: int = 100) -> List[Dict]:
    try:
        import requests
        pair = _yahoo_to_bybit_pair(symbol)
        url = "https://api.bybit.com/v5/market/recent-trade"  # fallback proxy
        # Bybit doesn't expose historical liquidations without auth; we use
        # recent-trade volume spikes as a hunt-proxy.
        r = requests.get(url, params={"category": "linear", "symbol": pair,
                                       "limit": min(limit, 500)}, timeout=5)
        if r.status_code != 200:
            return []
        data = r.json().get("result", {}).get("list", [])
        if not data:
            return []
        # Build "synthetic liq clusters" from volume-weighted trade prices
        # (large prints often follow liquidation cascades)
        cluster_map: Dict[float, float] = {}
        for trade in data:
            try:
                p = float(trade.get("price", 0))
                v = float(trade.get("size", 0)) * p
                if p > 0 and v > 1000:    # only >$1k prints
                    # bucket to nearest 0.1%
                    bucket = round(p, max(0, 6 - int(len(str(int(p))))))
                    cluster_map[bucket] = cluster_map.get(bucket, 0) + v
            except Exception:
                pass
        out = [{"price": p, "magnitude": v, "side": "unknown",
                "ts": int(time.time() * 1000), "source": "bybit_proxy"}
               for p, v in cluster_map.items() if v > 5000]
        # Keep only top-20 largest clusters
        out.sort(key=lambda x: x["magnitude"], reverse=True)
        return out[:20]
    except Exception:
        return []


# ──────────────────────────────────────────────────────────────────────────
# OKX public liquidation orders
# ──────────────────────────────────────────────────────────────────────────
def _fetch_okx_liqs(symbol: str) -> List[Dict]:
    try:
        import requests
        base = symbol.replace("-USD", "").replace("-USDT", "").upper()
        inst = f"{base}-USDT-SWAP"
        url = "https://www.okx.com/api/v5/public/liquidation-orders"
        r = requests.get(url, params={"instType": "SWAP", "instFamily": f"{base}-USDT",
                                       "limit": 100}, timeout=5)
        if r.status_code != 200:
            return []
        data = r.json().get("data", [])
        if not data:
            return []
        out = []
        for entry in data:
            details = entry.get("details", [])
            for d in details:
                try:
                    out.append({
                        "price":     float(d.get("bkPx", 0)),    # bankruptcy price
                        "magnitude": float(d.get("sz", 0)) * float(d.get("bkPx", 0)),
                        "side":      "long" if d.get("side") == "sell" else "short",
                        "ts":        int(d.get("ts", 0)),
                        "source":    "okx",
                    })
                except Exception:
                    pass
        return out
    except Exception:
        return []


# ──────────────────────────────────────────────────────────────────────────
# Public API
# ──────────────────────────────────────────────────────────────────────────
def get_liquidation_clusters(symbol: str,
                              lookback_min: int = 60,
                              min_magnitude_usd: float = 1000.0) -> List[Dict]:
    """Aggregate liq events from multiple exchanges into price clusters.

    Returns sorted-by-magnitude list of {"price": float, "magnitude": float,
                                            "side": str, "ts": int, "source": str}
    Empty list if all APIs failed (analysis continues with vp + wick only).
    """
    cache_key = f"{symbol}:{lookback_min}"
    now = time.time()
    with _lock:
        if cache_key in _cache:
            ts, clusters = _cache[cache_key]
            if now - ts < _TTL:
                return clusters

    print(f"  [liq] fetching liquidation clusters for {symbol} (60s timeout)…", flush=True)
    all_liqs: List[Dict] = []
    for fetcher, name in [
        (_fetch_okx_liqs,     "OKX"),
        (_fetch_bybit_liqs,   "Bybit proxy"),
        (_fetch_binance_liqs, "Binance"),
    ]:
        try:
            chunk = fetcher(symbol) if fetcher != _fetch_bybit_liqs \
                    else fetcher(symbol, limit=200)
            if chunk:
                print(f"  [liq] {name:<14}: {len(chunk):>3} events", flush=True)
                all_liqs.extend(chunk)
            else:
                print(f"  [liq] {name:<14}: 0 events (skipped)", flush=True)
        except Exception as e:
            print(f"  [liq] {name:<14}: failed ({str(e)[:60]})", flush=True)

    if not all_liqs:
        print(f"  [liq] all sources empty — proceeding with vp+wick only", flush=True)
        with _lock:
            _cache[cache_key] = (now, [])
        return []

    # Cluster by price bucket — group within 0.2% of each other
    all_liqs.sort(key=lambda x: x["price"])
    clusters: List[Dict] = []
    bucket_pct = 0.002        # 0.2% buckets
    cur_bucket: List[Dict] = []
    cur_anchor: Optional[float] = None
    for ev in all_liqs:
        p = ev["price"]
        if p <= 0:
            continue
        if cur_anchor is None or abs(p - cur_anchor) / cur_anchor < bucket_pct:
            cur_bucket.append(ev)
            cur_anchor = p if cur_anchor is None else cur_anchor
        else:
            if cur_bucket:
                tot_mag = sum(e["magnitude"] for e in cur_bucket)
                if tot_mag >= min_magnitude_usd:
                    clusters.append({
                        "price":     sum(e["price"] * e["magnitude"] for e in cur_bucket) / tot_mag,
                        "magnitude": tot_mag,
                        "n_events":  len(cur_bucket),
                        "side":      max(set(e["side"] for e in cur_bucket),
                                          key=lambda s: sum(1 for e in cur_bucket if e["side"] == s)),
                        "sources":   list(set(e["source"] for e in cur_bucket)),
                    })
            cur_bucket = [ev]
            cur_anchor = p
    # final flush
    if cur_bucket:
        tot_mag = sum(e["magnitude"] for e in cur_bucket)
        if tot_mag >= min_magnitude_usd:
            clusters.append({
                "price":     sum(e["price"] * e["magnitude"] for e in cur_bucket) / tot_mag,
                "magnitude": tot_mag,
                "n_events":  len(cur_bucket),
                "side":      "mixed",
                "sources":   list(set(e["source"] for e in cur_bucket)),
            })

    clusters.sort(key=lambda x: x["magnitude"], reverse=True)
    clusters = clusters[:30]          # top 30 by magnitude
    print(f"  [liq] aggregated into {len(clusters)} clusters "
          f"(max magnitude ${clusters[0]['magnitude']:,.0f})" if clusters
          else f"  [liq] no significant clusters", flush=True)

    with _lock:
        _cache[cache_key] = (now, clusters)
    return clusters
