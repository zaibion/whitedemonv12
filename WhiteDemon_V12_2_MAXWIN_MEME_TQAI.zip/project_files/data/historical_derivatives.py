"""Historical derivatives features (V9.5 no-leakage).

Builds timestamp-aligned funding / open-interest / long-short-ratio features.
Uses public APIs when available and falls back to neutral values without failing.

Main source: Binance USD-M futures public endpoints.
Optional supplemental source: OKX funding-rate-history.
"""
from __future__ import annotations
from typing import Dict, Any
import os, time, json, hashlib, datetime
import requests
import pandas as pd
import numpy as np

CACHE_DIR = os.environ.get("WD_DERIV_CACHE", "derivatives_cache")
os.makedirs(CACHE_DIR, exist_ok=True)


def _sym_usdt(symbol: str) -> str:
    s = (symbol or "BTC-USD").upper().replace("-", "")
    if s.endswith("USD") and not s.endswith("USDT"):
        s = s[:-3] + "USDT"
    if not s.endswith("USDT"):
        s = s.split("USDT")[0] + "USDT"
    return s


def _okx_inst(symbol: str) -> str:
    base = _sym_usdt(symbol).replace("USDT", "")
    return f"{base}-USDT-SWAP"


def _cache_path(symbol: str, start_ms: int, end_ms: int) -> str:
    key = f"{_sym_usdt(symbol)}_{start_ms}_{end_ms}_v95"
    h = hashlib.md5(key.encode()).hexdigest()[:16]
    return os.path.join(CACHE_DIR, f"deriv_{h}.csv")


def _get_json(url: str, params: dict, timeout: int = 10):
    r = requests.get(url, params=params, timeout=timeout)
    r.raise_for_status()
    return r.json()


def _fetch_binance_funding(sym: str, start_ms: int, end_ms: int) -> pd.DataFrame:
    rows = []
    cur = start_ms
    base = "https://fapi.binance.com/fapi/v1/fundingRate"
    # Binance funding history is 8h-ish; limit max 1000.
    for _ in range(30):
        try:
            js = _get_json(base, {"symbol": sym, "startTime": cur, "endTime": end_ms, "limit": 1000})
        except Exception:
            break
        if not js:
            break
        rows.extend(js)
        last = int(js[-1].get("fundingTime", cur))
        if last <= cur or last >= end_ms:
            break
        cur = last + 1
        time.sleep(0.05)
    if not rows:
        return pd.DataFrame(columns=["open_time", "funding_rate"])
    out = pd.DataFrame(rows)
    out["open_time"] = pd.to_datetime(out["fundingTime"], unit="ms", utc=True)
    out["funding_rate"] = pd.to_numeric(out["fundingRate"], errors="coerce").fillna(0.0)
    return out[["open_time", "funding_rate"]].drop_duplicates("open_time").sort_values("open_time")


def _fetch_binance_oi(sym: str, start_ms: int, end_ms: int) -> pd.DataFrame:
    rows = []
    cur = start_ms
    base = "https://fapi.binance.com/futures/data/openInterestHist"
    # Use 1d period to avoid huge pagination while still avoiding leakage.
    for _ in range(20):
        try:
            js = _get_json(base, {"symbol": sym, "period": "1d", "startTime": cur, "endTime": end_ms, "limit": 500})
        except Exception:
            break
        if not js:
            break
        rows.extend(js)
        last = int(js[-1].get("timestamp", cur))
        if last <= cur or last >= end_ms:
            break
        cur = last + 1
        time.sleep(0.05)
    if not rows:
        return pd.DataFrame(columns=["open_time", "oi_raw"])
    out = pd.DataFrame(rows)
    out["open_time"] = pd.to_datetime(out["timestamp"], unit="ms", utc=True)
    # sumOpenInterest is contracts; normalize later after merge.
    out["oi_raw"] = pd.to_numeric(out.get("sumOpenInterest", 0), errors="coerce").fillna(0.0)
    return out[["open_time", "oi_raw"]].drop_duplicates("open_time").sort_values("open_time")


def _fetch_binance_ls(sym: str, start_ms: int, end_ms: int) -> pd.DataFrame:
    rows = []
    cur = start_ms
    base = "https://fapi.binance.com/futures/data/globalLongShortAccountRatio"
    for _ in range(20):
        try:
            js = _get_json(base, {"symbol": sym, "period": "1d", "startTime": cur, "endTime": end_ms, "limit": 500})
        except Exception:
            break
        if not js:
            break
        rows.extend(js)
        last = int(js[-1].get("timestamp", cur))
        if last <= cur or last >= end_ms:
            break
        cur = last + 1
        time.sleep(0.05)
    if not rows:
        return pd.DataFrame(columns=["open_time", "ls_ratio"])
    out = pd.DataFrame(rows)
    out["open_time"] = pd.to_datetime(out["timestamp"], unit="ms", utc=True)
    out["ls_ratio"] = pd.to_numeric(out.get("longShortRatio", 1.0), errors="coerce").fillna(1.0)
    return out[["open_time", "ls_ratio"]].drop_duplicates("open_time").sort_values("open_time")


def _fetch_okx_funding(symbol: str, start_ms: int, end_ms: int) -> pd.DataFrame:
    # OKX endpoint returns recent history and may ignore large ranges; use only as supplemental.
    try:
        inst = _okx_inst(symbol)
        js = _get_json("https://www.okx.com/api/v5/public/funding-rate-history", {"instId": inst, "limit": 100})
        data = js.get("data", []) if isinstance(js, dict) else []
        if not data:
            return pd.DataFrame(columns=["open_time", "okx_funding_rate"])
        out = pd.DataFrame(data)
        out["open_time"] = pd.to_datetime(pd.to_numeric(out["fundingTime"], errors="coerce"), unit="ms", utc=True)
        out["okx_funding_rate"] = pd.to_numeric(out["fundingRate"], errors="coerce").fillna(0.0)
        out = out[(out["open_time"].astype("int64") // 1_000_000 >= start_ms) &
                  (out["open_time"].astype("int64") // 1_000_000 <= end_ms)]
        return out[["open_time", "okx_funding_rate"]].drop_duplicates("open_time").sort_values("open_time")
    except Exception:
        return pd.DataFrame(columns=["open_time", "okx_funding_rate"])


def historical_derivatives_features(df: pd.DataFrame, symbol: str) -> pd.DataFrame:
    """Return dataframe with one row per df row: historical derivatives aligned by timestamp.

    No lookahead: uses merge_asof backward so each candle gets the most recent
    derivatives datapoint at or before that candle timestamp.
    """
    if df is None or len(df) == 0 or "open_time" not in df.columns:
        return pd.DataFrame({"funding_rate": [], "funding_ann": [], "oi_raw": [], "ls_ratio": [], "ls_long_bias": []})
    times = pd.to_datetime(df["open_time"], utc=True, errors="coerce")
    base = pd.DataFrame({"open_time": times}).dropna().sort_values("open_time")
    if len(base) != len(df):
        # preserve row count with neutral fallback on malformed timestamps
        return _neutral(len(df))

    start_ms = int(base["open_time"].iloc[0].value // 1_000_000)
    end_ms = int(base["open_time"].iloc[-1].value // 1_000_000)
    cp = _cache_path(symbol, start_ms, end_ms)
    if os.path.exists(cp):
        try:
            cached = pd.read_csv(cp)
            req = ["funding_rate", "funding_ann", "oi_raw", "ls_ratio", "ls_long_bias"]
            if len(cached) == len(df) and all(c in cached.columns for c in req):
                out_cached = cached[req].apply(pd.to_numeric, errors="coerce")
                if np.isfinite(out_cached.fillna(0).values).all():
                    return out_cached.fillna({"funding_rate":0.0,"funding_ann":0.0,"oi_raw":0.0,"ls_ratio":1.0,"ls_long_bias":0.0})
        except Exception:
            pass

    sym = _sym_usdt(symbol)
    merged = base.copy()
    try:
        funding = _fetch_binance_funding(sym, start_ms, end_ms)
        if len(funding):
            merged = pd.merge_asof(merged, funding, on="open_time", direction="backward", tolerance=pd.Timedelta(hours=16))
    except Exception:
        pass
    try:
        okx = _fetch_okx_funding(symbol, start_ms, end_ms)
        if len(okx):
            merged = pd.merge_asof(merged, okx, on="open_time", direction="backward", tolerance=pd.Timedelta(hours=16))
    except Exception:
        pass
    try:
        oi = _fetch_binance_oi(sym, start_ms, end_ms)
        if len(oi):
            merged = pd.merge_asof(merged, oi, on="open_time", direction="backward", tolerance=pd.Timedelta(days=3))
    except Exception:
        pass
    try:
        ls = _fetch_binance_ls(sym, start_ms, end_ms)
        if len(ls):
            merged = pd.merge_asof(merged, ls, on="open_time", direction="backward", tolerance=pd.Timedelta(days=3))
    except Exception:
        pass

    # Combine/fallback.
    if "funding_rate" not in merged.columns:
        merged["funding_rate"] = 0.0
    if "okx_funding_rate" in merged.columns:
        # use average where both exist; otherwise binance/default
        merged["funding_rate"] = pd.concat([merged["funding_rate"], merged["okx_funding_rate"]], axis=1).mean(axis=1, skipna=True)
    merged["funding_rate"] = pd.to_numeric(merged["funding_rate"], errors="coerce").fillna(0.0)
    merged["funding_ann"] = merged["funding_rate"] * 3 * 365

    if "oi_raw" not in merged.columns:
        merged["oi_raw"] = 0.0
    merged["oi_raw"] = pd.to_numeric(merged["oi_raw"], errors="coerce").fillna(0.0)
    # No-lookahead normalization: each row uses only expanding past median.
    _oi_raw_orig = merged["oi_raw"].copy()
    _denom = _oi_raw_orig.replace(0, np.nan).expanding(min_periods=1).median().ffill().fillna(1.0)
    merged["oi_raw"] = (_oi_raw_orig / _denom.clip(lower=1.0)).replace([np.inf, -np.inf], 0).fillna(0).clip(0, 10)

    if "ls_ratio" not in merged.columns:
        merged["ls_ratio"] = 1.0
    merged["ls_ratio"] = pd.to_numeric(merged["ls_ratio"], errors="coerce").fillna(1.0).clip(0.1, 10)
    merged["ls_long_bias"] = np.where(merged["ls_ratio"] > 1.2, 1.0, np.where(merged["ls_ratio"] < 0.8, -1.0, 0.0))

    out = merged[["funding_rate", "funding_ann", "oi_raw", "ls_ratio", "ls_long_bias"]].reset_index(drop=True)
    if len(out) != len(df):
        out = _neutral(len(df))
    try:
        out.to_csv(cp, index=False)
    except Exception:
        pass
    return out


def _neutral(n: int) -> pd.DataFrame:
    return pd.DataFrame({
        "funding_rate": np.zeros(n, dtype=float),
        "funding_ann": np.zeros(n, dtype=float),
        "oi_raw": np.zeros(n, dtype=float),
        "ls_ratio": np.ones(n, dtype=float),
        "ls_long_bias": np.zeros(n, dtype=float),
    })
