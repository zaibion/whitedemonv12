"""FinBERT news sentiment — from engine."""
from _engine import FinBERTSentiment, fetch_sentiment
