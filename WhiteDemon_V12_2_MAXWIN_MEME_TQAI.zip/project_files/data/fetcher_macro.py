"""Macro context (DXY, VIX, SPX, Gold, 10Y) — from engine."""
from _engine import fetch_macro_context, attach_macro_features
