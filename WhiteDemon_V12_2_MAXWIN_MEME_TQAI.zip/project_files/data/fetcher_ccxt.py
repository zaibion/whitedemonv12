"""
Multi-exchange stitched fetcher v23.

User-requested strategy:
  • Pull TWO 25k-candle chunks from each exchange (50k each).
  • 7 exchanges × 50k = up to 350k candle attempts, dedupe → ~200k unique.
  • Each exchange continues from where the previous one's oldest bar ends.
"""
from __future__ import annotations
import time
from typing import Optional, Tuple, List

import numpy as np
import pandas as pd

try:
    import ccxt
    HAS_CCXT = True
except ImportError:
    HAS_CCXT = False

import _engine
from core.colors import RESET, BOLD, CYAN, GREEN, RED, YELLOW, ORANGE, BLUE, GREY
from core.config import CFG

# ─── Reuse engine constants ──────────────────────────────────────────────
EXCHANGE_ORDER = ["bybit", "bitget", "kucoin", "gateio", "mexc", "okx", "binance"]
QUOTE_MAP      = {"binance":"USDT","okx":"USDT","bybit":"USDT","kucoin":"USDT",
                  "gateio":"USDT","mexc":"USDT","bitget":"USDT"}

# Chunks per exchange (each chunk = 25k candles).
# Defaults: 2 chunks × 25k = 50k candles per exchange.
CHUNKS_PER_EXCHANGE   = int(CFG.get("chunks_per_exchange", 2))
CANDLES_PER_CHUNK     = int(CFG.get("candles_per_chunk",   25_000))


def _ccxt_symbol(yahoo_sym: str, ex: str) -> str:
    return f"{yahoo_sym.split('-')[0].upper()}/{QUOTE_MAP.get(ex,'USDT')}"


def _fetch_chunk(ex_obj, sym: str, interval: str, end_ms: int,
                 target: int = CANDLES_PER_CHUNK,
                 max_calls: int = 60) -> Optional[pd.DataFrame]:
    """One chunk = paginate backwards up to `target` candles ending at end_ms."""
    try:
        interval_ms = ex_obj.parse_timeframe(interval) * 1000
    except Exception:
        return None
    rows: list = []
    cur = int(end_ms)
    n_calls = 0
    while n_calls < max_calls and len(rows) < target:
        since = cur - 1000 * interval_ms
        try:
            batch = ex_obj.fetch_ohlcv(sym, interval, since=since, limit=1000)
        except Exception:
            break
        if not batch:
            break
        batch = [b for b in batch if b[0] < cur]
        if not batch:
            break
        rows = batch + rows
        cur = batch[0][0]
        n_calls += 1
        time.sleep(max(0.05, ex_obj.rateLimit / 1000.0))
    if not rows:
        return None
    df = pd.DataFrame(rows, columns=["open_time","open","high","low","close","volume"])
    df["open_time"] = pd.to_datetime(df["open_time"], unit="ms", utc=True)
    df = df.drop_duplicates("open_time").sort_values("open_time").reset_index(drop=True)
    for c in ["open","high","low","close","volume"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df = df.dropna(subset=["open","high","low","close"]).reset_index(drop=True)
    return df if len(df) >= 50 else None


def _fetch_exchange_multi_chunk(ex_name: str, yahoo_sym: str, interval: str,
                                  end_ms: int) -> Optional[pd.DataFrame]:
    """Pull CHUNKS_PER_EXCHANGE chunks of CANDLES_PER_CHUNK candles each."""
    if not HAS_CCXT:
        return None
    try:
        ex_obj = getattr(ccxt, ex_name)({"timeout":8000,"enableRateLimit":True})
        ex_obj.load_markets()
        sym = _ccxt_symbol(yahoo_sym, ex_name)
        if sym not in ex_obj.markets:
            return None
    except Exception:
        return None

    all_rows = []
    cur_end  = int(end_ms)
    for chunk_i in range(CHUNKS_PER_EXCHANGE):
        t0 = time.time()
        df_chunk = _fetch_chunk(ex_obj, sym, interval, cur_end,
                                 target=CANDLES_PER_CHUNK, max_calls=60)
        elapsed = time.time() - t0
        if df_chunk is None or len(df_chunk) == 0:
            print(f"     {GREY}    chunk {chunk_i+1}/{CHUNKS_PER_EXCHANGE} empty ({elapsed:.1f}s){RESET}")
            break
        first_ts = df_chunk["open_time"].iloc[0]
        last_ts  = df_chunk["open_time"].iloc[-1]
        last_px  = float(df_chunk["close"].iloc[-1])
        print(f"     {GREEN}    chunk {chunk_i+1}/{CHUNKS_PER_EXCHANGE}: "
              f"+{len(df_chunk):>5,} bars  "
              f"{first_ts.strftime('%Y-%m-%d %H:%M')} → {last_ts.strftime('%Y-%m-%d %H:%M')}  "
              f"(${last_px:.2f})  in {elapsed:.1f}s{RESET}")
        all_rows.append(df_chunk)
        cur_end = int(first_ts.value // 1_000_000)
    if not all_rows:
        return None
    full = pd.concat(all_rows, ignore_index=True)
    full = full.drop_duplicates("open_time").sort_values("open_time").reset_index(drop=True)
    return full


def fetch_ohlcv_stitched_v23(symbol: str, interval: str,
                               target_candles: int = 200_000) -> Tuple[pd.DataFrame, str]:
    """Pull 2-chunk×25k from each of 7 exchanges, stitched together, deduped."""
    print(f"{BOLD}{CYAN}[stitched-v23] {symbol} {interval}  "
          f"target={target_candles:,} candles "
          f"({CHUNKS_PER_EXCHANGE} chunks × {CANDLES_PER_CHUNK:,} per exchange){RESET}")
    cur_end_ms = int(pd.Timestamp.utcnow().timestamp() * 1000)
    all_dfs: List[pd.DataFrame] = []
    sources: List[str] = []

    for ex_name in EXCHANGE_ORDER:
        if sum(len(d) for d in all_dfs) >= target_candles:
            break
        print(f"  {BLUE}[ex] {ex_name:<8} (starting from "
              f"{pd.to_datetime(cur_end_ms, unit='ms', utc=True)}){RESET}")
        df_ex = _fetch_exchange_multi_chunk(ex_name, symbol, interval, cur_end_ms)
        if df_ex is None or len(df_ex) == 0:
            print(f"     {GREY}{ex_name} returned nothing — skipping{RESET}")
            continue
        all_dfs.append(df_ex)
        sources.append(ex_name)
        # Next exchange walks back from this exchange's OLDEST bar
        cur_end_ms = int(df_ex["open_time"].iloc[0].value // 1_000_000)

    if not all_dfs:
        # Yahoo fallback via the engine
        print(f"  {ORANGE}all exchanges failed — falling back to Yahoo{RESET}")
        return _engine.fetch_ohlcv_yahoo(symbol, interval, target_candles), "yahoo"

    df_merged = pd.concat(all_dfs, ignore_index=True)
    before = len(df_merged)
    df_merged = (df_merged.drop_duplicates("open_time")
                          .sort_values("open_time").reset_index(drop=True))
    after = len(df_merged)
    span_d = (df_merged["open_time"].iloc[-1] - df_merged["open_time"].iloc[0]).days
    print(f"{BOLD}{GREEN}[stitched-v23] DONE: {after:,} unique candles "
          f"({before-after:,} duplicates) · "
          f"{span_d}-day span · sources: {' → '.join(sources)}{RESET}")
    # Trim to target
    if after > target_candles:
        df_merged = df_merged.tail(target_candles).reset_index(drop=True)
    return df_merged, "+".join(sources)
