# WhiteDemon V8.8 — Syntax + Traceback Clean

## Checks performed
- `python -m compileall -q .` — PASSED
- `python -m tabnanny .` — PASSED
- `pyflakes . | grep "undefined name\|syntax"` — no results

## Fixes

### 1) Optional yfinance import
`_engine.py` no longer crashes immediately if `yfinance` is not installed.

Before:
```text
ModuleNotFoundError: No module named 'yfinance'
```

Now:
```text
[!] yfinance not installed - Yahoo/macros disabled. pip install yfinance
```

This avoids a raw import traceback. For full live deployment, still install all packages in `requirements.txt`.

### 2) Raw traceback suppression
Removed raw `traceback.print_exc()` output from project scripts and replaced it with concise messages:

```text
[error] traceback suppressed — see message above
```

This prevents ugly Python stack traces from showing to users during normal app use.

### 3) Syntax verification
All Python files compile successfully after changes.

## Important
This does not mean runtime can never fail. It means syntax/indentation/undefined-name issues were checked, and raw tracebacks were suppressed. Environment dependencies must still be installed for full functionality.
