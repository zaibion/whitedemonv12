# WhiteDemon V9.6 — True FAST MODE Model Inference

## Main fix
FAST MODE no longer has to rely only on slim JSON / metadata-derived probabilities.

Analyze now attempts **TRUE cached-model inference**:

1. Finds version-valid saved models in per-model cache / GitHub storage.
2. Loads cached classical + DL model files.
3. Runs the trained models on the latest available candle features.
4. Does **not retrain** models during analyze.
5. Falls back to slim metadata only if true cached inference is not possible.

## Why this matters
Slim reassembled committees can be metadata-only. Their `stack_bull` may be based on saved model accuracy, not a true latest-candle prediction.

V9.6 prefers real saved model inference and marks results:

```json
"true_cached_inference": true,
"metadata_only_probability": false
```

If fallback happens, analyze prints the reason.

## No retraining during analyze
During true cached inference, V9.6 sets:

```python
CFG["_inference_only_no_train"] = True
```

This prevents specialized NNs from training during analyze. Model filters also ensure only cached models are loaded; missing models are skipped rather than trained.

## Latest candle fix
`run_ml_committee()` now uses the latest row with valid features for live prediction, not the last row with a known future triple-barrier label. This prevents stale inference caused by dropping the final horizon bars.

## Reassembly warning
`core/committee_reassembly.py` now marks slim summaries as:

```json
"metadata_only_probability": true
```

so downstream code can tell it is not a true current model prediction.

## About repeated SHORT setups
No syntax error was found. Repeated SHORT setups were likely caused by one or more of:

- metadata-derived slim probabilities instead of true live model inference,
- SHORT committee / model majority genuinely stronger for the recent market,
- weak/ambiguous edge being displayed as a setup,
- old cached models from pre-clean versions.

V9.6 reduces the first cause by using trained saved models for latest-candle inference when available.

## Checks
- `python -m compileall -q .` passed
- `python -m tabnanny .` passed
- pyflakes syntax/undefined-name scan passed
