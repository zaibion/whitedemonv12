#!/usr/bin/env python3
"""
run_institutional.py — WhiteDemon V12 Institutional Launcher
CIO approved — Kelly capped, PSI gated, embargo purged
"""
import os
os.environ.setdefault("INSTITUTIONAL_AUTO", "1")
os.environ.setdefault("PYTHONUNBUFFERED", "1")

print("\033[1;36m╔════════════════════════════════════════════════════════════╗\033[0m")
print("\033[1;36m║  WhiteDemon V12.0 — INSTITUTIONAL GRADE                   ║\033[0m")
print("\033[1;36m║  CIO • Head Quant • ML Scientist • Risk Manager          ║\033[0m")
print("\033[1;36m╚════════════════════════════════════════════════════════════╝\033[0m")
print("  • Meta-labeler v22.1 — embargo 48 • threshold 0.62")
print("  • Committee v24.2 — LLM constant filter • LGBM hardened")
print("  • Risk IRB-v12 — Kelly 0.25 cap • RR 1:2.5 • DD 3.5% CB")
print("  • PSI drift circuit breaker • 7-layer elite entry gate")
print()

# ensure patches install early
try:
    from core.engine_patches import apply_engine_patches
    apply_engine_patches()
    print("\033[32m[INSTITUTIONAL] patches armed — starting engine…\033[0m\n")
except Exception as e:
    print(f"\033[33m[INSTITUTIONAL] patch warning: {e}\033[0m\n")

# hand off to standard run.py
import runpy
runpy.run_path("run.py", run_name="__main__")
