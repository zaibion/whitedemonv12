"""
train_sl_nn.py — WhiteDemon_V8.2

Incremental + verified Bayesian SL Placement NN trainer.

Modes:
  --mode scratch  : train from zero on N candles (replaces existing batch)
  --mode next     : continue from previous batch — fetches OLDER N candles
                     starting where last batch ended, fine-tunes the saved NN
  --mode specific : train on a specific batch label (re-trains that batch)
  --list          : show all SL-NN batches saved for current pair/TF
  --wipe          : delete all SL-NN batches for current pair/TF

Each batch is saved separately to per-model cache so anyone can resume:
    perm/<SYM>/<TF>/BOTH/<COUNT>/nn/sl_placement.bundle.gz       (latest)
    perm/<SYM>/<TF>/BOTH/<COUNT>/nn/sl_placement_batch<i>.bundle.gz  (history)

Save chain: Firebase → Supabase → GitHub → local disk fallback.
After save we verify the file IS readable back from storage before reporting OK.

Usage examples:
  python train_sl_nn.py --mode scratch --candles 10000 --epochs 20
  python train_sl_nn.py --mode next    --candles 10000 --epochs 15  # next 10k older
  python train_sl_nn.py --list
  python train_sl_nn.py --wipe
"""
from __future__ import annotations
import argparse, sys, os, time, json, datetime

from core.gpu_setup import enable_gpu; enable_gpu(verbose=True)
from core.config import CFG, SYMBOL, TF_LABEL, PAIR, TF, apply_selection
from core.colors import RESET, BOLD, CYAN, GREEN, RED, YELLOW, GREY
from core.storage import STORE
from core import per_model_cache as pmc
from data.fetcher_ccxt import fetch_ohlcv_stitched_v23
from indicators.basic import calc_atr

apply_selection(PAIR, TF)


# ──────────────────────────────────────────────────────────────────────────
# Per-pair batch registry — tracks every SL-NN training round
# ──────────────────────────────────────────────────────────────────────────
def _registry_key():
    return f"sl_nn_registry_{SYMBOL.replace('-','_')}_{TF_LABEL}"


def _load_registry() -> dict:
    r = STORE.get_json(_registry_key()) or {}
    r.setdefault("batches", [])
    r.setdefault("last_ts_end", None)   # timestamp of OLDEST bar already used
    r.setdefault("symbol", SYMBOL)
    r.setdefault("tf", TF_LABEL)
    return r


def _save_registry(r: dict) -> bool:
    r["updated_at"] = datetime.datetime.utcnow().isoformat() + "Z"
    return STORE.put_json(_registry_key(), r,
                           message=f"SL-NN registry {SYMBOL}/{TF_LABEL}")


# ──────────────────────────────────────────────────────────────────────────
# Verified save — checks the blob is actually readable back from storage
# ──────────────────────────────────────────────────────────────────────────
def _verified_save_nn(sym, tf, count, name, wrapper, meta) -> tuple[bool, str]:
    """Save NN AND verify the bytes round-trip through storage.
    Returns (ok, where) where where ∈ {"github","supabase","firebase","disk","none"}."""
    print(f"\n  {CYAN}[verify] saving + verifying {name} (count={count})…{RESET}")
    ok = pmc.save_nn(sym, tf, count, name, wrapper, meta=meta)
    if not ok:
        return False, "none"
    # Re-load into a fresh wrapper to prove the bundle is intact
    from neural_nets.sl_placement_nn import SLPlacementWrapper
    probe = SLPlacementWrapper()
    if pmc.load_nn(sym, tf, count, name, probe):
        # Where did it land? Check storage.list() for the key
        key = f"perm/{sym.replace('-','_')}/{tf}/BOTH/{count}/nn/{name}.bundle.gz"
        # Try GitHub by listing the directory
        where = "unknown"
        try:
            for b in STORE.backends:
                files = b.list(f"blobs/perm/{sym.replace('-','_')}/{tf}/BOTH/{count}/nn")
                if any(f.endswith(f"{name}.bundle.gz") or f.endswith(f"{name}.bundle.gz.gz")
                       for f in files):
                    where = b.name
                    break
        except Exception:
            pass
        if where == "unknown":
            # Probably saved to disk fallback
            from core.per_model_cache import _disk_path
            if os.path.exists(_disk_path(f"blobs/{key}")) or \
               os.path.exists(_disk_path(f"blobs/{key}.gz")):
                where = "disk"
        print(f"  {GREEN}✓ VERIFIED on {where} — bundle is round-trip readable{RESET}")
        return True, where
    else:
        print(f"  {RED}✗ verify-read FAILED — save did not persist{RESET}")
        return False, "none"


# ──────────────────────────────────────────────────────────────────────────
# Modes
# ──────────────────────────────────────────────────────────────────────────
def cmd_list():
    r = _load_registry()
    print(f"\n{BOLD}{CYAN}━━ SL-NN batches for {SYMBOL} @ {TF_LABEL} ━━{RESET}\n")
    if not r["batches"]:
        print(f"  {GREY}(none yet — train with: python train_sl_nn.py --mode scratch --candles 10000){RESET}")
        return
    print(f"   #  | candles | epochs | mode    | train_acc | range                  | saved      | where")
    print(f"   ── | ─────── | ────── | ─────── | ───────── | ────────────────────── | ────────── | ──────────")
    for i, b in enumerate(r["batches"], 1):
        rng = f"{(b.get('ts_start') or '?')[:10]} → {(b.get('ts_end') or '?')[:10]}"
        print(f"  {i:>2}  | {b.get('n_candles',0):>7,} | {b.get('epochs',0):>6} | "
              f"{b.get('mode','?'):<7} | {b.get('train_acc',0):>9.3f} | {rng:<22} | "
              f"{(b.get('saved_at') or '?')[:10]} | {b.get('saved_to','?')}")
    print(f"\n  last_ts_end (cursor): {r.get('last_ts_end')}")


def cmd_wipe():
    r = _load_registry()
    if not r["batches"]:
        print(f"  {YELLOW}nothing to wipe{RESET}"); return
    print(f"  {RED}⚠ wiping {len(r['batches'])} SL-NN batches for {SYMBOL} @ {TF_LABEL}{RESET}")
    if input("  type 'y' to confirm: ").strip().lower() != "y":
        print(f"  {YELLOW}cancelled{RESET}"); return
    # Mark each batch as deleted in storage by overwriting with an empty marker
    from core.storage import STORE
    for b in r["batches"]:
        cnt = b.get("n_candles") or b.get("count") or 0
        key = f"perm/{SYMBOL.replace('-','_')}/{TF_LABEL}/BOTH/{cnt}/nn/sl_placement.bundle.gz"
        try:
            for backend in STORE.backends:
                # write a tiny "deleted" blob (we can't true-delete from git history)
                backend.put(f"blobs/{key}", b"DELETED", message="wipe SL-NN batch")
        except Exception: pass
    r["batches"] = []
    r["last_ts_end"] = None
    _save_registry(r)
    print(f"  {GREEN}✓ registry cleared; old blobs marked deleted{RESET}")


def cmd_train(mode: str, n_candles: int, epochs: int, batch: int, lr: float,
              horizon: int):
    print(f"\n{BOLD}{CYAN}━━ SL-NN TRAIN ({mode}) · {SYMBOL} @ {TF_LABEL} ━━{RESET}\n")
    print(f"  candles : {n_candles:,}")
    print(f"  epochs  : {epochs}")
    print(f"  horizon : {horizon} bars forward simulation")
    print(f"  mode    : {mode}\n")

    registry = _load_registry()

    # Determine how many candles to fetch:
    #   scratch  → fetch latest n_candles
    #   next     → fetch  n_candles ENDING at last_ts_end (or latest if first batch)
    #   specific → fetch latest n_candles, but mark as that count's batch
    if mode == "next" and registry.get("last_ts_end"):
        # Engine's fetch_ohlcv_stitched_v23 doesn't accept "end_ts" directly,
        # so we fetch a LARGE chunk and slice by timestamp.
        print(f"[1/5] Fetching extra-large history (5×{n_candles:,} = "
              f"{5*n_candles:,} bars) to walk back to {registry['last_ts_end'][:19]} …")
        df, src = fetch_ohlcv_stitched_v23(SYMBOL, TF_LABEL, 5 * n_candles)
        if df is None or len(df) < n_candles + 200:
            print(f"  {RED}❌ insufficient data ({len(df) if df is not None else 0}){RESET}")
            sys.exit(1)
        # Slice to "candles ENDING before last_ts_end"
        import pandas as pd
        end_ts = pd.to_datetime(registry["last_ts_end"])
        df = df[df["open_time"] < end_ts].tail(n_candles).reset_index(drop=True)
        if len(df) < horizon + 200:
            print(f"  {YELLOW}only {len(df)} older bars available — using whatever exists{RESET}")
    else:
        print(f"[1/5] Fetching {n_candles:,} latest candles …")
        df, src = fetch_ohlcv_stitched_v23(SYMBOL, TF_LABEL, n_candles)
        if df is None or len(df) < horizon + 200:
            print(f"  {RED}❌ insufficient data ({len(df) if df is not None else 0}){RESET}")
            sys.exit(1)
    print(f"  ✓ {len(df):,} bars  ({df['open_time'].iloc[0]} → {df['open_time'].iloc[-1]})\n")

    print(f"[2/5] Computing ATR + features …")
    df["atr"] = calc_atr(df)

    print(f"[3/5] Loading existing SL NN (if any) for fine-tuning …")
    from neural_nets.sl_placement_nn import SLPlacementWrapper
    nn = SLPlacementWrapper()
    if not nn.enabled:
        print(f"  {RED}torch not available — install it first{RESET}")
        sys.exit(1)
    # Try to load latest batch as starting point (only in "next" mode)
    if mode == "next" and registry["batches"]:
        last_count = registry["batches"][-1].get("n_candles", n_candles)
        if pmc.load_nn(SYMBOL, TF_LABEL, last_count, "sl_placement", nn):
            print(f"  ✓ loaded previous batch (count={last_count}, "
                  f"train_acc={nn.train_acc:.3f}) — fine-tuning from these weights")
        else:
            print(f"  {GREY}(no previous weights found — starting fresh){RESET}")
    elif mode == "specific":
        # Re-train this specific batch from scratch
        print(f"  {GREY}(specific mode — training from scratch on this batch){RESET}")
    else:
        print(f"  {GREY}(scratch mode — fresh weights){RESET}")

    print(f"\n[4/5] Training SL placement NN …")
    t0 = time.time()
    nn.train(df, epochs=epochs, batch_size=batch, lr=lr)
    dt = time.time() - t0
    print(f"  ✓ training done in {dt:.1f}s · train_acc={nn.train_acc:.3f}\n")

    if not nn.trained:
        print(f"  {YELLOW}NN didn't train (insufficient labels). "
              f"Try a bigger --candles value.{RESET}")
        sys.exit(2)

    print(f"[5/5] Saving to per-model cache + verifying round-trip …")
    saved_at = datetime.datetime.utcnow().isoformat() + "Z"
    ts_start = str(df["open_time"].iloc[0])
    ts_end   = str(df["open_time"].iloc[-1])
    meta = {
        "trained_at": saved_at,
        "epochs":     epochs,
        "horizon":    horizon,
        "n_candles":  len(df),
        "ts_start":   ts_start,
        "ts_end":     ts_end,
        "mode":       mode,
        "lr":         lr,
        "batch":      batch,
        "train_acc":  float(nn.train_acc),
    }
    # Save with VERIFICATION
    ok, where = _verified_save_nn(SYMBOL, TF_LABEL, len(df), "sl_placement",
                                   nn, meta=meta)
    if not ok:
        print(f"  {RED}✗ save failed — bytes did NOT persist anywhere.{RESET}")
        sys.exit(3)

    # Also save a versioned copy as `sl_placement_batchN` so user can always
    # roll back to previous training
    batch_num = len(registry["batches"]) + 1
    ok_v, where_v = _verified_save_nn(SYMBOL, TF_LABEL, len(df),
                                       f"sl_placement_batch{batch_num}", nn,
                                       meta=meta)
    print(f"  versioned copy → batch{batch_num}: {'✓' if ok_v else '✗'} ({where_v})")

    # Update registry
    registry["batches"].append({**meta, "saved_at": saved_at, "saved_to": where,
                                 "batch_id": batch_num})
    # In "next" mode, the cursor moves to the OLDEST timestamp of THIS batch
    if mode == "next":
        registry["last_ts_end"] = ts_start
    else:
        # On scratch/specific, the cursor anchors to oldest bar of this fetch
        registry["last_ts_end"] = ts_start
    _save_registry(registry)
    print(f"\n  {GREEN}✓ registry updated. analyze.py + full_pipeline auto-load this NN.{RESET}")
    print(f"  Total batches now: {len(registry['batches'])}\n")


# ──────────────────────────────────────────────────────────────────────────
# CLI
# ──────────────────────────────────────────────────────────────────────────
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["scratch", "next", "specific"],
                    default="scratch")
    ap.add_argument("--candles", type=int, default=10000)
    ap.add_argument("--epochs",  type=int, default=20)
    ap.add_argument("--batch",   type=int, default=64)
    ap.add_argument("--lr",      type=float, default=1e-3)
    ap.add_argument("--horizon", type=int, default=96)
    ap.add_argument("--list",    action="store_true")
    ap.add_argument("--wipe",    action="store_true")
    args = ap.parse_args()

    if args.list:
        cmd_list(); return
    if args.wipe:
        cmd_wipe(); return
    cmd_train(args.mode, args.candles, args.epochs, args.batch, args.lr, args.horizon)


if __name__ == "__main__":
    main()
