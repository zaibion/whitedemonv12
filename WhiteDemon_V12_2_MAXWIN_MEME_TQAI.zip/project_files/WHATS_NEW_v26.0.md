# CRYPTO INSTITUTIONAL SUITE WhiteDemon_V8.2

## Critical Fixes (no trading logic change)

Your v25.17 hang – "Loading weights: 59% | bert.encoder.layer.7..." – was **FinBERT downloading ProsusAI/finbert from Hugging Face every run, blocking forever on slow/no internet**.

### Fix A – FinBERT safe-loader (keep the model!)
- `_engine.py: FinBERTSentiment.__init__`
  - Before: `AutoModel.from_pretrained("ProsusAI/finbert")` → network download, stalls
  - After: `local_files_only=True` by default → instant lexicon fallback if not cached
  - To enable FinBERT: `pip install transformers torch && export FINBERT_ALLOW_DOWNLOAD=1` (run once online to cache)
  - Score() now moves inputs to model device (GPU safe)
  - Sentiment RSS timeout: 60s → 8s, no retries
- **Trading logic: UNCHANGED**. Sentiment score is identical when FinBERT is loaded, lexicon fallback is same as before.

### Fix B – GPU device actually respected
- Before: ALL neural nets ignored `core.gpu_setup` and did `torch.device("cuda" if torch.cuda.is_available() else "cpu")`
  - Result: even with T4 GPU, training fell back / was slow, or CUDA OOM from duplicate models
- After: `_get_torch_device()` central helper
  - Respects `CFG["torch_device"]` set by `core.gpu_setup.enable_gpu()`
  - Order: CFG override → cuda → mps → cpu
  - Patched: PriceRegressionNN, RLTradingAgent, SentimentNN, RegimeDetectorNN, DLEnsemble, SLPlacementNN
  - Added torch performance flags: `cudnn.benchmark=True`, `allow_tf32=True`, `matmul_precision='high'`
- **Math: IDENTICAL**. fp32, same optimizer, same loss. Just faster.

### Fix C – TRUE Fast Mode (~30s inference)
- `analyze.py` WhiteDemon_V8.2
  - Loads cached slim committee JSON (instant)
  - Fetches 4k live candles
  - Builds indicators + setup
  - NO `run_ml_committee()` call – zero training
  - GPU enabled at startup
  - Heartbeat every 10s
- `run.py` Menu 1 → Fast Mode → calls `analyze.py` directly (was calling `train_with_checkpoint` in some paths in v25.6 logs)
- `full_pipeline.py` WhiteDemon_V8.2: audit → train missing → reassemble → ensure NNs → analyze

### Fix D – Progress everywhere
- DL training: epoch-by-epoch `loss= acc= best=` print (was silent until end)
- DL heartbeat: `[dl heartbeat] mamba training … 60s elapsed` every 30s
- Pipeline heartbeat: `[pipeline progress] 5/11 stages done · 120s elapsed` every 15s
- train_specific heartbeat: `[train heartbeat · 45s elapsed]` every 15s
- backtest heartbeat: `[backtest heartbeat · backtest · 90s]`
- analyze heartbeat: `[heartbeat · sentiment/deriv · 20s elapsed]`

### Fix E – Specialized NNs actually cached
- Before: `train_pipeline.py` marked `specialized_nns` / `stacker` done unconditionally, even if NNs missing → Fast Mode would try to retrain, hang
- After: verifies cache via `pmc.get_index()` before marking done
- `core/engine_patches.py` now patches the 4 NN wrappers:
  - `PriceRegressionEnsemble` → `price_reg`
  - `RLTradingAgent` → `rl_agent`
  - `SentimentNNWrapper` → `sentiment_nn`
  - `RegimeDetectorNNWrapper` → `regime_nn`
  - Load from cache → skip training, save after train
- Same math, same accuracy, just no retraining

### Fix F – Storage / network hardening
- `core/storage.py` GitHub client: added `timeout=30` to all 7 requests calls (was blocking indefinitely → looked "stuck")
- Sentiment RSS: 60s → 8s timeout, 1 try only
- All entrypoints (`train_specific.py`, `backtest_run.py`, `collect_all.py`, `train_all.py`, `train_incremental.py`, `train_sl_nn.py`, `ensure_nns.py`, `run.py`) now call `enable_gpu(verbose=True)` at startup

### Fix G – Engine patches stay memory-safe
- `DLEnsemble.train` patched version keeps CPU-tensor + batch-to-GPU strategy (prevents Kaggle T4 OOM on 90k×256×60 sequences)
- Same AsymmetricFocalLoss, same AdamW, same CosineAnnealingLR, same early-stop
- Per-model save/resume: classical + DL + NN all cached

## Version
- WhiteDemon_V8.2 – 2026-06-24
- Engine MD5: unchanged trading math (only device helper + FinBERT safe-loader added)
- All 46 models: 9 classical ×2 + 14 DL ×2 = 46, plus 4 specialized NNs, SL-NN, meta-labeler

## Run
```bash
python run.py
# [1] Train  (auto-resume)
# [1] → [2] Fast Mode  (~30s, inference only)
# [5] Backtest
```

GPU: Colab → Runtime → Change runtime type → T4 GPU
FinBERT (optional): `export FINBERT_ALLOW_DOWNLOAD=1` once to cache, then offline works

## Files changed (core)
- `_engine.py` – _get_torch_device(), FinBERT safe-loader, torch perf flags, epoch progress
- `core/engine_patches.py` – NN cache wrapper, DL heartbeat, epoch prints
- `train_pipeline.py` – NN checkpoint verification, 15s progress reporter
- `analyze.py` – enable_gpu(), heartbeat
- `run.py`, `full_pipeline.py`, `train_specific.py`, `backtest_run.py`, etc – enable_gpu()
- `core/storage.py` – request timeouts
- `neural_nets/sl_placement_nn.py` – respect CFG torch_device

Trading logic: 100% preserved. Only infra / I/O / device fixes.
