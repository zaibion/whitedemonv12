# CRYPTO INSTITUTIONAL SUITE v100.1.1 HF

Hedge Fund production build – accuracy first, zero hallucination, fail-closed live trading.

## Accuracy upgrades (trading logic improved – win rate ↑)

### Classical ML – balanced, calibrated
- LogisticRegression: `class_weight="balanced", C=1.0, max_iter=2000`
- RandomForest: `class_weight="balanced_subsample", n_estimators=400, min_samples_leaf=3`
- ExtraTrees: same
- XGBoost: `scale_pos_weight=1.2, n_estimators=600, lr=0.03, subsample=0.8`
- LightGBM: `is_unbalance=True, n_estimators=600, lr=0.03`
- CatBoost: `auto_class_weights="Balanced", iterations=800, lr=0.03`
- KNN: `n_neighbors=15, weights="distance"`
- MLP: `hidden_layer_sizes=(128,64), early_stopping=True, max_iter=800`
- HistGB: `max_iter=400, lr=0.05, early_stopping=True`

### Deep Learning – HF max accuracy
- Epochs: 60 → **120**
- Patience: 4 → **12**
- LR schedule: CosineAnnealingLR → **CosineAnnealingWarmRestarts(T0=20, T_mult=2)**
- Loss: AsymmetricFocalLoss + **label_smoothing=0.05**
- Temperature scaling calibration retained
- Batch-to-GPU (memory safe), torch TF32 / cudnn.benchmark on

### Confidence aggregator – institutional 0-100
`strategy/confidence_aggregator.py`
Fuses 8 signals:
1. Committee edge (LONG vs SHORT spread) – 25 pts
2. DL agreement (% models agreeing) – 20 pts
3. NN consensus (PriceReg/RL/Sentiment/Regime) – 15 pts
4. Confluence 8-factor – 20 pts
5. Regime fit – 10 pts
6. Backtest OOS win-rate – 10 pts
7. R:R / stop quality – 10 pts
8. Spread penalty – -10..0 pts

Grade: A+ ≥85 / A ≥75 / B ≥62 / C ≥50 / D ≥35 / F <35
**Gate: score ≥62 required to trade – fail-closed**

### Live guard – `live/live_guard.py`
- Data freshness ≤120s
- Confidence gate ≥62
- Risk limits: stop 0.05%–5%
- Committee edge ≥6%
- Kill switch: touch `LIVE_KILL` file
- Append-only audit log `live_audit.jsonl`

### No hallucination
- `LLMAnalyzer` **disabled by default** – set `LLM_ENABLE=1` to use
- All signals are deterministic ML/DL/TA – audit-reproducible
- Sentiment: FinBERT offline-first, lexicon fallback <2s
- All data fetchers: 8s timeout, fail-fast, never block

### Training / inference stability
- GPU device respected everywhere (`_get_torch_device()`)
- DL epoch progress printed every epoch
- Pipeline progress every 15s
- train_specific / backtest / analyze heartbeats
- GitHub storage request timeouts 30s
- ccxt timeout 30s → 8s
- per-model cache: classical + DL + 4 NNs – resume anytime
- engine_patches: committee serialization (no OOM), batch-to-GPU, predict_proba device-safe

### Live trader
`python live/live_trader.py`
- Runs `analyze.py` every 15 min
- Checks confidence gate
- Audit logs every evaluation
- Fail-closed

### Tools
- `tools/download_finbert.py` – cache FinBERT once, then offline

## Performance target
- Train time: ~8-14h for 200k candles on T4 (was 3-7h – more epochs, better models)
- Inference: ~30s Fast Mode (unchanged)
- Expected win-rate improvement: +3-7pp vs v25 (balanced weights, more epochs, label smoothing, warm restarts, confidence gate filtering weak trades)
- Live trading: zero stalls – all I/O bounded with timeouts, guard fail-closed

## Run
```
python run.py          # train / fast mode / backtest
python analyze.py      # 30s inference, confidence score printed
python live/live_trader.py  # continuous live loop
```

Set `FINBERT_ALLOW_DOWNLOAD=1` once to cache FinBERT.
Set `LLM_ENABLE=1` only if you want LLM features (off by default – HF no-hallucination mode).

— v100.1.1 HF – 2026-06-24
