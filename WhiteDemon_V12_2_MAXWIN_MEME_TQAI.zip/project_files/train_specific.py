"""
train_specific.py — Train ONE or a FEW specific models per run.

Use case: parallelize training across multiple Colab cells.

  Cell 1 (running): python train_specific.py        # picks: LONG/xgb + LONG/lgb
  Cell 2 (running): python train_specific.py        # picks: LONG/rf  + LONG/et
  Cell 3 (running): python train_specific.py        # picks: SHORT/lstm

Each cell:
  1. Fetches the same data (cached after first time, so 2nd onwards is instant)
  2. Trains ONLY the models you ticked
  3. Saves each to storage immediately
  4. Other models in the engine are skipped (not trained, not saved)

When all 46 models (9 classical + 14 DL × 2 directions) exist in storage,
FAST MODE works for that pair/TF — no full retrain needed.

USAGE
  python train_specific.py                   # interactive picker
  python train_specific.py --list            # show what's done vs missing
  python train_specific.py --direction LONG  --classical xgb,lgb,rf
  python train_specific.py --direction SHORT --dl lstm,gru,tcn
  python train_specific.py --candles 30000   # custom candle count
  python train_specific.py --missing          # auto-pick everything not yet trained
"""
from __future__ import annotations
import os, sys, argparse, time

# Parse args BEFORE importing core (which mutates sys.argv)
ap = argparse.ArgumentParser()
ap.add_argument("--list",      action="store_true",
                help="show training status table and exit")
ap.add_argument("--missing",   action="store_true",
                help="train ALL not-yet-trained models for current pair/TF")
ap.add_argument("--reassemble", action="store_true",
                help="only rebuild slim FAST-MODE JSON from existing per-model cache (no training)")
ap.add_argument("--direction", choices=["LONG", "SHORT", "BOTH"], default=None)
ap.add_argument("--classical", default="",
                help="comma-separated classical names, e.g. 'xgb,lgb,rf'")
ap.add_argument("--dl",        default="",
                help="comma-separated DL names, e.g. 'lstm,gru,tcn'")
ap.add_argument("--candles",   type=int, default=None,
                help="target candle count (default = CFG target)")
args = ap.parse_args()

# Engine model lists (must match _engine.py exactly)
CLASSICAL_MODELS = ["lr", "knn", "rf", "et", "xgb", "lgb", "cat", "hgb", "mlp"]
DL_MODELS = ["lstm", "bilstm", "gru", "tcn", "wavenet", "transformer",
              "cnn1d", "nbeats", "mamba", "patchtst", "itransformer",
              "frets", "tft", "mamba_pdf"]
ALL_DIRECTIONS = ["LONG", "SHORT"]

from core.config        import SYMBOL, TF_LABEL, CFG
from core.colors        import RESET, BOLD, CYAN, GREEN, YELLOW, RED, ORANGE, GREY
from core               import per_model_cache as pmc
from core.storage       import STORE
from core.engine_patches import (engine_context, set_model_filter,
                                  clear_model_filter, apply_engine_patches)

apply_engine_patches()


def _target_count() -> int:
    if args.candles is not None:
        return int(args.candles)
    return int(CFG.get("target_total_candles", 200_000))


def _status_for(count: int) -> dict:
    """Return {direction: {'classical': [..., 'done'/'missing'], 'dl': [...]}}.
    Useful for the --list table."""
    out = {}
    for d in ALL_DIRECTIONS:
        done = pmc.list_done(SYMBOL, TF_LABEL, d, count)
        out[d] = {
            "classical_done": done["classical"],
            "classical_missing": [m for m in CLASSICAL_MODELS if m not in done["classical"]],
            "dl_done": done["dl"],
            "dl_missing": [m for m in DL_MODELS if m not in done["dl"]],
        }
    return out


def _print_status_table(count: int):
    s = _status_for(count)
    print(f"\n{BOLD}{CYAN}━━ Per-model status: {SYMBOL} @ {TF_LABEL} (count={count:,}) ━━{RESET}\n")
    total_models = (len(CLASSICAL_MODELS) + len(DL_MODELS)) * 2
    done_count = sum(len(s[d]["classical_done"]) + len(s[d]["dl_done"]) for d in ALL_DIRECTIONS)
    pct = 100 * done_count / max(1, total_models)
    print(f"  Overall: {done_count}/{total_models} models trained ({pct:.0f}%)")
    if done_count == total_models:
        print(f"  {GREEN}✅ ALL DONE — FAST MODE is ready for {SYMBOL} @ {TF_LABEL}{RESET}\n")
    else:
        print(f"  {YELLOW}⚠ {total_models - done_count} models still need training{RESET}\n")

    for d in ALL_DIRECTIONS:
        st = s[d]
        print(f"  {BOLD}{d}{RESET}:")
        # Classical
        line = "    classical : "
        for m in CLASSICAL_MODELS:
            if m in st["classical_done"]:
                line += f"{GREEN}{m}✓{RESET} "
            else:
                line += f"{GREY}{m}·{RESET} "
        print(line)
        # DL
        line = "    DL        : "
        for m in DL_MODELS:
            if m in st["dl_done"]:
                line += f"{GREEN}{m}✓{RESET} "
            else:
                line += f"{GREY}{m}·{RESET} "
        print(line)
        print()


def _pick_interactively(count: int) -> dict:
    """Returns {'LONG': {'classical': [...], 'dl': [...]}, 'SHORT': {...}}."""
    s = _status_for(count)
    print(f"\n{BOLD}{CYAN}━━ Pick models to train this run ━━{RESET}\n")
    print(f"  {SYMBOL} @ {TF_LABEL} · target candles={count:,}\n")
    print(f"  Tip: train 2-4 models per cell for best speed.")
    print(f"  Tip: run this same command in multiple Colab cells (different models)")
    print(f"       — they all share the same fetched data via storage.\n")

    print(f"  [1]  Pick INDIVIDUAL models (you tick names)")
    print(f"  [2]  Train ALL not-yet-trained for LONG only")
    print(f"  [3]  Train ALL not-yet-trained for SHORT only")
    print(f"  [4]  Train ALL not-yet-trained for BOTH (this run does everything left)")
    print(f"  [5]  Train just the CLASSICAL models (both directions)")
    print(f"  [6]  Train just the DL models (both directions)")
    print(f"  [0]  Cancel\n")

    choice = input(f"{BOLD}Pick [1-6/0]: {RESET}").strip()
    if choice == "0":
        sys.exit(0)

    pick = {d: {"classical": [], "dl": []} for d in ALL_DIRECTIONS}

    if choice == "2":
        pick["LONG"]["classical"] = s["LONG"]["classical_missing"]
        pick["LONG"]["dl"]        = s["LONG"]["dl_missing"]
    elif choice == "3":
        pick["SHORT"]["classical"] = s["SHORT"]["classical_missing"]
        pick["SHORT"]["dl"]        = s["SHORT"]["dl_missing"]
    elif choice == "4":
        for d in ALL_DIRECTIONS:
            pick[d]["classical"] = s[d]["classical_missing"]
            pick[d]["dl"]        = s[d]["dl_missing"]
    elif choice == "5":
        for d in ALL_DIRECTIONS:
            pick[d]["classical"] = s[d]["classical_missing"]
    elif choice == "6":
        for d in ALL_DIRECTIONS:
            pick[d]["dl"] = s[d]["dl_missing"]
    else:   # "1" or anything else → individual
        for d in ALL_DIRECTIONS:
            missing_cls = s[d]["classical_missing"]
            missing_dl  = s[d]["dl_missing"]
            if not missing_cls and not missing_dl:
                print(f"  {GREEN}{d} fully trained — skipping{RESET}")
                continue
            print(f"\n  {BOLD}{d}{RESET}:")
            if missing_cls:
                print(f"    Classical not trained: {', '.join(missing_cls)}")
                inp = input(f"    Pick classical to train this run "
                            f"(comma-separated names, or 'all', or '' to skip): ").strip().lower()
                if inp == "all":
                    pick[d]["classical"] = missing_cls
                elif inp:
                    pick[d]["classical"] = [m.strip() for m in inp.split(",")
                                              if m.strip() in missing_cls]
            if missing_dl:
                print(f"    DL not trained: {', '.join(missing_dl)}")
                inp = input(f"    Pick DL to train this run "
                            f"(comma-separated names, or 'all', or '' to skip): ").strip().lower()
                if inp == "all":
                    pick[d]["dl"] = missing_dl
                elif inp:
                    pick[d]["dl"] = [m.strip() for m in inp.split(",")
                                       if m.strip() in missing_dl]
    return pick


def _train_one_direction(direction: str, classical: list, dl: list, count: int):
    """Run engine for one direction with model-filter set."""
    if not classical and not dl:
        return None

    print(f"\n{BOLD}{CYAN}━━ Training {direction}: classical={classical or '—'} · dl={dl or '—'} ━━{RESET}\n")

    # We need to actually invoke the same pipeline that loads data + features.
    # Easiest: lazy import the heavy modules + call run_ml_committee with the filter.
    from data.fetcher_ccxt   import fetch_ohlcv_stitched_v23
    from data.fetcher_sentiment import FinBERTSentiment, fetch_sentiment
    from ml_models.committee import run_ml_committee
    from core import checkpoint as ck_mod
    import pickle as _pk, gzip as _gz

    sym, tf = SYMBOL, TF_LABEL
    rid = f"{sym.replace('-','_')}_{tf}"

    # ── 1. Try to reuse the fetched data from training cache ──
    raw_blob_key = f"raw_{rid}.pkl"
    blob = STORE.get_blob(raw_blob_key)
    df = None
    if blob:
        try:
            data = _pk.loads(blob)
            df = data["df"]
            print(f"  ✓ resumed {len(df):,} candles from storage")
        except Exception as e:
            print(f"  {YELLOW}cache load failed ({e}); re-fetching{RESET}")
    if df is None:
        print(f"  ↻ fetching {count:,} fresh candles for {sym} @ {tf} …")
        df, _ = fetch_ohlcv_stitched_v23(sym, tf, count)
        if df is None or len(df) < 500:
            print(f"  {RED}❌ fetch returned only {len(df) if df is not None else 0} bars{RESET}")
            return None
        # Persist for the OTHER cells you'll run in parallel
        try:
            payload = _pk.dumps({"df": df})
            STORE.put_blob(raw_blob_key, payload, compress=True,
                            message=f"raw {sym}/{tf}")
        except Exception:
            pass

    # ── 2. Compute indicators / sentiment quickly ──
    from indicators.basic     import calc_rsi, calc_atr, calc_vwap, calc_cvd, calc_macd
    df["rsi"] = calc_rsi(df["close"])
    df["atr"] = calc_atr(df)
    df["vwap"]= calc_vwap(df)
    df["cvd"] = calc_cvd(df)
    df["macd"], df["macd_sig"], df["macd_hist"] = calc_macd(df["close"])
    nlp = fetch_sentiment(FinBERTSentiment())

    train_cutoff = int(len(df) * 0.95)

    # ── 3. Run engine inside the filtered context ──
    with engine_context(sym, tf, direction, count):
        set_model_filter(classical=classical, dl=dl)
        try:
            t0 = time.time()
            cm = run_ml_committee(df, nlp["score"], train_cutoff,
                                   llm_features=None, direction=direction)
            print(f"\n  {GREEN}✓ {direction} batch finished in {time.time()-t0:.0f}s "
                  f"(only requested models actually trained){RESET}")
        except (RuntimeError, MemoryError) as e:
            # CUDA crash, OOM, etc — DON'T propagate. Saved models stay safe.
            print(f"\n  {RED}❌ {direction} batch error: {str(e)[:200]}{RESET}")
            print(f"  {YELLOW}↩ continuing — already-saved models are preserved.{RESET}")
            # Force CPU if it was a CUDA issue
            if "CUDA" in str(e) or "no kernel image" in str(e):
                import os
                os.environ["CUDA_VISIBLE_DEVICES"] = ""
                print(f"  {YELLOW}↻ CUDA_VISIBLE_DEVICES cleared — restart kernel to retry on CPU{RESET}")
        except Exception as e:
            print(f"\n  {RED}❌ Unexpected error: {type(e).__name__}: {str(e)[:200]}{RESET}")
            print("  [error] traceback suppressed — see message above", flush=True)
            print(f"  {YELLOW}↩ continuing — already-saved models are preserved.{RESET}")
        finally:
            clear_model_filter()


# ════════════════════════════════════════════════════════════════════════
# Main
# ════════════════════════════════════════════════════════════════════════
count = _target_count()

if args.list:
    _print_status_table(count)
    sys.exit(0)

if args.reassemble:
    from core.committee_reassembly import write_slim_for_fast_mode
    print(f"\n{BOLD}{CYAN}━━ Reassembling FAST-MODE slim JSON from cache ━━{RESET}\n")
    ok = write_slim_for_fast_mode(SYMBOL, TF_LABEL, count, require_dl=False)
    _print_status_table(count)
    sys.exit(0 if ok else 1)

if args.missing:
    s = _status_for(count)
    # Respect --direction AND --classical/--dl filters with --missing.
    # Old behavior ignored --classical/--dl whenever --missing was present,
    # so "train one by one" or BBB classical-only steps could accidentally
    # select every missing DL model too.
    dirs = ([args.direction] if args.direction and args.direction != "BOTH"
                              else ALL_DIRECTIONS)
    req_cls = [m.strip().lower() for m in args.classical.split(",") if m.strip()]
    req_dl  = [m.strip().lower() for m in args.dl.split(",")        if m.strip()]
    pick = {d: {"classical": [], "dl": []} for d in ALL_DIRECTIONS}
    for d in dirs:
        miss_cls = s[d]["classical_missing"]
        miss_dl  = s[d]["dl_missing"]
        if req_cls or req_dl:
            pick[d] = {
                "classical": [m for m in miss_cls if m in req_cls],
                "dl":        [m for m in miss_dl  if m in req_dl],
            }
        else:
            pick[d] = {"classical": miss_cls, "dl": miss_dl}
elif args.classical or args.dl:
    directions = ([args.direction] if args.direction and args.direction != "BOTH"
                                  else ALL_DIRECTIONS)
    cls_list = [m.strip().lower() for m in args.classical.split(",") if m.strip().lower() in CLASSICAL_MODELS]
    dl_list  = [m.strip().lower() for m in args.dl.split(",")        if m.strip().lower() in DL_MODELS]
    pick = {d: {"classical": [], "dl": []} for d in ALL_DIRECTIONS}
    for d in directions:
        pick[d]["classical"] = cls_list
        pick[d]["dl"]        = dl_list
else:
    pick = _pick_interactively(count)

# Summary
total = sum(len(pick[d]["classical"]) + len(pick[d]["dl"]) for d in ALL_DIRECTIONS)
if total == 0:
    print(f"\n{YELLOW}Nothing to train.{RESET}")
    _print_status_table(count)
    sys.exit(0)

print(f"\n{BOLD}{CYAN}━━ Plan for this run ━━{RESET}")
for d in ALL_DIRECTIONS:
    if pick[d]["classical"] or pick[d]["dl"]:
        print(f"  {d}: classical={pick[d]['classical'] or '—'} · "
              f"dl={pick[d]['dl'] or '—'}")
print(f"  Total: {total} model(s)\n")

for d in ALL_DIRECTIONS:
    _train_one_direction(d, pick[d]["classical"], pick[d]["dl"], count)

# ── Reassemble slim committee JSON so FAST MODE works ──
from core.committee_reassembly import write_slim_for_fast_mode, is_fully_trained
print(f"\n{BOLD}{CYAN}━━ Reassembling for FAST MODE ━━{RESET}")
ok_both = write_slim_for_fast_mode(SYMBOL, TF_LABEL, count, require_dl=False)
if ok_both:
    print(f"\n  {GREEN}{BOLD}✅ {SYMBOL} @ {TF_LABEL} is FAST-MODE-READY{RESET}")
    print(f"     Now you can run option [1] FAST MODE from the main menu.")
    # Also flag the checkpoint as ready
    try:
        from core import checkpoint as ck_mod
        ck = ck_mod.load(SYMBOL, TF_LABEL)
        for stg in ("fetch_data","indicators","advanced_features","structure",
                     "long_committee","short_committee","long_dl","short_dl",
                     "specialized_nns","stacker","save_dashboard"):
            ck["stages"][stg] = {"done": True}
        ck["verdict"] = "FAST_MODE_READY"
        ck["trained_candles"] = count
        ck_mod.save(ck)
        print(f"     Checkpoint marked FAST_MODE_READY.")
    except Exception as _e:
        print(f"     (couldn't flag checkpoint: {_e})")

# Final status
print(f"\n{BOLD}{GREEN}━━ DONE ━━{RESET}")
_print_status_table(count)
