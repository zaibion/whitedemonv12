# Crypto Suite WhiteDemon_V8.2 — Smart-SL NN: incremental training + verified git save

## ✅ What you asked for

> "everything will be saved in git verify it also stoploss nn smart stoploss as we start training it also save all in git and also i can customize it like train on 10k candles then train on next 10k candles so on or train from scratch okay and all will be saved in menu"

All shipped:

### 1. Incremental SL-NN training (just like ML/DL bit-by-bit flow)

`train_sl_nn.py` now has 3 modes:

| Mode | What it does |
|---|---|
| `--mode scratch` | Train from zero on N latest candles (replaces any existing batch) |
| `--mode next`    | Fetches N **older** candles starting where previous batch ended, fine-tunes from previous batch's weights — true incremental learning |
| `--mode specific`| Re-trains a specific candle count from scratch (doesn't shift cursor) |

Each batch knows its candle range — the registry stores `ts_start` / `ts_end` so the next "next batch" knows exactly where to walk back to.

### 2. Verified save to git (with round-trip check)

Every batch goes through `_verified_save_nn(...)`:

1. Calls `pmc.save_nn` which uses chain **Firebase → Supabase → GitHub → local disk fallback**
2. Each backend already prints `✓ NN sl_placement VERIFIED on github (47.3 KB)` after re-reading the bytes from THAT backend
3. THEN `_verified_save_nn` does a **second-level check**: instantiates a fresh `SLPlacementWrapper`, calls `pmc.load_nn` on the same key, confirms the bundle deserializes correctly
4. Reports `✓ VERIFIED on {backend} — bundle is round-trip readable`
5. **AND** saves a versioned copy `sl_placement_batch{N}.bundle.gz` so you always have rollback history

If verification fails, the trainer exits with code 3 and tells you exactly which backend dropped the data.

### 3. Per-pair batch registry on storage

A new JSON `sl_nn_registry_<sym>_<tf>.json` saved to storage tracks every batch:

```json
{
  "symbol": "ADA-USD",
  "tf": "15m",
  "last_ts_end": "2024-12-20 14:00:00",
  "batches": [
    {"batch_id": 1, "n_candles": 10000, "epochs": 20, "mode": "scratch",
     "ts_start": "2025-01-15", "ts_end": "2026-06-20",
     "train_acc": 0.71, "saved_at": "...", "saved_to": "github"},
    {"batch_id": 2, "n_candles": 10000, "epochs": 15, "mode": "next",
     "ts_start": "2024-08-10", "ts_end": "2025-01-15",
     "train_acc": 0.74, "saved_at": "...", "saved_to": "github"},
    ...
  ]
}
```

`analyze.py` and `train_pipeline.py` auto-load the **latest batch** via `SLPlacementWrapper.load_latest_for(SYMBOL, TF_LABEL)` — they walk the registry from newest to oldest and use the first one that successfully deserializes.

### 4. Full sub-menu under Menu 4 → [11]

```
━━ Smart-SL Placement NN · ADA-USD @ 15m ━━

   #  | candles | epochs | mode    | train_acc | range                  | saved      | where
   ── | ─────── | ────── | ─────── | ───────── | ────────────────────── | ────────── | ──────
    1 |  10,000 |     20 | scratch |     0.712 | 2025-01-15 → 2026-06-20 | 2026-06-22 | github
    2 |  10,000 |     15 | next    |     0.738 | 2024-08-10 → 2025-01-15 | 2026-06-22 | github

  TRAIN:
   [1] 🆕 Train from SCRATCH (replaces existing — pick candle count)
   [2] ⏭  Train NEXT batch (fine-tune from previous + walk back N older bars)
   [3] 🎚 Train on SPECIFIC candle count (custom)

  MANAGE:
   [4] 📋 List all batches saved (with timestamps + where saved)
   [5] 🗑 WIPE all SL-NN batches for this pair
   [0] ↩ back
```

Picking [1], [2] or [3] then asks for size (10k / 30k / 100k / custom) — same UX as the bit-by-bit ML training in Menu 3.

## 🔍 What "verified" really means

When you run `python train_sl_nn.py --mode scratch --candles 10000` you'll see:

```
[5/5] Saving to per-model cache + verifying round-trip …

  [verify] saving + verifying sl_placement (count=10000)…
  [pmc] ⏫ uploading NN sl_placement → firebase-web+supabase+github (47.3 KB)…
  [firebase-web] put RTDB perm/ADA_USD/15m/BOTH/10000/nn/sl_placement_bundle_gz (47.3 KB)
  [supabase] put blob blobs/perm/ADA_USD/15m/BOTH/10000/nn/sl_placement.bundle.gz (47.3 KB)
  [github] put blobs/perm/ADA_USD/15m/BOTH/10000/nn/sl_placement.bundle.gz (47.3 KB)
  [pmc] ✓ NN sl_placement VERIFIED on storage (47.3 KB)
  ✓ VERIFIED on github — bundle is round-trip readable

  versioned copy → batch1: ✓ (github)

  ✓ registry updated. analyze.py + full_pipeline auto-load this NN.
  Total batches now: 1
```

Three independent checks:
1. **Storage chain succeeded** (write went through to at least one backend)
2. **Per-backend verify-read** (each backend re-fetches the blob immediately after writing)
3. **Full round-trip deserialization** (fresh wrapper loads the bundle, scaler restores, model.state_dict reloads)

## ⚡ Quick usage

```python
# Kaggle
%cd /kaggle/working/crypto-v23

# Train first batch (latest 10k bars)
%run train_sl_nn.py --mode scratch --candles 10000 --epochs 20

# Train next batch (10k older bars, fine-tunes from batch 1)
%run train_sl_nn.py --mode next --candles 10000 --epochs 15

# Train one more older batch
%run train_sl_nn.py --mode next --candles 10000 --epochs 15

# Check what you have
%run train_sl_nn.py --list

# Now run analysis — SL-NN auto-loads latest batch
%run analyze.py
# → "✓ SL-placement NN loaded — latest batch (train_acc=0.738)"

# Or use the menu (same flow)
%run run.py
# → Menu 4 → [11] Smart-SL Placement NN sub-menu
```

## 📋 Files changed since WhiteDemon_V8.2

```
train_sl_nn.py                  — full rewrite: scratch/next/specific modes, verified save, registry
run.py                          — _train_sl_nn() now a 5-option sub-menu (scratch/next/specific/list/wipe)
analyze.py                      — uses SLPlacementWrapper.load_latest_for()  (auto-pick latest batch)
train_pipeline.py               — same auto-pick wiring
neural_nets/sl_placement_nn.py  — new classmethod load_latest_for() walks registry
WHATS_NEW_WhiteDemon_V8.2.md             — this file
```

Engine MD5 unchanged: `7d0ce1868dcd0b35b629ee0f6c51afb1` (still v22-byte-identical).
