# WhiteDemon V9.5 — Historical Derivatives + Honest Calibration

## 1) Derivatives leakage fixed without removing derivatives
Derivatives are NOT removed.

Instead of stamping today's funding/OI/L/S snapshot onto every historical candle, V9.5 adds timestamp-aligned historical derivatives features.

New module:

```text
data/historical_derivatives.py
```

Sources/methods:
- Binance USD-M Futures funding history
- Binance open interest history
- Binance global long/short account ratio history
- OKX funding history as supplemental source when available
- local CSV cache under `derivatives_cache/`

No-lookahead alignment:

```text
merge_asof(..., direction="backward")
```

So each candle only receives the latest derivatives datapoint available at or before that candle time.

If APIs fail, neutral values are used so the pipeline does not crash:
- funding = 0
- OI = 0
- L/S = 1
- bias = 0

## 2) Honest calibration fix
Main classical committee calibration no longer fits isotonic calibration on the same data used by the base model.

New behavior:
- train base calibration model on first 80%
- calibrate on last 20%
- use sigmoid calibration if calibration sample is small
- use isotonic calibration if calibration sample is large
- fallback safely if calibration fails

Meta-labeler calibration was also updated to use a holdout split instead of in-sample calibration.

## 3) Model cache versioning
New cache version:

```text
v9.5_no_leakage_honest_calibration
```

Old pre-V9.5 models will not count as done in per-model cache status. This forces a clean retrain once. After clean weekly retraining, the new V9.5 models are saved to GitHub/storage and future runs skip them normally.

## 4) What to expect
Backtest numbers may drop first because leakage/fake calibration edge is removed.

That is good. It means results are more honest.

Expected benefit:
- more realistic probabilities
- less overconfident signals
- cleaner live/backtest match
- more trustworthy weekly retraining

## Checks
- compileall passed
- tabnanny passed
- pyflakes syntax/undefined-name scan passed
