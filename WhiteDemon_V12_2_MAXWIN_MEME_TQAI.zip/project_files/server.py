"""
server.py — Flask web server.
Serves the dashboard and exposes /api/* endpoints to push backend actions
from the HTML (train, analyze, backtest).

Also keeps a rolling stdout buffer so the HTML's System tab can display
live training output in a terminal-like panel.
"""
from __future__ import annotations
import os, json, threading, subprocess, datetime, time, sys, io
from flask import Flask, request, jsonify, send_file, Response, abort
from collections import deque

# ── Rolling stdout buffer (last 1000 lines) for the dashboard's output panel
LOG_BUFFER: deque = deque(maxlen=1000)

class TeeStdout:
    """Mirrors every print() to both real stdout AND LOG_BUFFER.
    Handles BOTH str and bytes (Flask/click may write bytes)."""
    def __init__(self, real):
        self.real = real
    def write(self, msg):
        # Coerce bytes → str so click.echo() (which writes bytes) doesn't crash
        if isinstance(msg, (bytes, bytearray)):
            try: msg = msg.decode("utf-8", errors="replace")
            except Exception: msg = str(msg)
        try: self.real.write(msg); self.real.flush()
        except Exception:
            # If real stream rejects too (e.g. expects bytes), encode back
            try:
                self.real.write(msg.encode("utf-8", errors="replace"))
                self.real.flush()
            except Exception: pass
        if msg and msg.strip():
            for line in msg.rstrip("\n").split("\n"):
                LOG_BUFFER.append(
                    f"[{datetime.datetime.utcnow().strftime('%H:%M:%S')}] {line}")
    def flush(self):
        try: self.real.flush()
        except Exception: pass
    # Some libs probe for these — return safe defaults
    def isatty(self):  return False
    def fileno(self):
        try: return self.real.fileno()
        except Exception: raise OSError("no fileno")
    @property
    def encoding(self):
        return getattr(self.real, "encoding", "utf-8") or "utf-8"
    @property
    def buffer(self):
        # If anything wants raw bytes access, give them the underlying real one
        return getattr(self.real, "buffer", self.real)

sys.stdout = TeeStdout(sys.stdout)
sys.stderr = TeeStdout(sys.stderr)

from core.config import SYMBOL, TF_LABEL, PAIR_ID, TF_ID
from core.storage import STORE

app = Flask(__name__, static_folder="frontend")
PORT = int(os.environ.get("PORT", "8000"))

# Action lock so we never run two trainings in parallel
_lock = threading.Lock()
_state = {"state": "idle", "current_action": None,
           "last_run": None, "history": deque(maxlen=20)}




def _request_value(name: str, default=None):
    """Read parameter from JSON body, form body, or query string."""
    try:
        js = request.get_json(silent=True) or {}
    except Exception:
        js = {}
    return js.get(name) or request.form.get(name) or request.args.get(name) or default


def _normalize_pair_tf(pair: str | None, tf: str | None):
    pair = (pair or SYMBOL).upper().replace("/", "-").strip()
    if pair.endswith("-USDT"):
        pair = pair[:-5] + "-USD"
    tf = (tf or TF_LABEL).strip()
    return pair, tf


def _analysis_cmd(pair: str | None = None, tf: str | None = None, mode: str | None = None) -> list[str]:
    """Build a safe subprocess command for mobile/API analysis.

    smart/fast keeps trained models as-is and runs the unified Smart Analysis path.
    full is still available, but not used by the Android/mobile UI by default.
    """
    pair, tf = _normalize_pair_tf(pair, tf)
    mode = (mode or "smart").lower().strip()
    base = [sys.executable, "run.py", "--pair", pair, "--tf", tf]
    if mode in ("full", "pipeline", "full_pipeline"):
        return [sys.executable, "full_pipeline.py"]
    if mode in ("raw", "analyze", "cache", "cache-only"):
        return base + ["analyze"]
    return base + ["fast"]

def _run_action(name: str, cmd: list):
    if not _lock.acquire(blocking=False):
        return {"queued": False, "reason": "another action is running"}
    def _worker():
        _state["state"] = "running"
        _state["current_action"] = name
        t0 = time.time()
        LOG_BUFFER.append(f"[{datetime.datetime.utcnow().strftime('%H:%M:%S')}] "
                          f"━━━ starting {name} ━━━")
        try:
            # Stream subprocess output line-by-line into LOG_BUFFER so the
            # dashboard's terminal panel shows live progress.
            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE,
                                     stderr=subprocess.STDOUT,
                                     bufsize=1, text=True)
            for line in proc.stdout:
                LOG_BUFFER.append(
                    f"[{datetime.datetime.utcnow().strftime('%H:%M:%S')}] {line.rstrip()}")
                # also mirror to console
                try: sys.__stdout__.write(line); sys.__stdout__.flush()
                except Exception: pass
            proc.wait()
            ok = proc.returncode == 0
            LOG_BUFFER.append(f"[{datetime.datetime.utcnow().strftime('%H:%M:%S')}] "
                              f"━━━ {name} finished ({'✓ ok' if ok else '✗ FAILED'}) "
                              f"in {time.time()-t0:.1f}s ━━━")
            _state["history"].appendleft({
                "name": name, "ok": ok,
                "duration": round(time.time() - t0, 1),
                "ended_at": datetime.datetime.utcnow().isoformat() + "Z",
            })
        finally:
            _state["state"] = "idle"
            _state["current_action"] = None
            _state["last_run"] = datetime.datetime.utcnow().isoformat() + "Z"
            _lock.release()
    threading.Thread(target=_worker, daemon=True).start()
    return {"queued": True, "name": name}


# ── ROUTES ─────────────────────────────────────────────────────────────
@app.route("/")
def index():
    return send_file(os.path.join("frontend", "dashboard.html"))

@app.route("/mobile")
def mobile_index():
    """Mobile-first UI for Android/Termux/local-phone usage."""
    mobile_path = os.path.join("frontend", "mobile.html")
    if os.path.exists(mobile_path):
        return send_file(mobile_path)
    return send_file(os.path.join("frontend", "dashboard.html"))

@app.route("/healthz")
def healthz():
    return "ok", 200

@app.route("/api/status")
def api_status():
    return jsonify({
        "state": _state["state"],
        "current_action": _state["current_action"],
        "last_run": _state["last_run"],
        "history": list(_state["history"]),
        "pair": SYMBOL, "tf": TF_LABEL,
        "server_time": datetime.datetime.utcnow().isoformat() + "Z",
        "storage_backend": STORE.backend_name,
    })

@app.route("/api/dashboard")
def api_dashboard():
    """Pull latest dashboard_data from storage."""
    data = STORE.get_json("dashboard_data")
    if data is None:
        # local fallback
        try:
            with open("dashboard_data.json") as f:
                data = json.load(f)
        except Exception:
            return jsonify({"error": "no dashboard data yet"}), 503
    return jsonify(data)


@app.route("/api/latest_signal")
def api_latest_signal():
    """One-call mobile endpoint: status + latest dashboard/final data if present."""
    dash = STORE.get_json("dashboard_data")
    if dash is None:
        try:
            with open("dashboard_data.json") as f:
                dash = json.load(f)
        except Exception:
            dash = None
    rid = f"{SYMBOL.replace('-','_')}_{TF_LABEL}"
    final = STORE.get_json(f"final_{rid}")
    return jsonify({
        "status": {
            "state": _state["state"],
            "current_action": _state["current_action"],
            "last_run": _state["last_run"],
            "pair": SYMBOL,
            "tf": TF_LABEL,
        },
        "dashboard": dash,
        "final": final,
    })

@app.route("/api/final")
def api_final():
    rid = f"{SYMBOL.replace('-','_')}_{TF_LABEL}"
    data = STORE.get_json(f"final_{rid}")
    return jsonify(data or {"error": "no final yet"})

@app.route("/api/backtest")
def api_backtest():
    rid = f"{SYMBOL.replace('-','_')}_{TF_LABEL}"
    data = STORE.get_json(f"backtest_{rid}")
    if data is None:
        return jsonify({"error": "no backtest yet"}), 404
    return jsonify(data)

@app.route("/api/candles")
def api_candles():
    """Return last 500 candles for the TradingView chart."""
    try:
        from data.fetcher_ccxt import fetch_ohlcv_stitched_v23
        df, _ = fetch_ohlcv_stitched_v23(SYMBOL, TF_LABEL, 500)
        out = [{
            "time": int(r["open_time"].timestamp()),
            "open": float(r["open"]), "high": float(r["high"]),
            "low":  float(r["low"]),  "close": float(r["close"]),
        } for _, r in df.tail(500).iterrows()]
        return jsonify(out)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/api/cache", methods=["GET"])
def api_cache():
    """Returns whether the current (pair, TF) has trained models."""
    from core.cache_manager import get_cache_info
    return jsonify(get_cache_info(SYMBOL, TF_LABEL))


@app.route("/api/train", methods=["POST"])
def api_train():
    force = request.args.get("force", "0") == "1"
    cmd = ["python", "train_all.py"]
    if force:
        cmd.append("--force")
    return jsonify(_run_action("train_all", cmd))


@app.route("/api/logs")
def api_logs():
    """Return the last N log lines for the dashboard's output panel."""
    n = min(1000, int(request.args.get("n", "300")))
    lines = list(LOG_BUFFER)[-n:]
    return Response("\n".join(lines) + "\n", mimetype="text/plain")

@app.route("/api/analyze", methods=["GET", "POST"])
def api_analyze():
    """Queue an analysis run.

    Mobile/extension friendly contract:
      GET/POST /api/analyze?pair=SOL-USDT&tf=15m&mode=smart

    Returns immediately with queued=True/False. Poll /api/status, /api/logs,
    and /api/dashboard for the final signal. Default mode is Smart Analysis,
    not retraining from scratch.
    """
    pair = _request_value("pair", SYMBOL)
    tf = _request_value("tf", TF_LABEL)
    mode = _request_value("mode", "smart")
    pair_norm, tf_norm = _normalize_pair_tf(pair, tf)
    cmd = _analysis_cmd(pair_norm, tf_norm, mode)
    return jsonify(_run_action(f"analyze_{pair_norm}_{tf_norm}_{mode}", cmd))


@app.route("/api/full_pipeline", methods=["POST"])
def api_full_pipeline():
    return jsonify(_run_action("full_pipeline", ["python", "full_pipeline.py"]))


@app.route("/api/fast_analyze", methods=["GET", "POST"])
def api_fast_analyze():
    """Mobile-safe smart/fast inference on cached models."""
    pair = _request_value("pair", SYMBOL)
    tf = _request_value("tf", TF_LABEL)
    pair_norm, tf_norm = _normalize_pair_tf(pair, tf)
    return jsonify(_run_action(f"fast_analyze_{pair_norm}_{tf_norm}",
                               _analysis_cmd(pair_norm, tf_norm, "smart")))


@app.route("/api/autotrader/start", methods=["POST"])
def api_autotrader_start():
    """Start the 24/7 auto-trader loop (foreground subprocess)."""
    return jsonify(_run_action("autotrader", ["python", "-m", "live.autotrader"]))


@app.route("/api/autotrader/once", methods=["POST"])
def api_autotrader_once():
    """Single tick of the auto-trader (test mode)."""
    return jsonify(_run_action("autotrader_once",
                                ["python", "-m", "live.autotrader", "--once"]))

@app.route("/api/backtest", methods=["POST"])
def api_run_backtest():
    return jsonify(_run_action("backtest", ["python", "backtest_run.py"]))


if __name__ == "__main__":
    print(f"\n{'─'*60}")
    print(f"  Crypto Suite WhiteDemon_V8.2 — server starting on :{PORT}")
    print(f"  storage backend: {STORE.backend_name}")
    print(f"  pair: {SYMBOL}  tf: {TF_LABEL}")
    print(f"  open  http://localhost:{PORT}  in your browser")
    print(f"{'─'*60}\n")
    # Bypass Flask/click's startup banner (which writes BYTES via click.echo
    # and crashes our TeeStdout wrapper). werkzeug.run_simple does NOT use
    # click and is what Flask wraps anyway.
    try:
        from werkzeug.serving import run_simple
        run_simple("0.0.0.0", PORT, app,
                   use_reloader=False, use_debugger=False, threaded=True)
    except Exception as _e:
        print(f"  [warn] werkzeug.run_simple failed ({_e}); falling back to app.run()")
        # Temporarily restore stdout to avoid bytes-write crash
        sys.stdout = sys.__stdout__
        sys.stderr = sys.__stderr__
        app.run(host="0.0.0.0", port=PORT, debug=False)

# ──────────────────────────────────────────────────────────────
# V12.2 — Trade Outcome Journal + TQAI
# ──────────────────────────────────────────────────────────────
@app.route("/journal")
def journal_page():
    """Serve institutional trade journal UI"""
    try:
        from flask import send_from_directory
        return send_from_directory("frontend", "trade_journal.html")
    except Exception as e:
        return f"Journal UI load error: {e}", 500

@app.route("/api/trades", methods=["GET"])
def api_trades_list():
    """List recent trades from TQAI journal — supports ?limit=&symbol=&outcome="""
    try:
        limit = int(request.args.get("limit", 200))
    except Exception:
        limit = 200
    symbol = request.args.get("symbol")
    outcome = request.args.get("outcome")
    try:
        from journal.trade_outcome_tracker import list_recent_trades
        trades = list_recent_trades(limit=max(10, min(limit, 1000)))
        if symbol:
            s = symbol.upper().replace("USDT","").replace("USD","")
            trades = [t for t in trades if s in str(t.get("symbol","")).upper()]
        if outcome:
            trades = [t for t in trades if str(t.get("outcome","")).upper() == outcome.upper()]
        return jsonify({"ok": True, "trades": trades, "count": len(trades), "source": "tqai_v12_2"})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e), "trades": []}), 500

@app.route("/api/trade_feedback", methods=["POST", "OPTIONS"])
def api_trade_feedback():
    """Mark a trade WIN / LOSS — feeds Trade Quality AI + saves to GitHub storage"""
    if request.method == "OPTIONS":
        return ("", 204, {"Access-Control-Allow-Origin": "*", "Access-Control-Allow-Methods": "POST, OPTIONS", "Access-Control-Allow-Headers": "Content-Type"})
    try:
        data = request.get_json(force=True, silent=True) or {}
        # normalize
        trade = {
            "id": data.get("id") or data.get("trade_id") or f"tq_{int(__import__('time').time())}",
            "symbol": data.get("symbol") or data.get("pair") or "UNKNOWN",
            "direction": data.get("direction") or data.get("side") or "LONG",
            "entry_price": data.get("entry_price"),
            "exit_price": data.get("exit_price"),
            "entry_time": data.get("entry_time"),
            "exit_time": data.get("exit_time") or __import__('datetime').datetime.utcnow().isoformat(),
            "stack_bull": float(data.get("stack_bull") or data.get("meta_prob_live") or 0.5),
            "meta_prob_live": float(data.get("meta_prob_live") or 0.5),
            "pass_winrate": data.get("pass_winrate"),
            "regime": data.get("regime") or data.get("drift_level") or "RANGING",
            "confidence": data.get("confidence"),
            "outcome": str(data.get("outcome","OPEN")).upper(),
            "pnl_pct": data.get("pnl_pct"),
            "rr_achieved": data.get("rr_achieved"),
            "note": data.get("note",""),
        }
        # auto compute pnl if prices given and outcome missing
        if trade["outcome"] not in ("WIN","LOSS") and trade["entry_price"] and trade["exit_price"]:
            try:
                ep = float(trade["entry_price"]); xp = float(trade["exit_price"])
                pnl = (xp-ep)/ep if trade["direction"]!="SHORT" else (ep-xp)/ep
                trade["pnl_pct"] = round(pnl*100,4)
                trade["outcome"] = "WIN" if pnl > 0 else "LOSS"
            except Exception:
                pass
        from journal.trade_outcome_tracker import record_trade_outcome
        res = record_trade_outcome(trade)
        # also push through TQAI live scorer so next signal benefits immediately
        try:
            from core.live_performance import score_live_signal
            _ = score_live_signal(trade)
        except Exception:
            pass
        return jsonify({"ok": True, "saved": res, "trade_id": trade["id"], "outcome": trade["outcome"]}), 200, {"Access-Control-Allow-Origin": "*"}
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500

@app.route("/api/tqai/performance", methods=["GET"])
def api_tqai_performance():
    """Live performance analytics — by regime / confidence / session"""
    try:
        from core.live_performance import get_live_analytics
        return jsonify(get_live_analytics())
    except Exception as e:
        return jsonify({"available": False, "error": str(e)})

@app.route("/api/tqai/score", methods=["POST"])
def api_tqai_score():
    """Score a live signal through Trade Quality AI before execution"""
    try:
        sig = request.get_json(force=True, silent=True) or {}
        from core.live_performance import score_live_signal
        out = score_live_signal(sig)
        return jsonify({"ok": True, "scored": out})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500

# end V12.2 journal
