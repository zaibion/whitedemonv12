# WhiteDemon V10.7 — Analysis Menu Choices + Smart Recommended

## Why
User asked to keep both Full Pipeline and Fast Mode, but also add one combined best option.

## Menu 4 → 8 now has

```text
[1] FULL PIPELINE
[2] FULL PIPELINE AGAIN
[3] FAST MODE
[4] CACHE-ONLY ANALYZE
[5] SMART ANALYSIS  (RECOMMENDED)
```

## Which one to use

### Full Pipeline
Best when you intentionally want to train/refresh missing pieces. Slower. Can use legacy path.

### Fast Mode
Best only when models and bundles are already complete. Fastest. No training.

### Smart Analysis — recommended
Best default. It checks cache/bundles first:
- if complete: runs final analyzer directly
- if incomplete: trains only missing models / refreshes bundles
- then runs final unified `analyze.py`

This combines full-pipeline reliability with fast-mode final output consistency.

## Checks
- compileall passed
- tabnanny passed
- pyflakes syntax/undefined-name scan passed
