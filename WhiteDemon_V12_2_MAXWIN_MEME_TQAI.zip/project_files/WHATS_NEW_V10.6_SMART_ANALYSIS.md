# WhiteDemon V10.6 — Smart Analysis Mode

## Why
User asked which is better: full pipeline or fast mode.

Answer implemented: **Smart Analysis** combines both ideas:

- If trained models and bundles are complete → run final analyzer only.
- If models/bundles are missing → train only missing pieces / rebuild bundles using cached models, then run final analyzer.
- Final authoritative result always comes from the unified `analyze.py` path.

## New file

```text
smart_analysis.py
```

## Behavior
Smart Analysis:

1. Checks per-model cache status for LONG and SHORT.
2. Checks whether full committee bundles exist.
3. If complete → directly runs `analyze.py`.
4. If incomplete → runs `train_specific.py` for BOTH directions with all classical + DL model names.
   - already-trained models are skipped from cache,
   - missing models train,
   - bundles are created/refreshed,
   - then `analyze.py` runs once as the final output.

## Menu changes
These now use Smart Analysis:

- Main Fast Mode
- Menu 4 → 8 → all options 1/2/3/4
- Show trained pair analysis

This avoids comparing different analysis engines and reduces contradictory LONG/SHORT outputs.

## Direct command

```bash
python run.py --pair SOL-USDT --tf 15m fast
```

This now uses Smart Analysis.

## Important
`full_pipeline.py` is still available from collect/dashboard workflows, but trade direction should be trusted from the final unified `analyze.py` output produced by Smart Analysis.

## Checks
- compileall passed
- tabnanny passed
- pyflakes syntax/undefined-name scan passed
