"""
config.example.py — copy to config.py and fill in YOUR credentials.

⚠️ NEVER commit config.py to git — it's already in .gitignore.
"""

# ─── What to trade ───────────────────────────────────────────────────────
# PAIR IDs:  1=BTC  2=ETH  3=SOL  4=BNB  5=XRP  6=LTC  7=ADA  8=DOGE
#            9=AVAX 10=DOT 11=MATIC 12=LINK 13=TRX 14=ATOM 15=NEAR
#           16=ARB 17=OP 18=SHIB
# TF  IDs:   1=1m  2=3m  3=5m  4=15m  5=30m  6=1h  7=4h  8=1d
PAIR_ID = 3      # 3 = SOL-USD
TF_ID   = 5      # 5 = 30m

# ─── Data sizing ─────────────────────────────────────────────────────────
TARGET_CANDLES = 200_000     # initial training (stitched: 2x25k per exchange)
FAST_CANDLES   = 4_000       # FAST MODE refresh (analyze.py)

# ─── Storage backend — pick ONE (or both, Firebase takes priority) ───────
#
# 🅰  FIREBASE  (recommended for big model files)
#
#    1. Go to https://console.firebase.google.com
#    2. Project Settings → Service accounts → "Generate new private key"
#    3. Download the JSON file → put it next to this config.py
#    4. Enable Firebase Storage at https://console.firebase.google.com/project/_/storage
#    5. Fill in below:
#
FIREBASE_CREDENTIALS = ""                                # e.g. "firebase-service-account.json"
FIREBASE_PROJECT_ID  = ""                                # e.g. "gen-lang-client-0703468344"
FIREBASE_BUCKET      = ""                                # e.g. "gen-lang-client-0703468344.firebasestorage.app"

# 🅱  GITHUB  (fallback / always-free option)
#
#    1. Create a NEW EMPTY private repo at https://github.com/new
#    2. Generate token: https://github.com/settings/tokens
#         → "Generate new token (classic)" → tick ☑ repo → copy
#    3. Fill in below (NO .git suffix on the repo!)
#
GITHUB_TOKEN  = ""                                       # ghp_xxxxxxxxxxxxxxxxx
GITHUB_REPO   = ""                                       # "owner/repo"  e.g. "zaibion/kinapp"
GITHUB_BRANCH = "main"
