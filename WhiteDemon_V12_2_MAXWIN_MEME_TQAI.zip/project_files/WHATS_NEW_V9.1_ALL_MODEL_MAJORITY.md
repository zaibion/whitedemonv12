# WhiteDemon V9.1 — All-Model Majority Direction Logic

## Problem fixed
The previous setup screen could still feel wrong because LONG and SHORT committees can both show probabilities above 50%. They are separate questions, not a single BUY/SELL vote.

## New logic
The app now asks ALL available model votes first and chooses ONE direction by majority:

- LONG committee classical votes
- SHORT committee classical votes
- LONG committee DL votes
- SHORT committee DL votes
- DL aggregate votes
- committee stack comparison
- stored specialized neural signals when available

Direction-specific interpretation is fixed:

- LONG committee `pred=1` votes LONG
- LONG committee `pred=0` votes SHORT
- SHORT committee `pred=1` votes SHORT
- SHORT committee `pred=0` votes LONG

This converts separate LONG/SHORT committees into one final BUY/SELL majority decision.

## Output now shows
Only one setup:

```text
BEST SETUP: LONG/SHORT
ALL-MODEL MAJORITY: LONG (27/48 weighted votes, 56.3%)
selected committee win-prob=...
selected-side breakdown=...
```

It does not show the opposite trade setup in the user-facing output.

## Trade filtering
Even if majority chooses a direction, the setup can still be blocked as NO_TRADE if:
- all-model majority is weak
- setup score is low
- risk/TP/SL geometry is bad
- confidence/risk guard blocks it
- backtest expectancy is bad

## Future setup levels
Still limited to only 2 non-signal watch zones.

## Storage upload
`final_<PAIR>_<TF>` and `setup_watch_<PAIR>_<TF>` now include `all_model_majority`.

## Checks
- compileall passed
- tabnanny passed
- pyflakes syntax/undefined-name scan passed
