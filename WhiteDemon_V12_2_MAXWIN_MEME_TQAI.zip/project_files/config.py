# ─── WhiteDemon_V8.2 CONFIGURATION ──────────────────────────────────────────
# This file contains your secret credentials. 
# It is automatically excluded from git via .gitignore.

# ─── What to trade (Defaults - can be changed in setup.py) ─────────────────
PAIR_ID = 3      # 3 = SOL-USD
TF_ID   = 5      # 5 = 30m

# ─── Data sizing ─────────────────────────────────────────────────────────
TARGET_CANDLES = 200000
FAST_CANDLES   = 4000

# ─── Firebase Credentials ────────────────────────────────────────────────
# Note: FIREBASE_CREDENTIALS usually expects a path to a .json file.
FIREBASE_CREDENTIALS = "AIzaSyAy__mH-4QCpl8lCDuaTb8lEtsB4kA_jFQ" 
FIREBASE_PROJECT_ID  = "gen-lang-client-0703468344"
FIREBASE_BUCKET      = "gen-lang-client-0703468344.firebasestorage.app"

# ─── GitHub Credentials ──────────────────────────────────────────────────
GITHUB_TOKEN  = "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"
GITHUB_REPO   = "zaibion/kinapp"
GITHUB_BRANCH = "main"

# ─── LLM / API Keys ───────────────────────────────────────────────────────
MISTRAL_API_KEY = "72evn1FYorqHPd1yFfflFxRkrXWAQ7za"
GROK_API_KEY    = "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"

# ─── Other Settings ──────────────────────────────────────────────────────
# You can add other custom variables here
FINBERT_ALLOW_DOWNLOAD = "1"
