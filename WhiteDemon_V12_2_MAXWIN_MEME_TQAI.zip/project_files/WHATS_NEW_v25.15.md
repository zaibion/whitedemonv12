# Crypto Suite WhiteDemon_V8.2 — Auto multi-TP + breakeven lifecycle alerts

## ✅ What you asked for

> "I don't need to set up SL and TP. I'll just add alerts and it will set
> SL+TP as shown in setup, like multiple TPs and breakeven. Make it work
> in a loop and send alerts."

Shipped. You add an alert subscription for a trained pair → bot computes
the setup once → manages the lifecycle automatically and fires an alert
on every state change.

## 🎯 The position lifecycle (fully automatic)

```
ENTRY  (signal fires, position = OPEN)
  │ 50% allocated to TP1, 30% to TP2, 20% to TP3, full SL at original
  │
  ├── price hits SL before any TP        → close all, -1.0R  (event: sl_hit)
  │
  ├── price hits TP1
  │     • close 50% at TP1
  │     • move SL → entry price (BREAKEVEN)
  │     • position state → BE
  │     • fires 2 alerts: tp1_hit + breakeven_set
  │     • worst case from here = +0R (BE locked in)
  │
  ├── price then hits TP2
  │     • close 30% at TP2
  │     • move SL → TP1 price (locks 1R on remaining 20%)
  │     • position state → TRAIL
  │     • fires alert: tp2_hit
  │
  └── price then hits TP3
        • close remaining 20% at TP3
        • fires alert: tp3_hit  +  blended-R logged
        • position state → CLOSED
```

If price reverses while in BE/TRAIL state, the trailed SL handles it —
you never give back more than already-locked profit.

## 🔔 Alert events fired during the lifecycle

| Event             | Sent when                              | `action_for_event`    |
|-------------------|----------------------------------------|-----------------------|
| `entry`           | TAKE_TRADE verdict, position opens     | `buy` / `sell`        |
| `tp1_hit`         | first TP hit, 50% closed               | `close_partial_50pct` |
| `breakeven_set`   | right after tp1_hit, SL moved to entry | `move_sl`             |
| `tp2_hit`         | second TP, 30% closed, SL → TP1        | `close_partial_30pct` |
| `tp3_hit`         | final TP, last 20% closed              | `close_all`           |
| `sl_hit`          | SL triggered (original OR trailed)     | `close_all`           |

Each event ships ALL the position fields (entry/sl_current/tp1-3, realized_R,
partial_R, fraction_closed, new_sl, …) so the receiving bot has everything
it needs.

## 📋 Updated Menu 13 add-flow

```
━━ Add alert subscription ━━

  TRAINED pairs:
   [ 1] BTC-USD       15m     trained 2026-06-22 18:30
   ...

  Pick pair #: 1

  Selected: BTC-USD @ 15m

  Webhook URL: https://your-bot.com/webhook

  Events to alert on:
   [1] ENTRY only            (just the trade signal)
   [2] ENTRY + ALL EXITS     [recommended — includes TP1/TP2/TP3/BE/SL]
   [3] ENTRY + breakeven + final close only
   [4] CUSTOM (pick events manually)
```

The DEFAULT JSON template now ships `event` + `action_for_event` so receiving
bots know which action to take per event (open, partial close, move SL,
close all).

## 🔁 The 24/7 loop

The autotrader loop (Menu 12 → [1] START) now:

1. Each bar close, for each enabled pair (Menu 12 + Menu 13 subs)
2. **If position is OPEN/BE/TRAIL** → check for SL/TP hits since last event
   - **Could trigger MULTIPLE events in one bar** (e.g. bar spikes from $100
     to $108: hits TP1=$103 AND TP2=$106 — both fire). Loop iterates up to 4
     events per tick.
   - On each event: save updated state → fire alerts → fire user subs
3. **If position closed or never opened** → run `analyze.py`, if
   `TAKE_TRADE` and win_prob ≥ threshold → fire `entry` event

Position state persists in `live_positions/<sym>_<tf>.json` on
Firebase + Supabase + GitHub. Survives restarts.

## 📐 New default JSON template (smart)

```json
{
  "action":          "{{action_for_event}}",
  "event":           "{{event}}",
  "symbol":          "{{symbol_clean}}",
  "side":            "{{side}}",
  "price":           "{{entry}}",
  "stop_loss":       "{{sl_current_or_sl}}",
  "take_profit":     "{{tp1}}",
  "take_profits":    "[{{tp1}}, {{tp2}}, {{tp3}}]",
  "fraction_closed": "{{fraction_closed}}",
  "new_sl":          "{{new_sl}}",
  "exit_price":      "{{exit_price}}",
  "realized_R":      "{{realized_R}}",
  "pnl_R":           "{{pnl_R}}",
  "leverage":        "{{leverage}}",
  "size_pct":        "{{size_pct}}",
  "verdict":         "{{verdict}}",
  "win_prob":        "{{win_prob}}",
  "tf":              "{{tf}}",
  "strategy":        "crypto-suite-v25",
  "ts":              "{{ts}}"
}
```

Just press Enter when adding a subscription to use it. Or paste your own.

## ➕ New placeholders

```
{{event}}             entry / tp1_hit / breakeven_set / tp2_hit / tp3_hit / sl_hit
{{action_for_event}}  buy / sell / close_partial_50pct / close_partial_30pct
                       / close_all / move_sl
{{close_side}}        sell on LONG exit, buy on SHORT exit (for reduceOnly orders)
{{sl_current}}        the trailed SL (moves to entry on TP1, to TP1 on TP2)
{{sl_current_or_sl}}  always-set helper — current SL if exists else original
{{new_sl}}            set on breakeven_set + tp2_hit (the new trailed level)
{{exit_price}}        actual price the TP/SL triggered at
{{partial_R}}         this event's R contribution
{{realized_R}}        running sum across the whole lifecycle
{{fraction_closed}}   0.5 / 0.3 / 0.2 / 1.0
{{state}}             OPEN / BE / TRAIL / CLOSED
```

Plus all the pre-existing ones (symbol/direction/win_prob/etc).

## 💡 Example flows

### Discord-only (you trade manually based on signals)

1. Menu 13 → Add → Pair: BTC-USD @ 15m
2. URL: `https://discord.com/api/webhooks/...`
3. Events: [2] ENTRY + ALL EXITS
4. Template: Enter (default)

You'll get 4-6 Discord messages per trade:
```
🔔 entry · LONG BTC-USD @ 15m · entry=43150 sl=42810 tp1=43810 (R=0)
🔔 tp1_hit · LONG BTC-USD @ 15m · entry=43150 sl_current=43150 tp1=43810 (R=0.97)
🔔 breakeven_set · LONG BTC-USD @ 15m · new_sl=43150
🔔 tp2_hit · LONG BTC-USD @ 15m · entry=43150 sl_current=43810 tp2=44100 (R=1.81)
🔔 tp3_hit · LONG BTC-USD @ 15m · entry=43150 tp3=44650 (R=2.51)
```

### Wundertrading / Altrady fully automated

1. Menu 13 → Add → same setup as above
2. URL: your Altrady webhook URL
3. Template:
   ```json
   {
     "action": "{{action_for_event}}",
     "symbol": "{{symbol_clean}}",
     "price": {{entry}},
     "stop_loss": {{sl_current_or_sl}},
     "take_profit": {{tp1}},
     "key": "your-altrady-secret"
   }
   ```

Altrady receives `buy` → opens, then `close_partial_50pct` → closes half,
then `move_sl` with `new_sl=<entry>` → updates SL to breakeven, etc.

## 📋 Files changed since WhiteDemon_V8.2

```
live/autotrader.py       — REWROTE _check_local_exit as state machine
                            (OPEN → BE → TRAIL → CLOSED)
                          — entry signal now includes state-machine fields
                          — bar-close loop processes multiple events per tick
live/alert_subs.py       — fire_sub: "close" expands to all exit events
                          — _default_template: new event-aware fields
                          — enrich_signal_for_template: action_for_event,
                            sl_current_or_sl, close_side computed
run.py                   — Menu 13 add-flow: 4 event preset options
                          — Menu 12 add-pair: note about auto-SL/TP
                          — Menu 13 → [6] template help: lifecycle docs
WHATS_NEW_WhiteDemon_V8.2.md      — this file
```

Engine MD5 unchanged: `7d0ce1868dcd0b35b629ee0f6c51afb1`.
