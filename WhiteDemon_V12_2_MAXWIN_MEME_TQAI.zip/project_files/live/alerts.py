"""
alerts.py — WhiteDemon_V8.2

Sends trade signals to:
  • Discord webhook        (rich embed)
  • Telegram bot + chat_id (markdown message)
  • Generic JSON webhook   (TradingView/Altrady/Signum/Wundertrading style)
  • Slack incoming webhook (text message)

Failures are logged but never crash the auto-trader.
"""
from __future__ import annotations
import json, time, traceback
from typing import Dict, Any, Optional

import requests

from core.colors import GREEN, YELLOW, RED, RESET, CYAN, GREY
from .credentials import get_webhook, get_creds


# ──────────────────────────────────────────────────────────────────────────
# Payload builders
# ──────────────────────────────────────────────────────────────────────────
def build_tv_payload(signal: Dict) -> Dict:
    """TradingView/Altrady/Signum/Wundertrading style JSON.

    Common fields these bots expect:
      action: 'buy' | 'sell' | 'close_long' | 'close_short'
      symbol: 'BTCUSDT' (no dash, use USDT)
      price:  float
      stop_loss: float
      take_profit: float (use TP1)
      take_profits: [tp1, tp2, tp3]
      leverage: int (optional)
      size_pct: float    (% of equity)
      strategy: 'crypto-suite-v25'
      key:    user-defined passphrase for auth (Altrady requires this)
    """
    sym  = signal.get("symbol", "").replace("-USD", "USDT").replace("-", "").upper()
    side = (signal.get("direction") or "").lower()
    action = "buy" if side == "long" else "sell"
    out = {
        "action":      action,
        "symbol":      sym,
        "price":       float(signal.get("entry", 0)),
        "stop_loss":   float(signal.get("sl", 0)),
        "take_profit": float(signal.get("tp1", 0)),
        "take_profits":[float(signal.get(k, 0)) for k in ("tp1", "tp2", "tp3")
                        if signal.get(k)],
        "leverage":    int(signal.get("leverage", 1)),
        "size_pct":    float(signal.get("size_pct", 1.0)),
        "strategy":    "crypto-suite-v25",
        "key":         signal.get("webhook_key", ""),
        "verdict":     signal.get("verdict", ""),
        "win_prob":    float(signal.get("win_prob", 0) or 0),
        "tf":          signal.get("tf", ""),
        "ts":          int(time.time()),
    }
    return out


def build_discord_embed(signal: Dict) -> Dict:
    """Discord webhook payload with a rich embed."""
    direction = (signal.get("direction") or "").upper()
    color = 0x52d273 if direction == "LONG" else 0xff5e7a
    sym  = signal.get("symbol", "?")
    tf   = signal.get("tf", "?")
    verdict = signal.get("verdict", "—")
    win_pct = (signal.get("win_prob") or 0) * 100
    entry, sl, tp1 = signal.get("entry", 0), signal.get("sl", 0), signal.get("tp1", 0)
    rr1 = signal.get("rr1") or (abs(tp1 - entry) / max(abs(entry - sl), 1e-9))
    emoji = "🟢" if direction == "LONG" else "🔴"
    fields = [
        {"name": "Pair / TF",   "value": f"`{sym} @ {tf}`",          "inline": True},
        {"name": "Direction",   "value": f"{emoji} **{direction}**",  "inline": True},
        {"name": "Verdict",     "value": f"**{verdict}**",            "inline": True},
        {"name": "Entry",       "value": f"`${entry:,.6g}`",          "inline": True},
        {"name": "Stop-Loss",   "value": f"`${sl:,.6g}`",             "inline": True},
        {"name": "TP1 (R:R)",   "value": f"`${tp1:,.6g}` ({rr1:.2f}R)","inline": True},
        {"name": "Win Prob",    "value": f"{win_pct:.1f}%",            "inline": True},
    ]
    if signal.get("tp2"):
        fields.append({"name": "TP2", "value": f"`${signal['tp2']:,.6g}`",
                       "inline": True})
    if signal.get("tp3"):
        fields.append({"name": "TP3", "value": f"`${signal['tp3']:,.6g}`",
                       "inline": True})
    if signal.get("smart_sl_chosen"):
        fields.append({"name": "Smart-SL", "value": signal["smart_sl_chosen"],
                       "inline": True})
    embed = {
        "title":     f"{emoji} {direction} {sym} @ {tf}",
        "color":     color,
        "fields":    fields,
        "footer":    {"text": f"crypto-suite-v25 · {signal.get('source', 'auto-trader')}"},
        "timestamp": __import__("datetime").datetime.utcnow().isoformat(),
    }
    return {"embeds": [embed]}


def build_telegram_text(signal: Dict) -> str:
    """Markdown message for Telegram (parse_mode=Markdown)."""
    direction = (signal.get("direction") or "").upper()
    emoji = "🟢" if direction == "LONG" else "🔴"
    sym = signal.get("symbol", "?")
    tf  = signal.get("tf", "?")
    return (
        f"*{emoji} {direction} {sym} @ {tf}*\n"
        f"_Verdict_: `{signal.get('verdict','—')}`\n"
        f"_Entry_:   `${signal.get('entry',0):,.6g}`\n"
        f"_SL_:      `${signal.get('sl',0):,.6g}`\n"
        f"_TP1_:     `${signal.get('tp1',0):,.6g}` ({signal.get('rr1',0):.2f}R)\n"
        f"_TP2_:     `${signal.get('tp2',0):,.6g}`\n"
        f"_TP3_:     `${signal.get('tp3',0):,.6g}`\n"
        f"_Win Prob_: *{(signal.get('win_prob',0) or 0)*100:.1f}%*\n"
        f"_Smart-SL_: {signal.get('smart_sl_chosen','')}\n"
        f"`crypto-suite-v25 · {signal.get('source','auto')}`"
    )


def build_slack_payload(signal: Dict) -> Dict:
    return {"text": build_telegram_text(signal).replace("*", "*").replace("_", "_")}


# ──────────────────────────────────────────────────────────────────────────
# Dispatchers (each one returns True on success, False otherwise)
# ──────────────────────────────────────────────────────────────────────────
def send_discord(signal: Dict, url: Optional[str] = None) -> bool:
    url = url or get_webhook("discord")
    if not url: return False
    try:
        r = requests.post(url, json=build_discord_embed(signal), timeout=10)
        if 200 <= r.status_code < 300:
            print(f"  {GREEN}[alert] discord ✓{RESET}")
            return True
        print(f"  {YELLOW}[alert] discord HTTP {r.status_code}: {r.text[:200]}{RESET}")
    except Exception as e:
        print(f"  {YELLOW}[alert] discord err: {str(e)[:150]}{RESET}")
    return False


def send_telegram(signal: Dict,
                   bot_token: Optional[str] = None,
                   chat_id:   Optional[str] = None) -> bool:
    creds = get_creds().get("telegram", {})
    bot_token = bot_token or creds.get("bot_token", "")
    chat_id   = chat_id   or creds.get("chat_id", "")
    if not bot_token or not chat_id:
        return False
    try:
        url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
        r = requests.post(url, json={
            "chat_id":    chat_id,
            "text":       build_telegram_text(signal),
            "parse_mode": "Markdown",
        }, timeout=10)
        if 200 <= r.status_code < 300:
            print(f"  {GREEN}[alert] telegram ✓{RESET}")
            return True
        print(f"  {YELLOW}[alert] telegram HTTP {r.status_code}: {r.text[:200]}{RESET}")
    except Exception as e:
        print(f"  {YELLOW}[alert] telegram err: {str(e)[:150]}{RESET}")
    return False


def send_webhook_json(signal: Dict, url: Optional[str] = None,
                       webhook_key: Optional[str] = None) -> bool:
    """Generic JSON POST — works for TradingView, Altrady, Signum,
    Wundertrading and any custom endpoint."""
    url = url or get_webhook("tradingview")
    if not url: return False
    if webhook_key:
        signal = {**signal, "webhook_key": webhook_key}
    payload = build_tv_payload(signal)
    try:
        r = requests.post(url, json=payload, timeout=15)
        if 200 <= r.status_code < 300:
            print(f"  {GREEN}[alert] webhook ✓ ({url[:40]}…){RESET}")
            return True
        print(f"  {YELLOW}[alert] webhook HTTP {r.status_code}: {r.text[:200]}{RESET}")
    except Exception as e:
        print(f"  {YELLOW}[alert] webhook err: {str(e)[:150]}{RESET}")
    return False


def send_slack(signal: Dict, url: Optional[str] = None) -> bool:
    url = url or get_webhook("slack")
    if not url: return False
    try:
        r = requests.post(url, json=build_slack_payload(signal), timeout=10)
        if 200 <= r.status_code < 300:
            print(f"  {GREEN}[alert] slack ✓{RESET}")
            return True
        print(f"  {YELLOW}[alert] slack HTTP {r.status_code}{RESET}")
    except Exception as e:
        print(f"  {YELLOW}[alert] slack err: {str(e)[:150]}{RESET}")
    return False


# ──────────────────────────────────────────────────────────────────────────
# Send to ALL configured channels
# ──────────────────────────────────────────────────────────────────────────
def dispatch_all(signal: Dict, webhook_key: Optional[str] = None) -> Dict[str, bool]:
    """Send signal to every configured channel. Returns {channel: ok}."""
    print(f"\n{CYAN}[alerts] dispatching signal {signal.get('direction')} "
          f"{signal.get('symbol')} {signal.get('tf')}…{RESET}")
    results = {
        "discord":      send_discord(signal),
        "telegram":     send_telegram(signal),
        "slack":        send_slack(signal),
        "webhook":      send_webhook_json(signal, webhook_key=webhook_key),
    }
    sent = sum(1 for v in results.values() if v)
    print(f"  {GREEN}✓ {sent}/{len(results)} channel(s) delivered{RESET}")
    return results
