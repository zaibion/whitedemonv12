"""
autotrader.py — WhiteDemon_V8.2

24/7 auto-trader loop. For each pair the user enabled:

  Every bar-close (15m → every 15 min, 1h → every 1h):
    1. Check open positions on the exchange (or in our position tracker)
    2. If open position exists for this pair:
         → poll its state (price, PnL, did SL/TP hit?)
         → save updated state to storage
         → if closed: send 'CLOSED' alert
       continue (skip new analysis for this pair)
    3. If no open position:
         → run full_pipeline.py analysis on 4k LIVE candles for this pair
         → if verdict is TAKE_TRADE and win_prob >= min_win_prob:
              → save signal to storage
              → dispatch alerts to all configured channels
              → if place_orders=True: place real CCXT order
         → if verdict is NO_TRADE: do nothing, wait next bar

Run:  python -m live.autotrader        (foreground loop)
      python -m live.autotrader --once (run once, exit)
      python -m live.autotrader --pair BTC-USD --tf 15m  (single pair)
"""
from __future__ import annotations
import os, sys, time, json, argparse, datetime, traceback, subprocess
from typing import Dict, List, Optional

from core.config import CFG, PAIRS, TIMEFRAMES
from core.colors import GREEN, YELLOW, RED, RESET, CYAN, BOLD, GREY
from core.storage import STORE

from .credentials import (get_creds, get_autotrader_pairs,
                           get_exchange_creds)
from .alerts import dispatch_all
from .alert_subs import load_subs, fire_sub, enrich_signal_for_template


_TF_TO_SECS = {"1m": 60, "3m": 180, "5m": 300, "15m": 900, "30m": 1800,
                "1h": 3600, "4h": 14400, "1d": 86400}


# ──────────────────────────────────────────────────────────────────────────
# Position tracker (storage-backed)
# ──────────────────────────────────────────────────────────────────────────
def _position_key(symbol: str, tf: str) -> str:
    return f"live_positions/{symbol.replace('-','_')}_{tf}"


def get_open_position(symbol: str, tf: str) -> Optional[Dict]:
    """Return open position record stored locally (NOT from exchange).
    Used when place_orders=False (alerts-only mode)."""
    p = STORE.get_json(_position_key(symbol, tf)) or {}
    if p.get("deleted") or p.get("closed_at"):
        return None
    if not p.get("entry"):
        return None
    return p


def save_position(symbol: str, tf: str, position: Dict) -> bool:
    return STORE.put_json(_position_key(symbol, tf), position,
                           message=f"position update {symbol}/{tf}")


def close_position_record(symbol: str, tf: str, exit_price: float,
                            reason: str, pnl_R: float = 0) -> bool:
    p = STORE.get_json(_position_key(symbol, tf)) or {}
    if not p.get("entry"):
        return False
    p["closed_at"] = datetime.datetime.utcnow().isoformat() + "Z"
    p["exit_price"] = exit_price
    p["exit_reason"] = reason
    p["pnl_R"] = pnl_R
    return STORE.put_json(_position_key(symbol, tf), p,
                           message=f"position closed {symbol}/{tf}")


# ──────────────────────────────────────────────────────────────────────────
# Per-pair tick
# ──────────────────────────────────────────────────────────────────────────
def run_pair_once(pair_cfg: Dict) -> Dict:
    """Single 'check this pair' iteration. Returns a status dict."""
    symbol = pair_cfg.get("symbol")
    tf     = pair_cfg.get("tf")
    if not symbol or not tf:
        return {"error": "missing symbol/tf"}

    print(f"\n{BOLD}{CYAN}━━ AUTO-TRADER tick · {symbol} @ {tf} "
          f"({datetime.datetime.utcnow().strftime('%H:%M:%S UTC')}) ━━{RESET}")

    # Switch context to this pair (so analyze.py + full_pipeline see it)
    _switch_pair(symbol, tf)

    # ── 1. Check live exchange positions if real trading is enabled ──
    exchange_name = pair_cfg.get("exchange", "bybit").lower()
    place_orders  = bool(pair_cfg.get("place_orders", False))
    open_pos = None
    if place_orders:
        try:
            from .exchange import get_open_positions
            live = get_open_positions(exchange_name, symbol=symbol)
            if live:
                open_pos = live[0]
                print(f"  {YELLOW}[live] open {open_pos['side']} {open_pos['size']} "
                      f"@ {open_pos['entry']:.6g} · pnl ${open_pos['pnl']:+.2f}{RESET}")
        except Exception as e:
            print(f"  {YELLOW}[live] exchange query failed: {str(e)[:150]}{RESET}")

    # ── 2. Check local position tracker (multi-TP + breakeven state machine) ──
    local_pos = get_open_position(symbol, tf)
    if local_pos:
        state_str = local_pos.get("state", "OPEN")
        hits_str  = ",".join(local_pos.get("tp_hits", [])) or "—"
        print(f"  [tracker] local open {local_pos.get('direction')} "
              f"@ {local_pos.get('entry'):.6g} · state={state_str} · "
              f"hits=[{hits_str}] · current_SL=${local_pos.get('sl_current', local_pos.get('sl', 0)):.6g}")
        try:
            from data.fetcher_ccxt import fetch_ohlcv_stitched_v23
            df, _ = fetch_ohlcv_stitched_v23(symbol, tf, 200)
            if df is not None and len(df):
                cur_price = float(df["close"].iloc[-1])
                # Loop: may have hit MULTIPLE TPs since last check
                for _ in range(4):       # max TP1+TP2+TP3+SL events per tick
                    ev = _check_local_exit(local_pos, df)
                    if ev is None:
                        break
                    event_name = ev["event"]
                    print(f"  {GREEN}[tracker] event={event_name} reason={ev['reason']} "
                          f"@ ${ev.get('exit_price', cur_price):.6g} "
                          f"partial={ev.get('partial_R', 0):+.2f}R "
                          f"realized={ev.get('realized_R', 0):+.2f}R{RESET}")
                    # Build event-specific signal
                    event_signal = {**local_pos,
                                     "event":        event_name,
                                     "verdict":      event_name.upper(),
                                     "exit_price":   ev.get("exit_price"),
                                     "exit_reason":  ev["reason"],
                                     "pnl_R":        ev.get("pnl_R", 0),
                                     "partial_R":    ev.get("partial_R", 0),
                                     "realized_R":   ev.get("realized_R", 0),
                                     "fraction_closed": ev.get("fraction_closed", 0),
                                     "new_sl":       ev.get("new_sl"),
                                     "state":        ev.get("state"),
                                     "tf":           tf,
                                     "symbol":       symbol,
                                     "source":       "auto-trader"}
                    if pair_cfg.get("send_alerts", True):
                        dispatch_all(event_signal,
                                      webhook_key=pair_cfg.get("webhook_key", ""))
                    # Fire per-pair user subscriptions
                    _fire_pair_subs(event_signal, event=event_name)
                    # If first TP hit, ALSO fire a "breakeven_set" event so SL-move
                    # alerts get out
                    if event_name == "tp1_hit":
                        be_signal = {**event_signal,
                                      "event":   "breakeven_set",
                                      "verdict": "BREAKEVEN_SET",
                                      "new_sl":  local_pos.get("entry"),
                                      "exit_price": local_pos.get("entry")}
                        _fire_pair_subs(be_signal, event="breakeven_set")
                    # If position fully closed, log + break
                    if local_pos.get("state") == "CLOSED":
                        close_position_record(symbol, tf,
                                               ev.get("exit_price", cur_price),
                                               ev["reason"],
                                               ev.get("blended_pnl_R", ev.get("pnl_R", 0)))
                        open_pos = None
                        break
                    save_position(symbol, tf, local_pos)
                else:
                    # No new events — just update snapshot
                    pass
                if local_pos.get("state") not in (None, "CLOSED"):
                    local_pos["current_price"] = cur_price
                    save_position(symbol, tf, local_pos)
                    open_pos = local_pos
                    print(f"  [tracker] still open · current ${cur_price:,.6g} · "
                          f"state={local_pos.get('state')}")
        except Exception as e:
            print(f"  {YELLOW}[tracker] price check failed: {str(e)[:150]}{RESET}")

    if open_pos:
        return {"action": "hold", "pair": f"{symbol}@{tf}",
                "reason": f"position open ({open_pos.get('state','OPEN')})"}

    # ── 3. No open position → run analysis ──
    print(f"  {CYAN}no open position → running analysis (full_pipeline){RESET}")
    try:
        # Use analyze.py only (faster than full_pipeline on each tick).
        # Full pipeline still runs once per session via Menu 1.
        rc = subprocess.call([sys.executable, "analyze.py"])
        if rc != 0:
            print(f"  {YELLOW}analyze.py exited rc={rc}{RESET}")
    except Exception as e:
        print(f"  {RED}analyze.py failed: {e}{RESET}")
        return {"action": "skip", "error": str(e)}

    # Read the just-written final_<rid>.json
    rid = f"{symbol.replace('-','_')}_{tf}"
    final = STORE.get_json(f"final_{rid}") or {}
    if not final or final.get("deleted"):
        return {"action": "skip", "reason": "no final_ verdict"}

    verdict   = final.get("verdict", "NO_TRADE")
    direction = final.get("direction")
    win_prob  = float(final.get("win_prob") or 0)
    setup     = final.get("setup", {})

    print(f"  → verdict={verdict}  direction={direction}  win_prob={win_prob*100:.1f}%")

    min_win = float(pair_cfg.get("min_win_prob", 0.55))
    if verdict != "TAKE_TRADE" or win_prob < min_win:
        return {"action": "no_trade", "verdict": verdict, "win_prob": win_prob,
                "min_win": min_win}

    # ── 4. Build signal + dispatch alerts ──
    # WhiteDemon_V8.2: state-machine fields baked in so multi-TP / breakeven lifecycle
    # gets tracked from the very first save.
    _opened_at = datetime.datetime.utcnow().isoformat() + "Z"
    signal = {
        "symbol":   symbol,
        "tf":       tf,
        "direction": direction,
        "verdict":  verdict,
        "win_prob": win_prob,
        "entry":    setup.get("entry"),
        "sl":       setup.get("sl"),
        "sl_current": setup.get("sl"),      # dynamic SL — moves on TP hits
        "tp1":      setup.get("tp1"),
        "tp2":      setup.get("tp2"),
        "tp3":      setup.get("tp3"),
        "rr1":      setup.get("rr1"),
        "rr2":      setup.get("rr2"),
        "rr3":      setup.get("rr3"),
        "smart_sl_chosen": setup.get("smart_sl_chosen"),
        "leverage": int(pair_cfg.get("leverage", 3)),
        "size_pct": float(pair_cfg.get("risk_pct", 1.0)),
        "source":   "auto-trader",
        "opened_at":     _opened_at,
        "last_event_at": _opened_at,
        # State machine
        "state":         "OPEN",
        "tp_hits":       [],
        "realized_R":    0.0,
        # Allocation (informational; engine logic uses _TP1/2/3_FRAC consts)
        "alloc_tp1": _TP1_FRAC,
        "alloc_tp2": _TP2_FRAC,
        "alloc_tp3": _TP3_FRAC,
        "event":    "entry",
    }

    if pair_cfg.get("send_alerts", True):
        dispatch_all(signal, webhook_key=pair_cfg.get("webhook_key", ""))
    # WhiteDemon_V8.2: fire per-pair user subscriptions on ENTRY
    _fire_pair_subs(signal, event="entry")

    # ── 5. Place real CCXT order if enabled ──
    order_result = None
    if place_orders:
        try:
            from .exchange import place_order
            order_result = place_order(exchange_name, signal,
                                        size_pct=float(pair_cfg.get("risk_pct", 1.0)),
                                        leverage=int(pair_cfg.get("leverage", 3)),
                                        dry_run=bool(pair_cfg.get("dry_run", False)))
        except Exception as e:
            print(f"  {RED}[order] failed: {e}{RESET}")
            order_result = {"error": str(e)}

    # ── 6. Save to position tracker ──
    save_position(symbol, tf, {**signal, "order_result": order_result})
    return {"action": "opened", **signal}


# ──────────────────────────────────────────────────────────────────────────
# Multi-TP + breakeven position manager (WhiteDemon_V8.2)
# ──────────────────────────────────────────────────────────────────────────
# A position lifecycle is now a STATE MACHINE:
#
#   OPEN (50%+30%+20% allocated to TP1, TP2, TP3, full SL underneath)
#     │
#     ├── SL_HIT before any TP   → close all, -1.0R
#     │
#     ├── TP1_HIT first
#     │     → close 50% at TP1, move SL to BREAKEVEN (entry price)
#     │     → state becomes BE  (worst case = +0R from here)
#     │
#     ├── TP2_HIT after TP1
#     │     → close 30% at TP2, move SL to TP1 price (lock in 1R)
#     │     → state becomes TRAIL
#     │
#     └── TP3_HIT after TP2
#           → close remaining 20% at TP3
#           → fully closed, blended-R logged
#
# Each transition fires an alert event so subscriptions get notified.
# Events: entry, tp1_hit, breakeven_set, tp2_hit, tp3_hit, sl_hit, closed.
# ──────────────────────────────────────────────────────────────────────────

# Allocation percentages (must sum to 1.0)
_TP1_FRAC = 0.50
_TP2_FRAC = 0.30
_TP3_FRAC = 0.20


def _check_local_exit(pos: Dict, df) -> Optional[Dict]:
    """Stateful TP/SL checker — tracks tp_hits_so_far + dynamic SL.

    Returns one of:
      None                          → still open, nothing happened this bar
      {"event": "tp1_hit", ...}     → first TP hit, SL moved to breakeven
      {"event": "tp2_hit", ...}     → second TP hit, SL moved to TP1
      {"event": "tp3_hit", ...}     → final TP hit, position fully closed
      {"event": "sl_hit",  ...}     → SL hit (could be breakeven or original)
      {"event": "closed",  ...}     → already fully closed (no-op)

    Mutates `pos` in place — caller must save_position() after.
    """
    direction = (pos.get("direction") or "").upper()
    entry  = float(pos.get("entry", 0))
    sl_orig = float(pos.get("sl", 0))
    sl_cur  = float(pos.get("sl_current", sl_orig))    # dynamic SL
    tp1     = float(pos.get("tp1", 0))
    tp2     = float(pos.get("tp2", 0))
    tp3     = float(pos.get("tp3", 0))
    state   = pos.get("state", "OPEN")
    hits    = pos.get("tp_hits", [])
    if state in ("CLOSED", "FULL_CLOSE") or not entry or not sl_orig:
        return None

    # Look at bars SINCE THE LAST STATE CHANGE (not since open) so a TP1 hit
    # bar doesn't accidentally also trigger TP2 in the same bar.
    last_event_at = pos.get("last_event_at") or pos.get("opened_at", "")
    try:
        import pandas as pd
        since_ts = pd.to_datetime(last_event_at)
        df_since = df[df["open_time"] >= since_ts]
        if not len(df_since):
            df_since = df.tail(1)
    except Exception:
        df_since = df.tail(50)

    hi = float(df_since["high"].max())
    lo = float(df_since["low"].min())
    risk = abs(entry - sl_orig) or 1e-9

    def _hit_above(price): return price and hi >= price
    def _hit_below(price): return price and lo <= price

    is_long = direction == "LONG"
    # SL HIT first (always takes priority — represents the worst-case path)
    if (is_long and _hit_below(sl_cur)) or (not is_long and _hit_above(sl_cur)):
        # PnL: if SL moved to breakeven → 0R, if moved to TP1 → 1R already locked
        if state == "OPEN":
            pnl_R = -1.0
            reason = "SL_HIT"
        elif state == "BE":
            # 50% closed at +1R (TP1), 50% closed at 0R (breakeven) → blended +0.5R
            pnl_R = (_TP1_FRAC * float(pos.get("rr1", 1.0))) + ((1 - _TP1_FRAC) * 0.0)
            reason = "BE_SL_HIT_AFTER_TP1"
        elif state == "TRAIL":
            # 50% at TP1 (+rr1) + 30% at TP2 (+rr2) + 20% trail SL at +rr1
            pnl_R = (_TP1_FRAC * float(pos.get("rr1", 1.0)) +
                     _TP2_FRAC * float(pos.get("rr2", 2.0)) +
                     _TP3_FRAC * float(pos.get("rr1", 1.0)))
            reason = "TRAIL_SL_HIT_AFTER_TP2"
        else:
            pnl_R = 0.0
            reason = "SL_HIT"
        pos["state"] = "CLOSED"
        pos["sl_current"] = sl_cur
        return {"event": "sl_hit", "exit_price": sl_cur, "reason": reason,
                "pnl_R": pnl_R, "blended_pnl_R": pnl_R, "state": "CLOSED"}

    # TP1 — only if we haven't hit it yet
    if "tp1" not in hits and tp1 and \
       ((is_long and _hit_above(tp1)) or (not is_long and _hit_below(tp1))):
        hits.append("tp1")
        pos["tp_hits"] = hits
        pos["state"] = "BE"
        pos["sl_current"] = entry           # move SL to breakeven
        pos["last_event_at"] = datetime.datetime.utcnow().isoformat() + "Z"
        rr1 = float(pos.get("rr1", 1.0))
        partial_R = _TP1_FRAC * rr1
        pos["realized_R"] = pos.get("realized_R", 0.0) + partial_R
        return {"event": "tp1_hit", "exit_price": tp1, "reason": "TP1_HIT",
                "pnl_R": partial_R, "partial_R": partial_R,
                "realized_R": pos["realized_R"],
                "new_sl": entry, "fraction_closed": _TP1_FRAC,
                "state": "BE"}

    # TP2 — only if TP1 already hit
    if "tp1" in hits and "tp2" not in hits and tp2 and \
       ((is_long and _hit_above(tp2)) or (not is_long and _hit_below(tp2))):
        hits.append("tp2")
        pos["tp_hits"] = hits
        pos["state"] = "TRAIL"
        pos["sl_current"] = tp1             # trail SL up to TP1
        pos["last_event_at"] = datetime.datetime.utcnow().isoformat() + "Z"
        rr2 = float(pos.get("rr2", 2.0))
        partial_R = _TP2_FRAC * rr2
        pos["realized_R"] = pos.get("realized_R", 0.0) + partial_R
        return {"event": "tp2_hit", "exit_price": tp2, "reason": "TP2_HIT",
                "pnl_R": partial_R, "partial_R": partial_R,
                "realized_R": pos["realized_R"],
                "new_sl": tp1, "fraction_closed": _TP2_FRAC,
                "state": "TRAIL"}

    # TP3 — only if TP1 + TP2 already hit
    if "tp1" in hits and "tp2" in hits and "tp3" not in hits and tp3 and \
       ((is_long and _hit_above(tp3)) or (not is_long and _hit_below(tp3))):
        hits.append("tp3")
        pos["tp_hits"] = hits
        pos["state"] = "CLOSED"
        pos["sl_current"] = tp1
        pos["last_event_at"] = datetime.datetime.utcnow().isoformat() + "Z"
        rr3 = float(pos.get("rr3", 3.0))
        partial_R = _TP3_FRAC * rr3
        pos["realized_R"] = pos.get("realized_R", 0.0) + partial_R
        return {"event": "tp3_hit", "exit_price": tp3, "reason": "TP3_HIT",
                "pnl_R": pos["realized_R"], "partial_R": partial_R,
                "realized_R": pos["realized_R"],
                "fraction_closed": _TP3_FRAC,
                "state": "CLOSED",
                "blended_pnl_R": pos["realized_R"]}

    return None


def _fire_pair_subs(signal: Dict, event: str = "entry"):
    """WhiteDemon_V8.2: send the signal to every per-pair alert subscription that
    matches this pair/tf. Independent of Menu 12 auto-trader pairs."""
    try:
        subs = load_subs()
    except Exception as e:
        print(f"  {YELLOW}[subs] load failed: {e}{RESET}"); return
    sym = signal.get("symbol")
    tf  = signal.get("tf")
    matching = [s for s in subs
                if s.get("pair") == sym and s.get("tf") == tf
                and s.get("enabled", True)]
    if not matching:
        return
    enriched = enrich_signal_for_template(signal)
    print(f"  [subs] firing {len(matching)} subscription(s) for {sym}@{tf} ({event})")
    for s in matching:
        try:
            fire_sub(s, enriched, event=event)
        except Exception as e:
            print(f"  {YELLOW}[subs] fire error: {e}{RESET}")


def run_subscription_pairs_once() -> list:
    """WhiteDemon_V8.2: process every pair that has an alert subscription, even if
    NOT configured in Menu 12 autotrader. Runs FAST MODE (analyze.py) and
    fires the subscription webhooks. Returns list of result dicts."""
    subs = load_subs()
    if not subs:
        return []
    # Group by (pair, tf) — process each combo once
    seen = set()
    pair_configs = []
    for s in subs:
        if not s.get("enabled", True): continue
        key = (s.get("pair"), s.get("tf"))
        if key in seen or not key[0] or not key[1]: continue
        seen.add(key)
        pair_configs.append({
            "symbol":   key[0],
            "tf":       key[1],
            "enabled":  True,
            "send_alerts": False,   # we use subscription's own template
            "place_orders": False,
            "exchange": "",
            "leverage": 1,
            "risk_pct": 0,
            "min_win_prob": 0.50,
            "webhook_key": "",
            "_from_sub": True,
        })
    results = []
    for cfg in pair_configs:
        try:
            r = run_pair_once(cfg)
            results.append(r)
        except Exception as e:
            print(f"  {RED}[subs] pair {cfg.get('symbol')} failed: {e}{RESET}")
    return results


def _switch_pair(symbol: str, tf: str):
    """Update .setup_state.json so analyze.py / full_pipeline.py see this pair."""
    import json as _j, os as _os
    pid = next((p["id"] for p in PAIRS if p["symbol"] == symbol), None)
    tid = next((t["id"] for t in TIMEFRAMES if t["label"] == tf), None)
    if pid is None or tid is None:
        return
    root = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
    for d in (root, _os.getcwd(), "/kaggle/working/crypto-v23",
              "/content/crypto-v23"):
        p = _os.path.join(d, ".setup_state.json")
        if _os.path.exists(p):
            try:
                with open(p) as f: st = _j.load(f)
                st["PAIR_ID"] = pid; st["TF_ID"] = tid
                with open(p, "w") as f: _j.dump(st, f, indent=2)
            except Exception: pass


# ──────────────────────────────────────────────────────────────────────────
# Main loop
# ──────────────────────────────────────────────────────────────────────────
def _next_tick_at(tf: str) -> float:
    """Next aligned bar close + a few seconds buffer."""
    secs = _TF_TO_SECS.get(tf, 900)
    now = time.time()
    next_bar = (int(now // secs) + 1) * secs
    return next_bar + 5      # 5s buffer for candle to close


def loop(once: bool = False, pair_filter: Optional[str] = None,
          tf_filter: Optional[str] = None):
    print(f"\n{BOLD}{CYAN}╔════════════════════════════════════════════╗")
    print(f"║   ⚡ AUTO-TRADER LOOP (24/7) — WhiteDemon_V8.2      ║")
    print(f"╚════════════════════════════════════════════╝{RESET}")

    while True:
        # WhiteDemon_V8.2: pull from BOTH Menu 12 auto-trader pairs AND Menu 14 alert subs.
        # Subscription pairs are processed first; menu-12 pairs may overlap (same
        # symbol+tf) — we de-dupe so analyze.py runs once per pair per tick.
        m12 = get_autotrader_pairs() or []
        if pair_filter:
            m12 = [p for p in m12 if p.get("symbol") == pair_filter]
        if tf_filter:
            m12 = [p for p in m12 if p.get("tf") == tf_filter]
        m12 = [p for p in m12 if p.get("enabled", True)]

        try:
            from .alert_subs import load_subs
            sub_pairs = []
            seen_keys = {(p.get("symbol"), p.get("tf")) for p in m12}
            for s in load_subs():
                if not s.get("enabled", True): continue
                k = (s.get("pair"), s.get("tf"))
                if not k[0] or not k[1] or k in seen_keys: continue
                if pair_filter and s.get("pair") != pair_filter: continue
                if tf_filter   and s.get("tf")   != tf_filter:   continue
                seen_keys.add(k)
                sub_pairs.append({
                    "symbol":   k[0], "tf": k[1], "enabled": True,
                    "send_alerts": False,            # alert subs handle their own webhook
                    "place_orders": False,
                    "exchange": "", "leverage": 1, "risk_pct": 0,
                    "min_win_prob": 0.50, "webhook_key": "",
                    "_from_sub": True,
                })
        except Exception as e:
            sub_pairs = []
            print(f"  {YELLOW}[subs] load failed: {e}{RESET}")

        pairs = m12 + sub_pairs

        if not pairs:
            print(f"\n  {YELLOW}No pairs configured for auto-trading OR alerts.{RESET}")
            print(f"  Add via Menu 12 (auto-trader) or Menu 14 (alert subscriptions)")
            if once: return
            time.sleep(60); continue

        if m12 or sub_pairs:
            print(f"\n  Tick covers: {len(m12)} auto-trader pair(s) + "
                  f"{len(sub_pairs)} alert-only pair(s)")

        # Process each pair sequentially (avoids storage races)
        for cfg in pairs:
            try:
                run_pair_once(cfg)
            except Exception as e:
                print(f"  {RED}pair {cfg.get('symbol')} failed: {e}{RESET}")
                print("  [error] traceback suppressed — see message above", flush=True)

        if once:
            print(f"\n{GREEN}--once mode complete.{RESET}")
            return

        # Sleep until the next bar close (use the SHORTEST TF among enabled pairs)
        next_times = [_next_tick_at(c["tf"]) for c in pairs]
        next_t = min(next_times)
        wait_s = max(10, int(next_t - time.time()))
        print(f"\n{GREY}[sleep] next tick in {wait_s}s ({datetime.datetime.fromtimestamp(next_t).strftime('%H:%M:%S')}){RESET}")
        try:
            time.sleep(wait_s)
        except KeyboardInterrupt:
            print(f"\n{YELLOW}[!] interrupted — exiting auto-trader.{RESET}")
            return


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--once", action="store_true", help="run one tick then exit")
    ap.add_argument("--pair", default=None, help="filter to single symbol")
    ap.add_argument("--tf",   default=None, help="filter to single TF")
    args = ap.parse_args()
    loop(once=args.once, pair_filter=args.pair, tf_filter=args.tf)


if __name__ == "__main__":
    main()
