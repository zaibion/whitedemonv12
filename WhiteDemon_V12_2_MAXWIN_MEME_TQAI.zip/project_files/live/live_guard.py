"""
live_guard.py — WhiteDemon_V8.2
Live trading safety: circuit breaker, stale data check, audit log.
Fail-closed. No hallucination.
"""
from __future__ import annotations
import time, json, os, datetime
from typing import Dict, Any

AUDIT_PATH = "live_audit.jsonl"

class LiveGuard:
    """Fail-closed guard for live trading."""
    def __init__(self, max_stale_sec: int = 120, max_daily_loss_pct: float = 3.0):
        self.max_stale_sec = max_stale_sec
        self.max_daily_loss_pct = max_daily_loss_pct
        self.killed = False
        self.kill_reason = ""
    
    def check_data_freshness(self, last_candle_ts) -> tuple[bool, str]:
        """Reject stale market data."""
        try:
            import pandas as pd
            now = pd.Timestamp.utcnow()
            if hasattr(last_candle_ts, 'tz_localize'):
                ts = pd.Timestamp(last_candle_ts)
            else:
                ts = pd.Timestamp(last_candle_ts)
            if ts.tzinfo is None:
                # assume UTC
                pass
            age = (now - ts.tz_convert('UTC') if getattr(ts, 'tz', None) else now - ts).total_seconds()
            if age > self.max_stale_sec:
                return False, f"Stale data: {age:.0f}s old > {self.max_stale_sec}s"
            return True, "ok"
        except Exception as e:
            return False, f"freshness check failed: {e}"
    
    def check_confidence_gate(self, confidence: dict) -> tuple[bool, str]:
        """Enforce institutional confidence gate."""
        score = float(confidence.get("score", 0))
        passed = bool(confidence.get("pass", False))
        if not passed or score < 62:
            return False, f"Confidence {score} < 62 – BLOCKED"
        return True, f"Confidence {score} grade {confidence.get('grade')} – PASS"
    
    def check_risk_limits(self, setup: dict, account_balance: float = 10000.0) -> tuple[bool, str]:
        """Basic risk sanity."""
        try:
            entry = float(setup.get("entry", 0))
            sl = float(setup.get("sl", 0))
            if entry == 0 or sl == 0:
                return False, "Invalid SL/entry"
            risk_pct = abs(entry - sl) / entry * 100
            if risk_pct > 5.0:
                return False, f"Stop too wide: {risk_pct:.2f}% > 5%"
            if risk_pct < 0.05:
                return False, f"Stop too tight: {risk_pct:.3f}% – likely noise"
            return True, "risk ok"
        except Exception as e:
            return False, f"risk check failed: {e}"
    
    def audit(self, event: str, payload: Dict[str, Any]):
        """Append-only audit log."""
        try:
            rec = {
                "ts": datetime.datetime.utcnow().isoformat() + "Z",
                "event": event,
                **payload
            }
            with open(AUDIT_PATH, "a") as f:
                f.write(json.dumps(rec, default=str) + "\n")
        except Exception:
            pass
    
    def evaluate_trade(self, ctx: Dict[str, Any]) -> Dict[str, Any]:
        """Full pre-trade evaluation. Fail-closed."""
        checks = []
        ok_all = True
        
        # 1. data freshness
        try:
            last_ts = ctx.get("last_candle_ts")
            if last_ts:
                ok, msg = self.check_data_freshness(last_ts)
                checks.append({"check": "freshness", "ok": ok, "msg": msg})
                ok_all &= ok
        except Exception as e:
            checks.append({"check": "freshness", "ok": False, "msg": str(e)})
            ok_all = False
        
        # 2. confidence
        conf = ctx.get("confidence", {})
        ok, msg = self.check_confidence_gate(conf)
        checks.append({"check": "confidence", "ok": ok, "msg": msg})
        ok_all &= ok
        
        # 3. risk
        setup = ctx.get("setup", {})
        ok, msg = self.check_risk_limits(setup)
        checks.append({"check": "risk", "ok": ok, "msg": msg})
        ok_all &= ok
        
        # 4. committee agreement minimum
        p_long = float(ctx.get("p_long", 0.5))
        p_short = float(ctx.get("p_short", 0.5))
        edge = abs(p_long - p_short)
        ok = edge >= 0.06
        checks.append({"check": "committee_edge", "ok": ok, "msg": f"edge={edge:.1%}"})
        ok_all &= ok
        
        # 5. kill switch file
        if os.path.exists("LIVE_KILL"):
            ok_all = False
            checks.append({"check": "kill_switch", "ok": False, "msg": "LIVE_KILL file present"})
        
        result = {
            "allow_trade": ok_all and not self.killed,
            "checks": checks,
            "timestamp": datetime.datetime.utcnow().isoformat() + "Z"
        }
        self.audit("trade_evaluation", result)
        return result
