"""
alert_subs.py — WhiteDemon_V8.2

Per-pair alert subscriptions (TradingView-style).

User flow:
  1. Pick a TRAINED pair (only completed-training pairs offered)
  2. Paste a webhook URL (Discord, Altrady, Wundertrading, Signum, custom...)
  3. Paste an optional JSON template with placeholders:
        {"symbol":"{{symbol}}","side":"{{direction}}","price":{{entry}},
         "stop_loss":{{sl}},"take_profit":{{tp1}},"key":"my-secret"}
  4. Choose alert events: entry / close / both
  5. Bot auto-runs Fast Mode on each bar close and fires the webhook
     with the substituted JSON

Storage key: `alert_subs.json` on Firebase + Supabase + GitHub.
"""
from __future__ import annotations
import json, re, time, datetime
from typing import Dict, List, Optional, Any

import requests

from core.storage import STORE
from core.colors  import GREEN, YELLOW, RED, RESET, CYAN, BOLD, GREY
from core         import checkpoint as ck_mod


_KEY = "alert_subs"


# ──────────────────────────────────────────────────────────────────────────
# Storage
# ──────────────────────────────────────────────────────────────────────────
def load_subs() -> List[Dict]:
    doc = STORE.get_json(_KEY) or {}
    if doc.get("deleted"):
        return []
    return doc.get("subs", [])


def save_subs(subs: List[Dict]) -> bool:
    return STORE.put_json(_KEY, {"subs": subs,
                                 "updated_at": datetime.datetime.utcnow().isoformat() + "Z"},
                          message="alert subscriptions update")


def upsert_sub(sub: Dict) -> bool:
    """Add or update a subscription by id (or pair+tf+url combo)."""
    subs = load_subs()
    sid = sub.get("id")
    if not sid:
        sid = f"{sub.get('pair','')}_{sub.get('tf','')}_{int(time.time())}"
        sub["id"] = sid
    sub["updated_at"] = datetime.datetime.utcnow().isoformat() + "Z"
    for i, s in enumerate(subs):
        if s.get("id") == sid:
            subs[i] = {**s, **sub}
            return save_subs(subs)
    sub.setdefault("created_at", sub["updated_at"])
    subs.append(sub)
    return save_subs(subs)


def delete_sub(sub_id: str) -> bool:
    subs = [s for s in load_subs() if s.get("id") != sub_id]
    return save_subs(subs)


def list_trained_pairs() -> List[Dict]:
    """Return only pairs where ALL training stages are complete.
    Each entry: {symbol, tf_label, last_update}."""
    ready = ck_mod.list_all_ready() or []
    return sorted(ready, key=lambda x: (x.get("symbol"), x.get("tf_label")))


# ──────────────────────────────────────────────────────────────────────────
# Template substitution
# ──────────────────────────────────────────────────────────────────────────
def _flatten(d: Dict, prefix: str = "", out: Dict = None) -> Dict:
    """Flatten nested dict — {'setup':{'sl':1}} → {'setup.sl':1}."""
    if out is None: out = {}
    for k, v in d.items():
        key = f"{prefix}{k}"
        if isinstance(v, dict):
            _flatten(v, key + ".", out)
        else:
            out[key] = v
    return out


def render_template(template: str, signal: Dict) -> str:
    """Replace {{key}} or {{key.nested}} placeholders with signal values.
    Supports: {{symbol}}, {{tf}}, {{direction}}, {{entry}}, {{sl}}, {{tp1}},
              {{tp2}}, {{tp3}}, {{rr1}}, {{win_prob}}, {{verdict}},
              {{leverage}}, {{size_pct}}, {{setup.smart_sl_chosen}}, etc.
    Also adds: {{timestamp}}, {{ts}} (unix sec)."""
    if not template:
        return ""
    flat = _flatten(signal)
    flat["timestamp"] = datetime.datetime.utcnow().isoformat() + "Z"
    flat["ts"]        = int(time.time())
    # Substitute
    def _replace(m):
        k = m.group(1).strip()
        v = flat.get(k, "")
        if isinstance(v, (dict, list)):
            return json.dumps(v)
        return str(v)
    return re.sub(r"\{\{\s*([^\}]+?)\s*\}\}", _replace, template)


# ──────────────────────────────────────────────────────────────────────────
# Dispatcher
# ──────────────────────────────────────────────────────────────────────────
def fire_sub(sub: Dict, signal: Dict, event: str = "entry") -> bool:
    """Send the templated webhook for this subscription. Returns True on success.

    WhiteDemon_V8.2 events:
      entry           — TAKE_TRADE verdict, new position opened
      tp1_hit         — first TP hit, 50% closed
      breakeven_set   — fired right after tp1_hit when SL moves to entry
      tp2_hit         — second TP, 30% closed, SL trailed to TP1
      tp3_hit         — final TP, last 20% closed, position fully done
      sl_hit          — SL triggered (could be original or trailed)
      close           — generic close (kept for backward compat)
    """
    if not sub.get("enabled", True):
        return False
    # Backward compat: if user picked old "close", fire on ANY exit event
    user_events = sub.get("events", ["entry", "close"])
    expanded = set(user_events)
    if "close" in expanded:
        expanded.update({"sl_hit", "tp1_hit", "tp2_hit", "tp3_hit",
                          "breakeven_set"})
    if "entry" in expanded:
        expanded.add("entry")
    if event not in expanded:
        return False
    url = sub.get("webhook_url", "")
    if not url:
        return False
    tmpl = sub.get("json_template") or _default_template()
    rendered = render_template(tmpl, {**signal, "event": event})
    # Try parse to JSON; if it's not valid JSON, send raw string
    try:
        body = json.loads(rendered)
        send_json = True
    except json.JSONDecodeError:
        body = rendered
        send_json = False
    try:
        headers = {}
        # Discord webhooks need content-type
        if "discord.com" in url and send_json and isinstance(body, dict) and "content" not in body and "embeds" not in body:
            body = {"content": json.dumps(body, indent=2)}
        if send_json:
            r = requests.post(url, json=body, timeout=15)
        else:
            r = requests.post(url, data=body,
                              headers={"Content-Type": "text/plain"}, timeout=15)
        ok = 200 <= r.status_code < 300
        sym = signal.get("symbol", "?")
        if ok:
            print(f"  {GREEN}[sub:{sub.get('id','?')[-8:]}] ✓ {event} fired for {sym}{RESET}")
        else:
            print(f"  {YELLOW}[sub] HTTP {r.status_code} for {sym}: {r.text[:200]}{RESET}")
        # Record last fire
        sub["last_fire_at"] = datetime.datetime.utcnow().isoformat() + "Z"
        sub["last_fire_ok"] = ok
        sub["last_fire_status"] = r.status_code
        upsert_sub(sub)
        return ok
    except Exception as e:
        print(f"  {RED}[sub] dispatch error: {str(e)[:200]}{RESET}")
        return False


def _default_template() -> str:
    """Default TradingView/Altrady-style JSON template — handles ALL events
    (entry / tp1_hit / breakeven_set / tp2_hit / tp3_hit / sl_hit).

    The receiving bot reads `event` and `action` to know what to do:
      event=entry         action=buy/sell                  → open position
      event=tp1_hit       action=close_half                 → partial close 50%
      event=breakeven_set action=move_sl, new_sl=<entry>   → modify SL
      event=tp2_hit       action=close_30                   → partial close 30%
      event=tp3_hit       action=close_all                  → close remaining
      event=sl_hit        action=close_all                  → close position

    Most 3rd-party bots (Altrady/Wundertrading) just need: symbol/side/price/sl/tp.
    """
    return json.dumps({
        "action":         "{{action_for_event}}",  # buy/sell/close_partial/move_sl/close_all
        "event":          "{{event}}",             # entry / tp1_hit / breakeven_set / tp2_hit / tp3_hit / sl_hit
        "symbol":         "{{symbol_clean}}",      # BTCUSDT
        "side":           "{{side}}",              # long/short
        "price":          "{{entry}}",             # entry price (or exit price on close events)
        "stop_loss":      "{{sl_current_or_sl}}", # original SL or trailed SL (breakeven, TP1, etc)
        "take_profit":    "{{tp1}}",
        "take_profits":   "[{{tp1}}, {{tp2}}, {{tp3}}]",
        "fraction_closed":"{{fraction_closed}}",   # 0.5 / 0.3 / 0.2 / 1.0
        "new_sl":         "{{new_sl}}",            # only set on breakeven_set / tp2_hit
        "exit_price":     "{{exit_price}}",        # only on TP/SL events
        "realized_R":     "{{realized_R}}",        # running R total
        "pnl_R":          "{{pnl_R}}",             # this event's R contribution
        "leverage":       "{{leverage}}",
        "size_pct":       "{{size_pct}}",
        "verdict":        "{{verdict}}",
        "win_prob":       "{{win_prob}}",
        "tf":             "{{tf}}",
        "strategy":       "crypto-suite-v25",
        "ts":             "{{ts}}",
    }, indent=2)


def enrich_signal_for_template(signal: Dict) -> Dict:
    """Add convenience fields users can reference in JSON templates.

    Computed fields (WhiteDemon_V8.2):
      symbol_clean        — BTC-USD → BTCUSDT
      side                — long / short  (lowercase)
      action              — buy / sell (entry-time)  OR
                            close_50 / close_30 / close_all / move_sl
                            depending on event type
      action_for_event    — same as action but always lifecycle-aware
      sl_current_or_sl    — sl_current if present else sl  (so the receiving
                            bot always gets the LATEST stop, not the original)
    """
    out = dict(signal)
    sym = out.get("symbol", "")
    out.setdefault("symbol_clean",
                   sym.replace("-USD", "USDT").replace("-", "").upper())
    direction = (out.get("direction") or "").upper()
    out.setdefault("side", direction.lower())

    # Always include a current-SL field. Fall back to original.
    out["sl_current_or_sl"] = out.get("sl_current") or out.get("sl") or 0

    # Lifecycle-aware action mapping
    event = (out.get("event") or "entry").lower()
    entry_action = "buy" if direction == "LONG" else "sell"
    exit_action  = "sell" if direction == "LONG" else "buy"
    action_map = {
        "entry":          entry_action,
        "tp1_hit":        f"close_partial_{int(0.5*100)}pct",
        "tp2_hit":        f"close_partial_{int(0.3*100)}pct",
        "tp3_hit":        "close_all",
        "sl_hit":         "close_all",
        "breakeven_set":  "move_sl",
        "close":          "close_all",
    }
    out["action_for_event"] = action_map.get(event, entry_action)
    out.setdefault("action", out["action_for_event"])

    # Side hint for partial-close bots (always opposite of entry direction)
    out["close_side"] = exit_action

    # Make sure all numeric fields have safe defaults
    for k in ("entry","sl","sl_current","tp1","tp2","tp3","rr1","rr2","rr3",
              "win_prob","leverage","size_pct","fraction_closed","new_sl",
              "exit_price","realized_R","pnl_R","partial_R"):
        out.setdefault(k, 0)
    return out
