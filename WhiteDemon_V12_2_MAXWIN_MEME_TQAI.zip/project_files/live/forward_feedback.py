"""
v100 Forward Feedback System
Tracks live signals, resolves against real OHLCV, adjusts confidence multiplier (0.5-1.1x)
"""
import json, os
from datetime import datetime

FEEDBACK_FILE = "live_feedback.json"

def load_feedback():
    if os.path.exists(FEEDBACK_FILE):
        with open(FEEDBACK_FILE) as f:
            return json.load(f)
    return {"trades": [], "multiplier": 1.0}

def save_feedback(data):
    with open(FEEDBACK_FILE, "w") as f:
        json.dump(data, f, indent=2)

def record_trade(signal, entry_price, exit_price=None, pnl=None):
    data = load_feedback()
    data["trades"].append({
        "time": datetime.utcnow().isoformat(),
        "signal": signal,
        "entry": entry_price,
        "exit": exit_price,
        "pnl": pnl
    })
    # Keep only last 30 trades
    data["trades"] = data["trades"][-30:]
    # Update multiplier
    if len(data["trades"]) >= 10:
        wins = sum(1 for t in data["trades"] if t.get("pnl", 0) > 0)
        wr = wins / len(data["trades"])
        if wr < 0.45:
            data["multiplier"] = max(0.5, data["multiplier"] * 0.95)
        elif wr > 0.60:
            data["multiplier"] = min(1.1, data["multiplier"] * 1.02)
    save_feedback(data)
    return data["multiplier"]

def get_confidence_multiplier():
    return load_feedback().get("multiplier", 1.0)
