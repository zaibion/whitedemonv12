"""
credentials.py — WhiteDemon_V8.2

Stores exchange API keys + alert webhook URLs in STORAGE (Firebase/Supabase/
GitHub) — NOT in setup.py. Keys live at `data/live_creds.json` so the bot
can pick them up no matter what machine it's running on.

Public API:
    get_creds() -> dict
    save_creds(payload) -> bool
    get_exchange_creds(exchange: str) -> dict
    get_webhook(name: str) -> str
"""
from __future__ import annotations
import os, json, time
from typing import Dict, Optional

from core.storage import STORE
from core.colors  import GREEN, YELLOW, RED, RESET, CYAN, BOLD, GREY


_KEY = "live_creds"
_LOCAL_CACHE: Dict = {}
_LOCAL_TS = 0
_TTL = 30   # seconds


def get_creds() -> Dict:
    """Get all live creds (cached 30s). Returns empty dict if none saved."""
    global _LOCAL_CACHE, _LOCAL_TS
    if time.time() - _LOCAL_TS < _TTL and _LOCAL_CACHE:
        return _LOCAL_CACHE
    payload = STORE.get_json(_KEY) or {}
    if payload.get("deleted"):
        payload = {}
    _LOCAL_CACHE = payload
    _LOCAL_TS = time.time()
    return payload


def save_creds(payload: Dict) -> bool:
    """Save (or merge) creds to storage."""
    global _LOCAL_CACHE, _LOCAL_TS
    existing = STORE.get_json(_KEY) or {}
    if existing.get("deleted"):
        existing = {}
    # Deep-ish merge so partial updates don't blow away other sections
    for k, v in payload.items():
        if isinstance(v, dict) and isinstance(existing.get(k), dict):
            existing[k].update(v)
        else:
            existing[k] = v
    ok = STORE.put_json(_KEY, existing, message="live creds update")
    _LOCAL_CACHE = existing
    _LOCAL_TS = time.time()
    return ok


def get_exchange_creds(exchange: str) -> Dict:
    """Returns {'apiKey':..,'secret':..,'password':..,'testnet':bool}.
    Empty dict if not configured."""
    return (get_creds().get("exchanges", {}) or {}).get(exchange.lower(), {})


def get_webhook(name: str) -> str:
    """Returns webhook URL for `name` (discord/telegram/altrady/...) or ''."""
    return ((get_creds().get("webhooks", {}) or {}).get(name.lower())) or ""


def get_autotrader_pairs() -> list:
    """List of pair configs the user has enabled for auto-trading.
    Each entry: {'symbol':'BTC-USD','tf':'15m','enabled':True,'send_alerts':True,
                  'place_orders':False,'exchange':'bybit','leverage':3,'risk_pct':1.0,
                  'min_win_prob':0.55,'max_concurrent':1}"""
    return get_creds().get("autotrader_pairs", []) or []


def upsert_autotrader_pair(pair_cfg: Dict) -> bool:
    """Add or update a single pair's auto-trader settings."""
    creds = get_creds()
    pairs = creds.get("autotrader_pairs", [])
    key = (pair_cfg.get("symbol"), pair_cfg.get("tf"))
    for i, p in enumerate(pairs):
        if (p.get("symbol"), p.get("tf")) == key:
            pairs[i] = {**p, **pair_cfg}
            break
    else:
        pairs.append(pair_cfg)
    creds["autotrader_pairs"] = pairs
    return save_creds(creds)


def remove_autotrader_pair(symbol: str, tf: str) -> bool:
    creds = get_creds()
    pairs = creds.get("autotrader_pairs", [])
    creds["autotrader_pairs"] = [p for p in pairs
                                  if (p.get("symbol"), p.get("tf")) != (symbol, tf)]
    return save_creds(creds)
