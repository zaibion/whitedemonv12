"""
live_trader.py — WhiteDemon_V8.2
Continuous live analysis loop with institutional confidence gate.
Fail-closed. Audit-logged. No hallucination.
"""
import time, sys, subprocess, json, datetime
from pathlib import Path

INTERVAL_SEC = 60 * 15  # 15m TF default – run every candle
CONF_THRESHOLD = 62

def run_once():
    print(f"\n{'='*60}\n  LIVE CYCLE {datetime.datetime.utcnow().isoformat()}Z\n{'='*60}")
    rc = subprocess.call([sys.executable, "analyze.py"])
    if rc != 0:
        print(f"  analyze.py rc={rc}")
        return False
    # read confidence from dashboard payload if present
    try:
        from core.storage import STORE
        from core.config import SYMBOL, TF_LABEL
        rid = f"{SYMBOL.replace('-','_')}_{TF_LABEL}"
        d = STORE.get_json(f"dashboard_{rid}") or {}
        conf = d.get("confidence_score", 0)
        grade = d.get("confidence_grade", "?")
        allowed = d.get("trade_allowed", False)
        print(f"  Confidence: {conf} / Grade {grade} / Allowed: {allowed}")
        return allowed
    except Exception as e:
        print(f"  confidence read failed: {e}")
        return False

def main():
    print("🏦 LIVE TRADER WhiteDemon_V8.2 – Ctrl+C to stop, touch LIVE_KILL to emergency stop")
    n = 0
    while True:
        n += 1
        if Path("LIVE_KILL").exists():
            print("🛑 LIVE_KILL detected – exiting")
            break
        try:
            allowed = run_once()
            if allowed:
                print("  ✅ Trade signal PASSED institutional gate – check dashboard")
            else:
                print("  ⏸ No trade – confidence gate blocked")
        except KeyboardInterrupt:
            break
        except Exception as e:
            print(f"  ERROR in cycle: {e}")
        print(f"  Sleeping {INTERVAL_SEC}s … (cycle {n})")
        time.sleep(INTERVAL_SEC)

if __name__ == "__main__":
    main()


# === v100 ENHANCEMENTS ===
from .forward_feedback import record_trade, get_confidence_multiplier

def apply_trailing_stop(position, current_price, atr, entry_price, r_multiple=1.0):
    """Trail stop by 0.5x ATR after 1R profit"""
    if (current_price - entry_price) >= r_multiple * atr:
        trail_dist = 0.5 * atr
        new_sl = current_price - trail_dist if position == "long" else current_price + trail_dist
        return max(new_sl, position.get("sl", 0)) if position == "long" else min(new_sl, position.get("sl", 999999))
    return position.get("sl")

# Auto-apply feedback multiplier on every signal
CONFIDENCE_MULTIPLIER = get_confidence_multiplier()
