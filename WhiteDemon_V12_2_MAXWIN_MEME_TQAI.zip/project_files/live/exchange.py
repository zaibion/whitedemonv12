"""
exchange.py — WhiteDemon_V8.2

Thin CCXT wrapper for live trading.

Supports: bybit, binance, okx, kucoin, bitfinex (whatever CCXT supports)

Public API:
    get_exchange(name) -> ccxt instance (configured with API key + secret)
    get_open_positions(exchange_name) -> list of {symbol, side, size, entry, pnl, ...}
    place_order(exchange_name, signal) -> dict (CCXT order response)
    close_position(exchange_name, symbol, side) -> dict
"""
from __future__ import annotations
import time
from typing import Dict, List, Optional, Any

from core.colors import GREEN, YELLOW, RED, RESET, CYAN, GREY
from .credentials import get_exchange_creds


try:
    import ccxt
    HAS_CCXT = True
except ImportError:
    HAS_CCXT = False


def _yahoo_to_ccxt(symbol: str, quote: str = "USDT") -> str:
    """BTC-USD → BTC/USDT (CCXT unified symbol)."""
    base = symbol.replace("-USD", "").replace("-USDT", "").upper()
    return f"{base}/{quote}"


# ──────────────────────────────────────────────────────────────────────────
# Exchange instance factory
# ──────────────────────────────────────────────────────────────────────────
def get_exchange(name: str):
    if not HAS_CCXT:
        raise RuntimeError("ccxt not installed. pip install ccxt")
    name = name.lower()
    creds = get_exchange_creds(name)
    if not creds.get("apiKey") or not creds.get("secret"):
        raise RuntimeError(f"No API key configured for {name}. "
                            f"Add via Menu 11 → Exchange credentials")
    cls = getattr(ccxt, name, None)
    if cls is None:
        raise RuntimeError(f"Unknown exchange '{name}'. Check ccxt.exchanges.")
    cfg = {
        "apiKey":          creds["apiKey"],
        "secret":          creds["secret"],
        "enableRateLimit": True,
        "options":         {"defaultType": creds.get("market_type", "future")},
    }
    if creds.get("password"):     # OKX needs passphrase
        cfg["password"] = creds["password"]
    ex = cls(cfg)
    if creds.get("testnet"):
        try:
            ex.set_sandbox_mode(True)
            print(f"  [exchange] {name} → TESTNET mode")
        except Exception:
            print(f"  {YELLOW}[exchange] {name}: sandbox mode not supported{RESET}")
    return ex


# ──────────────────────────────────────────────────────────────────────────
# Read-only — open positions / account balance
# ──────────────────────────────────────────────────────────────────────────
def get_open_positions(exchange_name: str,
                        symbol: Optional[str] = None) -> List[Dict]:
    """Return list of currently open positions (size != 0)."""
    try:
        ex = get_exchange(exchange_name)
        pairs = [_yahoo_to_ccxt(symbol)] if symbol else None
        positions = ex.fetch_positions(symbols=pairs)
        out = []
        for p in positions:
            try:
                size = float(p.get("contracts") or p.get("size") or 0)
                if size == 0:
                    continue
                out.append({
                    "symbol":   p.get("symbol", ""),
                    "side":     p.get("side", "").lower(),
                    "size":     size,
                    "entry":    float(p.get("entryPrice") or 0),
                    "mark":     float(p.get("markPrice") or 0),
                    "pnl":      float(p.get("unrealizedPnl") or 0),
                    "leverage": float(p.get("leverage") or 1),
                    "liquidation": float(p.get("liquidationPrice") or 0),
                    "raw":      p,
                })
            except Exception:
                continue
        return out
    except Exception as e:
        print(f"  {YELLOW}[exchange] fetch_positions failed: {str(e)[:200]}{RESET}")
        return []


def get_balance(exchange_name: str, quote: str = "USDT") -> float:
    try:
        ex = get_exchange(exchange_name)
        bal = ex.fetch_balance()
        free = float((bal.get(quote, {}) or {}).get("free", 0) or 0)
        return free
    except Exception as e:
        print(f"  {YELLOW}[exchange] fetch_balance failed: {str(e)[:200]}{RESET}")
        return 0.0


# ──────────────────────────────────────────────────────────────────────────
# Order placement
# ──────────────────────────────────────────────────────────────────────────
def place_order(exchange_name: str, signal: Dict,
                 size_pct: float = 1.0,
                 leverage: int = 3,
                 dry_run: bool = False) -> Dict:
    """Place market entry + attach SL and TP1 reduce-only orders.

    signal: {symbol, direction (LONG/SHORT), entry, sl, tp1, tp2, tp3, ...}
    size_pct: % of free balance to risk per trade  (NOT % of equity for position size —
              the position size is computed from risk_amount / SL distance)

    Returns: {entry_order, sl_order, tp1_order, ...} dict
    """
    try:
        ex     = get_exchange(exchange_name)
        symbol = _yahoo_to_ccxt(signal.get("symbol", ""))
        side   = "buy" if signal.get("direction") == "LONG" else "sell"
        exit_side = "sell" if side == "buy" else "buy"
        entry  = float(signal.get("entry", 0))
        sl     = float(signal.get("sl", 0))
        tp1    = float(signal.get("tp1", 0))
        if entry <= 0 or sl <= 0:
            return {"error": "invalid entry/sl"}

        # Set leverage (best-effort, some exchanges silently ignore)
        try:
            ex.set_leverage(leverage, symbol)
        except Exception as e:
            print(f"  {GREY}[order] set_leverage skipped: {str(e)[:120]}{RESET}")

        # Position size: risk size_pct% of free balance per trade
        free = get_balance(exchange_name)
        risk_amount = free * (size_pct / 100.0)
        sl_dist_pct = abs(entry - sl) / entry
        if sl_dist_pct <= 0:
            return {"error": "zero SL distance"}
        notional = risk_amount / sl_dist_pct          # USDT notional
        notional_with_lev = notional * leverage
        amount = notional_with_lev / entry             # base coin amount

        print(f"  {CYAN}[order] {side.upper()} {symbol} amount={amount:.6f} "
              f"lev={leverage}× risk={size_pct}% (~${risk_amount:.2f}){RESET}")
        if dry_run:
            return {"dry_run": True, "amount": amount, "leverage": leverage,
                    "notional": notional, "side": side, "symbol": symbol}

        # Entry market order
        entry_order = ex.create_order(symbol, "market", side, amount,
                                       params={"reduceOnly": False})
        out = {"entry_order": entry_order}
        time.sleep(1.0)

        # SL stop-market reduceOnly
        try:
            sl_order = ex.create_order(symbol, "stop", exit_side, amount,
                                        sl,
                                        params={"reduceOnly": True,
                                                 "stopPrice": sl,
                                                 "triggerPrice": sl,
                                                 "trigger": "last_price"})
            out["sl_order"] = sl_order
            print(f"  {GREEN}[order] SL placed @ {sl}{RESET}")
        except Exception as e:
            print(f"  {YELLOW}[order] SL place failed: {str(e)[:200]}{RESET}")

        # TP1 limit reduceOnly (50% of position)
        try:
            tp1_amt = amount * 0.5
            tp1_order = ex.create_order(symbol, "limit", exit_side, tp1_amt, tp1,
                                         params={"reduceOnly": True})
            out["tp1_order"] = tp1_order
            print(f"  {GREEN}[order] TP1 placed @ {tp1} (50% size){RESET}")
        except Exception as e:
            print(f"  {YELLOW}[order] TP1 place failed: {str(e)[:200]}{RESET}")

        print(f"  {GREEN}[order] ✓ entry+SL+TP1 placed on {exchange_name}{RESET}")
        return out
    except Exception as e:
        print(f"  {RED}[order] FAILED: {str(e)[:300]}{RESET}")
        print("  [error] traceback suppressed — see message above", flush=True)
        return {"error": str(e)}


def close_position(exchange_name: str, symbol: str,
                    side: str) -> Dict:
    """Market-close an open position."""
    try:
        ex = get_exchange(exchange_name)
        pair = _yahoo_to_ccxt(symbol)
        positions = ex.fetch_positions(symbols=[pair])
        for p in positions:
            sz = float(p.get("contracts") or p.get("size") or 0)
            if sz == 0:
                continue
            exit_side = "sell" if side == "long" else "buy"
            order = ex.create_order(pair, "market", exit_side, abs(sz),
                                     params={"reduceOnly": True})
            print(f"  {GREEN}[close] {pair} {side} closed at market{RESET}")
            return {"order": order}
        return {"error": "no open position"}
    except Exception as e:
        print(f"  {RED}[close] failed: {str(e)[:200]}{RESET}")
        return {"error": str(e)}
