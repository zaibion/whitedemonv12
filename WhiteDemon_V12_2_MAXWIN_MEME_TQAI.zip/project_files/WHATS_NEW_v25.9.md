# Crypto Suite WhiteDemon_V8.2 — Force FULL pipeline · no more slim-cache shortcut

## ❗ You were right: Fast Mode / Assemble were still using slim cache

ML/DL/Neural tabs showed blank because:
- `analyze.py` *did* call `run_ml_committee` (WhiteDemon_V8.2), but if the call had any
  partial failure it silently fell back to the slim cached JSON which only
  carries `stack_bull`. `preds`, `probs`, `wf_accs`, `dl_individual` were empty.
- The "Assemble" path (`train_specific.py --reassemble`) writes synthetic slim
  JSONs from per-model index metadata — no real model votes inside.
- Fast Mode in run.py was calling `analyze.py` directly — so any cached slim
  result would short-circuit a real committee rebuild.

## ✅ The 10-step "force full pipeline" runner

**NEW file:** `full_pipeline.py`. Runs all 10 steps you asked for in order:

```
1. Train all missing classical/DL models       (train_specific.py --missing)
2. Force rebuild LONG/SHORT committees         (train_specific.py --reassemble)
3. Run specialised neural nets                 (train_pipeline w/ flags reset)
4. Run meta/stacker                            (part of step 3)
5. Run triple-barrier setup models             (part of step 3)
6. Run Monte Carlo robustness                  (during step 10 analyze)
7. Build dashboard / final verdict             (part of step 3)
8. Reassemble cache                            (train_specific.py --reassemble)
9. Fetch fresh latest 4k candles               (analyze.py)
10. Run analysis on those candles + push HTML  (analyze.py)
```

Before step 3 it **resets the checkpoint flags** for `specialized_nns`,
`stacker`, `save_dashboard` so the engine actually re-runs them.

## 🔁 Every "analysis" entry point now uses full_pipeline.py

| Old path | What now triggers `full_pipeline.py` |
|---|---|
| Menu 4 → Sub-menu 8 → `[1] START ANALYSIS`     | ✅ |
| Menu 4 → Sub-menu 8 → `[2] START ANALYSIS AGAIN` | ✅ |
| Menu 4 → Sub-menu 8 → `[3] FAST MODE`          | ✅ (was slim-cache before) |
| Menu 1 sub-menu → `[2] FAST MODE`              | ✅ |
| Menu 7 → `[2] Run COLLECT ALL`                 | ✅ |
| Menu 8 → pick pair → analyze                   | ✅ |
| Menu 10 COLLECT ALL                            | ✅ |
| `python run.py fast`                            | ✅ |

The ONLY path that still skips full_pipeline is **Menu 4 → Sub-menu 8 → [4]
ANALYSIS USING ONLY TRAINED MODELS** — which by your spec should only
reassemble + analyze without training missing.

## 🛠 analyze.py improvements

- Hydrate slim cache fallback now copies ALL useful fields (`preds`, `probs`,
  `wf_accs`, `dl_individual`, `brier_scores`, `logloss_scores`,
  `feature_importance`, `price_reg_nn`, `rl_agent`, `sentiment_nn`,
  `regime_nn`) — so even if the live committee call fails, dashboard tabs
  show whatever data is available.
- Marks slim fallback rows with `_from_slim_cache: True` so the dashboard
  shows a yellow warning under the table.
- **Persists the RICH committee result** back into `long_<rid>` /
  `short_<rid>` slim cache after every successful run — so future Assemble
  + Fast Mode reads ALSO get full data, not just `stack_bull`.

## 🎨 Frontend improvements (dashboard.html)

- `renderModels()` tolerates slim-cache results — shows whatever data exists
  (wf_accs even without preds), not "Not trained".
- `renderDL()` now shows BOTH LONG and SHORT columns side-by-side (was only
  showing committee's direction). Always renders all 14 architectures.
- Shows yellow warning when data came from slim cache: "⚠ from slim cache —
  run full_pipeline.py for live inference".
- `listKeys()` now scans GitHub + Supabase + Firebase RTDB (shallow query) —
  the pair-picker finds analyses across all backends.
- `refreshPairPicker()` regex matches multiple naming patterns
  (`final_*`, `dashboard_data_*`, `checkpoints/*`).

## 🚀 Quick start

```python
# Kaggle / Colab
%cd /kaggle/working/crypto-v23

# THE main thing — explicit 10-step pipeline
%run full_pipeline.py

# OR via interactive menu (all "analysis" options now wire to full_pipeline)
%run run.py

# OR web dashboard (now works after server.py fix in WhiteDemon_V8.2)
%run server.py    # → http://localhost:8000
```

## 📋 Files changed since WhiteDemon_V8.2

```
full_pipeline.py        — NEW. The 10-step explicit force-rebuild runner.
analyze.py              — slim-cache hydrator + persist rich result back
run.py                  — all analysis paths now call full_pipeline.py
frontend/dashboard.html — robust renderers, multi-backend listKeys
WHATS_NEW_WhiteDemon_V8.2.md      — this file
```
