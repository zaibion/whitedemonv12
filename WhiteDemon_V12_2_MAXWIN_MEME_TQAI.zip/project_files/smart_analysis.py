"""WhiteDemon Smart Analysis (V10.6)

One unified analysis launcher:
  1) checks trained model/cache status
  2) ensures committee bundles exist using cached models (no retrain if already done)
  3) trains only missing committee models if needed
  4) runs the latest analyze.py once as the final authoritative output

Use this when you want the 'full pipeline safety' but final result from the
unified V10 analyzer.
"""
from __future__ import annotations
import sys, subprocess, datetime

from core.config import SYMBOL, TF_LABEL, CFG
from core.colors import BOLD, CYAN, GREEN, YELLOW, RED, RESET
from core import per_model_cache as pmc

CLASSICAL = "lr,knn,rf,et,xgb,lgb,cat,hgb,mlp"
DL = "lstm,bilstm,gru,tcn,wavenet,transformer,cnn1d,nbeats,mamba,patchtst,itransformer,frets,tft,mamba_pdf"
EXPECTED_CLS = 9
EXPECTED_DL = 14


def _counts_to_try():
    target = int(CFG.get("target_total_candles", 200_000))
    out = []
    for x in (target, 200_000, 100_000, 60_000, 30_000, 10_000):
        if x not in out:
            out.append(int(x))
    return out


def _bundle_exists(count: int) -> bool:
    try:
        from core.committee_bundle import load_committee_bundle
        return bool(load_committee_bundle(SYMBOL, TF_LABEL, "LONG", count) and
                    load_committee_bundle(SYMBOL, TF_LABEL, "SHORT", count))
    except Exception:
        return False


def _status(count: int) -> dict:
    dl = pmc.list_done(SYMBOL, TF_LABEL, "LONG", count)
    ds = pmc.list_done(SYMBOL, TF_LABEL, "SHORT", count)
    return {
        "count": count,
        "long": dl,
        "short": ds,
        "n_long": len(dl.get("classical", [])) + len(dl.get("dl", [])),
        "n_short": len(ds.get("classical", [])) + len(ds.get("dl", [])),
        "complete": (len(dl.get("classical", [])) >= EXPECTED_CLS and
                     len(dl.get("dl", [])) >= EXPECTED_DL and
                     len(ds.get("classical", [])) >= EXPECTED_CLS and
                     len(ds.get("dl", [])) >= EXPECTED_DL),
        "bundle": _bundle_exists(count),
    }


def _best_status() -> dict:
    stats = [_status(c) for c in _counts_to_try()]
    # Prefer complete+bundle, then complete, then most models.
    stats.sort(key=lambda s: (s["complete"] and s["bundle"], s["complete"], s["n_long"] + s["n_short"]), reverse=True)
    return stats[0]


def _ensure_committees_and_bundles(count: int):
    print(f"\n{BOLD}{CYAN}━━ Smart ensure: committee models + full bundles · {SYMBOL} @ {TF_LABEL} ━━{RESET}")
    print(f"  Target count: {count:,}")
    print("  This uses cached models when present. Missing models train; completed models skip.")
    cmd = [sys.executable, "train_specific.py", "--direction", "BOTH",
           "--classical", CLASSICAL, "--dl", DL, "--candles", str(count)]
    rc = subprocess.call(cmd)
    if rc != 0:
        print(f"  {YELLOW}train_specific returned rc={rc}; continuing to final analyze with available cache.{RESET}")


def main():
    print(f"\n{BOLD}{CYAN}══ SMART ANALYSIS V10.6 · {SYMBOL} @ {TF_LABEL} ══{RESET}")
    st = _best_status()
    print(f"  Cache status @ {st['count']:,}: LONG {st['n_long']}/23 · SHORT {st['n_short']}/23 · bundle={st['bundle']}")

    # If full bundle missing or models incomplete, ensure first. This gives the
    # 'full pipeline' reliability but avoids retraining already saved models.
    if not (st["complete"] and st["bundle"]):
        print(f"  {YELLOW}Models/bundles incomplete for best FAST inference — ensuring now.{RESET}")
        _ensure_committees_and_bundles(st["count"])
    else:
        print(f"  {GREEN}✓ Models and full bundles complete — running final analyzer only.{RESET}")

    print(f"\n{BOLD}{CYAN}━━ Final authoritative analysis (unified analyze.py) ━━{RESET}\n")
    subprocess.call([sys.executable, "analyze.py"])


if __name__ == "__main__":
    main()
