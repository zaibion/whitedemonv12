# WhiteDemon V10.0 — Current Market Similarity Check

## Purpose
Prevents the model from blindly repeating training bias.

Example problem:
- training period was mostly bullish
- model learned LONG baseline
- current market is not like past winning LONG setups
- old logic could still lean LONG

V10.0 adds a current market similarity check.

## What changed

### 1) Similarity profile saved during training
When a committee bundle is saved, the system now stores what historical **winning** and **losing** setups looked like in scaled feature space:

- winner feature median
- loser feature median
- winner feature MAD/spread
- number of winning samples
- number of losing samples

This is saved inside the full committee bundle.

### 2) Similarity checked during FAST MODE
During analyze / FAST MODE, the latest 4k-candle feature state is compared against the saved profile.

It reports:

```text
market similarity: score=... · closer_to=WINNERS/LOSERS
```

### 3) Trade blocking
By default, the setup is blocked if:

- similarity score is too low
- current market is closer to historical losers than winners
- similarity profile is unavailable

Default threshold:

```text
high_precision_min_market_similarity = 0.35
```

### 4) Still no retraining during analyze
The model uses saved training as reference, then checks today's 4k candles against the patterns it learned.

### 5) DL all-model FAST MODE retained
V10.0 includes V9.8 all-model FAST MODE improvements:
- classical bundle inference
- cached DL state_dict inference when available
- no retraining during analyze

## Important
Existing old bundles do not have similarity profiles. You need one clean V10.0 training run to create similarity-enabled bundles.

If old bundles are used, analyze will say similarity unavailable and block/watch according to config.

## Checks
- compileall passed
- tabnanny passed
- pyflakes syntax/undefined-name scan passed
