"""
entry_filter_institutional.py — Elite Entry Gate V12
7-layer confluence, no trade unless all pass
"""

from __future__ import annotations
from typing import Dict, Any

def elite_entry_gate(signal: Dict[str, Any]) -> Dict[str, Any]:
    fails = []
    # 1 meta
    if not signal.get("passes_meta", False):
        fails.append("META_FAIL")
    if signal.get("meta_prob_live", 0) < 0.62:
        fails.append("META_PROB_LOW")
    # 2 win rate edge
    if signal.get("pass_winrate", 0) < 0.68:
        fails.append("WINRATE_LOW")
    # 3 stack bull
    sb = signal.get("stack_bull", signal.get("meta_prob_live", 0.5))
    if sb < 0.60 or sb > 0.88:  # avoid overconfidence
        fails.append("STACK_OUT_OF_BAND")
    # 4 drift
    if signal.get("drift_level") in ("drift","extreme"):
        if signal.get("psi_max", 0) > 0.30:
            fails.append("DRIFT_HIGH")
    # 5 Brier
    if signal.get("brier_mean", 0.20) > 0.22:
        fails.append("BRIER_HIGH")
    # 6 spread / liquidity — stub pass, real check in execution_quality
    # 7 risk manager
    if not signal.get("trade_allowed", True):
        fails.append("RISK_BLOCK")
    passed = len(fails) == 0
    return {
        "elite_pass": passed,
        "elite_fails": fails,
        "elite_score": max(0, 7 - len(fails)),
        "institutional_entry": "v12"
    }
