"""
setup_builder.py — WhiteDemon_V8.2

Thin wrapper around `_engine.build_setup` that ALSO applies smart-SL
placement (wick buffer + volume profile gap + liquidation cluster avoidance
+ optional Bayesian NN).

Backward compatible: callers still do `build_setup(direction, price,
sr_levels, demand, supply, atr)` — the smart-SL logic is enabled by setting
context with `set_smart_sl_context(df, liq_clusters, sl_nn, ...)` first.
"""
from __future__ import annotations
import os, threading
from typing import Optional, List, Dict
from _engine import build_setup as _engine_build_setup


_ctx_local = threading.local()


def set_smart_sl_context(df=None, liq_clusters=None, sl_nn=None,
                         aggressiveness: str = "balanced",
                         enabled: bool = True):
    """Call BEFORE build_setup() to opt in to smart-SL.
    Pass enabled=False to use raw engine behaviour."""
    _ctx_local.df             = df
    _ctx_local.liq_clusters   = liq_clusters
    _ctx_local.sl_nn          = sl_nn
    _ctx_local.aggressiveness = aggressiveness
    _ctx_local.enabled        = enabled


def clear_smart_sl_context():
    for a in ("df", "liq_clusters", "sl_nn", "aggressiveness", "enabled"):
        if hasattr(_ctx_local, a): delattr(_ctx_local, a)


def build_setup(direction, price, sr_levels, demand_zones, supply_zones, atr_val):
    """Engine build_setup + optional smart-SL post-processing."""
    setup = _engine_build_setup(direction, price, sr_levels,
                                 demand_zones, supply_zones, atr_val)
    if not setup or not setup.get("valid"):
        return setup

    enabled = getattr(_ctx_local, "enabled", False)
    df      = getattr(_ctx_local, "df",      None)
    if not enabled or df is None:
        return setup

    try:
        from .smart_sl import apply_smart_sl
        liq_clusters = getattr(_ctx_local, "liq_clusters", None) or []
        sl_nn        = getattr(_ctx_local, "sl_nn",        None)
        aggro        = getattr(_ctx_local, "aggressiveness", "balanced")
        smart = apply_smart_sl(setup, df, atr_val, direction,
                                liq_clusters=liq_clusters,
                                sl_nn=sl_nn,
                                aggressiveness=aggro)
        return smart
    except Exception as e:
        # On any error, fall back to raw engine setup — never break analyze
        print(f"  [smart-sl] error (using raw engine SL): {e}")
        return setup
