"""
smart_sl.py — WhiteDemon_V8.2

Smart stop-loss placement that combines multiple signals to dodge
liquidity hunts:

  • Historical wick analysis (last N bars: how far does price typically
    spike below a swing low before reversing?)
  • Volume profile gap (place SL just past the nearest low-volume node —
    where nobody else's stops are)
  • Liquidation cluster avoidance (Binance / Bybit public liq feed)
  • Safe minimum (never tighter than 1.2× ATR)
  • Bayesian SL NN (if trained — see neural_nets/sl_placement_nn.py)

Public API:
    apply_smart_sl(setup, df, atr_val, direction,
                    liq_clusters=None, sl_nn=None) -> setup
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from typing import Optional, List, Dict


# ──────────────────────────────────────────────────────────────────────────
# Building blocks
# ──────────────────────────────────────────────────────────────────────────
def compute_wick_buffer(df: pd.DataFrame, direction: str,
                        lookback: int = 100) -> float:
    """Average distance price spiked BEYOND the apparent swing low/high
    before continuing in the trade direction.

    For LONG: look at recent bullish bars (close > open). For each one,
              find the lowest low in the surrounding window (i-2 .. i+3).
              The wick = abs(this bar's low - that local min). Average it.
    For SHORT: same but with highs.

    Returns: float distance in price units (NOT percentage). Defaults to 0
             if data insufficient.
    """
    if df is None or len(df) < lookback + 10:
        return 0.0
    tail = df.tail(lookback + 10).reset_index(drop=True)
    wicks: List[float] = []
    if direction == "LONG":
        for i in range(2, len(tail) - 3):
            if tail.loc[i, "close"] > tail.loc[i, "open"]:
                window_low = tail.loc[i-2:i+3, "low"].min()
                wick = abs(tail.loc[i, "low"] - window_low)
                if wick > 0:
                    wicks.append(wick)
    else:  # SHORT
        for i in range(2, len(tail) - 3):
            if tail.loc[i, "close"] < tail.loc[i, "open"]:
                window_high = tail.loc[i-2:i+3, "high"].max()
                wick = abs(window_high - tail.loc[i, "high"])
                if wick > 0:
                    wicks.append(wick)
    if not wicks:
        return 0.0
    arr = np.array(wicks)
    # Use 70th percentile so we're protected against typical hunts,
    # not blown out by the worst flash crash
    return float(np.percentile(arr, 70) * 1.20)


def compute_volume_profile_gap(df: pd.DataFrame, target_price: float,
                                direction: str, atr_val: float,
                                bins: int = 50) -> Optional[float]:
    """Find the nearest LOW-VOLUME node beyond `target_price` in the
    direction OPPOSITE to the trade (i.e. where the SL would sit).

    Idea: high-volume nodes = where many trades happened = where many
    stops are clustered. Low-volume nodes = liquidity vacuum. Placing
    the SL just past a low-volume node means market makers have less
    incentive to push price there.

    Returns: price float, or None if nothing found within 4×ATR.
    """
    if df is None or len(df) < 100:
        return None
    tail = df.tail(500)
    prices = tail["close"].values
    vols   = tail["volume"].values if "volume" in tail.columns else \
             np.ones_like(prices)
    pmin, pmax = float(prices.min()), float(prices.max())
    if pmax <= pmin:
        return None
    hist, edges = np.histogram(prices, bins=bins, weights=vols,
                               range=(pmin, pmax))
    centers = 0.5 * (edges[:-1] + edges[1:])
    # Search within 4×ATR window opposite to trade direction
    search_lo = target_price - 4 * atr_val
    search_hi = target_price + 4 * atr_val
    mask = (centers >= search_lo) & (centers <= search_hi)
    if not mask.any():
        return None
    cands_centers = centers[mask]
    cands_vol     = hist[mask]
    if len(cands_vol) == 0:
        return None
    # For LONG: SL is BELOW entry → find lowest-volume bin BELOW target_price
    # For SHORT: SL is ABOVE entry → find lowest-volume bin ABOVE target_price
    if direction == "LONG":
        below_mask = cands_centers < target_price
        if not below_mask.any():
            return None
        sub_centers = cands_centers[below_mask]
        sub_vol     = cands_vol[below_mask]
        idx = int(np.argmin(sub_vol))
        # Place SL just past this low-vol node
        return float(sub_centers[idx] - 0.1 * atr_val)
    else:
        above_mask = cands_centers > target_price
        if not above_mask.any():
            return None
        sub_centers = cands_centers[above_mask]
        sub_vol     = cands_vol[above_mask]
        idx = int(np.argmin(sub_vol))
        return float(sub_centers[idx] + 0.1 * atr_val)


def avoid_liq_clusters(sl_price: float, entry: float, direction: str,
                       atr_val: float,
                       liq_clusters: Optional[List[Dict]] = None) -> float:
    """Push SL beyond any liquidation cluster between entry and current SL.

    liq_clusters: [{"price": float, "magnitude": float}, ...]
                  magnitude is total liquidation $ at that price.

    Returns: adjusted SL price.
    """
    if not liq_clusters:
        return sl_price
    if direction == "LONG":
        # Find clusters BETWEEN sl_price and entry (in our SL range)
        between = [c for c in liq_clusters
                   if sl_price <= c.get("price", 0) <= entry
                   and c.get("magnitude", 0) > 0]
        if between:
            # Push SL below the lowest cluster + 0.3 ATR buffer
            lowest_cluster_price = min(c["price"] for c in between)
            new_sl = lowest_cluster_price - 0.30 * atr_val
            if new_sl < sl_price:   # only widen, never tighten
                return float(new_sl)
    else:  # SHORT
        between = [c for c in liq_clusters
                   if entry <= c.get("price", 0) <= sl_price
                   and c.get("magnitude", 0) > 0]
        if between:
            highest_cluster_price = max(c["price"] for c in between)
            new_sl = highest_cluster_price + 0.30 * atr_val
            if new_sl > sl_price:
                return float(new_sl)
    return sl_price


# ──────────────────────────────────────────────────────────────────────────
# Main entry point
# ──────────────────────────────────────────────────────────────────────────
SAFE_MIN_SL_ATR = 1.20      # never tighter than this
SAFE_MAX_SL_ATR = 4.50      # never wider than this (risk budget)


def apply_smart_sl(setup: dict, df: pd.DataFrame, atr_val: float,
                   direction: str,
                   liq_clusters: Optional[List[Dict]] = None,
                   sl_nn=None,
                   aggressiveness: str = "balanced") -> dict:
    """Take engine's `build_setup` output and widen SL based on all signals.

    aggressiveness ∈ {"conservative", "balanced", "aggressive"}:
      conservative: +0.5×ATR buffer, no liq cluster check, wick buffer × 0.7
      balanced    : +1.0×ATR buffer, liq cluster check, wick buffer × 1.0
      aggressive  : +1.5×ATR buffer, liq cluster check, wick buffer × 1.5,
                    plus NN override if available
    """
    if not setup or not setup.get("valid"):
        return setup

    entry        = float(setup.get("entry", 0))
    original_sl  = float(setup.get("sl", 0))
    if entry <= 0 or original_sl <= 0 or atr_val <= 0:
        return setup

    # ── 1. Tier multipliers based on aggressiveness ──
    mult_atr_buf  = {"conservative": 0.5, "balanced": 1.0, "aggressive": 1.5}.get(
        aggressiveness, 1.0)
    mult_wick     = {"conservative": 0.7, "balanced": 1.0, "aggressive": 1.5}.get(
        aggressiveness, 1.0)
    use_liq       = aggressiveness in ("balanced", "aggressive")
    use_nn        = aggressiveness == "aggressive" and sl_nn is not None

    # ── 2. Compute candidate SLs ──
    candidates = {"original_struct": original_sl}

    # 2a. Always-on ATR-buffered original
    if direction == "LONG":
        candidates["atr_buffer"] = original_sl - mult_atr_buf * atr_val
    else:
        candidates["atr_buffer"] = original_sl + mult_atr_buf * atr_val

    # 2b. Historical wick buffer
    try:
        wick = compute_wick_buffer(df, direction, lookback=100) * mult_wick
        if wick > 0:
            if direction == "LONG":
                candidates["wick_buffer"] = original_sl - wick
            else:
                candidates["wick_buffer"] = original_sl + wick
    except Exception:
        pass

    # 2c. Volume profile gap
    try:
        vp_target = entry      # search around entry, not original sl
        vp_sl = compute_volume_profile_gap(df, vp_target, direction, atr_val)
        if vp_sl is not None:
            if direction == "LONG" and vp_sl < original_sl:
                candidates["vp_low_node"] = vp_sl
            elif direction == "SHORT" and vp_sl > original_sl:
                candidates["vp_low_node"] = vp_sl
    except Exception:
        pass

    # 2d. Liquidation cluster avoidance
    if use_liq:
        try:
            new = avoid_liq_clusters(original_sl, entry, direction, atr_val,
                                     liq_clusters or [])
            if (direction == "LONG" and new < original_sl) or \
               (direction == "SHORT" and new > original_sl):
                candidates["liq_avoid"] = new
        except Exception:
            pass

    # 2e. Bayesian SL NN (if available)
    if use_nn and sl_nn is not None:
        try:
            pred_atr = sl_nn.predict(df, direction)  # returns float (multiples of ATR)
            if pred_atr and 0.5 < pred_atr < 5.0:
                if direction == "LONG":
                    candidates["nn_predict"] = entry - pred_atr * atr_val
                else:
                    candidates["nn_predict"] = entry + pred_atr * atr_val
        except Exception:
            pass

    # ── 3. Pick the FURTHEST safe candidate ──
    if direction == "LONG":
        final = min(candidates.values())            # furthest below
        # Clamp to safe min/max
        final = min(final, entry - SAFE_MIN_SL_ATR * atr_val)
        final = max(final, entry - SAFE_MAX_SL_ATR * atr_val)
    else:
        final = max(candidates.values())            # furthest above
        final = max(final, entry + SAFE_MIN_SL_ATR * atr_val)
        final = min(final, entry + SAFE_MAX_SL_ATR * atr_val)

    final = round(float(final), 6)
    new_risk = abs(entry - final)
    if new_risk <= 0:
        return setup    # something weird, fall back

    # ── 4. Recompute R:Rs against new wider SL ──
    out = dict(setup)
    out["original_sl"]    = original_sl
    out["sl"]             = final
    out["risk"]           = round(new_risk, 6)
    out["risk_pct"]       = round(new_risk / entry * 100, 4)
    out["sl_dist_atr"]    = round(new_risk / atr_val, 2)
    out["smart_sl_candidates"] = {k: round(v, 6) for k, v in candidates.items()}
    out["smart_sl_chosen"] = "FURTHEST_SAFE"
    out["smart_sl_aggressiveness"] = aggressiveness

    for k in ("tp1", "tp2", "tp3"):
        if k in out and out[k]:
            out[f"rr_{k[2:]}"] = round(abs(out[k] - entry) / new_risk, 2)

    # Also recompute the headline rr1/rr2/rr3 fields the dashboard reads
    if "tp1" in out: out["rr1"] = round(abs(out["tp1"] - entry) / new_risk, 2)
    if "tp2" in out: out["rr2"] = round(abs(out["tp2"] - entry) / new_risk, 2)
    if "tp3" in out: out["rr3"] = round(abs(out["tp3"] - entry) / new_risk, 2)

    # Updated reason note
    chosen = min(candidates.items(), key=lambda kv: kv[1]) if direction == "LONG" \
             else max(candidates.items(), key=lambda kv: kv[1])
    out["smart_sl_reason"] = (
        f"Smart-SL widened from {original_sl:.6f} → {final:.6f} "
        f"({(new_risk/atr_val):.2f}× ATR) · chosen={chosen[0]} · "
        f"signals={list(candidates.keys())}"
    )
    return out
