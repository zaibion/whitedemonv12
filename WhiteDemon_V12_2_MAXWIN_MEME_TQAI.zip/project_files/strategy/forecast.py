from _engine import (algo_forecast_next_n, predict_next_candle,
                      predict_next_20_candles)
