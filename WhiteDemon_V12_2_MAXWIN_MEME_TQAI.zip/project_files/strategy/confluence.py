"""8-factor confluence + strict verdict gate."""
from _engine import (
    compute_confluence_score, decide_trade,
    STRICT_GATE_THRESHOLD, STRICT_MIN_WIN_PROB,
    STRICT_MIN_TP1_HIT,     STRICT_MAX_SL_TP_RATIO,
)


# === v100 ENHANCEMENT: Strict volume confirmation ===
def has_volume_expansion(df, idx, lookback=20, multiplier=1.4):
    """Require signal candle volume >= 1.4x 20-bar average"""
    if idx < lookback:
        return False
    avg_vol = df["volume"].iloc[idx-lookback:idx].mean()
    return df["volume"].iloc[idx] >= avg_vol * multiplier
