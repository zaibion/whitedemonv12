"""
confidence_aggregator.py — WhiteDemon_V8.2
Institutional trade confidence score 0-100.

Fuses:
  • ML committee stack_bull spread (LONG vs SHORT)
  • DL ensemble agreement (% models agreeing)
  • Specialized NN consensus (PriceReg, RL, SentimentNN, RegimeNN)
  • Confluence 8-factor score
  • Regime fit (trending vs ranging, matches direction?)
  • Walk-forward OOS win-rate
  • R:R, ATR stop quality, spread/slippage guard
  • Volatility regime penalty

Output: {
  "score": 0-100,
  "grade": "A+"|"A"|"B"|"C"|"D"|"F",
  "pass": bool,           # score >= threshold (default 62)
  "components": {...},
  "reasons": [...]
}

No LLM. Deterministic. No hallucination. Audit-log friendly.
"""
from __future__ import annotations
import math
from typing import Dict, Any

DEFAULT_THRESHOLD = 68  # HF gate – only take A/B trades

def _clip(x, a, b): return a if x < a else b if x > b else x

def aggregate_confidence(
    cm_long: dict, cm_short: dict,
    direction: str,
    confluence: dict,
    regime_info: dict,
    setup: dict,
    backtest_stats: dict | None = None,
    nn_signals: dict | None = None,
    spread_bps: float = 5.0,
) -> Dict[str, Any]:
    """Return institutional confidence 0-100."""
    nn_signals = nn_signals or {}
    backtest_stats = backtest_stats or {}
    
    committee = cm_long if direction == "LONG" else cm_short
    p_long = float(cm_long.get("stack_bull", 0.5))
    p_short = float(cm_short.get("stack_bull", 0.5))
    
    # 1. Committee edge (0-25 pts)
    # spread between LONG and SHORT stack
    edge = abs(p_long - p_short)
    committee_score = _clip(edge * 100, 0, 25)
    
    # 2. DL agreement (0-20 pts)
    dl_indiv = committee.get("dl_individual", {})
    if dl_indiv:
        vals = list(dl_indiv.values())
        bull_votes = sum(1 for v in vals if v >= 0.5)
        agreement = abs(bull_votes - len(vals)/2) / (len(vals)/2) if vals else 0
        dl_score = agreement * 20
    else:
        dl_score = 10.0
    
    # 3. NN consensus (0-15 pts)
    nn_score = 7.5
    try:
        pr = nn_signals.get("price_reg", {})
        rl = nn_signals.get("rl_agent", {})
        sn = nn_signals.get("sentiment_nn", {})
        rg = nn_signals.get("regime_nn", {})
        votes = 0
        n = 0
        for s in (pr, rl, sn, rg):
            if not s: continue
            d = s.get("direction", s.get("action", "HOLD")).upper()
            conf = float(s.get("confidence", 0.5))
            if direction in d:
                votes += conf
            elif ("SHORT" if direction=="LONG" else "LONG") in d:
                votes -= conf
            n += 1
        if n:
            nn_score = _clip(7.5 + (votes/n)*7.5, 0, 15)
    except Exception:
        pass
    
    # 4. Confluence 8-factor (0-20 pts)
    conf_score_raw = float(confluence.get("score", 50))
    confluence_score = _clip(conf_score_raw / 5.0, 0, 20)
    
    # 5. Regime fit (0-10 pts)
    regime = (regime_info or {}).get("regime", "RANGING").upper()
    regime_score = 5.0
    if direction == "LONG" and "BULL" in regime:
        regime_score = 10.0
    elif direction == "SHORT" and "BEAR" in regime:
        regime_score = 10.0
    elif "RANGING" in regime:
        regime_score = 3.0
    elif ("BULL" in regime and direction == "SHORT") or ("BEAR" in regime and direction == "LONG"):
        regime_score = 0.0
    
    # 6. Backtest OOS (0-10 pts)
    bt_wr = float(backtest_stats.get("win_rate", 0.5))
    bt_trades = int(backtest_stats.get("trades", 0))
    if bt_trades >= 30:
        bt_score = _clip((bt_wr - 0.5) * 40, 0, 10)
    elif bt_trades >= 10:
        bt_score = _clip((bt_wr - 0.5) * 30, 0, 7)
    else:
        bt_score = 3.0
    
    # 7. R:R / stop quality (0-10 pts, can be negative)
    rr = 0.0
    try:
        entry = float(setup.get("entry", 0))
        sl = float(setup.get("sl", 0))
        tp1 = float(setup.get("tp1", 0))
        if entry and sl and tp1 and entry != sl:
            risk = abs(entry - sl)
            reward = abs(tp1 - entry)
            rr = reward / risk if risk > 0 else 0
    except Exception:
        pass
    rr_score = _clip((rr - 1.0) * 5, -5, 10)
    
    # 8. Spread / slippage guard (-10 to 0 pts)
    spread_penalty = 0.0
    if spread_bps > 15:
        spread_penalty = -5
    elif spread_bps > 30:
        spread_penalty = -10
    
    # Total
    total = committee_score + dl_score + nn_score + confluence_score + regime_score + bt_score + rr_score + spread_penalty
    total = _clip(total, 0, 100)
    
    # Grade
    if total >= 85: grade = "A+"
    elif total >= 75: grade = "A"
    elif total >= 62: grade = "B"
    elif total >= 50: grade = "C"
    elif total >= 35: grade = "D"
    else: grade = "F"
    
    passed = total >= DEFAULT_THRESHOLD
    
    reasons = []
    if edge < 0.08: reasons.append(f"Weak committee edge {edge:.1%}")
    if dl_score < 10: reasons.append("DL ensemble split")
    if regime_score < 3: reasons.append(f"Regime {regime} conflicts with {direction}")
    if rr < 1.3: reasons.append(f"R:R {rr:.2f} < 1.3")
    if bt_trades >= 30 and bt_wr < 0.52: reasons.append(f"OOS win-rate {bt_wr:.1%} low")
    if spread_penalty < 0: reasons.append(f"Wide spread {spread_bps:.1f} bps")
    if not reasons and passed:
        reasons.append(f"Strong confluence – grade {grade}")
    
    return {
        "score": round(total, 1),
        "grade": grade,
        "pass": passed,
        "threshold": DEFAULT_THRESHOLD,
        "components": {
            "committee_edge": round(committee_score, 1),
            "dl_agreement": round(dl_score, 1),
            "nn_consensus": round(nn_score, 1),
            "confluence": round(confluence_score, 1),
            "regime_fit": round(regime_score, 1),
            "backtest_oos": round(bt_score, 1),
            "risk_reward": round(rr_score, 1),
            "spread_penalty": round(spread_penalty, 1),
        },
        "inputs": {
            "p_long": round(p_long, 4),
            "p_short": round(p_short, 4),
            "edge": round(edge, 4),
            "rr": round(rr, 2),
            "regime": regime,
            "bt_wr": round(bt_wr, 3),
            "bt_trades": bt_trades,
        },
        "reasons": reasons,
        "direction": direction,
    }


def temperature_scale_probs(probs: list[float], temp: float = 1.15) -> list[float]:
    """HF conservative calibration – slightly flatten overconfident probs."""
    import math
    out = []
    for p in probs:
        p = max(1e-4, min(1-1e-4, p))
        logit = math.log(p/(1-p))
        p_cal = 1/(1+math.exp(-logit/temp))
        out.append(p_cal)
    return out
