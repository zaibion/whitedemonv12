"""
train_pipeline.py — Resumable training pipeline.

Replaces train_all.py for menu-driven use. Same engine, but:

  • Saves a checkpoint to storage after EVERY stage
  • On startup, reads the checkpoint and SKIPS already-done stages
  • Pushes raw data + per-stage model artifacts to storage incrementally
  • If killed mid-training, next call resumes from the last completed stage

Used by run.py — not meant to be called directly (call via `run.py train`).
"""
from __future__ import annotations
import os, sys, time, json, datetime, traceback, pickle, base64, gzip
from typing import Dict, Optional

import numpy as np
import pandas as pd

from core.config       import CFG, SYMBOL, TF_LABEL, PAIR, TF, apply_selection
from core.colors       import RESET, BOLD, CYAN, GREEN, YELLOW, ORANGE, RED, GREY
from core.storage      import STORE
from core              import checkpoint as ck_mod

from data.fetcher_ccxt   import fetch_ohlcv_stitched_v23
from data.fetcher_sentiment import FinBERTSentiment, fetch_sentiment
from data.fetcher_derivatives import fetch_derivatives
from data.fetcher_macro  import fetch_macro_context, attach_macro_features

from indicators.basic     import calc_rsi, calc_atr, calc_vwap, calc_cvd, calc_macd
from indicators.structure import (zigzag, sr_from_zigzag, sr_from_rolling_pivots,
                                    sr_from_volume_profile, merge_all_sr,
                                    detect_bos_choch, mtf_trends, detect_market_regime)
from indicators.smc       import find_sd_zones, find_order_blocks, find_fvgs
from indicators.fibonacci import fibonacci
from indicators.hunting   import detect_stop_loss_hunting
from indicators.patterns  import pattern_scan

from ml_models.committee  import run_ml_committee
from core.checkpoint_thread import (start_background_checkpoint,
                                       stop_background_checkpoint)
from core.model_cache       import save_committee, load_committee
from core.engine_patches    import engine_context, apply_engine_patches
from core                   import per_model_cache as pmc

# Install per-model save/resume patches on the engine at import time
apply_engine_patches()


def _slim(cm: dict) -> dict:
    skip = {"models", "fitted", "scaler", "calibrator", "dl_models"}
    out = {}
    for k, v in (cm or {}).items():
        if k in skip: continue
        try:
            json.dumps(v, default=str); out[k] = v
        except Exception:
            try: out[k] = str(v)[:500]
            except Exception: pass
    return out


def _stage_msg(label: str, status: str, color: str = CYAN):
    print(f"\n{BOLD}{color}━━ {label}: {status} ━━{RESET}\n")


def train_with_checkpoint(force: bool = False,
                            skip_advanced: bool = False,
                            target_candles: Optional[int] = None) -> Dict:
    """Run the full training pipeline, resuming from the saved checkpoint
    if one exists. Returns the final checkpoint dict.

    Starts a background thread that pushes a checkpoint heartbeat every
    60 seconds so progress survives even if the script crashes mid-stage.
    """
    sym, tf = SYMBOL, TF_LABEL
    target_candles = target_candles or CFG.get("target_total_candles", 200_000)

    # ── GPU detection (massive speedup for DL models) ─────────────────
    from core.gpu_setup import enable_gpu
    device = enable_gpu(verbose=True)
    if device == "cpu":
        print(f"\n  {YELLOW}⚠️  CPU-only mode detected. DL training will be SLOW:{RESET}")
        print(f"     ~5-15 min PER DL net × 14 nets × 2 directions = ~3-7 HOURS total")
        print(f"     {YELLOW}STRONGLY RECOMMENDED: Colab → Runtime → Change runtime type → T4 GPU (free){RESET}")
        print(f"     With T4 GPU: ~30 sec per net → ~15 min total\n")

    # ── Sanity check: 1m / 5m TFs with low candle counts are broken ──
    # The triple-barrier horizon eats most rows; need at least 10-20x horizon
    tf_horizons = {"1m": 720, "3m": 480, "5m": 288, "15m": 192,
                    "30m": 96, "1h": 48, "4h": 24, "1d": 12}
    horizon = tf_horizons.get(tf, 192)
    min_needed = horizon * 20    # need at least 20× horizon for training to work
    if target_candles < min_needed:
        bumped = max(target_candles, min_needed)
        print(f"\n{YELLOW}⚠️  WARNING: target_candles={target_candles:,} is too low for {tf} timeframe.{RESET}")
        print(f"   Triple-barrier horizon = {horizon} bars → leaves <100 training rows.")
        print(f"   {BOLD}Auto-bumping to {bumped:,} candles{RESET} (you can edit config.py to override).")
        target_candles = bumped

    # Load or reset checkpoint
    if force:
        print(f"{YELLOW}[ckpt] --force → wiping checkpoint{RESET}")
        ck_mod.reset(sym, tf)
    ck = ck_mod.load(sym, tf)

    # Start background heartbeat → pushes state every 60s
    start_background_checkpoint(sym, tf, interval=60)

    # Anti-disconnect keepalive (Python side)
    try:
        from core.keepalive import start_keepalive, print_js_snippet
        start_keepalive(interval=30)
        # WhiteDemon_V8.2: progress reporter every 15s
        try:
            import threading
            _pr_stop = threading.Event()
            _pr_t0 = time.time()
            def _pr_beat():
                stages = ["fetch_data","indicators","advanced_features","structure",
                          "long_committee","short_committee","long_dl","short_dl",
                          "specialized_nns","stacker","save_dashboard"]
                while not _pr_stop.wait(15):
                    try:
                        _ck = ck_mod.load(sym, tf)
                        done = sum(1 for s in stages if _ck.get("stages",{}).get(s,{}).get("done"))
                        elapsed = int(time.time()-_pr_t0)
                        print(f"  [pipeline progress] {done}/{len(stages)} stages done · {elapsed}s elapsed", flush=True)
                    except Exception:
                        pass
            _pr_thr = threading.Thread(target=_pr_beat, daemon=True)
            _pr_thr.start()
        except Exception:
            _pr_stop = None
        # Show the browser-console snippet only on first run per process
        if not getattr(train_with_checkpoint, "_js_shown", False):
            print_js_snippet()
            train_with_checkpoint._js_shown = True
    except Exception as _e:
        print(f"  [keepalive] failed to start: {_e}")

    try:
        return _train_inner(ck, sym, tf, target_candles, skip_advanced)
    finally:
        try:
            if '_pr_stop' in locals() and _pr_stop: _pr_stop.set()
        except Exception: pass
        stop_background_checkpoint()
        try:
            from core.keepalive import stop_keepalive
            stop_keepalive()
        except Exception:
            pass


def _train_inner(ck: Dict, sym: str, tf: str,
                  target_candles: int, skip_advanced: bool) -> Dict:
    # MEMORY GUARD: cap the requested candle count to whatever the current
    # environment can handle. Free Colab silently kills the process when RAM
    # runs out — this is why your training stopped after 9 classical models.
    from core.memory_guard import safe_candle_target
    target_candles = safe_candle_target(target_candles)

    print(f"\n{BOLD}{CYAN}╔════════════════════════════════════════════════════════╗")
    print(f"║  TRAIN PIPELINE  ·  {sym:<12} {tf:<8}                   ║")
    print(f"║  Status: {ck['verdict']:<46}║")
    print(f"║  Progress: {ck_mod.progress_summary(ck):<44}║")
    print(f"╚════════════════════════════════════════════════════════╝{RESET}\n")

    apply_selection(PAIR, TF)
    rid = f"{sym.replace('-','_')}_{tf}"

    # ════════════════════════════════════════════════════════════════
    # STAGE 1 — fetch_data
    # ════════════════════════════════════════════════════════════════
    df = None
    raw_blob_key = f"raw_{rid}.pkl"

    if ck["stages"]["fetch_data"]["done"]:
        _stage_msg("STAGE 1/11  Fetch data", "RESUME (loading from storage)", GREEN)
        blob = STORE.get_blob(raw_blob_key)
        if blob:
            data = pickle.loads(blob)
            df = data["df"]
            print(f"  ✓ Resumed {len(df):,} candles from {raw_blob_key}")
        else:
            print(f"  {ORANGE}cached fetch_data flag set but blob missing — re-fetching{RESET}")
            ck["stages"]["fetch_data"]["done"] = False

    if not ck["stages"]["fetch_data"]["done"]:
        _stage_msg("STAGE 1/11  Fetch data", "STARTING", CYAN)
        df, src = fetch_ohlcv_stitched_v23(sym, tf, target_candles)
        print(f"  ✓ {len(df):,} candles fetched from {src}")
        # Save raw df immediately so re-runs skip the slow fetch
        STORE.put_blob(raw_blob_key, pickle.dumps({"df": df, "fetched_at": datetime.datetime.utcnow().isoformat()}))
        ck = ck_mod.mark_done(ck, "fetch_data", {"n_candles": len(df), "source": src})

    # ════════════════════════════════════════════════════════════════
    # STAGE 2 — indicators + macro + sentiment + derivatives
    # ════════════════════════════════════════════════════════════════
    ind_blob_key = f"indicators_{rid}.pkl"
    nlp = None; deriv = None

    if ck["stages"]["indicators"]["done"]:
        _stage_msg("STAGE 2/11  Indicators + macro + sentiment", "RESUME", GREEN)
        blob = STORE.get_blob(ind_blob_key)
        if blob:
            cached = pickle.loads(blob)
            df = cached["df"]; nlp = cached["nlp"]; deriv = cached["deriv"]
            print(f"  ✓ Loaded indicators from cache")
        else:
            ck["stages"]["indicators"]["done"] = False

    if not ck["stages"]["indicators"]["done"]:
        _stage_msg("STAGE 2/11  Indicators + macro + sentiment", "STARTING", CYAN)
        df["rsi"]   = calc_rsi(df["close"])
        df["atr"]   = calc_atr(df)
        df["vwap"]  = calc_vwap(df)
        df["cvd"]   = calc_cvd(df)
        _, _, df["macd_h"] = calc_macd(df["close"])
        print("  ✓ indicators computed")
        try:
            end_dt = pd.Timestamp(df["open_time"].iloc[-1]).to_pydatetime()
            if end_dt.tzinfo: end_dt = end_dt.replace(tzinfo=None)
            span = (df["open_time"].iloc[-1] - df["open_time"].iloc[0]).days
            macro = fetch_macro_context(end_dt, days_back=max(60, span + 14))
            df = attach_macro_features(df, macro)
            print("  ✓ macro context attached")
        except Exception as e:
            print(f"  {ORANGE}macro failed (non-fatal): {e}{RESET}")
            df = attach_macro_features(df, pd.DataFrame())
        nlp = fetch_sentiment(FinBERTSentiment())
        print(f"  ✓ sentiment {nlp['sentiment']} ({nlp['score']:+.2f})")
        deriv = fetch_derivatives()
        STORE.put_blob(ind_blob_key, pickle.dumps({
            "df": df, "nlp": nlp, "deriv": deriv,
        }))
        ck = ck_mod.mark_done(ck, "indicators")

    # ════════════════════════════════════════════════════════════════
    # STAGE 3 — advanced features
    # ════════════════════════════════════════════════════════════════
    advanced_feats = {}
    af_key = f"advanced_{rid}.json"
    if ck["stages"]["advanced_features"]["done"] and not skip_advanced:
        _stage_msg("STAGE 3/11  Advanced features", "RESUME", GREEN)
        cached = STORE.get_json(f"advanced_{rid}")
        if cached: advanced_feats = cached.get("features", {})
        print(f"  ✓ {len(advanced_feats)} advanced features cached")
    elif not skip_advanced:
        _stage_msg("STAGE 3/11  Advanced features", "STARTING", CYAN)
        try:
            from advanced.feature_blender import blend_advanced_features
            advanced_feats = blend_advanced_features(df, sym, skip_live=False)
            print(f"  ✓ {len(advanced_feats)} advanced features")
            STORE.put_json(f"advanced_{rid}", {"features": advanced_feats})
        except Exception as e:
            print(f"  {ORANGE}advanced features failed (non-fatal): {e}{RESET}")
        ck = ck_mod.mark_done(ck, "advanced_features")
    else:
        ck = ck_mod.mark_done(ck, "advanced_features", {"skipped": True})

    # ════════════════════════════════════════════════════════════════
    # STAGE 4 — structure
    # ════════════════════════════════════════════════════════════════
    struct = None
    struct_key = f"structure_{rid}.pkl"

    if ck["stages"]["structure"]["done"]:
        _stage_msg("STAGE 4/11  Market structure", "RESUME", GREEN)
        blob = STORE.get_blob(struct_key)
        if blob: struct = pickle.loads(blob)
        else: ck["stages"]["structure"]["done"] = False

    if not ck["stages"]["structure"]["done"]:
        _stage_msg("STAGE 4/11  Market structure", "STARTING", CYAN)
        CFG["trade_window"] = 2000
        train_cutoff = len(df) - CFG["trade_window"]
        if train_cutoff < 5000:
            train_cutoff = int(len(df) * 0.85)
            CFG["trade_window"] = len(df) - train_cutoff
        tdf = df.tail(CFG["trade_window"]).copy().reset_index(drop=True)
        pivots_zz, _, _ = zigzag(tdf.tail(CFG["zz_lookback"]), CFG["zz_dev_pct"])
        struct = {
            "train_cutoff":  train_cutoff,
            "sr_levels":     merge_all_sr(
                sr_from_zigzag(pivots_zz, CFG["sr_tol_pct"]),
                sr_from_rolling_pivots(tdf),
                sr_from_volume_profile(tdf),
                float(df["close"].iloc[-1]), tol_pct=0.3),
            "demand_zones":  None,
            "supply_zones":  None,
            "bull_obs":      None,
            "bear_obs":      None,
            "fvgs":          None,
            "bos":           None,
            "fib":           None,
            "hunting":       None,
            "mtf":           None,
            "patterns":      None,
            "regime_info":   None,
        }
        struct["demand_zones"], struct["supply_zones"] = find_sd_zones(tdf)
        struct["bull_obs"], struct["bear_obs"] = find_order_blocks(tdf)
        struct["fvgs"] = find_fvgs(tdf)
        struct["bos"]  = detect_bos_choch(tdf, [{**p, "idx": p["idx"]} for p in pivots_zz])
        struct["fib"]  = fibonacci(tdf)
        struct["hunting"] = detect_stop_loss_hunting(tdf, struct["sr_levels"])
        ltf, h1, h4, _ = mtf_trends(df)
        struct["mtf"] = {"ltf": ltf, "h1": h1, "h4": h4}
        struct["patterns"] = pattern_scan(df, train_cutoff)
        struct["regime_info"] = detect_market_regime(df)
        CFG["_current_regime"] = struct["regime_info"].get("regime", "RANGING")
        print(f"  ✓ {len(struct['sr_levels'])} SR · {len(struct['fvgs'])} FVGs · regime={struct['regime_info']['regime']}")
        STORE.put_blob(struct_key, pickle.dumps(struct))
        ck = ck_mod.mark_done(ck, "structure")

    train_cutoff = struct["train_cutoff"]

    # ════════════════════════════════════════════════════════════════
    # STAGES 5+6+7+8 — Committees (LONG + SHORT, classical + DL)
    # We collapse these into TWO function calls since run_ml_committee
    # trains classical + DL together. The checkpoint records both stages
    # as done atomically once each direction finishes.
    # ════════════════════════════════════════════════════════════════
    cm_long = cm_short = None
    long_key  = f"long_{rid}"
    short_key = f"short_{rid}"

    # ─── Try to load FULL pickled committee first (size-aware) ────────
    _ccount = int(target_candles)
    cached_full_long  = load_committee(sym, tf, "LONG",  _ccount)
    cached_full_short = load_committee(sym, tf, "SHORT", _ccount)
    if cached_full_long is not None:
        cm_long = cached_full_long
        ck = ck_mod.mark_done(ck, "long_committee",
                              {"stack_bull": cm_long.get("stack_bull", 0.5)})
        ck = ck_mod.mark_done(ck, "long_dl")
        _stage_msg("STAGE 5+7/11  LONG committee", "LOADED FROM CACHE", GREEN)
    if cached_full_short is not None:
        cm_short = cached_full_short
        ck = ck_mod.mark_done(ck, "short_committee",
                              {"stack_bull": cm_short.get("stack_bull", 0.5)})
        ck = ck_mod.mark_done(ck, "short_dl")
        _stage_msg("STAGE 6+8/11  SHORT committee", "LOADED FROM CACHE", GREEN)

    # ─── Fall back to slim metadata cache for backward compat ─────────
    if cm_long is None and ck["stages"]["long_committee"]["done"] and ck["stages"]["long_dl"]["done"]:
        _stage_msg("STAGE 5+7/11  LONG committee", "RESUME (slim)", GREEN)
        cached = STORE.get_json(long_key)
        cm_long = cached.get("result") if cached else None
        if not cm_long:
            ck["stages"]["long_committee"]["done"] = False
            ck["stages"]["long_dl"]["done"] = False

    if cm_short is None and ck["stages"]["short_committee"]["done"] and ck["stages"]["short_dl"]["done"]:
        _stage_msg("STAGE 6+8/11  SHORT committee", "RESUME (slim)", GREEN)
        cached = STORE.get_json(short_key)
        cm_short = cached.get("result") if cached else None
        if not cm_short:
            ck["stages"]["short_committee"]["done"] = False
            ck["stages"]["short_dl"]["done"] = False

    # ─── Train whichever committees are still missing — IN PARALLEL ──
    # Threads (not processes) because run_ml_committee uses sklearn which
    # releases the GIL during fit(). Each thread pushes its own committee
    # to storage IMMEDIATELY when done — so if one crashes the other still
    # saves.
    from concurrent.futures import ThreadPoolExecutor, as_completed

    jobs = []
    if not ck["stages"]["long_committee"]["done"]:
        jobs.append(("LONG", "long_committee", "long_dl", long_key))
    if not ck["stages"]["short_committee"]["done"]:
        jobs.append(("SHORT", "short_committee", "short_dl", short_key))

    if jobs:
        _stage_msg(f"STAGE 5-8/11  Train {len(jobs)} committee(s) in PARALLEL",
                    "STARTING (each saves independently)", CYAN)

        def _train_one(direction, ck_main, ck_dl, key):
            try:
                t0 = time.time()
                # Show per-model resume state BEFORE training starts
                _done = pmc.list_done(sym, tf, direction, _ccount)
                if _done["classical"] or _done["dl"]:
                    print(f"  {CYAN}[pmc] {direction} resume — "
                          f"classical {len(_done['classical'])}/9, "
                          f"DL {len(_done['dl'])}/14 already cached{RESET}")
                # Run engine with per-model save/load patches active
                with engine_context(sym, tf, direction, _ccount):
                    cm = run_ml_committee(df, nlp["score"], train_cutoff,
                                           llm_features=None, direction=direction)
                # 1) slim metadata for dashboard
                STORE.put_json(key, {"result": _slim(cm)},
                                message=f"{direction.lower()} committee {rid}")
                # 2) FULL pickled committee so next run skips retrain entirely
                try:
                    save_committee(sym, tf, direction, _ccount, cm)
                except Exception as _e:
                    print(f"  {YELLOW}[mcache] {direction} full save failed: {_e}{RESET}")
                print(f"\n  ✓ {direction} done in {time.time()-t0:.0f}s  "
                      f"stack_bull={cm['stack_bull']*100:.1f}%")
                return direction, cm, None
            except Exception as e:
                print("  [error] traceback suppressed — see message above", flush=True)
                return direction, None, str(e)

        # ── Always sequential (one direction at a time) ──
        # User explicitly requested "train models one by one". Running LONG
        # and SHORT in parallel doubles peak RAM AND causes GitHub 409 races
        # when both threads write the per-direction index simultaneously.
        # Order doesn't change model outputs (each direction is independent).
        if len(jobs) > 1:
            print(f"  [pmc] training committees SEQUENTIALLY (LONG → SHORT) — saves RAM + avoids storage races")
        with ThreadPoolExecutor(max_workers=1) as ex:
            futures = {ex.submit(_train_one, *j): j for j in jobs}
            for fut in as_completed(futures):
                direction, cm, err = fut.result()
                if cm is None:
                    print(f"\n  ❌ {direction} committee FAILED: {err}")
                    print(f"     Other committee may still succeed.")
                    continue
                if direction == "LONG":
                    cm_long = cm
                    ck = ck_mod.mark_done(ck, "long_committee", {"stack_bull": cm["stack_bull"]})
                    ck = ck_mod.mark_done(ck, "long_dl")
                else:
                    cm_short = cm
                    ck = ck_mod.mark_done(ck, "short_committee", {"stack_bull": cm["stack_bull"]})
                    ck = ck_mod.mark_done(ck, "short_dl")

    # ════════════════════════════════════════════════════════════════
    # STAGE 9 — Specialized NNs
    # WhiteDemon_V8.2: verify they actually exist before marking done
    # ════════════════════════════════════════════════════════════════
    if not ck["stages"]["specialized_nns"]["done"]:
        # Check cache
        try:
            nn_index = pmc.get_index(sym, tf, "BOTH", target_candles)
            nn_done = set(nn_index.get("nn", {}).keys())
            required_nn = {"price_reg", "rl_agent", "sentiment_nn", "regime_nn"}
            if required_nn.issubset(nn_done):
                ck = ck_mod.mark_done(ck, "specialized_nns")
            else:
                missing = required_nn - nn_done
                print(f"  {YELLOW}specialized_nns checkpoint not marked — missing: {sorted(missing)}{RESET}")
        except Exception:
            # fall back to old behavior if cache unreadable
            ck = ck_mod.mark_done(ck, "specialized_nns")

    # ════════════════════════════════════════════════════════════════
    # STAGE 10 — Stacker
    # ════════════════════════════════════════════════════════════════
    if not ck["stages"]["stacker"]["done"]:
        # stacker is trained inside run_ml_committee, verify committees exist
        if cm_long is not None and cm_short is not None:
            ck = ck_mod.mark_done(ck, "stacker")
        else:
            print(f"  {YELLOW}stacker not marked done — committees missing{RESET}")

    # ════════════════════════════════════════════════════════════════
    # STAGE 11 — Build dashboard payload
    # ════════════════════════════════════════════════════════════════
    _stage_msg("STAGE 11/11  Build dashboard payload", "STARTING", CYAN)
    from strategy.setup_builder import build_setup
    from strategy.tp_sl_prob    import calculate_tp_sl_probability
    from strategy.confluence    import decide_trade
    from strategy.forecast      import algo_forecast_next_n, predict_next_candle
    from strategy.reasoning     import build_trade_reasoning

    # Bulletproof defaults — if a committee failed mid-training we still
    # produce a dashboard so the user can see partial results.
    if cm_long is None:
        print(f"  {YELLOW}⚠️ LONG committee unavailable — using neutral fallback{RESET}")
        cm_long  = {"stack_bull": 0.5, "preds": {}, "probs": {}, "wf_accs": {},
                    "dl_individual": {}, "baseline_win_rate": 0.5, "n_models": 0}
    if cm_short is None:
        print(f"  {YELLOW}⚠️ SHORT committee unavailable — using neutral fallback{RESET}")
        cm_short = {"stack_bull": 0.5, "preds": {}, "probs": {}, "wf_accs": {},
                    "dl_individual": {}, "baseline_win_rate": 0.5, "n_models": 0}

    price = float(df["close"].iloc[-1])
    atr_val = float(df["atr"].iloc[-1])
    p_l = float(cm_long.get("stack_bull",  0.5))
    p_s = float(cm_short.get("stack_bull", 0.5))
    direction = "LONG" if p_l >= p_s else "SHORT"
    committee = cm_long if direction == "LONG" else cm_short

    # WhiteDemon_V8.2: smart-SL context (liquidity-aware stop placement)
    try:
        from strategy.setup_builder import set_smart_sl_context, clear_smart_sl_context
        from data.fetcher_liquidations import get_liquidation_clusters
        _liq = get_liquidation_clusters(sym, lookback_min=60)
    except Exception:
        _liq = []
        def set_smart_sl_context(**kwargs): pass
        def clear_smart_sl_context(): pass
    _sl_nn = None
    try:
        from neural_nets.sl_placement_nn import SLPlacementWrapper
        _sl_nn = SLPlacementWrapper.load_latest_for(sym, tf)
    except Exception:
        pass
    set_smart_sl_context(df=df, liq_clusters=_liq, sl_nn=_sl_nn,
                          aggressiveness=CFG.get("smart_sl_aggressiveness","balanced"),
                          enabled=True)
    try:
        setup = build_setup(direction, price, struct["sr_levels"],
                              struct["demand_zones"], struct["supply_zones"], atr_val)
        if not setup["valid"]:
            alt = "SHORT" if direction == "LONG" else "LONG"
            alt_setup = build_setup(alt, price, struct["sr_levels"],
                                      struct["demand_zones"], struct["supply_zones"], atr_val)
            if alt_setup["valid"]:
                setup, direction = alt_setup, alt
    finally:
        clear_smart_sl_context()
    tp_sl_prob = calculate_tp_sl_probability(df, setup, train_cutoff)

    # WhiteDemon_V8.2 confidence
    try:
        from strategy.confidence_aggregator import aggregate_confidence
        from live.live_guard import LiveGuard
        _nn_sig = {}
        for _k in ("price_reg","rl_agent","sentiment_nn","regime_nn"):
            try:
                _v = committee.get(_k)
                if _v: _nn_sig[_k] = _v
            except Exception: pass
        try:
            from strategy.confluence import compute_confluence_score
            _loc = locals()
            _sr_levels = _loc.get("sr_levels", struct["sr_levels"])
            _regime_raw = _loc.get("regime", None)
            _regime = _regime_raw if isinstance(_regime_raw, str) else struct["regime_info"].get("regime", "RANGING")
            _nlp_obj = _loc.get("nlp", {})
            _nlp_score = _nlp_obj.get("score", 0) if isinstance(_nlp_obj, dict) else 0.0
            _conf_v = compute_confluence_score(direction, price, _sr_levels,
                                               struct["demand_zones"], struct["supply_zones"],
                                               df.tail(200), _regime, _nlp_score)
            _conf_dict = {"score": float(_conf_v)}
        except Exception:
            _conf_dict = {"score": 50}
        confidence = aggregate_confidence(cm_long, cm_short, direction, _conf_dict, struct["regime_info"], setup,
                                          backtest_stats={"win_rate":0.5,"trades":0}, nn_signals=_nn_sig)
        _guard = LiveGuard()
        _guard_eval = _guard.evaluate_trade({"confidence": confidence, "setup": setup, "p_long": p_l, "p_short": p_s,
                                              "last_candle_ts": df["open_time"].iloc[-1] if "open_time" in df.columns else None})
    except Exception as _e:
        confidence = {"score": 50.0, "grade": "C", "pass": False, "components": {}, "reasons": [str(_e)]}
        _guard_eval = {"allow_trade": False, "checks": []}

    ctx = {
        "symbol": sym, "name": PAIR["name"], "tf_label": tf,
        "price": price, "n_total": len(df), "train_cutoff": train_cutoff,
        "trade_window": CFG["trade_window"],
        "newest": str(df["open_time"].iloc[-1]),
        "oldest": str(df["open_time"].iloc[0]),
        "advanced_features": advanced_feats,
        "nlp": nlp, "deriv": deriv, "direction": direction,
        "setup": setup, "tp_sl_prob": tp_sl_prob,
        "committee": _slim(committee),
        "confidence": confidence,
        "confidence_score": confidence.get("score", 50.0),
        "confidence_grade": confidence.get("grade", "C"),
        "trade_allowed": _guard_eval.get("allow_trade", False),
        "cm_long":  _slim(cm_long), "cm_short": _slim(cm_short),
        "tb_models": {"long_win_prob": p_l, "short_win_prob": p_s,
                       "historical_long_winrate": cm_long.get("baseline_win_rate", 0.5),
                       "historical_short_winrate": cm_short.get("baseline_win_rate", 0.5)},
        "regime": struct["regime_info"].get("regime"),
        "regime_info": struct["regime_info"],
        "monte_carlo": {"available": False},
        # FIX: confluence gate (compute_confluence_score) expects mtf as a
        # LIST so it can do mtf[:3]. The dict form crashes with
        # KeyError: slice(None, 3, None). Pass BOTH forms — engine uses list,
        # frontend reads dict-shaped keys from mtf_dict.
        "mtf": [struct["mtf"].get("ltf"), struct["mtf"].get("h1"), struct["mtf"].get("h4")],
        "mtf_dict": struct["mtf"],
        "patterns": struct["patterns"],
        "order_blocks": {"bull": struct["bull_obs"], "bear": struct["bear_obs"]},
        "supply_zones": struct["supply_zones"], "demand_zones": struct["demand_zones"],
        "fvgs": struct["fvgs"], "fib_lvls": struct["fib"], "hunting": struct["hunting"],
        "bos": struct["bos"], "sr_levels": struct["sr_levels"],
        "algo_forecast": algo_forecast_next_n(df, n=10, atr_value=atr_val),
        "pred_next": predict_next_candle(df, nlp["score"], train_cutoff),
        "elapsed": 0.0,
        "backtest_results": {"available": False},
    }
    decision = decide_trade(ctx)
    ctx["decision"] = decision
    try: ctx["reasoning"] = build_trade_reasoning(ctx, decision)
    except Exception: ctx["reasoning"] = {}

    # Attach last 300 candles + 20-candle prediction for the chart tab
    try:
        _tail = df.tail(300).copy()
        if "open_time" in _tail.columns:
            _tail["t"] = (_tail["open_time"].astype("int64") // 10**9).astype(int)
        else:
            _tail["t"] = list(range(len(_tail)))
        ctx["candles_tail"] = [
            {"time": int(r.t), "open": float(r.open), "high": float(r.high),
              "low": float(r.low), "close": float(r.close)}
            for r in _tail.itertuples()
        ]
        from strategy.forecast import predict_next_20_candles
        pred20 = predict_next_20_candles(df, nlp["score"], train_cutoff)
        last_t = ctx["candles_tail"][-1]["time"]
        tf_secs = {"1m":60,"3m":180,"5m":300,"15m":900,"30m":1800,
                    "1h":3600,"4h":14400,"1d":86400}.get(tf, 3600)
        if isinstance(pred20, list):
            ctx["pred_next_20"] = [
                {"time": int(last_t + tf_secs*(i+1)),
                  "open":  float(p.get("open",  p.get("close", price))),
                  "high":  float(p.get("high",  p.get("close", price))),
                  "low":   float(p.get("low",   p.get("close", price))),
                  "close": float(p.get("close", price))}
                for i, p in enumerate(pred20)
            ]
        else:
            ctx["pred_next_20"] = []
    except Exception as _e:
        print(f"  {YELLOW}chart payload skipped: {_e}{RESET}")
        ctx.setdefault("candles_tail", [])
        ctx.setdefault("pred_next_20", [])

    STORE.put_json("dashboard_data", {"ctx": ctx, "decision": decision,
                                        "saved_at": datetime.datetime.utcnow().isoformat() + "Z"})
    STORE.put_json(f"final_{rid}", {
        "symbol": sym, "tf_label": tf, "price": price,
        "direction": direction, "verdict": decision.get("verdict"),
        "verdict_text": decision.get("verdict_text"),
        "confluence": decision.get("chosen_score"),
        "win_prob": decision.get("chosen_win_prob"),
        "long_conviction": p_l, "short_conviction": p_s,
        "setup": setup, "tp_sl_prob": tp_sl_prob,
        "vetoes": decision.get("chosen_vetoes", []),
    })
    with open("dashboard_data.json", "w") as f:
        json.dump({"ctx": ctx, "decision": decision}, f, default=str, indent=2)
    ck = ck_mod.mark_done(ck, "save_dashboard")

    print(f"\n{BOLD}{GREEN}╔════════════════════════════════════════════════════════╗")
    print(f"║  ✅ TRAINING COMPLETE  ·  {sym} @ {tf}                ║")
    print(f"║  VERDICT = {decision.get('verdict'):<20} {direction} @ {decision.get('chosen_score',0)*100:.0f}% confluence ║")
    print(f"╚════════════════════════════════════════════════════════╝{RESET}\n")
    return ck
