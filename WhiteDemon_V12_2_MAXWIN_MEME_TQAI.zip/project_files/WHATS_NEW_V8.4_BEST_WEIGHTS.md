# WhiteDemon V8.4 — Best-Weight Restore / Early-Stop Clarity

## Why this was added
Training logs showed validation accuracy bouncing, for example:
- best accuracy around 70.1%
- later epochs dropping near 55–56%

Previously, the system could keep the final epoch weights even if an earlier epoch was better. That means the log could say `best=70.1%`, but the saved model might be from a later worse epoch.

## Fixes added
1. **Best weight snapshot**
   - Whenever validation accuracy improves, the model weights are copied to CPU memory.

2. **Restore best weights before save**
   - After early stop or after max epochs, the model restores the best epoch weights before calibration/saving.

3. **Clear patience display**
   - Training now prints:
     - `best_ep=...`
     - `no_improve=x/8` in patched GPU training
     - `no_improve=x/4` in direct engine fallback training

4. **Equal printed accuracy does not reset patience**
   - A tiny minimum delta is required, so repeated `70.1%` does not keep training forever unless it is a real improvement.

## Current behavior
- It will not always run all 60 epochs.
- In patched GPU training, it early-stops after 8 epochs with no real improvement.
- Before saving, it restores the best epoch weights.
