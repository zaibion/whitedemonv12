# WhiteDemon V11.3 — Small Mode Forecast Availability Fix

Fixes the issue where Small Mode could say unavailable almost every time.

## Root cause

`_engine.predict_next_20_candles()` returns:

```python
{"predictions": DataFrame_or_list, "total_move_pct": ...}
```

But `analyze.py` was expecting a plain list. Because of this mismatch, `ctx.pred_next_20` became empty and Small Mode reported:

```text
Small mode unavailable: no pred_next_20 forecast
```

## Fixed

- `analyze.py` now normalizes both supported formats:
  - plain list
  - dict with `predictions` DataFrame/list
- Adds `ctx.pred_next_20_meta` so the dashboard can show/debug source and errors.
- Small Mode now has an honest fallback to `algo_forecast_next_n` if the 20-candle ML forecast is unavailable.
- Small Mode dashboard now displays forecast source:
  - `pred_next_20`
  - or `algo_forecast_fallback`

## Important

Small Mode is still not a full trade signal. It only shows a short 3–4 candle micro forecast when no full setup is clean.

No model retraining. No cache invalidation.
