try:
    from _engine import WaveNetBlock, WaveNet as WaveNetNet
except ImportError:
    WaveNetBlock = WaveNetNet = None
