try:
    from _engine import NBeatsBlock, NBeatsNet
except ImportError:
    NBeatsBlock = NBeatsNet = None
