"""LSTM + BiLSTM architectures (gated recurrent networks)."""
try:
    from _engine import LSTMNet, BiLSTMNet
    BiLSTMAttnNet = BiLSTMNet   # alias used in __init__
except ImportError:
    LSTMNet = BiLSTMNet = BiLSTMAttnNet = None
