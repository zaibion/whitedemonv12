try:
    from _engine import TemporalFusionTransformer
except ImportError:
    TemporalFusionTransformer = None
