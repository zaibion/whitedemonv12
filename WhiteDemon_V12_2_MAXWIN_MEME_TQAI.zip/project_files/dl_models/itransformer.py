try:
    from _engine import iTransformerNet
except ImportError:
    iTransformerNet = None
