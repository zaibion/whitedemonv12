try:
    from _engine import MambaSSMNet
except ImportError:
    MambaSSMNet = None
