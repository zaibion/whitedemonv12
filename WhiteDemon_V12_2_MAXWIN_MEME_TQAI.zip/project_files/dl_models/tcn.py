try:
    from _engine import TCNBlock, TCNNet
except ImportError:
    TCNBlock = TCNNet = None
