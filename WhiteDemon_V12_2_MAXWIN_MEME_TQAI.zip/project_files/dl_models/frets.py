try:
    from _engine import FreTSNet
except ImportError:
    FreTSNet = None
