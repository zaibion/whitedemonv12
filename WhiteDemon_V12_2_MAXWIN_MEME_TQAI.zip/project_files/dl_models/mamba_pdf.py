try:
    from _engine import MambaBlock, MambaNet
except ImportError:
    MambaBlock = MambaNet = None
