try:
    from _engine import CNN1DNet
except ImportError:
    CNN1DNet = None
