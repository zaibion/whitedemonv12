try:
    from _engine import GRUNet
except ImportError:
    GRUNet = None
