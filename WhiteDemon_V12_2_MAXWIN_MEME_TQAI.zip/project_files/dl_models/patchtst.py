try:
    from _engine import PatchTSTNet
except ImportError:
    PatchTSTNet = None
