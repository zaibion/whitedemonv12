try:
    from _engine import TransformerNet
except ImportError:
    TransformerNet = None
