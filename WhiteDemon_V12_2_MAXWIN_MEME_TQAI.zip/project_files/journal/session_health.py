"""Session-stats + 6-check system-health monitor."""
from _engine import load_session_stats, SystemHealthCheck

# save_session_stats doesn't exist in engine; provide a thin shim
import os, json
_SESSION_PATH = "session_stats.json"
def save_session_stats(stats: dict) -> None:
    try:
        with open(_SESSION_PATH, "w") as f:
            json.dump(stats, f, default=str, indent=2)
    except Exception:
        pass
