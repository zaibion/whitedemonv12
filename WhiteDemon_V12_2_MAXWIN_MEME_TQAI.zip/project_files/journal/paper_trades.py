"""Paper-trade journal (local JSON-backed)."""
from _engine import record_paper_trade, resolve_paper_trades, journal_stats
