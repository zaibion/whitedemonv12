"""
trade_outcome_tracker.py — V12.2 Trade Journal + GitHub sync
"""
from __future__ import annotations
from typing import Dict, Any, List
import time, json
try:
    from core.trade_quality_ai import get_tqai
    HAS_TQ = True
except Exception:
    HAS_TQ = False

def record_trade_outcome(trade: Dict[str, Any]) -> Dict[str, Any]:
    """Save WIN/LOSS feedback — used by /api/trade_feedback"""
    try:
        if HAS_TQ:
            tq = get_tqai()
            tq.record_outcome(trade)
            return {"ok": True, "saved": True, "n_total": len(tq.trades)}
        # fallback local
        return {"ok": True, "saved": "local", "note": "TQAI not available"}
    except Exception as e:
        return {"ok": False, "error": str(e)[:160]}

def list_recent_trades(limit: int = 200) -> List[Dict[str, Any]]:
    try:
        if HAS_TQ:
            tq = get_tqai()
            tr = tq.trades[-limit:]
            # reverse chronological
            return list(reversed(tr))
        return []
    except Exception:
        return []
