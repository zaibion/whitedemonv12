# WhiteDemon V9.2 — Precision Arbiter

## What changed
The trade direction is no longer chosen by only one thing.

V9.2 uses a **Precision Arbiter** that combines:
- all-model majority votes
- committee direction and committee edge
- selected committee win probability
- setup score
- model agreement
- RR quality
- stop-risk quality
- warning/risk penalties
- cached OOS/backtest expectancy guard

## Why
A weak majority like:

```text
24 models LONG vs 22 models SHORT
```

is too close and should not create a real trade entry by itself.

Now weak majority cases are shown as setup/watch only and blocked unless committee/setup/risk also strongly agree.

## New rules
A setup can only become `TRADE_NOW` if:
- no warnings remain
- all-model majority is strong enough
- committee does not strongly disagree
- entry precision score is high enough
- risk/SL/TP geometry is valid
- confidence/backtest/risk guard pass

Default new thresholds:
- `high_precision_entry_score = 72`
- `min_all_model_vote_share = 58%`
- `min_all_model_vote_edge = 8%`

## Output example

```text
BEST SETUP: LONG · WATCH · setup_score=62.1 precision=66.4 grade=B
ALL-MODEL MAJORITY: LONG (24/46 weighted votes, 52.2%) · committee=SHORT edge=6.1%
NO TRADE / WARNINGS: all-model majority too close; entry precision score 66.4 < 72.0
```

## Important
This should reduce weak/ambiguous entries and make entries more selective. It may reduce trade count, but should improve trade quality.

## Checks
- compileall passed
- tabnanny passed
- pyflakes syntax/undefined-name scan passed
