"""
analyze.py — WhiteDemon_V8.2  TRUE FAST MODE

What changed (CRITICAL FIX):
  Previous versions called _engine.run_ml_committee() which is a TRAINING
  function. It re-trained 9 classical + 14 DL nets on the 4k live candles
  every time. That's why analysis hung for 30+ minutes.

  WhiteDemon_V8.2 does INFERENCE ONLY:
    1. Fetch 4k live candles
    2. Build indicators + structure (instant)
    3. Load cached SLIM committees (long_<rid>.json + short_<rid>.json) ← INSTANT
    4. Load Monte Carlo / position sizing / smart-SL extras
    5. Build trade setup with smart-SL post-processing
    6. Push dashboard + final + HTML embed

  Total time: ~30 seconds (just data fetch + indicators).

If slim cache is empty for current pair, we fall back to running the engine
ONCE to populate it (this is what 'training' means — the user needs to have
done Menu 1 first).

Visible heartbeat every 10 seconds so you can see it's working.
"""
from __future__ import annotations
import os, sys, json, datetime, re, traceback, threading, time

from core.config  import CFG, SYMBOL, TF_LABEL, PAIR, TF, apply_selection
from core.gpu_setup import enable_gpu
enable_gpu(verbose=True)
from core.colors  import RESET, BOLD, CYAN, GREEN, RED, ORANGE, YELLOW, GREY
from core.storage import STORE
from core.data_validation import validate_ohlcv, validation_text
from core.monitoring import emit_metrics
from core.rejected_trades import log_rejected_trade
from data.fetcher_ccxt import fetch_ohlcv_stitched_v23

import pandas as pd
import numpy as np


# ──────────────────────────────────────────────────────────────────────────
# Visible heartbeat — proves the script is alive during slow ops
# ──────────────────────────────────────────────────────────────────────────
class _Heartbeat:
    def __init__(self, label: str, interval: int = 10):
        self.label = label
        self.interval = interval
        self.stop_flag = threading.Event()
        self.thread = None
        self.t0 = time.time()
    def __enter__(self):
        def _beat():
            while not self.stop_flag.wait(self.interval):
                elapsed = int(time.time() - self.t0)
                print(f"  {GREY}[heartbeat · {self.label} · {elapsed}s elapsed]{RESET}",
                      flush=True)
        self.thread = threading.Thread(target=_beat, daemon=True)
        self.thread.start()
        return self
    def __exit__(self, *a):
        self.stop_flag.set()


print(f"\n{BOLD}{CYAN}══ ANALYZE (TRUE FAST MODE WhiteDemon_V10.4) · {SYMBOL} @ {TF_LABEL} ══{RESET}\n",
      flush=True)
apply_selection(PAIR, TF)
rid = f"{SYMBOL.replace('-','_')}_{TF_LABEL}"

# ════════════════════════════════════════════════════════════════════
# 1. Fetch FRESH 4k live candles
# ════════════════════════════════════════════════════════════════════
_requested = max(int(CFG.get("cache_fetch_candles", 4000)), 1500)
print(f"[1/5] Fetching fresh {_requested:,} candles …", flush=True)
t_step = time.time()
with _Heartbeat("fetch candles", 5):
    df, src = fetch_ohlcv_stitched_v23(SYMBOL, TF_LABEL, _requested)
# V9.4: validate/repair market data before indicators/models.
df, data_validation = validate_ohlcv(df, TF_LABEL, repair=True)
print(f"  data validation: {validation_text(data_validation)}", flush=True)
if df is None or len(df) < 500 or not data_validation.get("ok", False):
    print(f"  {RED}❌ Only {len(df) if df is not None else 0} candles fetched — "
          f"need ≥ 500{RESET}", flush=True)
    sys.exit(1)
print(f"  ✓ {len(df):,} bars · last=${df['close'].iloc[-1]:.4f} · "
      f"took {time.time()-t_step:.1f}s\n", flush=True)


# ════════════════════════════════════════════════════════════════════
# 2. Indicators + structure (no model calls)
# ════════════════════════════════════════════════════════════════════
print(f"[2/5] Indicators + structure (fast) …", flush=True)
t_step = time.time()
from indicators.basic     import calc_atr, calc_rsi
from indicators.structure import (zigzag, sr_from_zigzag, sr_from_rolling_pivots,
                                    sr_from_volume_profile, merge_all_sr,
                                    detect_bos_choch, detect_market_regime, mtf_trends)
from indicators.smc       import find_sd_zones, find_order_blocks, find_fvgs
from indicators.fibonacci import fibonacci
from indicators.hunting   import detect_stop_loss_hunting
from indicators.patterns  import pattern_scan
from strategy.setup_builder import (build_setup, set_smart_sl_context,
                                     clear_smart_sl_context)
from strategy.tp_sl_prob    import calculate_tp_sl_probability
from strategy.confluence    import decide_trade
from strategy.forecast      import (algo_forecast_next_n, predict_next_candle,
                                     predict_next_20_candles)
from strategy.reasoning     import build_trade_reasoning
from data.fetcher_sentiment import FinBERTSentiment, fetch_sentiment
from data.fetcher_derivatives import fetch_derivatives
from data.fetcher_liquidations import get_liquidation_clusters

try:
    from advanced.feature_blender import blend_advanced_features
    HAS_ADVANCED = True
except ImportError:
    HAS_ADVANCED = False

df["atr"] = calc_atr(df)
df["rsi"] = calc_rsi(df["close"])
_train_cutoff = max(50, len(df) - 100) if len(df) >= 600 else int(len(df) * 0.9)

price   = float(df["close"].iloc[-1])
atr_val = float(df["atr"].iloc[-1])
_tw     = min(CFG.get("trade_window", 500), max(150, len(df) // 2))
tdf     = df.tail(_tw).copy().reset_index(drop=True)
pivots_zz, _, _ = zigzag(tdf.tail(CFG["zz_lookback"]), CFG["zz_dev_pct"])
pivots = [{**p, "idx": p["idx"]} for p in pivots_zz]
sr = merge_all_sr(
    sr_from_zigzag(pivots_zz, CFG["sr_tol_pct"]),
    sr_from_rolling_pivots(tdf),
    sr_from_volume_profile(tdf), price, tol_pct=0.3)
demand, supply     = find_sd_zones(tdf)
bull_obs, bear_obs = find_order_blocks(tdf)
fvgs               = find_fvgs(tdf)
try:    bos_events = detect_bos_choch(tdf, pivots)
except: bos_events = []
try:    fib_lvls   = fibonacci(tdf)
except: fib_lvls = {}
try:    hunting    = detect_stop_loss_hunting(tdf, sr)
except: hunting = []
try:    patterns   = pattern_scan(df, _train_cutoff)
except: patterns = {"cases": 0, "bullish": 0, "bearish": 0}
regime_info    = detect_market_regime(df)
ltf, h1, h4, _ = mtf_trends(df)
# V9.4 adaptive regime profile: makes gates stricter in risky regimes.
try:
    _atr_pct_now = float(atr_val / max(price, 1e-9) * 100.0)
except Exception:
    _atr_pct_now = 0.0
regime_profile = {
    "regime": regime_info.get("regime", "UNKNOWN"),
    "atr_pct": round(_atr_pct_now, 4),
    "risk_mode": "normal",
    "threshold_add": 0.0,
    "reason": "normal market",
}
_reg = str(regime_profile["regime"]).upper()
if "RANG" in _reg or "UNCLEAR" in _reg or "CHOP" in _reg:
    regime_profile.update({"risk_mode": "strict", "threshold_add": 4.0,
                           "reason": "ranging/unclear regime"})
if _atr_pct_now > float(CFG.get("high_vol_atr_pct", 2.5)):
    regime_profile.update({"risk_mode": "very_strict", "threshold_add": max(regime_profile["threshold_add"], 7.0),
                           "reason": "high volatility"})
print(f"  ✓ indicators built in {time.time()-t_step:.1f}s\n", flush=True)


# ════════════════════════════════════════════════════════════════════
# 3. Load CACHED committee (INFERENCE-ONLY — no run_ml_committee call)
# ════════════════════════════════════════════════════════════════════
print(f"[3/5] Loading cached committee for {rid} (slim JSON + per-model index) …",
      flush=True)
t_step = time.time()
cm_long  = None
cm_short = None
_long_cached  = STORE.get_json(f"long_{rid}") or {}
_short_cached = STORE.get_json(f"short_{rid}") or {}
if _long_cached and _long_cached.get("result"):
    cm_long = _long_cached["result"]
    print(f"  ✓ LONG  committee  stack_bull={cm_long.get('stack_bull',0.5)*100:.1f}%  "
          f"n_models={cm_long.get('n_models',0)}", flush=True)
if _short_cached and _short_cached.get("result"):
    cm_short = _short_cached["result"]
    print(f"  ✓ SHORT committee  stack_bull={cm_short.get('stack_bull',0.5)*100:.1f}%  "
          f"n_models={cm_short.get('n_models',0)}", flush=True)

# Fall back to per-model index reassembly if slim cache empty
if not cm_long or not cm_short:
    print(f"  {YELLOW}⚠ slim cache incomplete — reassembling from per-model index{RESET}",
          flush=True)
    try:
        from core.committee_reassembly import build_slim_committee, is_fully_trained
        _target = CFG.get("target_total_candles", 200_000)
        # Try each candle count we might have trained on
        for _cnt in (_target, 200_000, 100_000, 60_000, 30_000, 10_000):
            if not cm_long and is_fully_trained(SYMBOL, TF_LABEL, "LONG", _cnt):
                cm_long = build_slim_committee(SYMBOL, TF_LABEL, "LONG", _cnt)
                print(f"  ✓ LONG  reassembled from {_cnt:,}-candle cache", flush=True)
            if not cm_short and is_fully_trained(SYMBOL, TF_LABEL, "SHORT", _cnt):
                cm_short = build_slim_committee(SYMBOL, TF_LABEL, "SHORT", _cnt)
                print(f"  ✓ SHORT reassembled from {_cnt:,}-candle cache", flush=True)
            if cm_long and cm_short:
                break
    except Exception as e:
        print(f"  {YELLOW}reassembly failed: {e}{RESET}", flush=True)



# V9.7: prefer full saved inference bundles (model objects + scaler + feature schema).
def _try_full_bundle_inference() -> tuple[dict | None, dict | None, dict]:
    info = {"used": False, "reason": "not attempted", "count": None}
    try:
        from core.committee_bundle import load_committee_bundle, infer_committee_bundle
        counts = [int(CFG.get("target_total_candles", 200_000)), 200_000, 100_000, 60_000, 30_000, 10_000]
        for cnt in counts:
            bL = load_committee_bundle(SYMBOL, TF_LABEL, "LONG", cnt)
            bS = load_committee_bundle(SYMBOL, TF_LABEL, "SHORT", cnt)
            if bL and bS:
                cmL = infer_committee_bundle(bL, df.copy(), 0.0, regime_profile.get("regime", "RANGING"),
                                              sym=SYMBOL, tf=TF_LABEL, count=cnt, include_dl=True)
                cmS = infer_committee_bundle(bS, df.copy(), 0.0, regime_profile.get("regime", "RANGING"),
                                              sym=SYMBOL, tf=TF_LABEL, count=cnt, include_dl=True)
                info.update({"used": True, "reason": "full saved committee bundles + cached DL inference", "count": cnt,
                             "long_models": cmL.get("trained_model_names", []),
                             "short_models": cmS.get("trained_model_names", []),
                             "long_dl_loaded": cmL.get("dl_loaded_names", []),
                             "short_dl_loaded": cmS.get("dl_loaded_names", [])})
                print(f"  {GREEN}[bundle-fast] TRUE all-model bundle inference @ {cnt:,}: "
                      f"LONG={cmL.get('stack_bull',0.5)*100:.1f}% "
                      f"SHORT={cmS.get('stack_bull',0.5)*100:.1f}% "
                      f"DL(L/S)={len(cmL.get('dl_loaded_names', []))}/{len(cmS.get('dl_loaded_names', []))}{RESET}", flush=True)
                return cmL, cmS, info
        info["reason"] = "no full committee bundles found yet (train once with V9.8 to create them)"
        return None, None, info
    except Exception as e:
        info["reason"] = f"bundle inference failed: {type(e).__name__}: {str(e)[:200]}"
        print(f"  {YELLOW}[bundle-fast] skipped: {info['reason']}{RESET}", flush=True)
        return None, None, info

_bundle_cm_long, _bundle_cm_short, bundle_fast_info = _try_full_bundle_inference()
if _bundle_cm_long and _bundle_cm_short:
    cm_long, cm_short = _bundle_cm_long, _bundle_cm_short

# V9.6: TRUE cached-model inference (no retraining).
# Slim JSON is metadata-only; this path loads saved models from GitHub/storage,
# runs them on the latest candles, and uses their real current predictions.
def _try_true_cached_inference() -> tuple[dict | None, dict | None, dict]:
    info = {"used": False, "reason": "not attempted", "count": None,
            "long_models": {}, "short_models": {}}
    if not bool(CFG.get("fast_mode_true_model_inference", True)):
        info["reason"] = "disabled by CFG.fast_mode_true_model_inference"
        return None, None, info
    try:
        from core import per_model_cache as pmc
        from core.engine_patches import (apply_engine_patches, engine_context,
                                         set_model_filter, clear_model_filter)
        from ml_models.committee import run_ml_committee
        from data.fetcher_sentiment import FinBERTSentiment, fetch_sentiment
        apply_engine_patches()
        counts = [int(CFG.get("target_total_candles", 200_000)), 200_000, 100_000, 60_000, 30_000, 10_000]
        chosen = None
        status = {}
        for cnt in counts:
            dL = pmc.list_done(SYMBOL, TF_LABEL, "LONG", cnt)
            dS = pmc.list_done(SYMBOL, TF_LABEL, "SHORT", cnt)
            nL = len(dL.get("classical", [])) + len(dL.get("dl", []))
            nS = len(dS.get("classical", [])) + len(dS.get("dl", []))
            if nL > 0 and nS > 0:
                chosen = cnt
                status = {"LONG": dL, "SHORT": dS}
                break
        if chosen is None:
            info["reason"] = "no version-valid per-model cache found for both LONG and SHORT"
            return None, None, info
        info["count"] = chosen
        info["long_models"] = status["LONG"]
        info["short_models"] = status["SHORT"]
        print(f"  [true-fast] using saved models @ {chosen:,} candles — NO retraining", flush=True)
        print(f"  [true-fast] LONG cached: cls={status['LONG'].get('classical', [])} dl={status['LONG'].get('dl', [])}", flush=True)
        print(f"  [true-fast] SHORT cached: cls={status['SHORT'].get('classical', [])} dl={status['SHORT'].get('dl', [])}", flush=True)
        try:
            _nlp_tmp = fetch_sentiment(FinBERTSentiment())
            _sent = float(_nlp_tmp.get("score", 0.0))
        except Exception:
            _sent = 0.0
        _cutoff = max(300, len(df) - 1)  # latest row is live row; earlier rows are context/training base for transforms
        out = {}
        for _dir in ("LONG", "SHORT"):
            allowed_cls = status[_dir].get("classical", [])
            allowed_dl = status[_dir].get("dl", [])
            if not allowed_cls and not allowed_dl:
                continue
            with engine_context(SYMBOL, TF_LABEL, _dir, chosen):
                set_model_filter(classical=allowed_cls, dl=allowed_dl)
                try:
                    _old_inf_flag = CFG.get("_inference_only_no_train", False)
                    CFG["_inference_only_no_train"] = True
                    try:
                        cm = run_ml_committee(df.copy(), _sent, _cutoff,
                                              llm_features=None, direction=_dir)
                    finally:
                        CFG["_inference_only_no_train"] = _old_inf_flag
                    cm["true_cached_inference"] = True
                    cm["metadata_only_probability"] = False
                    cm["cache_count"] = chosen
                    cm["inference_models"] = {"classical": allowed_cls, "dl": allowed_dl}
                    out[_dir] = cm
                finally:
                    clear_model_filter()
        if "LONG" in out and "SHORT" in out:
            info["used"] = True
            info["reason"] = "loaded saved models and ran latest-candle inference"
            return out["LONG"], out["SHORT"], info
        info["reason"] = "could not infer both directions from cached models"
        return None, None, info
    except Exception as e:
        info["reason"] = f"true cached inference failed: {type(e).__name__}: {str(e)[:200]}"
        print(f"  {YELLOW}[true-fast] skipped: {info['reason']}{RESET}", flush=True)
        return None, None, info

if bundle_fast_info.get("used"):
    true_fast_info = {"used": True, "method": "full_bundle", **bundle_fast_info}
else:
    _true_cm_long, _true_cm_short, true_fast_info = _try_true_cached_inference()
    if _true_cm_long and _true_cm_short:
        cm_long, cm_short = _true_cm_long, _true_cm_short
        print(f"  {GREEN}✓ TRUE FAST MODE inference complete: LONG={cm_long.get('stack_bull',0.5)*100:.1f}% SHORT={cm_short.get('stack_bull',0.5)*100:.1f}%{RESET}", flush=True)
    else:
        true_fast_info.setdefault("used", False)
        print(f"  {YELLOW}[true-fast] fallback to slim metadata: {true_fast_info.get('reason')}{RESET}", flush=True)

# Final fallback: neutral 50/50 (analysis still completes — just no edge)
if not cm_long:
    print(f"  {RED}❌ no LONG committee in cache — run Menu 1 to train first{RESET}",
          flush=True)
    cm_long = {"stack_bull": 0.5, "preds": {}, "probs": {}, "wf_accs": {},
                "dl_individual": {}, "n_models": 0, "baseline_win_rate": 0.5}
if not cm_short:
    print(f"  {RED}❌ no SHORT committee in cache — run Menu 1 to train first{RESET}",
          flush=True)
    cm_short = {"stack_bull": 0.5, "preds": {}, "probs": {}, "wf_accs": {},
                 "dl_individual": {}, "n_models": 0, "baseline_win_rate": 0.5}

print(f"  ✓ committee loaded in {time.time()-t_step:.1f}s\n", flush=True)


# ════════════════════════════════════════════════════════════════════
# 4. Build trade setup + decision + extras
# ════════════════════════════════════════════════════════════════════
print(f"[4/5] Build trade setup + smart-SL + Monte Carlo + position sizing …",
      flush=True)
t_step = time.time()

p_l = float(cm_long.get("stack_bull",  0.5))
p_s = float(cm_short.get("stack_bull", 0.5))

# High-Precision / Setup Watch configuration.  This DOES NOT hide setups:
# it always builds LONG and SHORT candidates, then marks them TRADE_NOW / WATCH / NO_TRADE.
# V9.3 ELITE ENTRY GATE: stricter defaults to reduce losing/ambiguous entries.
# V10.9 Balanced entry thresholds: less strict than elite mode, but still blocks junk.
HP_MIN_SCORE     = float(CFG.get("high_precision_min_score", 60.0))
HP_WATCH_SCORE   = float(CFG.get("watch_setup_min_score", 40.0))
HP_HARD_BLOCK_SCORE = float(CFG.get("hard_block_setup_score", 30.0))
HP_MIN_PROB      = float(CFG.get("high_precision_min_prob", 0.60))
HP_MIN_EDGE      = float(CFG.get("high_precision_min_edge", 0.05))
HP_MIN_AGREE     = float(CFG.get("high_precision_min_model_agreement", 0.58))
HP_MIN_RR        = float(CFG.get("high_precision_min_rr", 1.05))
HP_MAX_RR        = float(CFG.get("high_precision_max_rr", 4.50))
HP_MIN_RISK_PCT  = float(CFG.get("high_precision_min_risk_pct", 0.05))
HP_MAX_RISK_PCT  = float(CFG.get("high_precision_max_risk_pct", 4.50))
HP_MIN_PRECISION_SCORE = float(CFG.get("high_precision_entry_score", 60.0))
HP_WATCH_PRECISION_SCORE = float(CFG.get("watch_precision_score", 45.0))
HP_HARD_BLOCK_PRECISION_SCORE = float(CFG.get("hard_block_precision_score", 30.0))
HP_MIN_MAJORITY_EDGE   = float(CFG.get("min_all_model_vote_edge", 0.05))
HP_MIN_MAJORITY_SHARE  = float(CFG.get("min_all_model_vote_share", 0.55))
HP_REQUIRE_BACKTEST    = bool(CFG.get("high_precision_require_backtest", True))
HP_MIN_BACKTEST_TRADES = int(CFG.get("high_precision_min_backtest_trades", 50))
HP_MIN_BACKTEST_EXP_R  = float(CFG.get("high_precision_min_backtest_expectancy_R", 0.05))
HP_REQUIRE_HTF_ALIGN   = bool(CFG.get("high_precision_require_htf_alignment", True))
HP_MIN_LIVE_EDGE_OVER_BASELINE = float(CFG.get("high_precision_min_live_edge_over_baseline", 0.03))
HP_MIN_MARKET_SIMILARITY = float(CFG.get("high_precision_min_market_similarity", 0.35))
HP_REQUIRE_WINNER_SIMILARITY = bool(CFG.get("high_precision_require_winner_similarity", True))
HP_MIN_ANALOG_WIN_RATE = float(CFG.get("high_precision_min_analog_win_rate", 0.58))
HP_DRIFT_PSI_BLOCK = float(CFG.get("high_precision_drift_psi_block", 0.25))
HP_DRIFT_PSI_EXTREME = float(CFG.get("high_precision_drift_psi_extreme", 0.50))
SETUP_SCAN_BARS  = int(CFG.get("setup_scan_bars", 96))
# Apply adaptive regime strictness to score/probability gates.
try:
    _thr_add = float(regime_profile.get("threshold_add", 0.0))
    # keep regime adjustment humble; don't over-filter.
    HP_MIN_SCORE += min(_thr_add, 3.0)
    HP_MIN_PRECISION_SCORE += min(_thr_add, 3.0)
    if _thr_add >= 4:
        HP_MIN_PROB += 0.005
        HP_MIN_EDGE += 0.01
except Exception:
    pass   # if you run every 30-60m, scan recent bars for missed setups

from strategy.confidence_aggregator import aggregate_confidence
from live.live_guard import LiveGuard

# Fetch liquidation clusters (5s timeout per source, ~5-15s total)
print(f"  fetching liquidation clusters …", flush=True)
liq_clusters = []
with _Heartbeat("liq fetch", 8):
    try:
        liq_clusters = get_liquidation_clusters(SYMBOL, lookback_min=60)
        if liq_clusters:
            print(f"  ✓ {len(liq_clusters)} liquidation clusters "
                  f"(top mag ${liq_clusters[0]['magnitude']:,.0f})", flush=True)
    except Exception as e:
        print(f"  {YELLOW}liq fetch skipped: {e}{RESET}", flush=True)

# Load SL-placement NN (latest batch from registry)
sl_nn = None
try:
    from neural_nets.sl_placement_nn import SLPlacementWrapper
    sl_nn = SLPlacementWrapper.load_latest_for(SYMBOL, TF_LABEL)
    if sl_nn:
        print(f"  ✓ SL-NN loaded (train_acc={sl_nn.train_acc:.3f})", flush=True)
except Exception as e:
    print(f"  {GREY}SL-NN load skipped: {e}{RESET}", flush=True)

# Sentiment + derivatives (also fast, but heartbeat just in case)
print(f"  fetching sentiment + derivatives …", flush=True)
with _Heartbeat("sentiment/deriv", 10):
    try: nlp = fetch_sentiment(FinBERTSentiment())
    except Exception: nlp = {"score": 0.0, "headlines": [], "sentiment": "NEUTRAL"}
    try: deriv = fetch_derivatives()
    except Exception: deriv = {}

# Advanced features (optional)
advanced_feats = {}
if HAS_ADVANCED:
    try:
        with _Heartbeat("advanced features", 10):
            advanced_feats = blend_advanced_features(df, SYMBOL, skip_live=False)
    except Exception as _e:
        print(f"  {ORANGE}advanced features skipped: {_e}{RESET}", flush=True)

# collect NN signals if available for each committee
def _nn_signals_for(committee: dict) -> dict:
    out = {}
    for _k in ("price_reg","rl_agent","sentiment_nn","regime_nn"):
        try:
            _v = committee.get(_k)
            if _v: out[_k] = _v
        except Exception:
            pass
    return out

# cached backtest OOS stats if available
try:
    _bt = STORE.get_json(f"backtest_{rid}") or {}
    _ov = _bt.get("overall") or {}
    _bt_stats = {
        "win_rate": _ov.get("overall_wr", _bt.get("win_rate", 0.5)),
        "trades": _ov.get("total_trades", _bt.get("trades", 0)),
        "expectancy_R": _ov.get("net_expectancy_R", _bt.get("net_expectancy_R", 0.0)),
    }
except Exception:
    _bt_stats = {"win_rate": 0.5, "trades": 0, "expectancy_R": 0.0}

_guard = LiveGuard()

def _sf(x, default=0.0):
    try:
        if x is None: return default
        return float(x)
    except Exception:
        return default

def _model_agreement(committee: dict, direction: str) -> float:
    """Share of models supporting THIS direction-specific committee.

    Important: LONG and SHORT committees are trained separately.
    In BOTH committees, prediction=1 means "this committee's direction wins".
    So for SHORT, pred=1 supports SHORT too (not LONG).
    """
    preds = committee.get("preds") or {}
    vals = [v for k, v in preds.items() if k != "stack" and isinstance(v, (int, float, bool))]
    if not vals:
        dl = committee.get("dl_individual") or {}
        vals = [1 if _sf(v, 0.5) >= 0.5 else 0 for v in dl.values()]
    if not vals:
        return 0.50
    support = sum(1 for v in vals if int(v) == 1)
    return support / len(vals)

def _model_vote_summary(committee: dict, direction: str) -> dict:
    """Compact, honest summary of classical + DL/neural model support."""
    preds = committee.get("preds") or {}
    dl = committee.get("dl_individual") or {}
    classical_keys = [k for k in preds.keys() if k not in ("stack", "dl")]
    cls_total = len(classical_keys)
    cls_support = sum(1 for k in classical_keys if int(preds.get(k, 0)) == 1)
    dl_total = len(dl)
    dl_support = sum(1 for _, v in dl.items() if _sf(v, 0.5) >= 0.5)
    stack_prob = _sf(committee.get("stack_bull"), 0.5)
    total = cls_total + dl_total
    support = cls_support + dl_support
    return {
        "direction": direction,
        "classical_support": cls_support,
        "classical_total": cls_total,
        "dl_support": dl_support,
        "dl_total": dl_total,
        "total_support": support,
        "total_models": total,
        "agreement": round((support / total) if total else 0.5, 4),
        "committee_win_probability": round(stack_prob, 4),
        "summary": f"{support}/{total} models support {direction} (classic {cls_support}/{cls_total}, DL {dl_support}/{dl_total})",
    }

def _global_direction_vote() -> dict:
    """Ask ALL available model votes: classical + DL from LONG and SHORT committees + committee stack.

    Direction-specific interpretation:
      • LONG committee pred=1 votes LONG; pred=0 votes SHORT.
      • SHORT committee pred=1 votes SHORT; pred=0 votes LONG.
    This turns the two separate committees into ONE final BUY/SELL majority vote.
    """
    long_votes = 0.0
    short_votes = 0.0
    details = []

    def _add(vote_dir: str, group: str, name: str, weight: float = 1.0):
        nonlocal long_votes, short_votes
        if vote_dir == "LONG":
            long_votes += weight
        elif vote_dir == "SHORT":
            short_votes += weight
        details.append({"group": group, "name": name, "vote": vote_dir, "weight": weight})

    def _committee_votes(cm: dict, committee_dir: str):
        preds = cm.get("preds") or {}
        # Classical / stack-like integer predictions
        for name, val in preds.items():
            if name == "stack":
                continue
            try:
                pred = int(val)
            except Exception:
                continue
            if committee_dir == "LONG":
                _add("LONG" if pred == 1 else "SHORT", "classical" if name != "dl" else "dl_aggregate", f"LONG.{name}")
            else:
                _add("SHORT" if pred == 1 else "LONG", "classical" if name != "dl" else "dl_aggregate", f"SHORT.{name}")
        # Individual DL probabilities
        for name, prob in (cm.get("dl_individual") or {}).items():
            pr = _sf(prob, 0.5)
            if committee_dir == "LONG":
                _add("LONG" if pr >= 0.5 else "SHORT", "deep_learning", f"LONG.{name}")
            else:
                _add("SHORT" if pr >= 0.5 else "LONG", "deep_learning", f"SHORT.{name}")

    _committee_votes(cm_long, "LONG")
    _committee_votes(cm_short, "SHORT")

    # Committee stack vote is based on LIVE EDGE OVER EACH SIDE'S BASELINE,
    # not raw probability. This prevents a model trained in a long-heavy market
    # from saying LONG forever just because its baseline was high.
    _base_l = _sf(cm_long.get("baseline_win_rate"), 0.5)
    _base_s = _sf(cm_short.get("baseline_win_rate"), 0.5)
    _edge_l = p_l - _base_l
    _edge_s = p_s - _base_s
    if _edge_l > _edge_s:
        _add("LONG", "committee_stack", "stack_edge_over_baseline", 2.0)
    elif _edge_s > _edge_l:
        _add("SHORT", "committee_stack", "stack_edge_over_baseline", 2.0)

    # Specialized NN signals if stored inside either committee.
    for source_name, cm in (("LONG", cm_long), ("SHORT", cm_short)):
        for key in ("price_reg", "rl_agent", "sentiment_nn", "regime_nn"):
            sig = cm.get(key) if isinstance(cm, dict) else None
            if not isinstance(sig, dict):
                continue
            raw = str(sig.get("direction", sig.get("action", ""))).upper()
            if "LONG" in raw or "BUY" in raw or "UP" in raw or "BULL" in raw:
                _add("LONG", "neural_special", f"{source_name}.{key}")
            elif "SHORT" in raw or "SELL" in raw or "DOWN" in raw or "BEAR" in raw:
                _add("SHORT", "neural_special", f"{source_name}.{key}")

    total = long_votes + short_votes
    if total <= 0:
        chosen = "LONG" if p_l >= p_s else "SHORT"
        total = 1.0
        if chosen == "LONG": long_votes = 1.0
        else: short_votes = 1.0
    chosen = "LONG" if long_votes >= short_votes else "SHORT"
    chosen_votes = long_votes if chosen == "LONG" else short_votes
    other_votes = short_votes if chosen == "LONG" else long_votes
    long_share = long_votes / total
    short_share = short_votes / total
    edge_share = (chosen_votes - other_votes) / total
    _base_l = _sf(cm_long.get("baseline_win_rate"), 0.5)
    _base_s = _sf(cm_short.get("baseline_win_rate"), 0.5)
    _live_edge_l = p_l - _base_l
    _live_edge_s = p_s - _base_s
    committee_dir = "LONG" if _live_edge_l >= _live_edge_s else "SHORT"
    committee_edge = abs(_live_edge_l - _live_edge_s)
    return {
        "direction": chosen,
        "long_votes": round(long_votes, 2),
        "short_votes": round(short_votes, 2),
        "total_votes": round(total, 2),
        "chosen_votes": round(chosen_votes, 2),
        "other_votes": round(other_votes, 2),
        "long_share": round(long_share, 4),
        "short_share": round(short_share, 4),
        "chosen_share": round(chosen_votes / total, 4),
        "edge_share": round(edge_share, 4),
        "majority_strong": bool((chosen_votes / total) >= HP_MIN_MAJORITY_SHARE and edge_share >= HP_MIN_MAJORITY_EDGE),
        "committee_direction": committee_dir,
        "committee_edge": round(committee_edge, 4),
        "long_edge_over_baseline": round(_live_edge_l, 4),
        "short_edge_over_baseline": round(_live_edge_s, 4),
        "long_baseline": round(_base_l, 4),
        "short_baseline": round(_base_s, 4),
        "committee_strong": bool(committee_edge >= HP_MIN_EDGE),
        "details": details[:80],
        "summary": f"ALL-MODEL MAJORITY: {chosen} ({chosen_votes:.0f}/{total:.0f} weighted votes, {chosen_votes/total:.1%})",
    }

def _vote_share_for(direction: str) -> float:
    gv = globals().get("global_model_vote", {}) or {}
    total = float(gv.get("total_votes", 0) or 0)
    if total <= 0:
        return 0.5
    if direction == "LONG":
        return float(gv.get("long_votes", 0) or 0) / total
    return float(gv.get("short_votes", 0) or 0) / total

def _entry_precision_score(direction: str, prob: float, edge: float, agreement: float,
                           setup_score: float, geom: dict, warnings: list[str]) -> float:
    """One final entry score using all models + committee + setup quality.

    This is the arbiter the user asked for: not just vote majority, not just
    committee probability, but a combined precision score.
    """
    vote_share = _vote_share_for(direction)
    rr = float(geom.get("rr", 0) or 0)
    risk_pct = float(geom.get("risk_pct", 999) or 999)

    # Geometry score rewards realistic RR/risk, penalizes too-wide/too-tight stops.
    rr_score = 0.0
    if HP_MIN_RR <= rr <= 3.5:
        rr_score = 8.0
    elif 3.5 < rr <= HP_MAX_RR:
        rr_score = 4.0
    risk_score = 0.0
    if HP_MIN_RISK_PCT <= risk_pct <= min(3.0, HP_MAX_RISK_PCT):
        risk_score = 8.0
    elif risk_pct <= HP_MAX_RISK_PCT:
        risk_score = 4.0

    score = 0.0
    score += vote_share * 30.0                  # all-model majority
    score += max(0.0, min(1.0, prob)) * 25.0    # selected committee probability
    score += max(0.0, min(100.0, setup_score)) * 0.22
    score += max(0.0, min(1.0, agreement)) * 12.0
    score += max(-0.10, min(0.20, edge)) * 45.0 # committee edge / disagreement penalty
    score += rr_score + risk_score

    # Penalty for serious warnings, but don't double-kill informational warnings.
    serious = [w for w in warnings if not str(w).startswith("guard/freshness")]
    score -= min(30.0, len(serious) * 4.5)
    return round(max(0.0, min(100.0, score)), 1)

def _setup_warnings(setup: dict) -> tuple[list[str], dict]:
    """Geometry/risk checks. Warnings mean show the setup, but do not auto-trade."""
    warnings = []
    d = str(setup.get("direction", "")).upper()
    entry = _sf(setup.get("entry"))
    sl    = _sf(setup.get("sl"))
    tp1   = _sf(setup.get("tp1"))
    rr    = _sf(setup.get("avg_rr_partial_close", setup.get("rr1", 0)))
    valid = bool(setup.get("valid", False))
    risk_pct = abs(entry - sl) / entry * 100.0 if entry > 0 and sl > 0 else 999.0
    if not valid:
        warnings.append(f"setup invalid: {setup.get('reason','unknown')}")
    if entry <= 0:
        warnings.append("entry price invalid")
    if sl <= 0:
        warnings.append("stop loss invalid/non-positive")
    if tp1 <= 0:
        warnings.append("TP1 invalid/non-positive")
    if d == "LONG":
        if not (sl > 0 and sl < entry): warnings.append("LONG SL must be below entry")
        if not (tp1 > entry): warnings.append("LONG TP must be above entry")
    elif d == "SHORT":
        if not (sl > entry): warnings.append("SHORT SL must be above entry")
        if not (0 < tp1 < entry): warnings.append("SHORT TP must be below entry but above zero")
    else:
        warnings.append("direction invalid")
    if risk_pct > HP_MAX_RISK_PCT:
        warnings.append(f"stop too wide {risk_pct:.2f}% > {HP_MAX_RISK_PCT:.2f}%")
    if risk_pct < HP_MIN_RISK_PCT:
        warnings.append(f"stop too tight {risk_pct:.3f}% < {HP_MIN_RISK_PCT:.3f}%")
    if rr < HP_MIN_RR:
        warnings.append(f"RR {rr:.2f} < {HP_MIN_RR:.2f}")
    if rr > HP_MAX_RR:
        warnings.append(f"RR {rr:.2f} > {HP_MAX_RR:.2f} (may be unrealistic)")
    if setup.get("quality") == "FALLBACK_ATR":
        warnings.append("TP fallback is ATR-based, not structural")
    return warnings, {"entry": entry, "sl": sl, "tp1": tp1, "rr": rr, "risk_pct": risk_pct}

def _htf_alignment(direction: str) -> dict:
    vals = [str(x).lower() for x in (ltf, h1, h4)]
    if direction == "LONG":
        good = sum(1 for x in vals if "bull" in x or "up" in x)
        bad = sum(1 for x in vals if "bear" in x or "down" in x)
    else:
        good = sum(1 for x in vals if "bear" in x or "down" in x)
        bad = sum(1 for x in vals if "bull" in x or "up" in x)
    return {"support": good, "against": bad, "total": len(vals), "raw": vals,
            "ok": good >= 2 and bad == 0}

def _candidate(direction: str, setup: dict, last_ts=None) -> dict:
    committee_i = cm_long if direction == "LONG" else cm_short
    prob = p_l if direction == "LONG" else p_s
    other_prob = p_s if direction == "LONG" else p_l
    edge_signed = prob - other_prob
    baseline_prob = _sf(committee_i.get("baseline_win_rate"), 0.5)
    live_edge_over_baseline = prob - baseline_prob
    agree = _model_agreement(committee_i, direction)
    confluence_dict = {"score": 50.0}
    try:
        from strategy.confluence import compute_confluence_score
        _conf_raw = compute_confluence_score(direction, price, sr, demand, supply,
                                             df.tail(200), regime_info.get("regime","RANGING"),
                                             nlp.get("score",0))
        confluence_dict = {"score": float(_conf_raw)}
    except Exception:
        pass
    confidence_i = aggregate_confidence(
        cm_long, cm_short, direction,
        confluence_dict, regime_info, setup,
        backtest_stats=_bt_stats,
        nn_signals=_nn_signals_for(committee_i),
        spread_bps=5.0,
    )
    warnings, geom = _setup_warnings(setup)
    if confidence_i["score"] < HP_MIN_SCORE:
        warnings.append(f"setup score {confidence_i['score']:.1f} < {HP_MIN_SCORE:.1f}")
    if prob < HP_MIN_PROB:
        warnings.append(f"committee probability {prob:.1%} < {HP_MIN_PROB:.1%}")
    if edge_signed < HP_MIN_EDGE:
        warnings.append(f"direction edge {edge_signed:.1%} < {HP_MIN_EDGE:.1%}")
    if live_edge_over_baseline < HP_MIN_LIVE_EDGE_OVER_BASELINE:
        warnings.append(f"live edge over training baseline {live_edge_over_baseline:+.1%} < {HP_MIN_LIVE_EDGE_OVER_BASELINE:.1%}")
    sim = committee_i.get("current_market_similarity", {}) if isinstance(committee_i, dict) else {}
    if HP_REQUIRE_WINNER_SIMILARITY:
        if not sim.get("available"):
            warnings.append(f"market similarity check unavailable ({sim.get('reason','no profile')})")
        else:
            if float(sim.get("similarity_score", 0)) < HP_MIN_MARKET_SIMILARITY:
                warnings.append(f"current market not similar enough to past winners ({float(sim.get('similarity_score',0)):.2f} < {HP_MIN_MARKET_SIMILARITY:.2f})")
            if sim.get("closer_to") == "LOSERS":
                warnings.append("current market resembles past losing setups more than winners")
    analog = committee_i.get("current_analog_pattern", {}) if isinstance(committee_i, dict) else {}
    if analog.get("available"):
        if float(analog.get("analog_win_rate", 0.0)) < HP_MIN_ANALOG_WIN_RATE:
            warnings.append(f"analog pattern win-rate {float(analog.get('analog_win_rate',0)):.1%} < {HP_MIN_ANALOG_WIN_RATE:.1%}")
    else:
        warnings.append(f"analog pattern check unavailable ({analog.get('reason','no reference')})")
    drift = committee_i.get("current_feature_drift", {}) if isinstance(committee_i, dict) else {}
    if drift.get("available"):
        _psi_mean = float(drift.get("psi_mean", 0.0) or 0.0)
        _psi_max = float(drift.get("psi_max", 0.0) or 0.0)
        _level = str(drift.get("level", "ok"))
        if _psi_mean >= HP_DRIFT_PSI_BLOCK or _psi_max >= HP_DRIFT_PSI_EXTREME or _level in ("drift", "extreme"):
            warnings.append(f"feature drift {_level}: PSI mean={_psi_mean:.3f}, max={_psi_max:.3f}")
    else:
        warnings.append(f"feature drift check unavailable ({drift.get('reason','no reference')})")
    if agree < HP_MIN_AGREE:
        warnings.append(f"model agreement {agree:.1%} < {HP_MIN_AGREE:.1%}")
    try:
        if direction != global_model_vote.get("direction"):
            warnings.append(f"all-model majority prefers {global_model_vote.get('direction')}")
        elif float(global_model_vote.get("chosen_share", 0.5)) < float(CFG.get("min_all_model_vote_share", 0.58)):
            warnings.append(f"all-model majority weak {global_model_vote.get('chosen_share',0):.1%} < {float(CFG.get('min_all_model_vote_share',0.58)):.1%}")
    except Exception:
        pass
    # Elite OOS/backtest gate: no reliable edge = no real trade.
    bt_trades = int(_bt_stats.get("trades", 0) or 0)
    bt_exp = float(_bt_stats.get("expectancy_R", 0) or 0)
    if HP_REQUIRE_BACKTEST and bt_trades < HP_MIN_BACKTEST_TRADES:
        warnings.append(f"no reliable OOS backtest for this pair/TF ({bt_trades} trades < {HP_MIN_BACKTEST_TRADES})")
    elif bt_trades >= HP_MIN_BACKTEST_TRADES and bt_exp < HP_MIN_BACKTEST_EXP_R:
        warnings.append(f"cached OOS expectancy too low ({bt_exp:+.3f}R < {HP_MIN_BACKTEST_EXP_R:+.3f}R)")

    # Higher-timeframe alignment gate.
    htf = _htf_alignment(direction)
    if HP_REQUIRE_HTF_ALIGN and not htf.get("ok"):
        warnings.append(f"HTF trend not aligned ({htf.get('support')}/{htf.get('total')} support, {htf.get('against')} against)")

    # Regime conflict gate.
    regime_txt = str((regime_info or {}).get("regime", "")).upper()
    if direction == "LONG" and ("BEAR" in regime_txt or "DOWN" in regime_txt):
        warnings.append(f"regime conflicts with LONG ({regime_txt})")
    if direction == "SHORT" and ("BULL" in regime_txt or "UP" in regime_txt):
        warnings.append(f"regime conflicts with SHORT ({regime_txt})")
    if str(regime_profile.get("risk_mode")) == "very_strict":
        warnings.append(f"very strict regime gate: {regime_profile.get('reason')} ATR={regime_profile.get('atr_pct')}%")

    vote_summary = _model_vote_summary(committee_i, direction)
    guard_eval = _guard.evaluate_trade({
        "confidence": confidence_i,
        "setup": setup,
        "p_long": p_l,
        "p_short": p_s,
        "last_candle_ts": last_ts,
    })
    for chk in guard_eval.get("checks", []):
        if not chk.get("ok"):
            warnings.append(f"guard/{chk.get('check')}: {chk.get('msg')}")
    # De-duplicate while preserving order
    dedup = []
    for w in warnings:
        if w not in dedup: dedup.append(w)

    precision_score = _entry_precision_score(direction, prob, max(edge_signed, live_edge_over_baseline), agree,
                                             float(confidence_i.get("score", 0)), geom, dedup)
    gv = globals().get("global_model_vote", {}) or {}
    if direction == gv.get("direction") and not gv.get("majority_strong", False):
        # 24 vs 22 type cases: show the setup, but do not call it tradeable.
        dedup.append(f"all-model majority too close ({gv.get('chosen_share',0):.1%}, edge {gv.get('edge_share',0):.1%})")
    if precision_score < HP_MIN_PRECISION_SCORE:
        dedup.append(f"entry precision score {precision_score:.1f} < {HP_MIN_PRECISION_SCORE:.1f}")
    # If committee strongly disagrees with all-model majority, block until clean.
    if gv.get("committee_strong") and gv.get("committee_direction") != direction and not gv.get("majority_strong"):
        dedup.append(f"committee strongly prefers {gv.get('committee_direction')} while model majority is weak")

    # De-dupe again after precision warnings.
    dedup2 = []
    for w in dedup:
        if w not in dedup2: dedup2.append(w)
    dedup = dedup2

    # V10.9 status ladder:
    # - TRADE_NOW: clean enough to consider trading
    # - WATCH: usable setup shown, but confidence below ideal
    # - SMALL_MODE: no full setup, but micro forecast may indicate next few candles
    # - WAIT: no reliable setup; stay out
    # - BLOCKED_TOO_LOW: score/precision too low; do not show as trade idea
    hard_block = (float(confidence_i.get("score", 0)) < HP_HARD_BLOCK_SCORE or
                  precision_score < HP_HARD_BLOCK_PRECISION_SCORE or
                  not setup.get("valid"))
    if hard_block:
        status = "BLOCKED_TOO_LOW"
    elif not dedup and precision_score >= HP_MIN_PRECISION_SCORE and float(confidence_i.get("score", 0)) >= HP_MIN_SCORE:
        status = "TRADE_NOW"
    elif precision_score >= HP_WATCH_PRECISION_SCORE or float(confidence_i.get("score", 0)) >= HP_WATCH_SCORE:
        status = "WATCH"
    else:
        status = "WAIT"
    if status == "TRADE_NOW":
        msg = f"🎉 CONGRATULATIONS — {direction} setup found now"
    elif status == "WATCH":
        msg = f"{direction} setup is visible but confidence is below trade threshold: " + (dedup[0] if dedup else "watch only")
    elif status == "BLOCKED_TOO_LOW":
        msg = f"Setup score/precision too low — stay out completely"
    else:
        msg = "WAIT — no reliable full setup available"
    return {
        "direction": direction,
        "status": status,
        "message": msg,
        "probability": round(prob, 4),
        "other_probability": round(other_prob, 4),
        "baseline_probability": round(baseline_prob, 4),
        "live_edge_over_baseline": round(live_edge_over_baseline, 4),
        "edge": round(edge_signed, 4),
        "model_agreement": round(agree, 4),
        "model_vote_summary": vote_summary,
        "global_model_vote": globals().get("global_model_vote", {}),
        "current_market_similarity": committee_i.get("current_market_similarity", {}) if isinstance(committee_i, dict) else {},
        "current_analog_pattern": committee_i.get("current_analog_pattern", {}) if isinstance(committee_i, dict) else {},
        "current_feature_drift": committee_i.get("current_feature_drift", {}) if isinstance(committee_i, dict) else {},
        "htf_alignment": _htf_alignment(direction),
        "setup_score": confidence_i["score"],
        "entry_precision_score": precision_score,
        "grade": confidence_i["grade"],
        "warnings": dedup,
        "setup": setup,
        "geometry": geom,
        "confidence": confidence_i,
        "guard": guard_eval,
        "action_text": ("TRADE NOW" if status == "TRADE_NOW" else
                        "WATCH ONLY — lower confidence" if status == "WATCH" else
                        "WAIT — no clean setup" if status == "WAIT" else
                        "BLOCKED — score too low"),
    }

def _scan_recent_setups(max_bars: int = SETUP_SCAN_BARS) -> list[dict]:
    """When user cannot run 24h: scan recent candles and report any setup that appeared."""
    found = []
    try:
        if len(df) < 500:
            return found
        start_i = max(300, len(df) - max_bars)
        idxs = list(range(start_i, len(df), max(1, max_bars // 48)))
        for ix in idxs:
            sub = df.iloc[:ix+1].copy()
            px = float(sub["close"].iloc[-1])
            atr_i = float(sub["atr"].iloc[-1]) if "atr" in sub.columns else atr_val
            tdf_i = sub.tail(_tw).copy().reset_index(drop=True)
            try:
                piv_i, _, _ = zigzag(tdf_i.tail(CFG["zz_lookback"]), CFG["zz_dev_pct"])
                sr_i = merge_all_sr(sr_from_zigzag(piv_i, CFG["sr_tol_pct"]),
                                    sr_from_rolling_pivots(tdf_i),
                                    sr_from_volume_profile(tdf_i), px, tol_pct=0.3)
                dem_i, sup_i = find_sd_zones(tdf_i)
            except Exception:
                continue
            # Build local setups; score with current trained committee probabilities.
            old_price = globals().get('price')
            for d in ("LONG", "SHORT"):
                st = build_setup(d, px, sr_i, dem_i, sup_i, atr_i)
                warns, geom = _setup_warnings(st)
                prob = p_l if d == "LONG" else p_s
                edge = prob - (p_s if d == "LONG" else p_l)
                quick_score = 100.0 * max(0.0, min(1.0, (prob - 0.50) / 0.20))
                if st.get("valid") and not warns and prob >= HP_MIN_PROB and edge >= HP_MIN_EDGE:
                    found.append({
                        "found_at": str(sub["open_time"].iloc[-1]) if "open_time" in sub.columns else str(ix),
                        "bars_ago": int(len(df) - 1 - ix),
                        "direction": d,
                        "status": "RECENT_SETUP_FOUND" if ix < len(df)-1 else "CURRENT_SETUP_FOUND",
                        "message": f"🎉 Setup found {len(df)-1-ix} bars ago: {d} near ${px:.6f}",
                        "price_then": px,
                        "probability": round(prob, 4),
                        "edge": round(edge, 4),
                        "quick_score": round(quick_score, 1),
                        "setup": st,
                        "geometry": geom,
                    })
        # most recent/highest score first
        found = sorted(found, key=lambda x: (x.get("bars_ago", 999), -x.get("quick_score", 0)))[:10]
    except Exception as e:
        found.append({"status": "SCAN_ERROR", "message": str(e)[:200]})
    return found

def _potential_setup_levels() -> list[dict]:
    """Tell the user where a setup MAY appear if there is no clean setup now.

    This is not a trade signal. It gives watch prices/zones based on nearby
    support/resistance, demand/supply and ATR buffer so the user can re-run or
    watch the market near those prices.
    """
    levels = []
    try:
        sr_prices = sorted({round(_sf(x.get("price")), 8) for x in (sr or []) if _sf(x.get("price")) > 0})
        supports = [x for x in sr_prices if x < price]
        resistances = [x for x in sr_prices if x > price]
        nearest_support = supports[-1] if supports else None
        nearest_resistance = resistances[0] if resistances else None
        atr_buf = max(atr_val * 0.15, price * 0.001)
        zone_buf = max(atr_val * 0.35, price * 0.002)

        def _add(kind, direction, trigger, zone_low, zone_high, reason, invalid=None):
            if trigger is None or trigger <= 0:
                return
            levels.append({
                "kind": kind,
                "direction": direction,
                "trigger_price": round(float(trigger), 8),
                "zone_low": round(float(max(0.0, zone_low)), 8),
                "zone_high": round(float(max(0.0, zone_high)), 8),
                "invalid_below_above": round(float(invalid), 8) if invalid else None,
                "distance_pct_from_now": round((float(trigger) - price) / price * 100.0, 3) if price else 0.0,
                "reason": reason,
                "message": (f"Watch {direction}: possible {kind} setup near ${float(trigger):.6f}. "
                            f"Current price ${price:.6f}; distance {(float(trigger)-price)/price*100.0:+.2f}%"),
            })

        # LONG pullback: price comes back to support/demand and holds.
        if nearest_support:
            _add("pullback/support-hold", "LONG", nearest_support + atr_buf,
                 nearest_support - zone_buf, nearest_support + zone_buf,
                 "Possible buy setup if price pulls back to support and holds/rejects lower prices.",
                 nearest_support - zone_buf)

        # LONG breakout: price closes above resistance.
        if nearest_resistance:
            _add("breakout/resistance-close", "LONG", nearest_resistance + atr_buf,
                 nearest_resistance, nearest_resistance + zone_buf,
                 "Possible buy setup if a candle closes above resistance with momentum/volume.",
                 nearest_resistance - zone_buf)

        # SHORT rejection: price rallies into resistance/supply and rejects.
        if nearest_resistance:
            _add("rejection/resistance-hold", "SHORT", nearest_resistance - atr_buf,
                 nearest_resistance - zone_buf, nearest_resistance + zone_buf,
                 "Possible sell setup if price taps resistance/supply and rejects.",
                 nearest_resistance + zone_buf)

        # SHORT breakdown: price closes below support.
        if nearest_support:
            trig = nearest_support - atr_buf
            if trig > 0:
                _add("breakdown/support-close", "SHORT", trig,
                     max(0.0, nearest_support - zone_buf), nearest_support,
                     "Possible sell setup if a candle closes below support with momentum/volume.",
                     nearest_support + zone_buf)

        # Demand/supply zone based watch levels.
        fresh_d = [z for z in (demand or []) if not z.get("mitigated", False)]
        fresh_s = [z for z in (supply or []) if not z.get("mitigated", False)]
        below_d = sorted([z for z in fresh_d if _sf(z.get("top")) < price], key=lambda z: _sf(z.get("top")), reverse=True)
        above_s = sorted([z for z in fresh_s if _sf(z.get("bottom")) > price], key=lambda z: _sf(z.get("bottom")))
        if below_d:
            z = below_d[0]
            zl, zh = _sf(z.get("bottom")), _sf(z.get("top"))
            _add("demand-zone-retest", "LONG", zh,
                 zl, zh, "Possible buy setup if price returns to fresh demand and shows rejection.", zl - atr_buf)
        if above_s:
            z = above_s[0]
            zl, zh = _sf(z.get("bottom")), _sf(z.get("top"))
            _add("supply-zone-retest", "SHORT", zl,
                 zl, zh, "Possible sell setup if price returns to fresh supply and shows rejection.", zh + atr_buf)

        # Sort nearest first and de-duplicate similar triggers.
        out, seen = [], set()
        for lv in sorted(levels, key=lambda x: abs(x["distance_pct_from_now"])):
            key = (lv["direction"], round(lv["trigger_price"], 6), lv["kind"])
            if key in seen:
                continue
            seen.add(key); out.append(lv)
        return out[:2]
    except Exception as e:
        return [{"kind": "watch-level-error", "message": str(e)[:200]}]

# Activate smart-SL context, then build BOTH sides so user always sees a plan.
set_smart_sl_context(df=df, liq_clusters=liq_clusters, sl_nn=sl_nn,
                      aggressiveness=CFG.get("smart_sl_aggressiveness", "balanced"),
                      enabled=True)
try:
    setup_long = build_setup("LONG", price, sr, demand, supply, atr_val)
    setup_short = build_setup("SHORT", price, sr, demand, supply, atr_val)
finally:
    clear_smart_sl_context()

global_model_vote = _global_direction_vote()
candidate_long = _candidate("LONG", setup_long, df["open_time"].iloc[-1] if "open_time" in df.columns else None)
candidate_short = _candidate("SHORT", setup_short, df["open_time"].iloc[-1] if "open_time" in df.columns else None)
setup_candidates = {"LONG": candidate_long, "SHORT": candidate_short}

# Precision Arbiter: choose one side using ALL models + committee + setup quality.
# This avoids weak 24-vs-22 majority trades and avoids blindly following only committee probability.
def _arbiter_rank(c: dict) -> float:
    direction_i = c.get("direction")
    gv = global_model_vote or {}
    vote_share = _vote_share_for(direction_i)
    same_as_majority = 1.0 if direction_i == gv.get("direction") else 0.0
    committee_same = 1.0 if direction_i == gv.get("committee_direction") else 0.0
    rank = float(c.get("entry_precision_score", 0))
    rank += vote_share * 18.0
    rank += max(0.0, float(c.get("edge", 0))) * 50.0
    rank += same_as_majority * (8.0 if gv.get("majority_strong") else 1.0)
    rank += committee_same * (7.0 if gv.get("committee_strong") else 2.0)
    # If direction conflicts with a strong committee AND majority is weak, penalize heavily.
    if gv.get("committee_strong") and not gv.get("majority_strong") and not committee_same:
        rank -= 20.0
    return rank
_candidates_sorted = sorted([candidate_long, candidate_short], key=_arbiter_rank, reverse=True)
chosen_candidate = _candidates_sorted[0]
other_candidate = _candidates_sorted[1]
direction = chosen_candidate["direction"]
setup = chosen_candidate["setup"]
committee = cm_long if direction == "LONG" else cm_short
confidence = chosen_candidate["confidence"]
_guard_eval = chosen_candidate["guard"]

tp_sl_prob = calculate_tp_sl_probability(df, setup, _train_cutoff)
recent_setup_alerts = _scan_recent_setups(SETUP_SCAN_BARS)
potential_setup_levels = _potential_setup_levels()

print(f"\n  {'='*56}")
_g = chosen_candidate.get("geometry", {})
_vs = chosen_candidate.get("model_vote_summary", {})
print(f"  BEST SETUP: {chosen_candidate['direction']} · {chosen_candidate['status']} · "
      f"setup_score={chosen_candidate['setup_score']:.1f} precision={chosen_candidate.get('entry_precision_score',0):.1f} grade={chosen_candidate['grade']}")
print(f"    {global_model_vote.get('summary', 'ALL-MODEL MAJORITY unavailable')} · "
      f"committee={global_model_vote.get('committee_direction')} edge={global_model_vote.get('committee_edge',0):.1%}")
print(f"    selected committee win-prob={chosen_candidate['probability']:.1%} · "
      f"baseline={chosen_candidate.get('baseline_probability',0.5):.1%} · "
      f"live edge over baseline={chosen_candidate.get('live_edge_over_baseline',0):+.1%}")
print(f"    committee edge={chosen_candidate['edge']:.1%} · same-side agreement={chosen_candidate['model_agreement']:.1%}")
print(f"    elite thresholds: precision≥{HP_MIN_PRECISION_SCORE:.0f}, prob≥{HP_MIN_PROB:.0%}, "
      f"edge≥{HP_MIN_EDGE:.0%}, agreement≥{HP_MIN_AGREE:.0%}, risk≤{HP_MAX_RISK_PCT:.1f}%")
print(f"    selected-side breakdown: {_vs.get('summary', 'model summary unavailable')}")
_sim = chosen_candidate.get("current_market_similarity", {}) or {}
if _sim.get("available"):
    print(f"    market similarity: score={float(_sim.get('similarity_score',0)):.2f} · closer_to={_sim.get('closer_to')} · winner_dist={_sim.get('winner_distance')} loser_dist={_sim.get('loser_distance')}")
else:
    print(f"    market similarity: unavailable ({_sim.get('reason','no profile')})")
_an = chosen_candidate.get("current_analog_pattern", {}) or {}
if _an.get("available"):
    print(f"    analog pattern check: k={_an.get('k')} analog_WR={float(_an.get('analog_win_rate',0)):.1%} · ref_rows={_an.get('reference_rows')} · rows_after_filters={_an.get('rows_after_filters')} · metric={_an.get('metric')} · recency={_an.get('recency_weighted')} · dist={_an.get('nearest_mean_distance')}")
else:
    print(f"    analog pattern check: unavailable ({_an.get('reason','no reference')})")
_drift = chosen_candidate.get("current_feature_drift", {}) or {}
if _drift.get("available"):
    print(f"    feature drift: level={_drift.get('level')} PSI_mean={float(_drift.get('psi_mean',0)):.3f} PSI_max={float(_drift.get('psi_max',0)):.3f} drifted_features={_drift.get('features_drifted')}")
else:
    print(f"    feature drift: unavailable ({_drift.get('reason','not computed')})")
print(f"    entry=${_g.get('entry',0):.6f} sl=${_g.get('sl',0):.6f} "
      f"tp1=${_g.get('tp1',0):.6f} RR={_g.get('rr',0):.2f} risk={_g.get('risk_pct',0):.2f}%")
if chosen_candidate["warnings"]:
    print(f"    NO TRADE / WARNINGS: {'; '.join(chosen_candidate['warnings'][:6])}")
else:
    print(f"    🎉 CONGRATULATIONS — clean {chosen_candidate['direction']} setup found now")
print(f"  DISPLAY SETUP: {direction} · {chosen_candidate['action_text']}")
if recent_setup_alerts:
    print(f"  Recent setup scanner: {len(recent_setup_alerts)} setup(s) found in last {SETUP_SCAN_BARS} bars")
    for a in recent_setup_alerts[:2]:
        print(f"    {a.get('message')} · status={a.get('status')}")
else:
    print(f"  Recent setup scanner: no high-precision setup found in last {SETUP_SCAN_BARS} bars")
if chosen_candidate.get("status") != "TRADE_NOW":
    if potential_setup_levels:
        print("  Current clean setup: NONE — only 2 non-signal watch areas:")
        for lv in potential_setup_levels[:2]:
            print(f"    {lv.get('message', '')} · reason: {lv.get('reason','')}")
    else:
        print("  Current clean setup: NONE — no reliable future watch levels found")
print(f"  {'='*56}\n", flush=True)

# Monte Carlo (instant — uses cached backtest or synthesized)
monte_carlo = {"available": False}
try:
    bt = STORE.get_json(f"backtest_{rid}") or {}
    trades = bt.get("trades") or (bt.get("overall") or {}).get("trades") or []
    rs = None
    if trades and len(trades) > 30:
        rs = np.array([t.get("R", 0.0) for t in trades if isinstance(t, dict)])
        src_str = f"{len(rs)} historical backtest trades"
    else:
        wp = float(committee.get("stack_bull", 0.55) or 0.55)
        rr = float(setup.get("rr1", 2.5) or 2.5)
        rng = np.random.default_rng(seed=42)
        wins = rng.random(200) < wp
        rs = np.where(wins, rr, -1.0).astype(np.float64)
        src_str = f"synthetic ({200} trades · win_prob={wp:.2%} · R:R={rr})"
    if rs is not None and len(rs) > 30:
        try:
            import _engine
            mc = _engine.monte_carlo_robustness(rs, n_sims=2000, n_trades=100)
            monte_carlo = {"available": True, **(mc if isinstance(mc, dict) else {}),
                           "source": ("backtest" if (trades and len(trades) > 30)
                                       else "synthetic")}
            print(f"  ✓ Monte Carlo: {src_str}", flush=True)
        except Exception as e:
            print(f"  {YELLOW}MC compute skipped: {e}{RESET}", flush=True)
except Exception as e:
    print(f"  {YELLOW}MC skipped: {e}{RESET}", flush=True)

# Position sizing
position_sizing = {"available": False}
try:
    import _engine
    wp = float(committee.get("stack_bull", 0.55) or 0.55)
    rr = float(setup.get("rr1", 2.5) or 2.5)
    sz = _engine.calc_position_size(wp, rr, account_equity=10000.0,
                                     max_risk_pct=1.0)
    if sz is not None:
        position_sizing = ({"available": True, **sz} if isinstance(sz, dict)
                            else {"available": True, "size_usd": float(sz)})
        print(f"  ✓ position sizing computed", flush=True)
except Exception as e:
    print(f"  {YELLOW}sizing skipped: {e}{RESET}", flush=True)

print(f"  ✓ setup built in {time.time()-t_step:.1f}s\n", flush=True)

# Inject confidence into ctx payload for dashboard



# ════════════════════════════════════════════════════════════════════
# 5. Assemble ctx + decision, push everywhere, embed HTML
# ════════════════════════════════════════════════════════════════════
print(f"[5/5] Push to backends + embed HTML …", flush=True)
t_step = time.time()
ctx = {
    "symbol": SYMBOL, "name": PAIR["name"], "tf_label": TF_LABEL,
    "price": price, "n_total": len(df), "trade_window": _tw,
    "train_cutoff": _train_cutoff,
    "newest": str(df["open_time"].iloc[-1]),
    "oldest": str(df["open_time"].iloc[0]),
    "nlp": nlp, "deriv": deriv, "direction": direction,
    "setup": setup, "tp_sl_prob": tp_sl_prob,
    "committee": committee, "cm_long": cm_long, "cm_short": cm_short,
    "confidence": confidence,
    "true_fast_inference": true_fast_info,
    "bundle_fast_inference": bundle_fast_info,
    "setup_candidate": chosen_candidate,
    "chosen_candidate": chosen_candidate,
    "all_model_majority": global_model_vote,
    "recent_setup_alerts": recent_setup_alerts,
    "potential_setup_levels": potential_setup_levels,
    "setup_watch_config": {
        "min_score": HP_MIN_SCORE, "min_prob": HP_MIN_PROB, "min_edge": HP_MIN_EDGE,
        "min_model_agreement": HP_MIN_AGREE, "min_rr": HP_MIN_RR,
        "max_risk_pct": HP_MAX_RISK_PCT, "entry_precision_score": HP_MIN_PRECISION_SCORE,
        "watch_score": HP_WATCH_SCORE, "hard_block_score": HP_HARD_BLOCK_SCORE,
        "watch_precision": HP_WATCH_PRECISION_SCORE, "hard_block_precision": HP_HARD_BLOCK_PRECISION_SCORE,
        "min_majority_share": HP_MIN_MAJORITY_SHARE, "min_majority_edge": HP_MIN_MAJORITY_EDGE,
        "require_backtest": HP_REQUIRE_BACKTEST, "min_backtest_trades": HP_MIN_BACKTEST_TRADES,
        "min_backtest_expectancy_R": HP_MIN_BACKTEST_EXP_R,
        "require_htf_alignment": HP_REQUIRE_HTF_ALIGN,
        "min_live_edge_over_baseline": HP_MIN_LIVE_EDGE_OVER_BASELINE,
        "min_market_similarity": HP_MIN_MARKET_SIMILARITY,
        "require_winner_similarity": HP_REQUIRE_WINNER_SIMILARITY,
        "min_analog_win_rate": HP_MIN_ANALOG_WIN_RATE,
        "drift_psi_block": HP_DRIFT_PSI_BLOCK,
        "drift_psi_extreme": HP_DRIFT_PSI_EXTREME,
        "scan_bars": SETUP_SCAN_BARS,
    },
    "confidence_score": confidence["score"],
    "confidence_grade": confidence["grade"],
    "trade_allowed": _guard_eval["allow_trade"],
    "guard_checks": _guard_eval["checks"],
    "tb_models": {
        "available": True,
        "long_win_prob": p_l, "short_win_prob": p_s,
        "historical_long_winrate":  cm_long.get("baseline_win_rate", 0.5),
        "historical_short_winrate": cm_short.get("baseline_win_rate", 0.5),
    },
    "regime": regime_info.get("regime"), "regime_info": regime_info,
    "regime_profile": regime_profile,
    "data_validation": data_validation,
    "monte_carlo":     monte_carlo,
    "position_sizing": position_sizing,
    "mtf":      [ltf, h1, h4],
    "mtf_dict": {"ltf": ltf, "h1": h1, "h4": h4},
    "patterns": patterns,
    "order_blocks": {"bull": bull_obs, "bear": bear_obs},
    "supply_zones": supply, "demand_zones": demand, "fvgs": fvgs,
    "sr_levels": sr, "bos": bos_events, "fib_lvls": fib_lvls,
    "hunting": hunting, "advanced_features": advanced_feats,
    "algo_forecast": algo_forecast_next_n(df, n=10, atr_value=atr_val),
    "pred_next":     predict_next_candle(df, nlp["score"], _train_cutoff),
    "elapsed": 0.0,
    "backtest_results": {
        "available": bool(STORE.get_json(f"backtest_{rid}")),
        **(STORE.get_json(f"backtest_{rid}") or {}),
    },
}

# Chart payload (last 300 bars + 20-bar forecast)
try:
    _tail = df.tail(300).copy()
    _tail["t"] = (_tail["open_time"].astype("int64") // 10**9).astype(int) \
                  if "open_time" in _tail.columns \
                  else list(range(len(_tail)))
    ctx["candles_tail"] = [
        {"time": int(r.t), "open": float(r.open), "high": float(r.high),
          "low": float(r.low), "close": float(r.close)}
        for r in _tail.itertuples()
    ]
except Exception as _e:
    ctx["candles_tail"] = []
try:
    pred20_raw = predict_next_20_candles(df, nlp["score"], _train_cutoff)
    pred20_rows = []

    # V11.3: _engine.predict_next_20_candles returns a dict:
    #   {"predictions": DataFrame|list, "total_move_pct": ...}
    # Older analyze.py expected a plain list, so pred_next_20 became empty and
    # Small Mode was "unavailable" almost every time. Normalize both formats.
    if isinstance(pred20_raw, dict):
        _pred_obj = pred20_raw.get("predictions", [])
        try:
            if hasattr(_pred_obj, "to_dict"):
                pred20_rows = _pred_obj.to_dict("records")
            elif isinstance(_pred_obj, list):
                pred20_rows = _pred_obj
        except Exception:
            pred20_rows = []
        ctx["pred_next_20_meta"] = {
            "source": "predict_next_20_candles",
            "total_move_pct": float(pred20_raw.get("total_move_pct", 0.0) or 0.0),
            "raw_format": "dict",
        }
    elif isinstance(pred20_raw, list):
        pred20_rows = pred20_raw
        ctx["pred_next_20_meta"] = {"source": "predict_next_20_candles", "raw_format": "list"}
    else:
        pred20_rows = []
        ctx["pred_next_20_meta"] = {"source": "predict_next_20_candles", "raw_format": type(pred20_raw).__name__}

    if ctx["candles_tail"] and pred20_rows:
        last_t  = ctx["candles_tail"][-1]["time"]
        tf_secs = {"1m":60,"3m":180,"5m":300,"15m":900,"30m":1800,
                   "1h":3600,"4h":14400,"1d":86400}.get(TF_LABEL, 3600)
        ctx["pred_next_20"] = [
            {"time": int(last_t + tf_secs*(i+1)),
              "open":  float((p or {}).get("open",  (p or {}).get("close", price))),
              "high":  float((p or {}).get("high",  (p or {}).get("close", price))),
              "low":   float((p or {}).get("low",   (p or {}).get("close", price))),
              "close": float((p or {}).get("close", price))}
            for i, p in enumerate(pred20_rows[:20])
        ]
    else:
        ctx["pred_next_20"] = []
        ctx.setdefault("pred_next_20_meta", {})["empty_reason"] = "no normalized prediction rows or no chart candles"
except Exception as _p20_e:
    ctx["pred_next_20"] = []
    ctx["pred_next_20_meta"] = {"source": "predict_next_20_candles", "error": str(_p20_e)[:200]}


# V10.4 Small Mode: next 3–4 candle micro-path forecast inside the setup.
def _build_small_mode_forecast():
    try:
        preds = ctx.get("pred_next_20") or []
        cur = float(price)
        source = "pred_next_20"
        if not preds:
            # V11.3 fallback: still build Small Mode from the algo forecast if
            # the ML 20-candle forecaster is unavailable. This keeps the tab
            # useful, but labels the source honestly.
            _af_preds = (ctx.get("algo_forecast") or {}).get("predictions") or []
            if _af_preds:
                preds = _af_preds[:4]
                source = "algo_forecast_fallback"
            else:
                return {"available": False, "reason": "no pred_next_20 forecast and no algo forecast fallback",
                        "pred_next_20_meta": ctx.get("pred_next_20_meta", {})}
        first = preds[:4]
        steps = []
        prev = cur
        for i, p in enumerate(first, 1):
            close_i = float(p.get("close", prev))
            high_i = float(p.get("high", close_i))
            low_i = float(p.get("low", close_i))
            pct_from_now = (close_i - cur) / cur * 100.0 if cur else 0.0
            pct_step = (close_i - prev) / prev * 100.0 if prev else 0.0
            steps.append({
                "candle": i,
                "close": round(close_i, 8),
                "high": round(high_i, 8),
                "low": round(low_i, 8),
                "pct_from_now": round(pct_from_now, 4),
                "pct_from_prev": round(pct_step, 4),
                "direction": "UP" if pct_step > 0.03 else "DOWN" if pct_step < -0.03 else "FLAT",
            })
            prev = close_i
        final_pct = steps[-1]["pct_from_now"] if steps else 0.0
        min_low = min([x["low"] for x in steps], default=cur)
        max_high = max([x["high"] for x in steps], default=cur)
        dip_pct = (min_low - cur) / cur * 100.0 if cur else 0.0
        pop_pct = (max_high - cur) / cur * 100.0 if cur else 0.0
        dirs = [x["direction"] for x in steps]
        if final_pct > 0.10 and dip_pct < -0.05:
            path = "PULLBACK_THEN_UP"
            text = f"Small mode: possible small pullback ({dip_pct:+.2f}%) before upside attempt ({final_pct:+.2f}% by candle 4)."
        elif final_pct < -0.10 and pop_pct > 0.05:
            path = "BOUNCE_THEN_DOWN"
            text = f"Small mode: possible small bounce ({pop_pct:+.2f}%) before downside attempt ({final_pct:+.2f}% by candle 4)."
        elif final_pct > 0.10:
            path = "DIRECT_UP"
            text = f"Small mode: next 3–4 candles lean UP ({final_pct:+.2f}%)."
        elif final_pct < -0.10:
            path = "DIRECT_DOWN"
            text = f"Small mode: next 3–4 candles lean DOWN ({final_pct:+.2f}%)."
        else:
            path = "CHOP_FLAT"
            text = f"Small mode: next 3–4 candles look choppy/flat ({final_pct:+.2f}%)."
        # Agreement with selected setup direction.
        aligns = ((direction == "LONG" and final_pct > 0) or (direction == "SHORT" and final_pct < 0))
        return {
            "available": True,
            "horizon_candles": len(steps),
            "path": path,
            "summary": text,
            "final_pct_from_now": round(final_pct, 4),
            "max_up_pct": round(pop_pct, 4),
            "max_down_pct": round(dip_pct, 4),
            "aligns_with_setup": bool(aligns),
            "steps": steps,
            "source": source,
            "note": "Micro forecast only; not a separate trade signal. Use it to understand possible path to TP/SL.",
            "pred_next_20_meta": ctx.get("pred_next_20_meta", {})
        }
    except Exception as e:
        return {"available": False, "reason": str(e)[:160]}

ctx["small_mode_forecast"] = _build_small_mode_forecast()

# V11.0 Setup-Agnostic Model Outlook: what models think market may do,
# separate from whether the trade setup is valid. This does NOT alter setup logic.
def _build_model_market_outlook():
    try:
        votes = []
        def add_vote(source, model, direction_i, confidence=0.5, note=""):
            direction_i = str(direction_i or "NEUTRAL").upper()
            if direction_i not in ("LONG", "SHORT", "NEUTRAL"):
                direction_i = "NEUTRAL"
            try: confidence = float(confidence)
            except Exception: confidence = 0.5
            confidence = max(0.0, min(1.0, confidence))
            votes.append({"source": source, "model": model, "direction": direction_i,
                          "confidence": round(confidence, 4), "note": note})

        # Direction-specific committees converted into market direction votes.
        # LONG committee pred=1 -> market up/LONG; SHORT committee pred=1 -> market down/SHORT.
        for name, pred in (cm_long.get("preds") or {}).items():
            if name == "stack": continue
            try: pr = int(pred)
            except Exception: continue
            conf = float((cm_long.get("probs") or {}).get(name, 0.5) or 0.5)
            add_vote("LONG_committee", name, "LONG" if pr == 1 else "SHORT", conf,
                     "LONG model says setup wins" if pr == 1 else "LONG model rejects/upside weak")
        for name, pred in (cm_short.get("preds") or {}).items():
            if name == "stack": continue
            try: pr = int(pred)
            except Exception: continue
            conf = float((cm_short.get("probs") or {}).get(name, 0.5) or 0.5)
            add_vote("SHORT_committee", name, "SHORT" if pr == 1 else "LONG", conf,
                     "SHORT model says setup wins" if pr == 1 else "SHORT model rejects/downside weak")

        # Stack / aggregate votes.
        add_vote("committee_stack", "LONG_stack", "LONG" if p_l >= 0.5 else "SHORT", abs(p_l-0.5)*2, f"P_long={p_l:.2%}")
        add_vote("committee_stack", "SHORT_stack", "SHORT" if p_s >= 0.5 else "LONG", abs(p_s-0.5)*2, f"P_short={p_s:.2%}")
        try:
            gv_dir = (global_model_vote or {}).get("direction")
            add_vote("all_model_majority", "majority", gv_dir, float((global_model_vote or {}).get("chosen_share", 0.5)), (global_model_vote or {}).get("summary", ""))
        except Exception: pass

        # Forecast models independent from setup.
        pn = ctx.get("pred_next") or {}
        raw_dir = str(pn.get("direction", "")).upper()
        if raw_dir:
            add_vote("forecast", "next_candle", "LONG" if ("UP" in raw_dir or "BULL" in raw_dir) else "SHORT" if ("DOWN" in raw_dir or "BEAR" in raw_dir) else "NEUTRAL", float(pn.get("confidence", 50))/100.0, raw_dir)
        af = ctx.get("algo_forecast") or {}
        mv = float(af.get("total_move_pct", 0.0) or 0.0)
        add_vote("forecast", "algo_10_bar", "LONG" if mv > 0.05 else "SHORT" if mv < -0.05 else "NEUTRAL", min(1.0, abs(mv)/2.0), f"10-bar move {mv:+.3f}%")
        sm = ctx.get("small_mode_forecast") or {}
        if sm.get("available"):
            f4 = float(sm.get("final_pct_from_now", 0) or 0)
            add_vote("forecast", "small_mode_4_candle", "LONG" if f4 > 0.03 else "SHORT" if f4 < -0.03 else "NEUTRAL", min(1.0, abs(f4)/1.0), sm.get("summary", ""))

        long_w = sum(v["confidence"] for v in votes if v["direction"] == "LONG")
        short_w = sum(v["confidence"] for v in votes if v["direction"] == "SHORT")
        neutral_w = sum(v["confidence"] for v in votes if v["direction"] == "NEUTRAL")
        total_w = max(1e-9, long_w + short_w + neutral_w)
        if long_w > short_w and long_w/total_w >= 0.40:
            direction_i = "LONG"
        elif short_w > long_w and short_w/total_w >= 0.40:
            direction_i = "SHORT"
        else:
            direction_i = "NEUTRAL"
        edge = abs(long_w - short_w) / max(1e-9, long_w + short_w)

        # Magnitude estimates from forecasts, not setup targets.
        pred20 = ctx.get("pred_next_20") or []
        horizons = {}
        if pred20:
            for h in (1, 4, 10, 20):
                if len(pred20) >= h:
                    c = float(pred20[h-1].get("close", price))
                    horizons[f"{h}_candles"] = {"move_pct": round((c-price)/price*100.0, 4), "price": round(c, 8)}
        return {
            "available": True,
            "note": "Setup-agnostic model outlook. This is NOT a trade setup and does not override risk guards.",
            "overall_direction": direction_i,
            "long_weight": round(long_w, 4),
            "short_weight": round(short_w, 4),
            "neutral_weight": round(neutral_w, 4),
            "direction_edge": round(edge, 4),
            "long_share": round(long_w/total_w, 4),
            "short_share": round(short_w/total_w, 4),
            "neutral_share": round(neutral_w/total_w, 4),
            "horizon_estimates": horizons,
            "votes": votes,
            "summary": f"Models lean {direction_i} (LONG weight {long_w:.2f}, SHORT weight {short_w:.2f}, edge {edge:.1%})"
        }
    except Exception as e:
        return {"available": False, "reason": str(e)[:200]}

ctx["model_market_outlook"] = _build_model_market_outlook()
# V10.9: if no full setup is tradeable, show a separate micro-only view.
# This is not TP/SL setup and never exaggerates move size.
_sm = ctx.get("small_mode_forecast") or {}
_micro_min = float(CFG.get("small_mode_min_abs_move_pct", 0.12))
if chosen_candidate.get("status") in ("TRADE_NOW",):
    ctx["market_mode"] = "FULL_SETUP"
    ctx["small_setup_advice"] = {"available": False, "reason": "full setup available"}
elif _sm.get("available") and abs(float(_sm.get("final_pct_from_now", 0))) >= _micro_min:
    _micro_dir = "LONG" if float(_sm.get("final_pct_from_now", 0)) > 0 else "SHORT"
    ctx["market_mode"] = "SMALL_MODE"
    ctx["small_setup_advice"] = {
        "available": True,
        "direction": _micro_dir,
        "status": "MICRO_ONLY",
        "reason": "No full setup. Models only suggest a small next-3/4-candle move.",
        "max_expected_move_pct": _sm.get("final_pct_from_now"),
        "forecast": _sm,
        "warning": "Micro setup only — not a full TP/SL trade. Use smaller risk or wait for full setup."
    }
else:
    ctx["market_mode"] = "WAIT"
    ctx["small_setup_advice"] = {
        "available": False,
        "status": "WAIT",
        "reason": "No full setup and no meaningful short-term model move. Stay out."
    }

decision = decide_trade(ctx)

# V11.2: harmonize the old confluence decision with the newer precision arbiter.
# The previous dashboard could show MAIN direction from _engine.decide_trade()
# while Setup/Trade Setup showed ctx.setup/chosen_candidate from the precision
# arbiter. That created contradictions like MAIN=LONG but setup=SHORT.
# Keep the legacy decision for audit, but make the public final decision point
# at the exact same selected setup shown in the setup tabs.
try:
    _legacy_decision = dict(decision or {})
    _cc = chosen_candidate or {}
    _cc_status = str(_cc.get("status", "NO_TRADE") or "NO_TRADE").upper()
    _cc_dir = str(_cc.get("direction", direction) or direction).upper()
    _cc_warnings = list(_cc.get("warnings", []) or [])
    _legacy_vetoes = list(_legacy_decision.get("chosen_vetoes", []) or [])
    _merged_vetoes = []
    for _v in _cc_warnings + _legacy_vetoes:
        if _v not in _merged_vetoes:
            _merged_vetoes.append(_v)
    if _cc_status == "TRADE_NOW":
        _verdict = "TAKE_TRADE"
        _verdict_text = f"TAKE {_cc_dir}"
    elif _cc_status == "WATCH":
        _verdict = "WATCH"
        _verdict_text = f"WATCH {_cc_dir} — not a confirmed entry"
    elif _cc_status == "BLOCKED_TOO_LOW":
        _verdict = "NO_TRADE"
        _verdict_text = f"NO TRADE / BLOCKED — best setup {_cc_dir}"
    else:
        _verdict = "NO_TRADE"
        _verdict_text = f"NO TRADE / WAIT — best setup {_cc_dir}"
    decision = {**_legacy_decision,
        "verdict": _verdict,
        "verdict_text": _verdict_text,
        "chosen_direction": _cc_dir,
        "chosen_status": _cc_status,
        "chosen_score": float(_cc.get("setup_score", 0) or 0) / 100.0,
        "chosen_win_prob": float(_cc.get("probability", 0) or 0),
        "chosen_precision_score": float(_cc.get("entry_precision_score", 0) or 0),
        "chosen_grade": _cc.get("grade"),
        "chosen_vetoes": _merged_vetoes,
        "precision_arbiter_direction": _cc_dir,
        "precision_arbiter_status": _cc_status,
        "legacy_decision": _legacy_decision,
        "display_note": "Direction/status harmonized to chosen_candidate so dashboard hero, setup tab, and trade setup tab cannot disagree.",
    }
except Exception as _harm_e:
    print(f"  {YELLOW}decision harmonization skipped: {_harm_e}{RESET}", flush=True)
ctx["decision"] = decision
try: ctx["reasoning"] = build_trade_reasoning(ctx, decision)
except Exception: ctx["reasoning"] = {}

# V9.4 monitoring: local JSON + Prometheus text + optional StatsD.
_runtime_metrics = emit_metrics({
    "trade_allowed": 1 if chosen_candidate.get("status") == "TRADE_NOW" else 0,
    "setup_score": float(chosen_candidate.get("setup_score", 0)),
    "entry_precision_score": float(chosen_candidate.get("entry_precision_score", 0)),
    "committee_probability": float(chosen_candidate.get("probability", 0)),
    "committee_edge": float(chosen_candidate.get("edge", 0)),
    "model_agreement": float(chosen_candidate.get("model_agreement", 0)),
    "all_model_majority_share": float(global_model_vote.get("chosen_share", 0)),
    "all_model_majority_edge": float(global_model_vote.get("edge_share", 0)),
    "data_validation_ok": 1 if data_validation.get("ok") else 0,
    "data_validation_warnings": len(data_validation.get("warnings", [])),
    "regime_atr_pct": float(regime_profile.get("atr_pct", 0)),
    "risk_pct": float((chosen_candidate.get("geometry") or {}).get("risk_pct", 0)),
    "analog_win_rate": float((chosen_candidate.get("current_analog_pattern") or {}).get("analog_win_rate", 0)),
    "feature_drift_psi_mean": float((chosen_candidate.get("current_feature_drift") or {}).get("psi_mean", 0) or 0),
    "feature_drift_psi_max": float((chosen_candidate.get("current_feature_drift") or {}).get("psi_max", 0) or 0),
}, namespace="whitedemon")
ctx["runtime_metrics"] = _runtime_metrics

dashboard = {"ctx": ctx, "decision": decision,
              "saved_at": datetime.datetime.utcnow().isoformat() + "Z"}

# V10.2: log every rejected/watch setup for later research.
_rejected_log = None
if chosen_candidate.get("status") != "TRADE_NOW":
    _rejected_log = log_rejected_trade({
        "symbol": SYMBOL, "tf_label": TF_LABEL, "price": price,
        "direction": direction, "status": chosen_candidate.get("status"),
        "warnings": chosen_candidate.get("warnings", []),
        "setup_score": chosen_candidate.get("setup_score"),
        "entry_precision_score": chosen_candidate.get("entry_precision_score"),
        "probability": chosen_candidate.get("probability"),
        "analog": chosen_candidate.get("current_analog_pattern"),
        "drift": chosen_candidate.get("current_feature_drift"),
        "similarity": chosen_candidate.get("current_market_similarity"),
    })
    ctx["rejected_trade_log"] = _rejected_log

# Push to all backends (chain handles fallback)
STORE.put_json("dashboard_data",        dashboard, message=f"analyze refresh {rid}")
STORE.put_json(f"dashboard_data_{rid}", dashboard, message=f"analyze refresh {rid}")
STORE.put_json(f"final_{rid}", {
    "symbol": SYMBOL, "tf_label": TF_LABEL, "price": price,
    "direction": direction, "verdict": decision.get("verdict"),
    "verdict_text": decision.get("verdict_text"),
    "confluence": decision.get("chosen_score"),
    "win_prob": decision.get("chosen_win_prob"),
    "selected_committee_probability": chosen_candidate.get("probability"),
    "selected_edge": chosen_candidate.get("edge"),
    "all_model_majority": global_model_vote,
    "model_vote_summary": chosen_candidate.get("model_vote_summary"),
    "true_fast_inference": true_fast_info,
    "setup": setup, "tp_sl_prob": tp_sl_prob,
    "market_mode": ctx.get("market_mode"),
    "small_setup_advice": ctx.get("small_setup_advice"),
    "small_mode_forecast": ctx.get("small_mode_forecast"),
    "model_market_outlook": ctx.get("model_market_outlook"),
    "vetoes": decision.get("chosen_vetoes", []),
}, message=f"final {rid}")
STORE.put_json(f"setup_watch_{rid}", {
    "symbol": SYMBOL,
    "tf_label": TF_LABEL,
    "price": price,
    "best_setup": chosen_candidate,
    "all_model_majority": global_model_vote,
    "true_fast_inference": true_fast_info,
    "potential_setup_levels": potential_setup_levels,
    "recent_setup_alerts": recent_setup_alerts,
    "market_mode": ctx.get("market_mode"),
    "small_setup_advice": ctx.get("small_setup_advice"),
    "small_mode_forecast": ctx.get("small_mode_forecast"),
    "model_market_outlook": ctx.get("model_market_outlook"),
    "regime_profile": regime_profile,
    "data_validation": data_validation,
    "saved_at": datetime.datetime.utcnow().isoformat() + "Z",
}, message=f"setup watch {rid}")
STORE.put_json(f"live_metrics_{rid}", _runtime_metrics, message=f"live metrics {rid}")
if _rejected_log:
    STORE.put_json(f"rejected_latest_{rid}", _rejected_log, message=f"rejected latest {rid}")

# Local JSON backup
try:
    with open("dashboard_data.json", "w") as f:
        json.dump(dashboard, f, default=str, indent=2)
except Exception:
    pass

# Auto-embed into frontend/dashboard.html
try:
    here = os.path.dirname(os.path.abspath(__file__))
    src  = os.path.join(here, "frontend", "dashboard.html")
    if os.path.exists(src):
        html = open(src).read()
        inject = ("<script>window.__EMBED_DASHBOARD_DATA__ = "
                  + json.dumps(dashboard, default=str)
                  + ";</script>")
        if "__EMBED_DASHBOARD_DATA__" in html:
            html = re.sub(r"<script>window\.__EMBED_DASHBOARD_DATA__[\s\S]*?</script>",
                          lambda _m: inject, html)
        else:
            html = html.replace("</head>", inject + "\n</head>")
        with open(src, "w") as f: f.write(html)
        print(f"  ✓ embedded into {src}", flush=True)
        try:
            with open(src, "rb") as f:
                STORE.put_blob(f"dashboard_{rid}.html", f.read(), compress=False)
        except Exception: pass
except Exception as e:
    print(f"  {YELLOW}HTML embed skipped: {e}{RESET}", flush=True)

print(f"  ✓ push done in {time.time()-t_step:.1f}s\n", flush=True)

print(f"{GREEN}{BOLD}✅ ANALYZE DONE  ·  MODE = {ctx.get('market_mode')}  ·  "
      f"SETUP = {direction} / {chosen_candidate.get('status')}  ·  "
      f"precision={chosen_candidate.get('entry_precision_score',0):.1f}  "
      f"score={chosen_candidate.get('setup_score',0):.1f}  "
      f"prob={chosen_candidate.get('probability',0)*100:.1f}%  ·  "
      f"${price:.4f}{RESET}", flush=True)
print(f"  Setup: entry=${setup.get('entry',0):.6g}  "
      f"sl=${setup.get('sl',0):.6g}  tp1=${setup.get('tp1',0):.6g} "
      f"(R={setup.get('rr1',0):.2f})", flush=True)
try:
    _sm = ctx.get("small_mode_forecast") or {}
    if _sm.get("available"):
        print(f"  {_sm.get('summary')}  aligns_with_setup={_sm.get('aligns_with_setup')}", flush=True)
    else:
        print(f"  Small mode unavailable: {_sm.get('reason','unknown')}", flush=True)
    _adv = ctx.get("small_setup_advice") or {}
    if _adv.get("available"):
        print(f"  SMALL MODE ONLY: {_adv.get('direction')} · expected move {_adv.get('max_expected_move_pct')}% · {_adv.get('warning')}", flush=True)
    elif ctx.get("market_mode") == "WAIT":
        print(f"  WAIT MODE: {_adv.get('reason','No reliable model move')}", flush=True)
except Exception: pass
print(f"  Open  frontend/dashboard.html  in your browser (embedded data ready)", flush=True)
print(f"  Total elapsed: {time.time() - (time.time() - 0):.1f}s — fast mode complete\n",
      flush=True)


def main():
    return 0


if __name__ == "__main__":
    pass
