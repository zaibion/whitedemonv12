# WhiteDemon V8.7 — Potential Setup Price Alerts

## Added
When there is no clean current setup, analyze now prints watch prices where a setup MAY form.

Example output:

```text
Current clean setup: NONE — watch possible setup prices below:
Watch LONG: possible pullback/support-hold setup near $...
Watch LONG: possible breakout/resistance-close setup near $...
Watch SHORT: possible rejection/resistance-hold setup near $...
Watch SHORT: possible breakdown/support-close setup near $...
```

## How it works
The system calculates possible future setup zones from:
- nearest support below price
- nearest resistance above price
- fresh demand zones
- fresh supply zones
- ATR buffer

It creates watch levels for:
- LONG pullback/support hold
- LONG breakout above resistance
- SHORT rejection at resistance/supply
- SHORT breakdown below support

## Important
These are NOT trade signals by themselves. They are watch prices. The user should re-run analyze or watch confirmation near those levels. If high-precision checks pass, the app will show:

```text
🎉 CONGRATULATIONS — setup found now
```

## Payload fields added
- `potential_setup_levels`
- already existing `setup_candidates`
- already existing `recent_setup_alerts`
