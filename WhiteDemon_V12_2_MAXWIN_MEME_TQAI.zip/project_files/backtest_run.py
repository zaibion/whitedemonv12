"""
backtest_run.py — Deep walk-forward backtest.

Reports for EVERY year + EVERY combination of:
  • Gross  (no fees, no slippage)
  • Net   (with 0.30% RT fees)
  • Net + slippage (low: 0.05%, medium: 0.15%, high: 0.30%)

Also computes monthly + yearly breakdowns + Sharpe + Sortino + Calmar +
profit factor + max drawdown.

Saves results to:
  • backtest_<SYMBOL>_<TF>.json   (local copy)
  • storage backend (Firebase or GitHub) for the dashboard to display

USAGE
  python backtest_run.py
  python backtest_run.py --pair SOL-USD --tf 30m
  python backtest_run.py --years 3            # only test last 3 years
  python backtest_run.py --target 100000      # cap data size
"""
from __future__ import annotations
import os, sys, time, json, argparse, datetime, traceback
import numpy as np
import pandas as pd

# ── argparse FIRST (before core imports inject argv) ────────────────────
ap = argparse.ArgumentParser()
ap.add_argument("--pair",    default=None)
ap.add_argument("--tf",      default=None)
ap.add_argument("--target",  type=int, default=200_000)
ap.add_argument("--step",    type=int, default=4)
ap.add_argument("--horizon", type=int, default=192)
ap.add_argument("--fee-r",   type=float, default=0.30)
ap.add_argument("--years",   type=int, default=None,
                help="only test last N years (None = all available)")
ap.add_argument("--no-push", action="store_true")
ap.add_argument("--use-cached-models", action="store_true",
                help="Skip per-fold model retraining. Reuse cached models from "
                     "the main training run (massive speedup).")
ap.add_argument("--only-classical", default="",
                help="Comma list of classical models to use (rest skipped). "
                     "e.g. 'xgb,lgb,rf'. Implies --use-cached-models.")
ap.add_argument("--bbb-step", default=None,
                help="bit-by-bit step id (step1..step10) for multi-cell backtest")
ap.add_argument("--candles", type=int, default=None,
                help="explicit number of recent candles (used by Menu 5 specific-model)")
ap.add_argument("--only-dl", default="",
                help="Comma list of DL models to use (rest skipped). "
                     "e.g. 'lstm,gru,tcn'. Implies --use-cached-models.")
args = ap.parse_args()
# Filtering implies using cached models
if args.only_classical or args.only_dl:
    args.use_cached_models = True
# Candles override → translate to a small "years" approximation for short tests
if args.candles and not args.years:
    # rough mapping: candles/bars-per-year for common tfs
    args.target = max(args.candles + 5000, args.target)

# Bit-by-bit step handling — each step trains a specific subset, then exits
if args.bbb_step:
    import subprocess as _sp
    step = args.bbb_step.lower()
    print(f"\n[BBB] Running bit-by-bit step: {step}")
    if step in ("step1_classical_long",):
        _sp.call(["python", "train_specific.py", "--missing",
                  "--direction", "LONG",
                  "--classical", "lr,knn,rf,et,xgb,lgb,cat,hgb,mlp"])
        sys.exit(0)
    if step in ("step2_classical_short",):
        _sp.call(["python", "train_specific.py", "--missing",
                  "--direction", "SHORT",
                  "--classical", "lr,knn,rf,et,xgb,lgb,cat,hgb,mlp"])
        sys.exit(0)
    if step in ("step3_dl_long",):
        _sp.call(["python", "train_specific.py", "--missing", "--direction", "LONG",
                  "--dl", "lstm,bilstm,gru,tcn,wavenet,transformer,cnn1d,nbeats,mamba,patchtst,itransformer,frets,tft,mamba_pdf"])
        sys.exit(0)
    if step in ("step4_dl_short",):
        _sp.call(["python", "train_specific.py", "--missing", "--direction", "SHORT",
                  "--dl", "lstm,bilstm,gru,tcn,wavenet,transformer,cnn1d,nbeats,mamba,patchtst,itransformer,frets,tft,mamba_pdf"])
        sys.exit(0)
    if step in ("step5_neural", "step6_extras"):
        # both run the full pipeline (engine integrates them); will skip stages already done
        _sp.call(["python", "-c", "from train_pipeline import train_with_checkpoint; train_with_checkpoint(force=False)"])
        sys.exit(0)
    if step in ("step7_walkforward_a", "step8_walkforward_b", "step9_walkforward_c"):
        # split folds into thirds — limit years
        # if user already trained models, we use cached ones
        args.use_cached_models = True
        # restrict years roughly
        fold_third = {"step7_walkforward_a": (1, 3),
                      "step8_walkforward_b": (4, 6),
                      "step9_walkforward_c": (7, 9)}[step]
        # We set years to total/3; the loop below will run all folds, the
        # filtering for which fold-range to ACTUALLY run is done after fold list.
        args._bbb_fold_range = fold_third
        print(f"[BBB] will run folds {fold_third[0]}..{fold_third[1]} only")
    if step in ("step10_combine",):
        # Combine: reassemble + write the final report
        _sp.call(["python", "train_specific.py", "--reassemble"])
        rid = f"{(args.pair or '').replace('-','_')}_{args.tf or ''}"
        from core.storage import STORE as _S
        print("[BBB] step10 — combine complete; report saved to storage as backtest_<rid>.")
        sys.exit(0)

# Now import core
from core.config import CFG, SYMBOL as DEFAULT_SYM, TF_LABEL as DEFAULT_TF, \
                          PAIR, TF, apply_selection, PAIRS, TIMEFRAMES
from core.colors import RESET, BOLD, CYAN, GREEN, RED, YELLOW, ORANGE, GREY
from core.storage import STORE
from core.data_validation import validate_ohlcv, validation_text

import _engine
from data.fetcher_ccxt    import fetch_ohlcv_stitched_v23
from data.fetcher_sentiment import FinBERTSentiment, fetch_sentiment
from indicators.basic     import calc_atr, calc_rsi
from indicators.structure import zigzag, sr_from_zigzag, sr_from_rolling_pivots, \
                                   sr_from_volume_profile, merge_all_sr
from indicators.smc       import find_sd_zones
from ml_models.committee  import run_ml_committee
import threading, time
def _start_hb(label="backtest"):
    stop=threading.Event()
    t0=time.time()
    def beat():
        while not stop.wait(30):
            print(f"  [backtest heartbeat · {label} · {int(time.time()-t0)}s]", flush=True)
    threading.Thread(target=beat, daemon=True).start()
    return stop
from strategy.setup_builder import build_setup
from strategy.confluence    import STRICT_MIN_WIN_PROB
from core.engine_patches    import (engine_context, apply_engine_patches,
                                      set_model_filter, clear_model_filter)
from core                   import per_model_cache as pmc

# Install per-model save/resume patches on the engine at import time
apply_engine_patches()

# Override pair/tf if CLI specified
SYMBOL = args.pair or DEFAULT_SYM
TF_LABEL = args.tf or DEFAULT_TF
if SYMBOL != DEFAULT_SYM or TF_LABEL != DEFAULT_TF:
    _p = next((p for p in PAIRS if p["symbol"] == SYMBOL), None)
    _t = next((t for t in TIMEFRAMES if t["label"] == TF_LABEL), None)
    if _p and _t:
        apply_selection(_p, _t)
    else:
        print(f"❌ Unknown pair/tf: {SYMBOL} @ {TF_LABEL}"); sys.exit(1)

print(f"\n{BOLD}{CYAN}{'═'*72}")
print(f"  📊 DEEP WALK-FORWARD BACKTEST  ·  {SYMBOL} @ {TF_LABEL}")
print(f"{'═'*72}{RESET}\n")
print(f"  target candles : {args.target:,}")
print(f"  step           : every {args.step} bars")
print(f"  horizon        : {args.horizon} bars")
print(f"  base fee       : {args.fee_r}R per trade")
print(f"  years to test  : {args.years or 'all available'}\n")


# ── 1. Fetch maximum candles ────────────────────────────────────────────
print(f"{BOLD}[1/4] Fetching {args.target:,} candles for {SYMBOL} @ {TF_LABEL}…{RESET}")
df, src = fetch_ohlcv_stitched_v23(SYMBOL, TF_LABEL, args.target)
df, data_validation = validate_ohlcv(df, TF_LABEL, repair=True)
print(f"  data validation: {validation_text(data_validation)}")
if len(df) < 10_000 or not data_validation.get("ok", False):
    print(f"❌ Only {len(df):,} candles — need ≥ 10k for backtest. Try a higher TF.")
    sys.exit(1)
df = df.sort_values("open_time").reset_index(drop=True)
df["year"]  = pd.to_datetime(df["open_time"]).dt.year
df["month"] = pd.to_datetime(df["open_time"]).dt.month
df["atr"]   = calc_atr(df)
df["rsi"]   = calc_rsi(df["close"])

print(f"\n  ✓ {len(df):,} candles, {df['open_time'].iloc[0].date()} → "
      f"{df['open_time'].iloc[-1].date()}")
print(f"  bars/year: {dict(df['year'].value_counts().sort_index())}\n")

nlp = fetch_sentiment(FinBERTSentiment())
print(f"  ✓ sentiment loaded: {nlp['sentiment']} ({nlp['score']:+.2f})\n")


# ── 2. Build folds ──────────────────────────────────────────────────────
years = sorted(df["year"].unique())
folds = []
for i in range(1, len(years)):
    tr = years[:i]
    te = years[i]
    n_tr = int(df["year"].isin(tr).sum())
    n_te = int((df["year"] == te).sum())
    if n_tr < 5_000:
        continue
    folds.append({"fold": len(folds)+1, "train_years": tr, "test_year": te,
                   "n_train": n_tr, "n_test": n_te})

if args.years and len(folds) > args.years:
    folds = folds[-args.years:]
    print(f"  Limited to last {args.years} folds.\n")

# Bit-by-bit: limit to a specific fold range (third of all folds)
_bbb_range = getattr(args, "_bbb_fold_range", None)
if _bbb_range:
    a, b = _bbb_range
    # treat a,b as inclusive 1-based indices into folds
    a_i = max(0, a - 1)
    b_i = min(len(folds), b)
    folds = folds[a_i:b_i]
    print(f"  [BBB] running folds {a}..{b} only ({len(folds)} folds)\n")

if not folds:
    print(f"❌ Not enough data for any fold.")
    sys.exit(1)
print(f"{BOLD}[2/4] Will run {len(folds)} folds:{RESET}")
for f in folds:
    print(f"  Fold {f['fold']}: train {f['train_years']} ({f['n_train']:,}) → "
          f"test {f['test_year']} ({f['n_test']:,})")
print()


# ── 3. Trade simulation helper ──────────────────────────────────────────
def _simulate(direction, entry, sl, tp1, future):
    if direction == "LONG":
        sl_d = entry - sl; tp_d = tp1 - entry
    else:
        sl_d = sl - entry; tp_d = entry - tp1
    if sl_d <= 0 or tp_d <= 0:
        return "INVALID", 0.0, 0
    rr = tp_d / sl_d
    for j, (_, bar) in enumerate(future.iterrows()):
        if direction == "LONG":
            if bar["low"]  <= sl:  return "SL_HIT", -1.0, j
            if bar["high"] >= tp1: return "TP_HIT", float(rr), j
        else:
            if bar["high"] >= sl:  return "SL_HIT", -1.0, j
            if bar["low"]  <= tp1: return "TP_HIT", float(rr), j
    return "TIMEOUT", 0.0, len(future)


# ── 4. Run every fold + report deep metrics ─────────────────────────────
print(f"{BOLD}[3/4] Running folds…{RESET}")

# ── RESUME logic ────────────────────────────────────────────────────────
from core import backtest_checkpoint as bt_ck
prev = bt_ck.load(SYMBOL, TF_LABEL)
fold_results: list = []
all_trades_global: list = []
completed_ids: list = []

if prev and not prev.get("deleted") and prev.get("completed_fold_ids"):
    done_ids = prev["completed_fold_ids"]
    n_done   = len(done_ids)
    n_total  = prev.get("total_folds", len(folds))
    print(f"\n{BOLD}{YELLOW}━━ Previous backtest checkpoint found ━━{RESET}")
    print(f"   {SYMBOL} @ {TF_LABEL}")
    print(f"   Progress  : {n_done}/{n_total} folds done")
    print(f"   Last save : {(prev.get('last_update') or '—')[:16]}")
    print(f"   Trades so far : {len(prev.get('all_trades', []))}")
    print(f"\n   [r] RESUME — skip already-done folds, continue from fold {(max(done_ids)+1) if done_ids else 1}")
    print(f"   [n] NEW    — wipe progress and restart from fold 1")
    print(f"   [0] cancel")
    ans = input(f"\n{BOLD}Pick [r/n/0]: {RESET}").strip().lower()
    if ans == "0":
        print("  cancelled."); sys.exit(0)
    if ans in ("r", "resume"):
        fold_results      = prev.get("fold_results", [])
        all_trades_global = prev.get("all_trades", [])
        completed_ids     = list(done_ids)
        print(f"\n{GREEN}  ✓ Resuming — {len(completed_ids)} folds already done, "
              f"{len(folds) - len(completed_ids)} to go.{RESET}\n")
    else:
        bt_ck.reset(SYMBOL, TF_LABEL)
        print(f"\n{GREEN}  ✓ Starting fresh.{RESET}\n")

for fold in folds:
    # Skip already-completed folds on resume
    if fold["fold"] in completed_ids:
        print(f"  ⏩ Fold {fold['fold']} already done — skipped (resume)")
        continue
    print(f"\n{BOLD}{'─'*72}\n  ▶ FOLD {fold['fold']}: train {fold['train_years']} → "
          f"test {fold['test_year']}\n{'─'*72}{RESET}")
    t0 = time.time()

    tr_mask = df["year"].isin(fold["train_years"])
    te_mask = df["year"] == fold["test_year"]
    train_df = df[tr_mask].reset_index(drop=True)
    test_df  = df[te_mask].reset_index(drop=True)
    fake_df = pd.concat([train_df, test_df.head(CFG["trade_window"])],
                          ignore_index=True)
    train_cutoff = len(train_df)

    # ── Determine cache key based on mode ──
    if args.use_cached_models:
        # Reuse models from main training run (skip per-fold training)
        _bt_count = args.target
        for _try in (args.target, 200_000, 100_000, 60_000, 30_000, 10_000):
            _dL = pmc.list_done(SYMBOL, TF_LABEL, "LONG", _try)
            if _dL["classical"] or _dL["dl"]:
                _bt_count = _try
                break
        print(f"  [bt] FAST MODE — reusing cached models (trained on {_bt_count:,} candles)")
    else:
        print(f"  [train] {len(train_df):,} bars → LONG then SHORT committees …")
        # Per-fold cache key (different training data per fold)
        _bt_count = int(len(train_df)) * 10000 + int(fold["fold"])

    try:
        # Show per-model resume state if this fold was partially trained before
        _dL = pmc.list_done(SYMBOL, TF_LABEL, "LONG",  _bt_count)
        _dS = pmc.list_done(SYMBOL, TF_LABEL, "SHORT", _bt_count)
        if _dL["classical"] or _dL["dl"] or _dS["classical"] or _dS["dl"]:
            print(f"  [pmc] fold {fold['fold']} cache — "
                  f"LONG: {len(_dL['classical'])}/9 cls, {len(_dL['dl'])}/14 dl · "
                  f"SHORT: {len(_dS['classical'])}/9 cls, {len(_dS['dl'])}/14 dl")
        # Apply model filter if user wants to backtest specific models only
        _only_cls = [m.strip() for m in args.only_classical.split(",") if m.strip()] or None
        _only_dl  = [m.strip() for m in args.only_dl.split(",")        if m.strip()] or None
        if _only_cls or _only_dl:
            print(f"  [filter] using only — classical={_only_cls or 'all'}  dl={_only_dl or 'all'}")
        # Run LONG first, fully cleanup, then SHORT — prevents OOM on CPU/low RAM
        with engine_context(SYMBOL, TF_LABEL, "LONG", _bt_count):
            if _only_cls or _only_dl:
                set_model_filter(classical=_only_cls, dl=_only_dl)
            try:
                cm_long = run_ml_committee(fake_df, nlp["score"], train_cutoff,
                                             llm_features=None, direction="LONG")
            finally:
                if _only_cls or _only_dl:
                    clear_model_filter()
        import gc as _gc
        try:
            import torch as _torch
            if _torch.cuda.is_available(): _torch.cuda.empty_cache()
        except Exception: pass
        _gc.collect()
        with engine_context(SYMBOL, TF_LABEL, "SHORT", _bt_count):
            if _only_cls or _only_dl:
                set_model_filter(classical=_only_cls, dl=_only_dl)
            try:
                cm_short = run_ml_committee(fake_df, nlp["score"], train_cutoff,
                                             llm_features=None, direction="SHORT")
            finally:
                if _only_cls or _only_dl:
                    clear_model_filter()
    except Exception as e:
        print(f"  ❌ train failed: {e}")
        print("  [error] traceback suppressed — see message above", flush=True)
        fold_results.append({"fold": fold["fold"], "error": str(e),
                              "test_year": fold["test_year"]})
        continue
    print(f"  [train] done in {time.time()-t0:.0f}s  "
          f"P(L)={cm_long['stack_bull']*100:.1f}%  "
          f"P(S)={cm_short['stack_bull']*100:.1f}%")

    # V10.3 / Z.1: point-in-time bundle inference for each historical test bar.
    _bt_bundle_L = _bt_bundle_S = None
    try:
        from core.committee_bundle import load_committee_bundle
        _bt_bundle_L = load_committee_bundle(SYMBOL, TF_LABEL, "LONG", _bt_count)
        _bt_bundle_S = load_committee_bundle(SYMBOL, TF_LABEL, "SHORT", _bt_count)
        if _bt_bundle_L and _bt_bundle_S:
            print("  [bt] point-in-time bundle inference enabled for each test bar")
    except Exception as _e:
        print(f"  [bt] bundle point inference unavailable: {str(_e)[:120]}")

    print(f"  [walk] {len(test_df):,} test bars · step={args.step}")
    trades = []
    last_print = time.time()
    for i in range(0, len(test_df) - args.horizon, args.step):
        bar = test_df.iloc[i]
        price = float(bar["close"])
        abs_idx = int(df.index[df["open_time"] == bar["open_time"]][0])
        sub_df = df.iloc[:abs_idx + 1]
        if len(sub_df) < 300:
            continue
        tdf = sub_df.tail(CFG["trade_window"]).copy().reset_index(drop=True)
        try:
            pivots_zz, _, _ = zigzag(tdf.tail(CFG["zz_lookback"]),
                                       CFG["zz_dev_pct"])
            sr = merge_all_sr(
                sr_from_zigzag(pivots_zz, CFG["sr_tol_pct"]),
                sr_from_rolling_pivots(tdf),
                sr_from_volume_profile(tdf), price, tol_pct=0.3)
            demand, supply = find_sd_zones(tdf)
            atr_val = float(sub_df["atr"].iloc[-1])
        except Exception:
            continue
        cmL_i, cmS_i = cm_long, cm_short
        if _bt_bundle_L and _bt_bundle_S:
            try:
                from core.committee_bundle import infer_committee_bundle
                _reg_i = _engine.detect_market_regime(sub_df).get("regime", "RANGING")
                cmL_i = infer_committee_bundle(_bt_bundle_L, sub_df.copy(), nlp["score"], _reg_i,
                                               sym=SYMBOL, tf=TF_LABEL, count=_bt_count, include_dl=False)
                cmS_i = infer_committee_bundle(_bt_bundle_S, sub_df.copy(), nlp["score"], _reg_i,
                                               sym=SYMBOL, tf=TF_LABEL, count=_bt_count, include_dl=False)
            except Exception:
                cmL_i, cmS_i = cm_long, cm_short
        p_l = float(cmL_i.get("stack_bull",  0.5))
        p_s = float(cmS_i.get("stack_bull", 0.5))
        direction = "LONG" if p_l >= p_s else "SHORT"
        win_prob  = p_l if direction == "LONG" else p_s
        if win_prob < STRICT_MIN_WIN_PROB:
            continue
        # WhiteDemon_V8.2: smart-SL during backtest too (NO liq fetch — too slow per fold)
        try:
            from strategy.setup_builder import set_smart_sl_context, clear_smart_sl_context
            set_smart_sl_context(df=test_df.iloc[:i+1], liq_clusters=[], sl_nn=None,
                                  aggressiveness=CFG.get("smart_sl_aggressiveness","balanced"),
                                  enabled=True)
            try:
                setup = build_setup(direction, price, sr, demand, supply, atr_val)
            finally:
                clear_smart_sl_context()
        except Exception:
            setup = build_setup(direction, price, sr, demand, supply, atr_val)
        if not setup["valid"]:
            continue
        if setup["rr1"] < CFG.get("min_rr_ratio", 2.5):
            continue
        future = test_df.iloc[i+1 : i+1+args.horizon]
        out, r, bars = _simulate(direction, price, setup["sl"],
                                   setup["tp1"], future)
        if out == "INVALID":
            continue
        trade = {
            "time":       str(bar["open_time"]),
            "year":       int(bar["year"]),
            "month":      int(bar["month"]),
            "direction":  direction,
            "entry":      price,
            "sl":         setup["sl"],
            "tp1":        setup["tp1"],
            "rr1":        setup["rr1"],
            "outcome":    out,
            "realized_r": r,
            "bars":       bars,
            "win_prob":   win_prob,
            "model_stack_long": p_l,
            "model_stack_short": p_s,
            "model_votes_long": (cmL_i.get("preds") or {}),
            "model_votes_short": (cmS_i.get("preds") or {}),
            "analog_long": cmL_i.get("current_analog_pattern"),
            "analog_short": cmS_i.get("current_analog_pattern"),
            "feature_drift_long": cmL_i.get("current_feature_drift"),
            "feature_drift_short": cmS_i.get("current_feature_drift"),
        }
        trades.append(trade)
        all_trades_global.append(trade)
        if time.time() - last_print > 30:
            print(f"  [walk] bar {i:>6,}/{len(test_df):,} "
                  f"({i/len(test_df)*100:.0f}%)  trades={len(trades):>4}")
            last_print = time.time()

    # ── Aggregate this fold's metrics across ALL slippage scenarios ────
    if not trades:
        print(f"  [eval] 0 trades — no signals")
        fold_results.append({"fold": fold["fold"], "test_year": fold["test_year"],
                              "n_trades": 0, "rejections": 0})
        continue

    rs = np.array([t["realized_r"] for t in trades])
    wins = rs > 0
    n_trades = len(rs)
    wr = float(wins.mean())

    # Probability calibration diagnostics for final signal probabilities.
    pred_probs = np.array([float(t.get("win_prob", 0.5)) for t in trades], dtype=float)
    calibration = []
    ece = 0.0
    for lo, hi in [(0.50,0.60),(0.60,0.70),(0.70,0.80),(0.80,0.90),(0.90,1.01)]:
        m = (pred_probs >= lo) & (pred_probs < hi)
        if int(m.sum()) >= 3:
            pred_mean = float(pred_probs[m].mean())
            realized = float(wins[m].mean())
            ece += float(m.mean()) * abs(pred_mean - realized)
            calibration.append({"bucket": f"{int(lo*100)}-{int(hi*100)}%",
                                "n": int(m.sum()), "predicted": pred_mean,
                                "realized": realized})
    brier = float(np.mean((pred_probs - wins.astype(float)) ** 2)) if len(pred_probs) else 0.25

    scenarios = {
        "gross_no_fees":    {"fee": 0.00, "slip": 0.00},
        "net_fees_only":    {"fee": args.fee_r, "slip": 0.00},
        "net_fees_slip_low":   {"fee": args.fee_r, "slip": 0.05},
        "net_fees_slip_med":   {"fee": args.fee_r, "slip": 0.15},
        "net_fees_slip_high":  {"fee": args.fee_r, "slip": 0.30},
    }
    scenario_results = {}
    for name, params in scenarios.items():
        cost = params["fee"] + params["slip"]
        rs_adj = rs - cost
        wins_adj = rs_adj > 0
        e = float(rs_adj.mean())
        std = float(rs_adj.std()) if n_trades > 1 else 0.0
        sharpe = float(e/std*np.sqrt(252)) if std > 0 else 0.0
        # Sortino — downside-only std
        downside = rs_adj[rs_adj < 0]
        ddev = float(downside.std()) if len(downside) > 1 else 0.0
        sortino = float(e/ddev*np.sqrt(252)) if ddev > 0 else 0.0
        # Drawdown
        eq = np.cumsum(rs_adj)
        peak = np.maximum.accumulate(eq)
        dd = float((peak - eq).max())
        calmar = float(eq[-1]/dd) if dd > 0 else float("inf") if eq[-1] > 0 else 0.0
        gw = float(rs_adj[rs_adj > 0].sum()) if (rs_adj > 0).any() else 0.0
        gl = float(-rs_adj[rs_adj < 0].sum()) if (rs_adj < 0).any() else 0.0
        pf = float(gw/gl) if gl > 0 else float("inf") if gw > 0 else 0.0
        scenario_results[name] = {
            "expectancy_R":  e,
            "total_R":       float(rs_adj.sum()),
            "sharpe":        sharpe,
            "sortino":       sortino,
            "calmar":        calmar,
            "profit_factor": pf,
            "max_dd_R":      dd,
            "win_rate":      float(wins_adj.mean()),
        }

    # Monthly breakdown
    monthly = {}
    for t in trades:
        key = f"{t['year']}-{t['month']:02d}"
        monthly.setdefault(key, []).append(t["realized_r"])
    monthly_metrics = {
        m: {
            "n_trades": len(rs_m),
            "wr":       float((np.array(rs_m) > 0).mean()),
            "gross_R":  float(sum(rs_m)),
            "net_R":    float(sum(rs_m) - args.fee_r * len(rs_m)),
        } for m, rs_m in monthly.items()
    }

    print(f"\n  [eval] FOLD {fold['fold']} ({fold['test_year']}):")
    print(f"         trades        : {n_trades}")
    print(f"         win rate      : {wr*100:.1f}%")
    for name, m in scenario_results.items():
        print(f"         {name:<22} : E={m['expectancy_R']:+.3f}R · "
              f"PF={m['profit_factor']:.2f} · DD=-{m['max_dd_R']:.1f}R · "
              f"Sharpe={m['sharpe']:.2f}")
    print(f"         elapsed       : {time.time()-t0:.0f}s")

    fold_results.append({
        "fold":          fold["fold"],
        "train_years":   fold["train_years"],
        "test_year":     fold["test_year"],
        "n_trades":      n_trades,
        "wins":          int(wins.sum()),
        "losses":        int((~wins).sum()),
        "win_rate":      wr,
        "scenarios":     scenario_results,
        "monthly":       monthly_metrics,
        "calibration":   calibration,
        "brier_score":   brier,
        "ece":           ece,
        # back-compat aliases
        "gross_expectancy_R":  scenario_results["gross_no_fees"]["expectancy_R"],
        "gross_total_R":       scenario_results["gross_no_fees"]["total_R"],
        "gross_sharpe":        scenario_results["gross_no_fees"]["sharpe"],
        "gross_profit_factor": scenario_results["gross_no_fees"]["profit_factor"],
        "gross_max_dd_R":      scenario_results["gross_no_fees"]["max_dd_R"],
        "net_expectancy_R":    scenario_results["net_fees_only"]["expectancy_R"],
        "net_total_R":         scenario_results["net_fees_only"]["total_R"],
        "net_sharpe":          scenario_results["net_fees_only"]["sharpe"],
        "net_max_dd_R":        scenario_results["net_fees_only"]["max_dd_R"],
        "fee_per_trade_R":     args.fee_r,
        "elapsed_s":           round(time.time()-t0, 1),
    })

    # Save checkpoint AFTER each fold so backtest can resume on crash/disconnect
    completed_ids.append(fold["fold"])
    bt_ck.save(SYMBOL, TF_LABEL,
                completed_fold_ids = completed_ids,
                fold_results       = fold_results,
                all_trades         = all_trades_global,
                total_folds        = len(folds),
                args_dict          = vars(args))
    print(f"  💾 fold {fold['fold']} checkpointed ({len(completed_ids)}/{len(folds)} done)")


# ── 5. Overall summary ─────────────────────────────────────────────────
print(f"\n{BOLD}{'═'*72}")
print(f"  📈 OVERALL ({SYMBOL} @ {TF_LABEL})")
print(f"{'═'*72}{RESET}")
valid = [f for f in fold_results if f.get("n_trades", 0) > 0]
overall = {}
if valid and all_trades_global:
    all_rs = np.array([t["realized_r"] for t in all_trades_global])
    overall_scenarios = {}
    for name in ("gross_no_fees", "net_fees_only", "net_fees_slip_low",
                  "net_fees_slip_med", "net_fees_slip_high"):
        slip = {"gross_no_fees": 0, "net_fees_only": 0,
                "net_fees_slip_low": 0.05, "net_fees_slip_med": 0.15,
                "net_fees_slip_high": 0.30}[name]
        fee = 0 if name == "gross_no_fees" else args.fee_r
        adj = all_rs - (fee + slip)
        overall_scenarios[name] = {
            "expectancy_R": float(adj.mean()),
            "total_R":      float(adj.sum()),
            "win_rate":     float((adj > 0).mean()),
            "sharpe":       float(adj.mean()/adj.std()*np.sqrt(252)) if adj.std()>0 else 0.0,
        }
    overall = {
        "n_folds":      len(valid),
        "total_trades": len(all_trades_global),
        "scenarios":    overall_scenarios,
        # back-compat
        "overall_wr":         float((all_rs > 0).mean()),
        "gross_total_R":      overall_scenarios["gross_no_fees"]["total_R"],
        "gross_expectancy_R": overall_scenarios["gross_no_fees"]["expectancy_R"],
        "net_total_R":        overall_scenarios["net_fees_only"]["total_R"],
        "net_expectancy_R":   overall_scenarios["net_fees_only"]["expectancy_R"],
        "profitable_gross":   overall_scenarios["gross_no_fees"]["expectancy_R"] > 0,
        "profitable_net":     overall_scenarios["net_fees_only"]["expectancy_R"] > 0,
    }
    # Pretty per-year table
    print(f"\n  {'Year':<6} {'Trades':>7} {'WR%':>6} {'Gross E':>9} "
          f"{'Net E':>9} {'+slip-low':>11} {'+slip-med':>11} {'+slip-high':>11}")
    print(f"  {'─'*78}")
    for f in valid:
        s = f["scenarios"]
        print(f"  {f['test_year']:<6} {f['n_trades']:>7} {f['win_rate']*100:>5.1f}% "
              f"{s['gross_no_fees']['expectancy_R']:>+7.3f}R "
              f"{s['net_fees_only']['expectancy_R']:>+7.3f}R "
              f"{s['net_fees_slip_low']['expectancy_R']:>+9.3f}R "
              f"{s['net_fees_slip_med']['expectancy_R']:>+9.3f}R "
              f"{s['net_fees_slip_high']['expectancy_R']:>+9.3f}R")
    print(f"  {'─'*78}")
    o = overall["scenarios"]
    print(f"  {'TOTAL':<6} {overall['total_trades']:>7} "
          f"{overall['overall_wr']*100:>5.1f}% "
          f"{o['gross_no_fees']['expectancy_R']:>+7.3f}R "
          f"{o['net_fees_only']['expectancy_R']:>+7.3f}R "
          f"{o['net_fees_slip_low']['expectancy_R']:>+9.3f}R "
          f"{o['net_fees_slip_med']['expectancy_R']:>+9.3f}R "
          f"{o['net_fees_slip_high']['expectancy_R']:>+9.3f}R")
    print()
    verdict_g = "✅ PROFITABLE" if o["gross_no_fees"]["expectancy_R"] > 0 else "❌ UNPROFITABLE"
    verdict_n = "✅ PROFITABLE" if o["net_fees_only"]["expectancy_R"] > 0 else "❌ UNPROFITABLE"
    print(f"  Edge no fees    : {verdict_g}  E={o['gross_no_fees']['expectancy_R']:+.3f}R/trade")
    print(f"  Edge after fees : {verdict_n}  E={o['net_fees_only']['expectancy_R']:+.3f}R/trade")
else:
    print(f"  (no valid folds)")


# ── 6. Save to storage ─────────────────────────────────────────────────
payload = {
    "symbol":          SYMBOL,
    "tf_label":        TF_LABEL,
    "n_candles":       len(df),
    "data_first":      str(df["open_time"].iloc[0]),
    "data_last":       str(df["open_time"].iloc[-1]),
    "step":            args.step,
    "horizon":         args.horizon,
    "fee_r":           args.fee_r,
    "folds":           fold_results,
    "overall":         overall,
    "complete":        True,
    "saved_at":        datetime.datetime.utcnow().isoformat() + "Z",
}
local_path = f"backtest_{SYMBOL.replace('-','_')}_{TF_LABEL}.json"
with open(local_path, "w") as f:
    json.dump(payload, f, default=str, indent=2)
print(f"\n  ✓ local: {local_path}")
if not args.no_push:
    rid = f"{SYMBOL.replace('-','_')}_{TF_LABEL}"
    STORE.put_json(f"backtest_{rid}", payload,
                    message=f"backtest {SYMBOL} {TF_LABEL}")
    print(f"  ✓ uploaded to storage as backtest_{rid}")

# Wipe per-fold checkpoint now that we have the final aggregated result
try:
    bt_ck.reset(SYMBOL, TF_LABEL)
    print(f"  ✓ per-fold checkpoint cleared (next backtest starts fresh)")
except Exception:
    pass
print()
