# 24/7 Hosting Guide — WhiteDemon_V8.2

> Train heavy DL models on Kaggle GPU. Deploy inference-only auto-trader on a
> small VPS or PaaS that runs 24/7. The bot loads cached weights from GitHub
> on startup — no retraining needed.

You picked **Fly.io / Render**, so this guide focuses on those. Bonus
sections for VPS + Oracle Cloud at the bottom.

---

## Option A — Fly.io (RECOMMENDED — generous free tier, simple secrets)

### 1. Install + login
```bash
curl -L https://fly.io/install.sh | sh
flyctl auth login
```

### 2. Clone your project + cd into it
```bash
git clone https://github.com/zaibion/kinapp.git crypto-bot
cd crypto-bot
# OR upload your crypto-suite-WhiteDemon_V8.2.zip and unzip
```

### 3. Launch (creates fly app, doesn't deploy yet)
```bash
flyctl launch --no-deploy --copy-config --name your-bot-name
```

### 4. Set secrets (NEVER commit these to git)
```bash
flyctl secrets set GITHUB_TOKEN=ghp_yourtoken
flyctl secrets set GITHUB_REPO=zaibion/kinapp
flyctl secrets set GITHUB_BRANCH=main

# Optional — Firebase / Supabase
flyctl secrets set FIREBASE_API_KEY=AIzaSy...
flyctl secrets set FIREBASE_PROJECT_ID=gen-lang-client-...
flyctl secrets set FIREBASE_DATABASE_URL=https://...firebaseio.com
flyctl secrets set SUPABASE_URL=https://xxxxx.supabase.co
flyctl secrets set SUPABASE_KEY=eyJh...

# Default pair (auto-trader pairs override this per-pair anyway)
flyctl secrets set PAIR_ID=1
flyctl secrets set TF_ID=4
```

### 5. Deploy
```bash
flyctl deploy
```

You'll get a URL like `https://your-bot-name.fly.dev` — that's your dashboard.

### 6. Configure auto-trader (one-time, from your laptop)

```bash
# SSH into the machine
flyctl ssh console

# Add exchange keys + webhooks via the menu
python run.py
# → [13] LIVE CREDS  → add Bybit key, Discord webhook, etc.
# → [12] AUTO-TRADER → [3] ADD pair  → e.g. BTC-USD @ 15m, alerts only

exit
```

### 7. Auto-trader runs as a separate process

The included `fly.toml` defines two processes:
- `app`       → web dashboard (gunicorn)
- `autotrader` → 24/7 loop (python -m live.autotrader)

Both are auto-restarted by Fly's machine supervisor. To check status:
```bash
flyctl status
flyctl logs --process autotrader
```

### 💰 Cost
- Fly's free allotment: 3 shared-cpu-1x VMs × 256MB free per month
- Our `[[vm]]` block requests 1GB → costs ~$5/month
- Reduce to 512MB if your trained models fit (DL ensemble might OOM)

---

## Option B — Render.com (easier signup, smaller free tier)

### 1. Push project to GitHub
```bash
git remote add origin git@github.com:you/your-bot.git
git push -u origin main
```

### 2. Sign in at https://render.com → New → Blueprint
- Point to your repo
- Render auto-detects `render.yaml` and creates 2 services:
  - `crypto-suite-dashboard` (web)
  - `crypto-suite-autotrader` (worker)

### 3. Add env vars (Render dashboard → Service → Environment)
Paste:
```
GITHUB_TOKEN=ghp_...
GITHUB_REPO=zaibion/kinapp
GITHUB_BRANCH=main
FIREBASE_API_KEY=AIzaSy...
FIREBASE_PROJECT_ID=...
FIREBASE_DATABASE_URL=https://...firebaseio.com
SUPABASE_URL=https://....supabase.co
SUPABASE_KEY=eyJh...
PAIR_ID=1
TF_ID=4
```

### 4. Deploy
Render builds the Dockerfile and starts both services. You'll get a URL like
`https://crypto-suite-dashboard.onrender.com` for the dashboard.

### 5. Configure via dashboard
The dashboard's `/api/autotrader/start` endpoint can kick the autotrader,
OR configure pairs via Render's **shell** tab (free).

### 💰 Cost
- Dashboard (web): free tier OK (sleeps after 15 min inactivity)
- Autotrader (worker): requires **Starter $7/mo** (workers can't be free)
- Or run autotrader on your laptop / Kaggle session if you want full-free

---

## Option C — Cheap VPS (best price/perf — $4-5/month)

### Recommended providers
- **Hetzner CX22** — €4.50/mo · 2 vCPU · 4GB RAM · 40GB SSD · Germany/US
- **Contabo VPS S** — $5/mo · 4 vCPU · 8GB RAM · 200GB SSD · Germany
- **DigitalOcean Basic** — $6/mo · 1 vCPU · 1GB RAM

### Setup (Ubuntu 22.04)
```bash
ssh root@your-vps-ip

# Install Docker
curl -fsSL https://get.docker.com | sh
systemctl enable --now docker

# Clone repo + .env file
git clone https://github.com/zaibion/kinapp.git /opt/crypto-bot
cd /opt/crypto-bot
cat > .env <<EOF
GITHUB_TOKEN=ghp_...
GITHUB_REPO=zaibion/kinapp
FIREBASE_API_KEY=AIzaSy...
FIREBASE_PROJECT_ID=...
FIREBASE_DATABASE_URL=https://...firebaseio.com
SUPABASE_URL=https://....supabase.co
SUPABASE_KEY=eyJh...
PAIR_ID=1
TF_ID=4
EOF

# Build image
docker build -t crypto-bot .

# Run dashboard
docker run -d --name dashboard --restart unless-stopped \
  --env-file .env -p 80:8000 crypto-bot

# Run autotrader (separate container)
docker run -d --name autotrader --restart unless-stopped \
  --env-file .env crypto-bot \
  python -m live.autotrader
```

That's it. Both containers auto-restart on crash and survive reboots.
Open `http://your-vps-ip` for the dashboard.

---

## Option D — Oracle Cloud Always Free (literally $0)

Oracle gives 4 ARM cores + 24GB RAM permanently free. Setup is the same as
Option C above but on their VM. Sign up at
https://www.oracle.com/cloud/free/ — note ARM means you may need to
rebuild `requirements.txt` for ARM wheels (most modern libs have ARM).

---

## Discord webhook setup (for free alerts)

1. Discord → your server → channel settings → Integrations → New Webhook
2. Copy webhook URL (looks like `https://discord.com/api/webhooks/123/.../...`)
3. In the bot: Menu 13 → [2] Add/Edit DISCORD webhook → paste URL
4. Test: Menu 13 → [6] Test ALL channels

You'll get rich embeds like:
```
🟢 LONG BTC-USD @ 15m
Verdict: TAKE_TRADE  ·  Win Prob: 68.2%
Entry: $43,150    SL: $42,810    TP1: $43,810 (1.94R)
```

## Telegram setup

1. Talk to @BotFather → /newbot → get token
2. Talk to @userinfobot → get your chat_id
3. Menu 13 → [3] Add/Edit TELEGRAM → paste token + chat_id

## TradingView-style webhook (for Altrady/Signum/Wundertrading)

The bot sends standardized JSON to your webhook URL:
```json
{
  "action": "buy",
  "symbol": "BTCUSDT",
  "price": 43150.5,
  "stop_loss": 42810.0,
  "take_profit": 43810.0,
  "take_profits": [43810.0, 44100.0, 44650.0],
  "leverage": 3,
  "size_pct": 1.0,
  "strategy": "crypto-suite-v25",
  "key": "your-secret-key",
  "verdict": "TAKE_TRADE",
  "win_prob": 0.682,
  "tf": "15m",
  "ts": 1719234500
}
```

- **Altrady**: paste their webhook URL + set `key` in Menu 12 add-pair flow
- **Signum** / **Wundertrading** / **Cryptohopper**: same approach
- **Custom TradingView alerts**: any URL that accepts JSON POST works

---

## Recommended setup for YOU

Since you said train on Kaggle + deploy 24/7:

1. **Kaggle** — train all models (Menu 1, takes ~5h), train SL-NN (Menu 4→11)
2. All models save to GitHub `zaibion/kinapp` automatically
3. **Fly.io** — deploy WhiteDemon_V8.2 with the Dockerfile + fly.toml above ($5/mo)
4. SSH in once → `python run.py` → Menu 12 → add BTC-USD@15m, ETH-USD@15m
5. **Menu 13** → add Discord webhook + (optional) Bybit testnet API key
6. Autotrader runs forever, sends alerts to Discord, optionally places orders
