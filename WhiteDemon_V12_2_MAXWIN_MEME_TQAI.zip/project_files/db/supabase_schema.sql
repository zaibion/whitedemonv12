-- ============================================================
-- Crypto Suite v25.6 — Supabase schema
-- ============================================================
-- Paste this whole file into:
--   Supabase Dashboard → SQL Editor → New query → RUN
--
-- It creates one table + one storage bucket the bot needs.
-- Safe to re-run (uses IF NOT EXISTS).
-- ============================================================

-- 1. Key/value JSON table  (checkpoints, dashboard data, indexes, etc.)
create table if not exists public.kv_json (
    key         text primary key,
    value       jsonb not null,
    updated_at  timestamptz not null default now()
);

create index if not exists kv_json_updated_at_idx
    on public.kv_json(updated_at desc);

-- helper RPC: list keys by prefix
create or replace function public.kv_list_keys(prefix text)
    returns setof text
    language sql stable as $$
        select key from public.kv_json where key like prefix || '%';
    $$;

-- 2. Storage bucket for big model pickles (ml/dl/nn weights)
-- NOTE: bucket creation done via REST in core/storage.py — but you can also
-- create it manually here if RLS denies the REST call:
insert into storage.buckets (id, name, public)
    values ('cryptosuite', 'cryptosuite', true)
    on conflict (id) do nothing;

-- ============================================================
-- 3. Row-Level Security (RLS) policies
-- ============================================================
-- Allow service-role (or anon-key if you accept the risk) to read/write
-- everything in kv_json + storage bucket.

alter table public.kv_json enable row level security;

drop policy if exists "anon_all_kv_json" on public.kv_json;
create policy "anon_all_kv_json" on public.kv_json
    for all
    to anon, authenticated
    using (true)
    with check (true);

-- Storage bucket policies — allow anon read+write to 'cryptosuite'
drop policy if exists "cryptosuite_anon_read"  on storage.objects;
drop policy if exists "cryptosuite_anon_write" on storage.objects;
drop policy if exists "cryptosuite_anon_upd"   on storage.objects;
drop policy if exists "cryptosuite_anon_del"   on storage.objects;

create policy "cryptosuite_anon_read"  on storage.objects
    for select  to anon, authenticated
    using (bucket_id = 'cryptosuite');

create policy "cryptosuite_anon_write" on storage.objects
    for insert  to anon, authenticated
    with check (bucket_id = 'cryptosuite');

create policy "cryptosuite_anon_upd"   on storage.objects
    for update  to anon, authenticated
    using (bucket_id = 'cryptosuite')
    with check (bucket_id = 'cryptosuite');

create policy "cryptosuite_anon_del"   on storage.objects
    for delete  to anon, authenticated
    using (bucket_id = 'cryptosuite');

-- ============================================================
-- DONE.  Verify:
--   select count(*) from public.kv_json;
--   select * from storage.buckets where id='cryptosuite';
-- ============================================================
