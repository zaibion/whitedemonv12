# Crypto Suite WhiteDemon_V8.2 — Frontend + Collect-All + Disk-Cache fallback

## 🆕 What changed since WhiteDemon_V8.2

### 1. Frontend dashboard — now actually wired
* **`frontend/dashboard.html`** opens in your browser, you enter
  Firebase / Supabase / GitHub creds ONCE (stored in localStorage), it auto-fetches
  ALL data and renders the 20 tabs.
* New **"📂 View Saved Analyses"** picker — lists every pair/TF ever analyzed
  (scans `final_*` and `dashboard_data_*` keys on storage), pick one, the full
  20-tab dashboard repopulates for that pair.
* Supabase added to the credential overlay (URL + Key + bucket auto-detected from URL).
* `readJson()` chain: **embedded → Firebase → Supabase → GitHub** — first hit wins.
* `listKeys()` works against Supabase (`/rest/v1/kv_json?key=like.…`) AND GitHub.
* New `renderAll(d)` helper used by both `loadAll()` and `loadSelectedPair()`.
* When `collect_all.py` embeds payload into HTML (`window.__EMBED_DASHBOARD_DATA__`),
  opening the file with `file://` directly shows the latest setup with NO creds needed.
* Run local server: `python server.py` → `http://localhost:8000`

### 2. NEW Menu 11 — COLLECT ALL  (and rewired Menu 4 sub-menu 8)
Both invoke `collect_all.py` which:
1. Audits classical (9 × 2) + DL (14 × 2) + neural NN indexes
2. Trains **anything missing** via `train_specific.py --missing`
3. **Force-runs extras** stages by resetting `specialized_nns / stacker / save_dashboard`
   in the checkpoint — so the engine actually trains:
   - **PriceRegressionNN**
   - **RL Agent**
   - **SentimentNN (FinBERT)**
   - **RegimeDetectorNN**
   - **Monte Carlo robustness** (2,000 bootstrap runs over backtest trade R-array)
   - **Triple-Barrier model**
   - **Meta-labeler**
   - **Prophet forecast**
   - **Position sizing (Kelly + fractional)**
4. Fetches **4,000 LATEST live candles**
5. Runs committee + structure analysis on them
6. Enriches `dashboard_data.ctx` with `monte_carlo`, `position_sizing`, `tb_models`,
   `backtest_results` so all 20 tabs are populated (no more `{"available": False}` blanks)
7. Pushes payload to **Firebase + Supabase + GitHub**
8. **Embeds the payload into `frontend/dashboard.html`** so the local file shows the
   latest setup the moment you open it with `file://` (no creds needed)

### 3. NBeats / large-file save — disk-cache fallback
* `core/per_model_cache.py` new `_try_put_blob()`:
  1. Tries `STORE.put_blob()` (Firebase → Supabase → GitHub via Git Data API up to 100MB)
  2. If ALL backends reject (NBeats > 100MB scenario), falls back to
     **local disk cache** at `/kaggle/working/cryptosuite_cache/` (survives session)
     or `~/.cryptosuite_cache/`
  3. Marks `saved_to: "storage" | "disk"` in the index JSON
* `_try_get_blob()` reads from storage FIRST, then disk cache automatically
* You never lose a trained model now — even if GitHub rejects the upload size,
  NBeats persists in `/kaggle/working/cryptosuite_cache/` and the engine can reuse it

### 4. Menu 7 (Live Dashboard) sub-menu
Now has its own sub-menu:
- `[1]` Refresh payload + push HTML
- `[2]` Run COLLECT ALL
- `[3]` Start local web server
- `[4]` Show path to local HTML file

---

## 📋 Updated main menu

```
━━ MAIN MENU ━━
 [ 1] 🛠 TRAIN/RESUME ADA-USD @ 15m   (sub-menu when complete: re-train all / FAST MODE)
 [ 2] 🔄 CHANGE pair & timeframe  (107 pairs)
 [ 3] 📈 TRAIN BIT-BY-BIT  (incremental)
 [ 4] 🎯 TRAIN SPECIFIC MODELS  ▸ classical/DL/neural/extras/combine/wipe
 [ 5] 📊 BACKTEST  (specific/all/10-step bit-by-bit)
 [ 6] 🗑  WIPE EVERYTHING  (triple-confirm + DELETE word)
 [ 7] 🌐 LIVE DASHBOARD  (refresh/collect/server/local-file)
 [ 8] 📁 SHOW ALL TRAINED PAIRS  (pick → analyze)
 [ 9] 🔥 TEST / CHANGE Firebase + Supabase + GitHub credentials
 [10] 🧩 COLLECT ALL — train EVERY missing model + extras + 4k live + push HTML
 [11] 🚪 EXIT (save all)
```

## 🚀 How to use the new dashboard locally

```bash
# 1) On Kaggle, after Menu 1 (or 4-8 or 10) finishes:
# The dashboard.html in the repo will have the latest setup baked in.

# 2) Download the project folder OR just `frontend/dashboard.html` from your GitHub repo
# 3) Double-click it → opens in browser → 20 tabs populated.

# OR run the local server (live updates every 30s):
python server.py    # → http://localhost:8000

# OR keep dashboard.html clean (no embedded data) — enter creds once
# in the overlay, and it auto-fetches from Firebase/Supabase/GitHub.
```
