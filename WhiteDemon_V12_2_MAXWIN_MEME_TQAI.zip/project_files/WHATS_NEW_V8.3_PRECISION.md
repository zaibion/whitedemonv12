# WhiteDemon V8.3 Precision Updates

## 1) Lower DL Learning Rate
- Deep-learning optimizers are now set to `3e-4` instead of the previous higher rate.
- This should make training move in smaller, steadier steps and reduce accuracy bouncing.

## 2) Precision-Focused Asymmetric Focal Loss
`AsymmetricFocalLoss` was upgraded with:
- `fp_weight=4.0` to punish false-positive trade entries harder.
- `gamma=2.5` to focus more on difficult examples.
- `confident_wrong_weight=2.0` to punish confident-but-wrong predictions.
- `label_smoothing=0.03` to reduce brittle memorization and overconfidence.

## 3) Smoother DL Heartbeat
- Epoch progress now includes smoother ETA reporting where applicable.

## 4) Full Wipe From V8.2 Fix Preserved
- Menu `[6] WIPE EVERYTHING` still wipes `data/` and `blobs/` from configured Firebase/Supabase/GitHub current branch.
- Note: GitHub old commit history is not rewritten; current repo files are removed.

## Honest win-rate note
These updates can improve stability and may improve live win rate by reducing fake/unstable accuracy, but they cannot guarantee profit or a higher win rate in every market condition.
