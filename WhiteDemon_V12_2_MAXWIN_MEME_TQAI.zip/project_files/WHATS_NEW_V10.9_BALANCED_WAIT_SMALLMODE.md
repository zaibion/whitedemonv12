# WhiteDemon V10.9 — Balanced Mode + Wait Mode + Small Mode Panel

## Why
The previous elite gate was too strict and could hide usable watch setups. This version makes the setup logic less aggressive, less confusing, and more honest.

## Changes

### 1) Less strict thresholds
Defaults are relaxed:
- setup score trade threshold: 60 instead of 75
- precision score trade threshold: 60 instead of 78
- probability threshold: 60% instead of 66%
- edge threshold: 5% instead of 10%
- model agreement threshold: 58% instead of 72%
- risk max: 4.5% instead of 3%

### 2) Status ladder
Setups now fall into:
- `TRADE_NOW` — clean enough to consider
- `WATCH` — setup visible, but confidence is lower than ideal
- `WAIT` — no clean setup; stay out
- `BLOCKED_TOO_LOW` — score/precision too low, do not show as valid trade idea

Hard block defaults:
- setup score < 30
- precision score < 30

### 3) Wait mode
If there is no full setup and no meaningful short-term prediction, the system clearly says:

```text
WAIT — no reliable full setup available
```

### 4) Small Mode
If no full setup exists but models indicate a small next 3–4 candle move, the system shows a micro-only idea:

```text
SMALL MODE ONLY: LONG/SHORT · expected move ...%
```

This is not a full TP/SL trade. It is explicitly labelled micro-only.

### 5) No fake GO LONG/GO SHORT on dashboard
Frontend trade setup card no longer always says GO LONG/GO SHORT. It now shows:
- GO LONG / GO SHORT only for `TRADE_NOW`
- WATCH LONG/SHORT SETUP for `WATCH`
- WAIT for no clean setup
- BLOCKED for very low score

### 6) New frontend panel
Added new dashboard tab:

```text
🧭 Small Mode
```

It shows:
- market mode
- small-mode path
- next 3–4 candle forecast
- micro-only warning
- wait reason
- full setup block reasons

## Important
Small Mode is not a guarantee and not a full trade signal. It is a micro forecast to avoid forcing big TP/SL setups when only a small model-predicted move exists.

## Checks
- compileall passed
- tabnanny passed
- zip integrity passed
