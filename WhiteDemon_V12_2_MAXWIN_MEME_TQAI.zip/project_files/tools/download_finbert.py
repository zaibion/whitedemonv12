"""
Download FinBERT to local cache – run once online.
Then live trading works fully offline.
"""
from transformers import AutoTokenizer, AutoModelForSequenceClassification
print("Downloading ProsusAI/finbert …")
tok = AutoTokenizer.from_pretrained("ProsusAI/finbert")
mdl = AutoModelForSequenceClassification.from_pretrained("ProsusAI/finbert")
print("✓ cached to ~/.cache/huggingface")
print("Now set FINBERT_ALLOW_DOWNLOAD=0 (default) – offline inference will work")
