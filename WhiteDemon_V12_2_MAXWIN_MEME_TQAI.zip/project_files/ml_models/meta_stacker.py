"""Level-1 meta-stacker (logistic regression over OOF probs) lives inside
run_ml_committee in the engine. Exposed here for completeness."""
# The actual implementation is embedded in _engine.run_ml_committee.
# Nothing to re-export — file kept for module structure clarity.
