# WhiteDemon V8.6 — High Precision Setup Watch

## Goal
User may not run the bot 24/7. This update makes analyze always show actionable setup candidates and also scan recent candles so missed setups are reported.

## What changed

### 1) Always show LONG and SHORT setup candidates
Analyze now builds BOTH:
- LONG candidate
- SHORT candidate

Each candidate includes:
- status: `TRADE_NOW`, `WATCH`, or `NO_TRADE`
- setup score
- probability
- edge vs opposite side
- model agreement
- entry / SL / TP1 / RR / risk %
- warnings explaining exactly why it is blocked

So even if the final verdict is NO_TRADE, the dashboard/payload still shows the setup plan.

### 2) Congratulations message when a clean setup is found
If a setup passes high-precision checks, analyze prints:

```text
🎉 CONGRATULATIONS — LONG/SHORT setup found now
```

If blocked, it prints the setup anyway with warnings.

### 3) Recent setup scanner
Analyze now scans recent candles (`setup_scan_bars`, default 96) and reports whether a high-precision setup appeared recently.

This helps when the user only runs the app every 30–60 minutes and may have missed a setup.

Output example:

```text
Recent setup scanner: 2 setup(s) found in last 96 bars
Setup found 4 bars ago: LONG near $...
```

### 4) High Precision filters
Current defaults:
- score >= 68
- probability >= 64%
- direction edge >= 8%
- model agreement >= 65%
- RR >= 1.20
- risk <= 5%
- valid positive TP/SL geometry

If these fail, setup is shown but marked `NO_TRADE` or `WATCH`.

### 5) Low-price short TP fix
For very low-priced coins, SHORT fallback targets could become negative. Targets are now clamped above zero and flagged as fallback/low-quality instead of displaying impossible negative TP values.

## Important
This does not force trades. It shows setups for planning, but still blocks unsafe trades.
