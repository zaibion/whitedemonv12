# WhiteDemon V9.3 — Elite Entry Gate

## Purpose
Make entries more selective, more precise, and less likely to take weak ambiguous trades.

## What changed
V9.3 is stricter than V9.2. A trade is not allowed just because one system says buy/sell.

It now requires stronger agreement across:
- all-model majority
- committee probability
- committee edge
- model agreement
- setup score
- entry precision score
- risk/SL/TP geometry
- higher timeframe alignment
- cached OOS/backtest edge
- regime conflict checks

## New stricter default thresholds
- setup score >= 75
- selected committee probability >= 66%
- committee edge >= 10%
- same-side model agreement >= 72%
- entry precision score >= 78
- all-model majority share >= 62%
- all-model majority edge >= 12%
- risk between 0.08% and 3.0%
- RR between 1.2 and 3.5
- backtest required by default: at least 50 OOS trades and +0.05R expectancy
- HTF alignment required by default: at least 2/3 higher timeframe trend support and 0 against

## New blocks
The setup will be blocked/warned if:
- all-model majority is too close
- committee disagrees while majority is weak
- no reliable OOS backtest exists
- cached OOS expectancy is too low
- HTF trend is not aligned
- regime conflicts with selected direction
- precision score is below threshold

## Expected effect
- Fewer trades
- More NO_TRADE/WATCH results
- Fewer weak entries
- Cleaner setup selection

This cannot guarantee profit, but it is intentionally stricter to reduce repeated low-quality entries.
