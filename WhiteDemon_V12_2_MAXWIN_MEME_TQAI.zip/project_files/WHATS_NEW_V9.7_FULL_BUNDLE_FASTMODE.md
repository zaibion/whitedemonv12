# WhiteDemon V9.7 — Full Bundle FAST MODE

## Main goal
FAST MODE should use trained models, not only saved accuracy/loss metadata.

## What changed

### 1) Full committee inference bundles
New file:

```text
core/committee_bundle.py
```

During training, the system now saves a full committee inference bundle containing:
- fitted classical model objects
- saved scaler
- exact feature list/schema
- model `needs_sc` map
- Brier/logloss metadata
- WF accuracy metadata
- baseline win rate
- training row count

Saved to GitHub/storage as:

```text
blobs/perm/<PAIR>/<TF>/<DIRECTION>/<COUNT>/committee_bundle.pkl.gz
```

### 2) Analyze uses full trained bundle first
`analyze.py` now tries this order:

1. Load full saved committee bundles and run latest-candle inference.
2. If no bundle exists yet, use V9.6 cached model inference.
3. If that fails, fallback to slim metadata and clearly warn.

### 3) No retraining in analyze
Bundle inference loads trained models and runs prediction only.
No training happens.

### 4) Latest candle prediction
The saved bundle uses the saved scaler and saved feature schema, then predicts on the latest complete feature row.

### 5) Why this helps
Before, FAST MODE could rely on slim committee metadata, where probability may look like historical model accuracy.
Now, after one V9.7 training run, FAST MODE can use actual saved trained models for current market prediction.

## About repeated SHORT
No syntax error was found. Repeated SHORT can happen because:
- true models really vote SHORT,
- market is bearish,
- old metadata-only slim cache was being used,
- old model cache was biased.

V9.7 reduces the metadata-only problem by using full trained bundles first.

## Important
You need one clean V9.7 training run to create the new full bundles. After that, analyze/FAST MODE can skip training and use those saved bundles.

## Checks
- compileall passed
- tabnanny passed
- pyflakes syntax/undefined-name scan passed
