# WhiteDemon V8.9 — Single Best Setup Display

## User-facing change
Analyze no longer prints LONG and SHORT trade setups at the same time.

It now shows only:

```text
BEST SETUP ONLY: LONG/SHORT ...
```

The opposite side is hidden to avoid confusion.

## Selection logic
The best setup is selected using:
- TRADE_NOW status first
- setup score
- committee probability
- positive edge vs opposite side
- model agreement
- fewer warnings

## Future watch areas still shown
If the best setup is not clean right now, it still prints:

```text
Current clean setup: NONE — watch possible setup prices below:
```

Then it shows future watch levels:
- LONG pullback/support
- LONG breakout/resistance
- SHORT rejection/resistance
- SHORT breakdown/support
- demand/supply retest levels

## GitHub/storage upload improved
Analyze now also uploads:

```text
data/setup_watch_<PAIR>_<TF>.json
```

This contains:
- best setup only
- future potential setup levels
- recent setup alerts

Existing uploads remain:
- `dashboard_data`
- `dashboard_data_<PAIR>_<TF>`
- `final_<PAIR>_<TF>`
- dashboard HTML blob

## Technical checks
- Python compile check passed
- Tab/indent check passed
- Undefined-name/syntax pyflakes scan passed
