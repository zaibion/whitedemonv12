# ⚡ Crypto Suite v23 — How to run

## 🎯 The 4 things you'll do

| Task | Command | Time | Auto-saves? |
|---|---|---|---|
| **First time setup** | `python setup.py` | 1 min | yes |
| **Train models** (once per pair/TF) | `python run.py` → pick "Train" | ~15 min | ✅ every 60s + per-model |
| **⚡ FAST MODE** (anytime after training) | `python run.py` → pick "Fast Mode" → pick pair | ~30 sec | yes |
| **Backtest** | `python run.py` → pick "Backtest" | ~30-90 min | ✅ every 60s |
| **Live dashboard** | open `frontend/dashboard.html` in browser | instant | reads storage |

## 🚀 Step-by-step in Google Colab

### Cell 1 — Upload zip + unpack
```python
from google.colab import files
uploaded = files.upload()        # pick crypto-suite-v23.3.zip
import zipfile, os
for fn in uploaded:
    with zipfile.ZipFile(fn) as z: z.extractall("/content")
os.chdir("/content/crypto-v23")
!ls
```

### Cell 2 — Install deps (3 min)
```python
!pip install -q ccxt rich xgboost lightgbm shap yfinance transformers torch firebase-admin flask prophet pyngrok psutil
```

### Cell 3 — Interactive setup (asks for credentials)
```python
!python setup.py
```
Prompts you for:
- Firebase JSON path (optional — press Enter to skip)
- GitHub token + repo
- Pair + TF + candle counts

### Cell 4 — Run the menu
```python
!python run.py
```

Menu shows up. Pick:
- **[1] ⚡ FAST MODE** — picks any TRAINED pair → fresh analysis (~30s)
- **[2] 🔄 Resume training** — continues from last checkpoint
- **[3] 🛠 Train NEW** — change pair/TF and train
- **[4] 📊 Backtest** — walk-forward with fees + slippage
- **[5] 🔁 Force retrain** — wipe & start over
- **[6] 🌐 Start web dashboard** — Flask server on port 8000
- **[7] 📋 Show status** — what's cached, latest verdict
- **[8] 📁 List all trained models** — across all pairs

### Cell 5 — Live dashboard via ngrok (optional)
```python
from pyngrok import ngrok
ngrok.set_auth_token("YOUR_NGROK_TOKEN")
ngrok.kill()
print("Open:", ngrok.connect(8000))
!python run.py server
```

Click the printed URL → dashboard opens.
First time: enter your Firebase/GitHub credentials in the popup → saved locally.

## 🔒 Resume-after-crash (the magic feature)

Every 60 seconds (and after every model finishes), the system pushes a checkpoint to storage.

If Colab disconnects mid-training:
1. Open new Colab tab (any account)
2. Re-run Cells 1+2+4
3. Menu auto-detects "🔄 7/11 done · pending: short_dl, stacker"
4. Pick **[2] Resume training**
5. It picks up exactly where you left off — skips the 7 stages already done

## ⚠️ Why training stopped mid-way last time

Your last log showed `^C` after 9 classical models because:
1. **Colab killed the process for hitting RAM limit** (200k candles × dual committee × DL models exceeds 12 GB free-Colab RAM)
2. **No background checkpoint** existed — so progress was lost

v23.3 fixes both:
- `core/memory_guard.py` auto-caps candles to your environment's RAM (12 GB → 100k cap)
- `core/checkpoint_thread.py` runs a background heartbeat every 60s

## 📊 Dashboard preview

Open `frontend/dashboard.html` directly in your browser (no Python server needed for read-only):

- **First time:** enter Firebase or GitHub credentials in the popup → saved to browser localStorage
- **Top section:** verdict (🟢/🟡/🔴) + KPI tiles
- **⚡ FAST MODE row:** dropdown of trained pairs + "Run Fast Mode" button (calls backend `/api/analyze`)
- **Tabs:** Chart · Setup · Models · DL · Advanced (Prophet/OFI/Funding/Liq) · Backtest · Actions · System
- **Auto-refresh every 30s** from your storage

## 🧠 What features now train into the models

Standard v22 features (unchanged):
- RSI, ATR, VWAP, CVD, MACD, EMAs
- Multi-timeframe trend, market regime
- Triple-barrier labels
- 8 classical ML + 14 deep learning + 4 specialised NNs

NEW in v23 (`advanced/` package):
- 🔮 **Prophet** — trend slope, changepoints, 24h forecast
- 💧 **OFI** — order-flow imbalance from OHLCV
- 📖 **Order Book** — live bid/ask imbalance from Bybit/Bitget/KuCoin
- 💸 **Multi-exchange Funding Rate** — avg + skew across 5 exchanges
- 💥 **Liquidation Cascade** — high-vol-wick detector

All saved as JSON per (pair, TF) so you can inspect them in the 🔬 Advanced tab.

## 🆘 If something errors out

Paste me the exact traceback. Don't try to patch it yourself — most errors at this point are one-line typo fixes I can ship in seconds.

Common ones already handled:
- ✅ `argv` collision (fixed in `core/config.py`)
- ✅ `meta_stacker` import (fixed in `ml_models/__init__.py`)
- ✅ Colab OOM (fixed in `core/memory_guard.py`)
- ✅ Lost progress on disconnect (fixed in `core/checkpoint_thread.py`)
