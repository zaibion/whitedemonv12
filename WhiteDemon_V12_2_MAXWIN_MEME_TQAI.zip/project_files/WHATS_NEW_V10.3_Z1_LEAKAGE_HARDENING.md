# WhiteDemon V10.3 — V10.2 + Z.1 Point-in-Time Leakage Hardening

## Goal
Keep V10.2 features and port Z.1 leakage-hardening improvements.

## Preserved from V10.2
- Regime / recency logic
- Drift monitoring concept
- Reject-trade logging
- Analog pattern inference
- Market similarity checks
- Live metrics / monitoring
- Validation and GitHub uploads

## Z.1 hardening integrated

### 1) Point-in-time analog inference
Analog search now supports strict timestamp-safe filtering using saved reference timestamps:

- reference timestamps saved as `reference_time_ns`
- current live timestamp passed to analog search
- analogs can be filtered to records before the decision time
- label horizon embargo is considered with `reference_horizon_bars` and `reference_bar_seconds`

### 2) Same-regime analog filtering
Analog search now attempts same-regime matching:

- TRENDING
- RANGING
- VOLATILE
- LOW_VOL

If enough same-regime analogs exist, only those are used.

### 3) Recency-weighted analogs
Analog weights now combine:

```text
distance weight × recency weight
```

Recent analogs matter more, while very similar old analogs can still contribute.

### 4) Configurable analog metric
Analog search supports:

- Euclidean
- Cosine
- diagonal Mahalanobis

Default remains Euclidean for stability.

### 5) Derivatives hardening
Historical derivatives now include:

- stale-data merge tolerances
- cache validation
- no-lookahead expanding OI normalization

This avoids carrying stale funding/OI/L/S values indefinitely and avoids future distribution leakage in OI normalization.

### 6) Feature drift monitoring upgraded
Added `core/drift_monitor.py` from Z.1.

It computes PSI-based distribution drift:

- PSI mean
- PSI max
- drifted features
- extreme features
- top drifted features
- level: ok / watch / drift / extreme

Analyze now uses PSI-based drift warnings.

### 7) Backtest point-in-time bundle inference
`backtest_run.py` now attempts per-test-bar bundle inference:

```text
train fold model bundle
for each test bar: infer using data available up to that bar only
```

This avoids using one fixed fold-level model probability for every bar when bundles are available.

### 8) Backtest calibration diagnostics
Backtest fold results now include:

- probability calibration buckets
- Brier score
- ECE (expected calibration error)

### 9) Rejected trade logging retained
V10.2 rejected trade logging remains active and uploads latest rejected setup.

## Important
You need a fresh V10.3 training run to create bundles with:

- reference timestamps
- regime labels
- training feature reference matrix
- drift profiles
- point-in-time analog metadata

Old bundles may load, but Z.1 checks may report unavailable until retrained.

## Checks
- `python -m compileall -q .` passed
- `python -m tabnanny .` passed
- pyflakes syntax/undefined-name scan passed
