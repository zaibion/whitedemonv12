"""
run.py — Crypto Suite WhiteDemon_V8.2 main entry point.

New 10-menu structure (per user request 2026-06):
  [1] TRAIN / RESUME current pair · (sub-menu appears when all done)
  [2] CHANGE pair & timeframe (100+ pairs)
  [3] TRAIN BIT-BY-BIT  (incremental)
  [4] TRAIN SPECIFIC MODELS  (classical/DL/neural/extras/full)
  [5] BACKTEST  (specific/all/10-step bit-by-bit)
  [6] WIPE ALL  (double-confirm + type DELETE)
  [7] LIVE DASHBOARD (HTML + auto-push to GitHub)
  [8] SHOW ALL TRAINED PAIRS  (across storage; pick → analyze)
  [9] TEST / CHANGE Firebase + Supabase + GitHub credentials
  [10] EXIT (save all)
"""
from __future__ import annotations
import os, sys, time, json, subprocess
from typing import Optional

# Detect state file
_state_exists = any(os.path.exists(p) for p in (
    "setup_state.json", ".setup_state.json",
    os.path.join(os.path.dirname(os.path.abspath(__file__)), ".setup_state.json"),
    "/kaggle/working/crypto-v23/.setup_state.json",
))
_config_exists = any(os.path.exists(p) for p in (
    "config.py",
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.py"),
))

if not _state_exists and not _config_exists:
    print("\n⚠️  No setup_state.json or config.py found.")
    print("    Run setup.py first:  python setup.py")
    sys.exit(1)

# Imports
from core.config       import (CFG, PAIRS, TIMEFRAMES, SYMBOL, TF_LABEL,
                                PAIR_ID, TF_ID, PAIR, TF)
from core.colors       import RESET, BOLD, CYAN, GREEN, YELLOW, RED, ORANGE, GREY
from core.storage      import STORE
from core              import checkpoint as ck_mod


# ════════════════════════════════════════════════════════════════════
# Helpers
# ════════════════════════════════════════════════════════════════════
def _ask(prompt: str, default: str = "") -> str:
    try:
        v = input(prompt).strip()
        return v if v else default
    except (EOFError, KeyboardInterrupt):
        return default

def _confirm(prompt: str, default_no: bool = True) -> bool:
    ans = _ask(prompt).lower()
    if default_no: return ans in ("y", "yes")
    return ans not in ("n", "no")

def _banner():
    backend = STORE.backend_name
    print(f"\n{BOLD}{CYAN}╔══════════════════════════════════════════════════════════╗")
    print(f"║       ⚡  CRYPTO INSTITUTIONAL SUITE WhiteDemon_V8.2 — COMMAND     ║")
    print(f"╠══════════════════════════════════════════════════════════╣")
    print(f"║  Pair: {SYMBOL:<10}  TF: {TF_LABEL:<6}  Backends: {backend:<22}║")
    print(f"╚══════════════════════════════════════════════════════════╝{RESET}")
    print(f"  {GREEN}✓ Configuration auto-loaded from config.py & setup_state.json{RESET}")
    print(f"  {GREY}→ Use menu [2] to quickly change Pair/TF without restarting setup.{RESET}")


def _get_training_status() -> dict:
    """Returns dict with: complete, n_done, n_total, models_status (dict)."""
    ck = ck_mod.load(SYMBOL, TF_LABEL)
    from core import per_model_cache as pmc
    target = CFG.get("target_total_candles", 100_000)
    done_l = pmc.list_done(SYMBOL, TF_LABEL, "LONG", target)
    done_s = pmc.list_done(SYMBOL, TF_LABEL, "SHORT", target)
    expected_cls = 9
    expected_dl  = 14
    total = (expected_cls + expected_dl) * 2
    have  = (len(done_l["classical"]) + len(done_l["dl"]) +
             len(done_s["classical"]) + len(done_s["dl"]))
    return {
        "complete":   ck_mod.is_complete(ck) and have >= total,
        "n_done":     have,
        "n_total":    total,
        "ck_verdict": ck.get("verdict"),
        "done_long":  done_l,
        "done_short": done_s,
    }


# ════════════════════════════════════════════════════════════════════
# MENU 1 — TRAIN / RESUME (+ sub-menu when complete)
# ════════════════════════════════════════════════════════════════════
def menu_train_or_resume():
    st = _get_training_status()
    label = "RESUME" if (st["ck_verdict"] == "TRAIN_INCOMPLETE" or st["n_done"] > 0) and not st["complete"] else "TRAIN"
    print(f"\n{BOLD}{CYAN}━━ [1] {label} · {SYMBOL} @ {TF_LABEL} ━━{RESET}")

    if st["complete"]:
        # Sub-menu only shown when fully complete
        print(f"  {GREEN}✓ All {st['n_total']} models trained for {SYMBOL} @ {TF_LABEL}{RESET}\n")
        print(f"  [1] 🔁 Train ALL AGAIN from scratch (wipe + retrain)")
        print(f"  [2] ⚡ FAST MODE  (fetch 4k live candles, use saved models, show setup)")
        print(f"  [0] ↩ back")
        ch = _ask(f"\n  {BOLD}Pick: {RESET}")
        if ch == "1":
            return _train_from_scratch()
        elif ch == "2":
            return _fast_mode_current()
        return

    # Not complete — show progress and offer to resume / train
    print(f"  Progress: {st['n_done']}/{st['n_total']} models trained")
    if st["n_done"] > 0:
        print(f"  Done LONG : cls={list(st['done_long']['classical'].keys())[:5]}…  dl={list(st['done_long']['dl'].keys())[:5]}…")
        print(f"  Done SHORT: cls={list(st['done_short']['classical'].keys())[:5]}…  dl={list(st['done_short']['dl'].keys())[:5]}…")
    print(f"\n  This will train ALL models (classical ML + 14 DL + neural nets + extras) ")
    print(f"  step-by-step and save each to {STORE.backend_name} so anyone can resume.")
    if not _confirm(f"\n  {BOLD}Start {label.lower()}ing? [y/N]: {RESET}"):
        print(f"  {YELLOW}cancelled{RESET}"); return
    from train_pipeline import train_with_checkpoint
    try:
        train_with_checkpoint(force=False)
    except KeyboardInterrupt:
        print(f"\n{YELLOW}[!] Stopped. Resume anytime from menu [1].{RESET}")
    except Exception as e:
        print(f"\n{RED}[X] {e}{RESET}")
        print("  [error] traceback suppressed — see message above", flush=True)


def _train_from_scratch():
    print(f"\n{BOLD}{RED}⚠ TRAIN ALL AGAIN — wipes {SYMBOL} @ {TF_LABEL} models, retrains.{RESET}")
    print(f"  ({GREEN}Other pairs are NOT affected. GitHub backup stays intact.{RESET})")
    if not _confirm(f"  Type 'y' to confirm: "):
        print(f"  {YELLOW}cancelled{RESET}"); return
    rid = f"{SYMBOL.replace('-','_')}_{TF_LABEL}"
    target = CFG.get("target_total_candles", 100_000)
    try: ck_mod.reset(SYMBOL, TF_LABEL)
    except Exception: pass
    for direction in ("LONG", "SHORT"):
        for count in (10000, 30000, 60000, 100000, 200000, target):
            try:
                key = f"perm/{SYMBOL.replace('-','_')}/{TF_LABEL}/{direction.lower()}/{count}/_index"
                STORE.put_json(key, {"classical": {}, "dl": {}, "nn": {}, "wiped": True})
            except Exception: pass
    from train_pipeline import train_with_checkpoint
    try:
        train_with_checkpoint(force=True)
    except KeyboardInterrupt:
        print(f"\n{YELLOW}[!] Stopped — resume from menu [1].{RESET}")


def _fast_mode_current():
    """WhiteDemon_V8.2: TRUE fast mode — pure inference, ~30 seconds.
    If models missing for current pair, offers to run full_pipeline first."""
    print(f"\n{BOLD}{CYAN}⚡ FAST MODE (inference only, ~30s) — {SYMBOL} @ {TF_LABEL}{RESET}")
    print(f"  Loads cached committee · fetches 4k live candles · runs inference\n")
    st = _get_training_status()
    miss = st["n_total"] - st["n_done"]
    if miss > 0:
        print(f"  {YELLOW}⚠ {miss} models missing. Smart FAST will train only missing models and skip completed ones.{RESET}")
    # V10.6 SMART FAST — ensure missing models/bundles only if needed, then unified analyze
    subprocess.call([sys.executable, "smart_analysis.py"])


# ════════════════════════════════════════════════════════════════════
# MENU 2 — CHANGE PAIR & TIMEFRAME
# ════════════════════════════════════════════════════════════════════
def menu_change_pair():
    print(f"\n{BOLD}{CYAN}━━ [2] CHANGE PAIR & TIMEFRAME ━━{RESET}")
    print(f"  Currently: {BOLD}{SYMBOL} @ {TF_LABEL}{RESET}  (PAIR_ID={PAIR_ID}, TF_ID={TF_ID})\n")

    # Show pairs in groups of 30 per page
    print(f"  {BOLD}Pairs:{RESET}")
    cols = 3
    for i in range(0, len(PAIRS), cols):
        line = "  "
        for p in PAIRS[i:i+cols]:
            mark = "★" if p["symbol"] == SYMBOL else " "
            line += f"{mark}{p['id']:>3}.{p['symbol']:<11}"
        print(line)

    pid = _ask(f"\n  PAIR_ID [default {PAIR_ID}]: ", str(PAIR_ID))
    try: pid = int(pid)
    except: pid = PAIR_ID

    # Optional availability probe (only for non-built-in pairs)
    if pid > 18:
        try:
            from core.pairs_ext import probe_pair_available, has_ccxt
            chosen = next((p for p in PAIRS if p["id"] == pid), None)
            if chosen:
                print(f"  Probing {chosen['symbol']} availability…")
                ok, src = probe_pair_available(chosen["symbol"])
                if ok:
                    print(f"  {GREEN}✓ found on: {src}{RESET}")
                else:
                    if not has_ccxt():
                        print(f"  {YELLOW}⚠ ccxt not installed AND yahoo has no data.{RESET}")
                        print(f"    Install:  pip install ccxt")
                    else:
                        print(f"  {RED}✗ pair not available on Binance/Bybit/OKX/KuCoin or Yahoo.{RESET}")
                    if not _confirm(f"    Use this pair anyway? [y/N]: "):
                        return
        except Exception:
            pass

    print(f"\n  {BOLD}Timeframes:{RESET}")
    for t in TIMEFRAMES:
        mark = "★" if t["label"] == TF_LABEL else " "
        print(f"    {mark}{t['id']}. {t['label']}")
    tid = _ask(f"\n  TF_ID [default {TF_ID}]: ", str(TF_ID))
    try: tid = int(tid)
    except: tid = TF_ID

    if pid == PAIR_ID and tid == TF_ID:
        print(f"  {GREY}(no change){RESET}"); return
    _persist_pair_tf(pid, tid)
    print(f"\n  {GREEN}✓ Switched to PAIR_ID={pid} TF_ID={tid}{RESET}")
    print(f"  Re-launching with new pair…\n")
    os.execv(sys.executable, [sys.executable] + sys.argv)


def _persist_pair_tf(pid: int, tid: int):
    import re, json as _json
    _root = os.path.dirname(os.path.abspath(__file__))
    for d in (_root, os.getcwd(), "/kaggle/working/crypto-v23",
              "/kaggle/working", "/content/crypto-v23", "/content"):
        sp = os.path.join(d, ".setup_state.json")
        if os.path.exists(sp):
            try:
                with open(sp) as f: st = _json.load(f)
                st["PAIR_ID"] = int(pid); st["TF_ID"] = int(tid)
                with open(sp, "w") as f: _json.dump(st, f, indent=2)
            except Exception: pass
        cp = os.path.join(d, "config.py")
        if os.path.exists(cp):
            try:
                s = open(cp).read()
                s = re.sub(r"PAIR_ID\s*=\s*\d+", f"PAIR_ID = {pid}", s, count=1)
                s = re.sub(r"TF_ID\s*=\s*\d+",   f"TF_ID = {tid}",   s, count=1)
                with open(cp, "w") as f: f.write(s)
            except Exception: pass


# ════════════════════════════════════════════════════════════════════
# MENU 3 — TRAIN BIT-BY-BIT (incremental)
# ════════════════════════════════════════════════════════════════════
def menu_bit_by_bit():
    print(f"\n{BOLD}{CYAN}━━ [3] TRAIN BIT-BY-BIT · {SYMBOL} @ {TF_LABEL} ━━{RESET}\n")

    # Show previous trained batches
    batches = _list_incremental_batches()
    if batches:
        print(f"  {BOLD}Previously trained batches:{RESET}")
        for i, b in enumerate(batches, 1):
            print(f"    [{i}] {b['count']:>7,} candles  range≈{b.get('range','?')}  saved {b.get('at','?')[:10]}")
        print()

    print(f"  [1] 📅 Train on SPECIFIC candle count (you pick)")
    print(f"  [2] ⏭  Train NEXT batch (continues older from previous batch)")
    print(f"  [3] ▶ Resume from a previous batch (pick from list above)")
    print(f"  [4] 🗑 WIPE all incremental training for this pair")
    print(f"  [0] ↩ back")
    ch = _ask(f"\n  {BOLD}Pick: {RESET}")

    if ch == "1":
        n = _ask(f"  How many candles to train on? [default 10000]: ", "10000")
        try: n = int(n)
        except: n = 10000
        subprocess.call([sys.executable, "train_incremental.py", str(n), "--new"])
    elif ch == "2":
        if not batches:
            print(f"  {YELLOW}No previous batch found — use option [1] first.{RESET}"); return
        n = _ask(f"  Candles for NEXT batch (going further back)? [default 10000]: ", "10000")
        try: n = int(n)
        except: n = 10000
        subprocess.call([sys.executable, "train_incremental.py", str(n), "--extend"])
    elif ch == "3":
        if not batches:
            print(f"  {YELLOW}No batches to resume.{RESET}"); return
        idx = _ask(f"  Pick batch # [1-{len(batches)}]: ")
        try:
            bi = int(idx) - 1
            if 0 <= bi < len(batches):
                subprocess.call([sys.executable, "train_incremental.py",
                                 str(batches[bi]["count"]), "--resume"])
        except: pass
    elif ch == "4":
        if not _confirm(f"  {RED}WIPE all incremental training for {SYMBOL} @ {TF_LABEL}? [y/N]: {RESET}"):
            return
        rid = f"{SYMBOL.replace('-','_')}_{TF_LABEL}"
        for cnt in (10000, 30000, 60000, 100000, 200000):
            for direction in ("LONG", "SHORT"):
                try:
                    key = f"perm/{SYMBOL.replace('-','_')}/{TF_LABEL}/{direction.lower()}/{cnt}/_index"
                    STORE.put_json(key, {"deleted": True, "classical": {}, "dl": {}})
                except Exception: pass
        print(f"  {GREEN}✓ incremental training wiped{RESET}")


def _list_incremental_batches() -> list:
    """Find which candle-count batches have been trained for this pair."""
    out = []
    for cnt in (10000, 30000, 60000, 100000, 200000, 300000):
        key_long = f"perm/{SYMBOL.replace('-','_')}/{TF_LABEL}/long/{cnt}/_index"
        idx = STORE.get_json(key_long)
        if idx and not idx.get("deleted") and (idx.get("classical") or idx.get("dl")):
            out.append({"count": cnt,
                        "at": idx.get("_saved_at", ""),
                        "range": "—"})
    return out


# ════════════════════════════════════════════════════════════════════
# MENU 4 — TRAIN SPECIFIC MODELS  (big submenu)
# ════════════════════════════════════════════════════════════════════
def menu_specific():
    while True:
        print(f"\n{BOLD}{CYAN}━━ [4] TRAIN SPECIFIC MODELS · {SYMBOL} @ {TF_LABEL} ━━{RESET}\n")
        print(f"  {BOLD}TRAIN:{RESET}")
        print(f"   [1] 🎯 Train CLASSICAL  (LONG + SHORT)   — 9 models × 2 directions")
        print(f"   [2] 🧠 Train ALL DL     (LONG + SHORT)   — 14 nets × 2 directions")
        print(f"   [3] ⬆  Train ALL for LONG  (cls + DL)")
        print(f"   [4] ⬇  Train ALL for SHORT (cls + DL)")
        print(f"   [5] 🧬 Train NEURAL nets (PriceReg / RL / SentimentNN / RegimeNN)")
        print(f"   [6] 📐 Train EXTRAS (Monte Carlo / Triple-Barrier / Meta-labeler / Prophet)")
        print(f"   [7] 🎚 Train SPECIFIC (pick LONG/SHORT/BOTH + pick models)")
        print(f"   [11] 🛡 Train SMART-SL Placement NN  (Bayesian wick-resistant stops)")
        print(f"   [12] ⚙  Configure Smart-SL aggressiveness (conservative/balanced/aggressive)")
        print()
        print(f"  {BOLD}ANALYSIS:{RESET}")
        print(f"   [8] 🧩 RUN COMPLETE ANALYSIS  (sub-menu: start / start-again / fast / trained-only)")
        print()
        print(f"  {BOLD}WIPE:{RESET}")
        print(f"   [9]  🗑  WIPE ALL models for {SYMBOL} @ {TF_LABEL}")
        print(f"   [10] 🗑  WIPE SOME (pick which to delete)")
        print(f"   [0] ↩ back")

        ch = _ask(f"\n  {BOLD}Pick: {RESET}")
        if ch == "0" or not ch: return
        if ch == "1":
            subprocess.call([sys.executable, "train_specific.py", "--direction", "BOTH",
                             "--classical", "lr,knn,rf,et,xgb,lgb,cat,hgb,mlp"])
        elif ch == "2":
            subprocess.call([sys.executable, "train_specific.py", "--direction", "BOTH",
                             "--dl", "lstm,bilstm,gru,tcn,wavenet,transformer,cnn1d,nbeats,mamba,patchtst,itransformer,frets,tft,mamba_pdf"])
        elif ch == "3":
            subprocess.call([sys.executable, "train_specific.py", "--missing", "--direction", "LONG"])
        elif ch == "4":
            subprocess.call([sys.executable, "train_specific.py", "--missing", "--direction", "SHORT"])
        elif ch == "5":
            _train_neural_only()
        elif ch == "6":
            _train_extras_only()
        elif ch == "7":
            _train_specific_picker()
        elif ch == "8":
            _menu_run_analysis()
        elif ch == "9":
            _wipe_specific_all()
        elif ch == "10":
            _wipe_specific_some()
        elif ch == "11":
            _train_sl_nn()
        elif ch == "12":
            _configure_smart_sl()


def _train_sl_nn():
    """WhiteDemon_V8.2: sub-menu for SL Placement NN — scratch / next-batch / list / wipe."""
    while True:
        print(f"\n{BOLD}{CYAN}━━ Smart-SL Placement NN · {SYMBOL} @ {TF_LABEL} ━━{RESET}")
        print(f"  Learns optimal SL distance per market state — avoids stop-loss hunts.")
        print(f"  All batches saved to Firebase → Supabase → GitHub (verified after write).\n")
        # Quick status snapshot
        subprocess.call([sys.executable, "train_sl_nn.py", "--list"])
        print()
        print(f"  {BOLD}TRAIN:{RESET}")
        print(f"   [1] 🆕 Train from SCRATCH (replaces existing — pick candle count)")
        print(f"   [2] ⏭  Train NEXT batch (fine-tune from previous + walk back N older bars)")
        print(f"   [3] 🎚 Train on SPECIFIC candle count (custom)")
        print()
        print(f"  {BOLD}MANAGE:{RESET}")
        print(f"   [4] 📋 List all batches saved (with timestamps + where saved)")
        print(f"   [5] 🗑 WIPE all SL-NN batches for {SYMBOL} @ {TF_LABEL}")
        print(f"   [0] ↩ back")
        ch = _ask(f"\n  {BOLD}Pick: {RESET}")
        if ch == "0" or not ch: return

        if ch in ("1", "2", "3"):
            mode = {"1": "scratch", "2": "next", "3": "specific"}[ch]
            print(f"\n  {BOLD}Candle count for this batch:{RESET}")
            print(f"   [1]  10,000  (~3 min, 20 epochs)")
            print(f"   [2]  30,000  (~8 min, 30 epochs)")
            print(f"   [3] 100,000  (~25 min, 50 epochs)")
            print(f"   [c]  custom")
            sub = _ask(f"\n   pick: ")
            presets = {"1": (10000, 20), "2": (30000, 30), "3": (100000, 50)}
            if sub in presets:
                cnd, eps = presets[sub]
            elif sub == "c":
                try:
                    cnd = int(_ask(f"   candles? [10000]: ", "10000"))
                    eps = int(_ask(f"   epochs?  [20]: ", "20"))
                except ValueError:
                    print(f"   {RED}invalid{RESET}"); continue
            else:
                print(f"   {RED}invalid{RESET}"); continue
            print(f"\n  Running:  python train_sl_nn.py --mode {mode} "
                  f"--candles {cnd} --epochs {eps}")
            subprocess.call([sys.executable, "train_sl_nn.py",
                             "--mode", mode,
                             "--candles", str(cnd),
                             "--epochs",  str(eps)])
        elif ch == "4":
            subprocess.call([sys.executable, "train_sl_nn.py", "--list"])
        elif ch == "5":
            subprocess.call([sys.executable, "train_sl_nn.py", "--wipe"])


def _configure_smart_sl():
    """WhiteDemon_V8.2: pick smart-SL aggressiveness preset."""
    print(f"\n{BOLD}{CYAN}━━ Smart-SL aggressiveness ━━{RESET}")
    print(f"  Current : {CFG.get('smart_sl_aggressiveness', 'balanced')}\n")
    print(f"  [1] conservative   — +0.5×ATR buffer, no liq-cluster check")
    print(f"  [2] balanced       — +1.0×ATR buffer, liq + wick + VP (RECOMMENDED)")
    print(f"  [3] aggressive     — +1.5×ATR buffer, also uses NN if trained")
    print(f"  [4] off            — use raw engine SL (no smart-SL)")
    print(f"  [0] cancel")
    ch = _ask(f"\n  {BOLD}Pick: {RESET}")
    mapping = {"1": "conservative", "2": "balanced", "3": "aggressive", "4": "off"}
    if ch not in mapping: return
    val = mapping[ch]
    # Persist to setup_state.json
    try:
        import json as _json, os as _os
        for d in (_os.path.dirname(_os.path.abspath(__file__)), _os.getcwd(),
                  "/kaggle/working/crypto-v23", "/content/crypto-v23"):
            p = _os.path.join(d, ".setup_state.json")
            if _os.path.exists(p):
                with open(p) as f: st = _json.load(f)
                st["smart_sl_aggressiveness"] = val
                with open(p, "w") as f: _json.dump(st, f, indent=2)
        CFG["smart_sl_aggressiveness"] = val
        print(f"  {GREEN}✓ smart_sl_aggressiveness = {val}{RESET}")
    except Exception as e:
        print(f"  {RED}save failed: {e}{RESET}")


def _train_neural_only():
    print(f"\n{BOLD}{CYAN}━━ Train Neural Networks · {SYMBOL} @ {TF_LABEL} ━━{RESET}")
    print(f"  Trains: PriceRegressionNN, RL Agent, SentimentNN, RegimeDetectorNN")
    if not _confirm(f"  Continue? [y/N]: "): return
    # These are inside engine's run_ml_committee → just kick a normal pipeline run
    from train_pipeline import train_with_checkpoint
    try: train_with_checkpoint(force=False)
    except Exception as e:
        print(f"  {RED}{e}{RESET}")


def _train_extras_only():
    print(f"\n{BOLD}{CYAN}━━ Train Extras · {SYMBOL} @ {TF_LABEL} ━━{RESET}")
    print(f"  Trains: Monte Carlo / Triple-Barrier / Meta-labeler / Prophet")
    if not _confirm(f"  Continue? [y/N]: "): return
    from train_pipeline import train_with_checkpoint
    try: train_with_checkpoint(force=False)
    except Exception as e:
        print(f"  {RED}{e}{RESET}")


def _train_specific_picker():
    d = _ask(f"  Direction (LONG/SHORT/BOTH) [BOTH]: ", "BOTH").upper()
    cls_in = _ask(f"  Classical names (comma, blank=skip): ")
    dl_in  = _ask(f"  DL names (comma, blank=skip): ")
    if not cls_in and not dl_in:
        print(f"  {YELLOW}nothing picked.{RESET}"); return
    args = [sys.executable, "train_specific.py", "--direction", d]
    if cls_in: args += ["--classical", cls_in]
    if dl_in:  args += ["--dl", dl_in]
    subprocess.call(args)


def _menu_run_analysis():
    print(f"\n{BOLD}{CYAN}━━ Run Complete Analysis · {SYMBOL} @ {TF_LABEL} ━━{RESET}")
    print(f"\n  [1] 🧱 FULL PIPELINE  (train/refresh missing pieces, then legacy full analysis)")
    print(f"  [2] 🔁 FULL PIPELINE AGAIN  (same as 1)")
    print(f"  [3] ⚡ FAST MODE  (pure cached-model inference, no training)")
    print(f"  [4] 🎯 CACHE-ONLY ANALYZE  (same as fast; no training)")
    print(f"  [5] 🧠 SMART ANALYSIS  (RECOMMENDED: ensure missing/bundles, then unified analyzer)")
    print(f"  [0] ↩ back")
    ch = _ask(f"\n  {BOLD}Pick: {RESET}")
    if ch in ("1", "2"):
        # Full pipeline kept for users who want the old full refresh/training flow.
        # Its intermediate/legacy analysis may differ from V10 unified analyze.
        subprocess.call([sys.executable, "full_pipeline.py"])
    elif ch in ("3", "4"):
        # Pure fast analyzer: no training. Best only when bundles/models are already complete.
        subprocess.call([sys.executable, "analyze.py"])
    elif ch == "5":
        # Recommended: combines full-pipeline reliability with unified final analyze.
        subprocess.call([sys.executable, "smart_analysis.py"])


def _wipe_specific_all():
    print(f"\n  {RED}WIPE ALL models for {SYMBOL} @ {TF_LABEL}{RESET}")
    if not _confirm(f"  Type 'y' to confirm: "): return
    if not _confirm(f"  {RED}Really? Type 'y' AGAIN: {RESET}"): return
    rid = f"{SYMBOL.replace('-','_')}_{TF_LABEL}"
    target = CFG.get("target_total_candles", 100_000)
    try: ck_mod.reset(SYMBOL, TF_LABEL)
    except Exception: pass
    for direction in ("LONG", "SHORT"):
        for cnt in (10000, 30000, 60000, 100000, 200000, target):
            try:
                key = f"perm/{SYMBOL.replace('-','_')}/{TF_LABEL}/{direction.lower()}/{cnt}/_index"
                STORE.put_json(key, {"deleted": True, "classical": {}, "dl": {}})
            except Exception: pass
    print(f"  {GREEN}✓ wiped{RESET}")


def _wipe_specific_some():
    d = _ask(f"  Direction (LONG/SHORT/BOTH) [BOTH]: ", "BOTH").upper()
    names = _ask(f"  Model names to wipe (comma, e.g. mamba,nbeats,xgb): ")
    if not names:
        print(f"  {YELLOW}nothing picked.{RESET}"); return
    target = CFG.get("target_total_candles", 100_000)
    from core import per_model_cache as pmc
    dirs = ["LONG", "SHORT"] if d == "BOTH" else [d]
    for direction in dirs:
        for name in [n.strip() for n in names.split(",") if n.strip()]:
            try:
                # mark as not-trained in index
                key = f"perm/{SYMBOL.replace('-','_')}/{TF_LABEL}/{direction.lower()}/{target}/_index"
                idx = STORE.get_json(key) or {"classical": {}, "dl": {}}
                idx.setdefault("classical", {}).pop(name, None)
                idx.setdefault("dl", {}).pop(name, None)
                STORE.put_json(key, idx)
                print(f"    removed {direction}/{name}")
            except Exception as e:
                print(f"    {YELLOW}{direction}/{name} failed: {e}{RESET}")
    print(f"  {GREEN}✓ done — re-run training to re-create.{RESET}")


# ════════════════════════════════════════════════════════════════════
# MENU 5 — BACKTEST
# ════════════════════════════════════════════════════════════════════
def menu_backtest():
    while True:
        print(f"\n{BOLD}{CYAN}━━ [5] BACKTEST · {SYMBOL} @ {TF_LABEL} ━━{RESET}")
        print(f"  (Backtest runs ONLY on currently selected pair)\n")
        print(f"  [1] 🎯 Backtest SPECIFIC model on SPECIFIC candles")
        print(f"  [2] 📊 Backtest ALL models on user-chosen time")
        print(f"  [3] 🧩 Backtest BIT-BY-BIT  (10 steps — run each in its own cell)")
        print(f"  [4] 🗑 WIPE backtest data")
        print(f"  [0] ↩ back")
        ch = _ask(f"\n  {BOLD}Pick: {RESET}")
        if ch == "0" or not ch: return

        if ch == "1":
            model = _ask(f"  Model name (e.g. xgb, lstm, mamba): ")
            if not model: continue
            cls_set = {"lr","knn","rf","et","xgb","lgb","cat","hgb","mlp"}
            n = _ask(f"  How many candles? [default 5000]: ", "5000")
            cmd = [sys.executable, "backtest_run.py", "--use-cached-models"]
            if model in cls_set:
                cmd += ["--only-classical", model]
            else:
                cmd += ["--only-dl", model]
            if n.isdigit():
                # convert candles to "years" approximation if possible (just pass)
                cmd += ["--candles", n]
            subprocess.call(cmd)
        elif ch == "2":
            years = _ask(f"  How many years to backtest? [default 3]: ", "3")
            cmd = [sys.executable, "backtest_run.py", "--use-cached-models"]
            if years.isdigit(): cmd += ["--years", years]
            subprocess.call(cmd)
        elif ch == "3":
            _backtest_bit_by_bit()
        elif ch == "4":
            if not _confirm(f"  {RED}WIPE backtest data for {SYMBOL} @ {TF_LABEL}? [y/N]: {RESET}"):
                continue
            rid = f"{SYMBOL.replace('-','_')}_{TF_LABEL}"
            for key in (f"backtest_{rid}", f"backtest_ck_{rid}"):
                try: STORE.put_json(key, {"deleted": True})
                except Exception: pass
            print(f"  {GREEN}✓ backtest data wiped{RESET}")


_BACKTEST_STEPS = [
    ("step1_classical_long",  "Train CLASSICAL  LONG"),
    ("step2_classical_short", "Train CLASSICAL  SHORT"),
    ("step3_dl_long",         "Train DL        LONG"),
    ("step4_dl_short",        "Train DL        SHORT"),
    ("step5_neural",          "Train Neural NNs (PriceReg/RL/Sentiment/Regime)"),
    ("step6_extras",          "Train Extras (Monte Carlo / Triple-Barrier / Meta)"),
    ("step7_walkforward_a",   "Walk-forward folds 1-3"),
    ("step8_walkforward_b",   "Walk-forward folds 4-6"),
    ("step9_walkforward_c",   "Walk-forward folds 7-9"),
    ("step10_combine",        "COMBINE all + write final report → GitHub"),
]


def _backtest_bit_by_bit():
    rid = f"{SYMBOL.replace('-','_')}_{TF_LABEL}"
    ck_key = f"backtest_bbb_{rid}"
    ck = STORE.get_json(ck_key) or {"done": []}
    done = set(ck.get("done", []))

    print(f"\n{BOLD}{CYAN}━━ BACKTEST BIT-BY-BIT · {SYMBOL} @ {TF_LABEL} ━━{RESET}")
    print(f"  Run each step in its OWN Colab/Kaggle cell — they save to {STORE.backend_name}.\n")
    for i, (sid, label) in enumerate(_BACKTEST_STEPS, 1):
        mark = f"{GREEN}✅{RESET}" if sid in done else "⏳"
        print(f"   [{i:>2}] {mark} {label}")
    print(f"   [0] ↩ back")
    ch = _ask(f"\n  {BOLD}Pick step to run: {RESET}")
    try:
        idx = int(ch) - 1
        if not (0 <= idx < len(_BACKTEST_STEPS)): return
    except: return
    sid, label = _BACKTEST_STEPS[idx]
    print(f"\n  Running step {idx+1}: {label} …")
    args = [sys.executable, "backtest_run.py", "--bbb-step", sid,
            "--use-cached-models"]
    rc = subprocess.call(args)
    if rc == 0:
        done.add(sid)
        ck["done"] = sorted(done)
        STORE.put_json(ck_key, ck)
        print(f"  {GREEN}✓ step '{sid}' marked done · saved to {STORE.backend_name}.{RESET}")
        if len(done) == len(_BACKTEST_STEPS):
            print(f"\n  {BOLD}{GREEN}🎉 ALL 10 STEPS DONE — combined report saved.{RESET}\n")


# ════════════════════════════════════════════════════════════════════
# MENU 6 — WIPE ALL (double-confirm + DELETE word)
# ════════════════════════════════════════════════════════════════════
def menu_wipe_everything():
    print(f"\n{BOLD}{RED}━━ [6] WIPE EVERYTHING ━━{RESET}")
    print(f"  This wipes from EVERY configured backend: {STORE.backend_name}")
    print(f"   - ALL JSON/database rows under data/ (models, checkpoints, dashboards, backtests, live/paper state)")
    print(f"   - ALL binary blobs under blobs/ (trained model bundles, raw data, dashboards, caches)")
    print(f"   - GitHub repo current branch is cleaned for data/ and blobs/ paths")
    print(f"\n  {YELLOW}This CANNOT be undone from the app.{RESET}")
    print(f"  {YELLOW}Note: GitHub old commit history is not rewritten; current repo files are removed.{RESET}")
    if not _confirm(f"\n  Confirm #1: type 'y' to proceed: "):
        print(f"  {YELLOW}cancelled.{RESET}"); return
    if not _confirm(f"  Confirm #2: type 'y' AGAIN: "):
        print(f"  {YELLOW}cancelled.{RESET}"); return
    word = _ask(f"  Final: type {BOLD}DELETE{RESET} (uppercase) to proceed: ")
    if word != "DELETE":
        print(f"  {GREEN}✓ NOT deleted. Your training is safe.{RESET}"); return

    print(f"\n  {RED}Wiping database JSON rows/files under data/...{RESET}")
    n_data = 0
    try:
        n_data = STORE.delete_prefix("data/", message="GLOBAL WIPE EVERYTHING: delete all data")
    except Exception as e:
        print(f"  {YELLOW}data/ wipe error: {str(e)[:200]}{RESET}")

    print(f"\n  {RED}Wiping binary blobs/model cache under blobs/...{RESET}")
    n_blobs = 0
    try:
        n_blobs = STORE.delete_prefix("blobs/", message="GLOBAL WIPE EVERYTHING: delete all blobs")
    except Exception as e:
        print(f"  {YELLOW}blobs/ wipe error: {str(e)[:200]}{RESET}")

    # Extra safety for legacy checkpoint helpers that may keep local in-memory/index state.
    try:
        for ck in (ck_mod.list_all_pending() + ck_mod.list_all_ready()):
            sym, tf = ck.get("symbol"), ck.get("tf_label")
            if sym and tf:
                try: ck_mod.reset(sym, tf)
                except Exception: pass
    except Exception:
        pass

    print(f"\n  {GREEN}{BOLD}✓ GLOBAL WIPE complete.{RESET}")
    print(f"  Removed current data paths from all reachable backends: data/ count≈{n_data}, blobs/ count≈{n_blobs}\n")


# ════════════════════════════════════════════════════════════════════
# MENU 7 — LIVE DASHBOARD
# ════════════════════════════════════════════════════════════════════
def menu_dashboard():
    print(f"\n{BOLD}{CYAN}━━ [7] LIVE DASHBOARD ━━{RESET}")
    print(f"  Options:")
    print(f"    [1] 🔁 Refresh dashboard payload (re-aggregate latest analyses)")
    print(f"    [2] 🧩 Run COLLECT ALL now (full audit + 4k live + push HTML)")
    print(f"    [3] 🌐 Start local web server (http://localhost:8000)")
    print(f"    [4] ⬇️  Download embed-HTML for offline viewing")
    print(f"    [0] ↩ back")
    ch = _ask(f"\n  {BOLD}Pick: {RESET}")
    rid = f"{SYMBOL.replace('-','_')}_{TF_LABEL}"
    html_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                             "frontend", "dashboard.html")
    if ch == "1":
        try: _build_dashboard_html(rid)
        except Exception as e: print(f"  {YELLOW}{e}{RESET}")
        # also push the html to storage
        if os.path.exists(html_path):
            try:
                with open(html_path, "rb") as f:
                    STORE.put_blob(f"dashboard_{rid}.html", f.read(), compress=False)
                print(f"  {GREEN}✓ Pushed dashboard HTML to {STORE.backend_name}.{RESET}")
            except Exception as e:
                print(f"  {YELLOW}push failed: {e}{RESET}")
    elif ch == "2":
        subprocess.call([sys.executable, "full_pipeline.py"])
    elif ch == "3":
        print(f"  Open  http://localhost:8000  in your browser …")
        subprocess.call([sys.executable, "server.py"])
    elif ch == "4":
        # collect_all writes embedded HTML; just point to it
        if os.path.exists(html_path):
            print(f"  Local file: {html_path}")
            print(f"  Open it directly in your browser (file://…), no server needed.")
        else:
            print(f"  {YELLOW}dashboard.html not found — run COLLECT ALL first.{RESET}")


def _build_dashboard_html(rid: str):
    """Fetch latest analyses + checkpoints from STORE, inject into dashboard.html."""
    final = STORE.get_json(f"final_{rid}")
    bt    = STORE.get_json(f"backtest_{rid}")
    payload = {
        "symbol": SYMBOL, "tf": TF_LABEL,
        "final": final or {}, "backtest": bt or {},
        "generated_at": __import__("datetime").datetime.utcnow().isoformat() + "Z",
    }
    # Save the JSON to storage so dashboard can fetch it via JS
    STORE.put_json(f"dashboard_data_{rid}", payload)
    # Save a global pointer too
    STORE.put_json("dashboard_data", payload)


# ════════════════════════════════════════════════════════════════════
# MENU 8 — SHOW ALL TRAINED PAIRS
# ════════════════════════════════════════════════════════════════════
def menu_show_trained():
    print(f"\n{BOLD}{CYAN}━━ [8] ALL TRAINED PAIRS (across {STORE.backend_name}) ━━{RESET}\n")
    ready   = ck_mod.list_all_ready()
    pending = ck_mod.list_all_pending()
    rows = []
    seen = set()
    for r in ready:
        k = (r["symbol"], r["tf_label"])
        if k in seen: continue
        seen.add(k)
        rows.append({"symbol": r["symbol"], "tf": r["tf_label"],
                     "status": "✅ COMPLETE", "missing": 0,
                     "at": r.get("last_update", "?")[:16]})
    for p in pending:
        k = (p["symbol"], p["tf_label"])
        if k in seen: continue
        seen.add(k)
        n_done = sum(1 for s in p.get("stages", {}).values() if s.get("done"))
        n_total = len(p.get("stages", {})) or 11
        rows.append({"symbol": p["symbol"], "tf": p["tf_label"],
                     "status": f"🔄 PARTIAL", "missing": n_total - n_done,
                     "at": p.get("last_update", "?")[:16]})

    if not rows:
        print(f"  (no trained pairs found on {STORE.backend_name})\n")
        return

    print(f"   #   Pair          TF      Status         Missing  Last update")
    print(f"   ─── ───────────── ─────── ────────────── ───────  ────────────────")
    for i, r in enumerate(rows, 1):
        print(f"  [{i:>2}] {r['symbol']:<13} {r['tf']:<7} {r['status']:<14} {r['missing']:>3}    {r['at']}")
    print(f"   [0] ↩ back\n")
    ch = _ask(f"  {BOLD}Pick #: {RESET}")
    try:
        idx = int(ch) - 1
        if not (0 <= idx < len(rows)): return
    except: return

    sel = rows[idx]
    # switch to that pair if not already current
    if sel["symbol"] != SYMBOL or sel["tf"] != TF_LABEL:
        pid = next((p["id"] for p in PAIRS if p["symbol"] == sel["symbol"]), PAIR_ID)
        tid = next((t["id"] for t in TIMEFRAMES if t["label"] == sel["tf"]), TF_ID)
        _persist_pair_tf(pid, tid)
        print(f"  {GREEN}✓ switched to {sel['symbol']} @ {sel['tf']}{RESET}")
        print(f"  Re-launching to run analysis on this pair…\n")
        os.execv(sys.executable, [sys.executable, "run.py", "_analyze_now"])

    # Already current pair — run the same unified analyzer used by FAST MODE.
    # Do not call full_pipeline here; it can use a different analysis path and
    # produce contradictory direction vs analyze.py.
    if sel["missing"] > 0:
        print(f"  {YELLOW}{sel['missing']} models missing — smart analysis will ensure what is needed first.{RESET}")
    subprocess.call([sys.executable, "smart_analysis.py"])


# ════════════════════════════════════════════════════════════════════
# MENU 9 — TEST / CHANGE BACKENDS
# ════════════════════════════════════════════════════════════════════
def menu_test_backends():
    print(f"\n{BOLD}{CYAN}━━ [9] BACKEND TEST / CHANGE CREDENTIALS ━━{RESET}\n")
    print(f"  Active chain: {BOLD}{STORE.backend_name}{RESET}\n")
    print(f"  [1] 🔍 Test all backends now (ping + read-back)")
    print(f"  [2] ✏  Re-run setup.py to change credentials")
    print(f"  [3] 🔥 GPU / CUDA check")
    print(f"  [0] ↩ back")
    ch = _ask(f"\n  {BOLD}Pick: {RESET}")
    if ch == "1":
        _ping_all_backends()
    elif ch == "2":
        subprocess.call([sys.executable, "setup.py"])
    elif ch == "3":
        _gpu_check()


def _ping_all_backends():
    if not STORE.backends:
        print(f"  {RED}No backends configured.{RESET}"); return
    import datetime as _dt
    payload = {"ping": True, "ts": _dt.datetime.utcnow().isoformat() + "Z"}
    body = json.dumps(payload).encode()
    for b in STORE.backends:
        print(f"\n  Testing {BOLD}{b.name}{RESET} …")
        try:
            ok = b.put("data/_ping.json", body, "ping")
            raw = b.get("data/_ping.json") if ok else None
            if ok and raw:
                print(f"    {GREEN}✓ read+write OK{RESET}")
            else:
                print(f"    {YELLOW}⚠ write OK but read returned nothing{RESET}")
        except Exception as e:
            msg = str(e)[:200]
            print(f"    {RED}✗ {msg}{RESET}")
            if "permission" in msg.lower():
                print(f"    {YELLOW}→ Fix: re-run setup.py and follow the rules-paste instructions{RESET}")


def _gpu_check():
    print(f"\n{BOLD}{CYAN}━━ GPU / CUDA status ━━{RESET}\n")
    try:
        from core.cuda_safe import print_status, verify_cuda_works
        from core import cuda_safe
        cuda_safe._CUDA_STATUS["verified"] = False
        verify_cuda_works(quiet=False)
        print_status()
    except Exception as e:
        print(f"  {RED}cuda_safe failed: {e}{RESET}")
    try:
        import torch
        print(f"  torch                 : {torch.__version__}")
        print(f"  torch.cuda.available  : {torch.cuda.is_available()}")
        print(f"  device_count          : {torch.cuda.device_count()}")
        if torch.cuda.is_available():
            for i in range(torch.cuda.device_count()):
                p = torch.cuda.get_device_properties(i)
                print(f"  device[{i}]: {p.name}  sm_{p.major}{p.minor}  {p.total_memory/1024**3:.1f} GB")
    except Exception as e:
        print(f"  {RED}{e}{RESET}")


# ════════════════════════════════════════════════════════════════════
# MENU 11 — COLLECT ALL  (NEW WhiteDemon_V8.2)
# ════════════════════════════════════════════════════════════════════
def menu_collect_all():
    """Train every missing model (committee + neural NNs + Monte Carlo +
    Triple-Barrier + Meta-labeler + Prophet + position sizing + regime),
    fetch 4k live candles, run full analysis, push setup to ALL backends
    AND embed into local HTML dashboard. Leaves nothing undone."""
    print(f"\n{BOLD}{CYAN}━━ [11] COLLECT ALL · {SYMBOL} @ {TF_LABEL} ━━{RESET}")
    print(f"  This will:")
    print(f"    • audit every model index")
    print(f"    • train ANY missing committee model (classical + DL, LONG + SHORT)")
    print(f"    • force-run extras: Neural NNs / Monte Carlo / Triple-Barrier /")
    print(f"      Meta-labeler / Prophet / position sizing / Kelly / regime detector")
    print(f"    • fetch 4,000 LATEST live candles")
    print(f"    • run full committee analysis on them")
    print(f"    • push the trade setup to {STORE.backend_name}")
    print(f"    • embed the data into frontend/dashboard.html so it opens locally\n")
    if not _confirm(f"  {BOLD}Proceed? [y/N]: {RESET}"):
        print(f"  {YELLOW}cancelled{RESET}"); return
    # WhiteDemon_V8.2: use the explicit 10-step full pipeline (no slim cache shortcut)
    subprocess.call([sys.executable, "full_pipeline.py"])


# ════════════════════════════════════════════════════════════════════
# MENU 12 — AUTO-TRADER (24/7 loop)  WhiteDemon_V8.2
# ════════════════════════════════════════════════════════════════════
def menu_autotrader():
    while True:
        try:
            from live.credentials import (get_autotrader_pairs,
                                            upsert_autotrader_pair,
                                            remove_autotrader_pair)
        except Exception as e:
            print(f"\n{RED}live/ module unavailable: {e}{RESET}"); return
        pairs = get_autotrader_pairs()
        print(f"\n{BOLD}{CYAN}━━ [12] AUTO-TRADER · 24/7 LOOP ━━{RESET}\n")
        if pairs:
            print(f"  {BOLD}Configured pairs:{RESET}")
            print(f"   #  | Pair         | TF   | Enabled | Alerts | Orders | Exchange | Lev | Risk%")
            print(f"   ── | ──────────── | ──── | ─────── | ────── | ────── | ──────── | ─── | ─────")
            for i, p in enumerate(pairs, 1):
                en  = "✓"  if p.get("enabled",True)        else " "
                al  = "✓"  if p.get("send_alerts",True)    else " "
                od  = "✓"  if p.get("place_orders",False)  else " "
                print(f"  {i:>2}  | {p.get('symbol','?'):<12} | {p.get('tf','?'):<4} "
                      f"|    {en}    |   {al}    |   {od}    | "
                      f"{p.get('exchange','—'):<8} | {p.get('leverage',3):>3} | "
                      f"{p.get('risk_pct',1.0):>4.1f}")
        else:
            print(f"  {GREY}(no pairs configured yet){RESET}")
        print()
        print(f"  [1] ▶  START auto-trader loop  (foreground; Ctrl-C to stop)")
        print(f"  [2] ➿  RUN ONCE  (single tick, exit)")
        print(f"  [3] ➕ ADD pair to auto-trader")
        print(f"  [4] ⚙  EDIT pair config (toggle enabled/alerts/orders)")
        print(f"  [5] 🗑 REMOVE pair from auto-trader")
        print(f"  [6] 📋 View open positions (live exchange query)")
        print(f"  [7] 🧪 SEND TEST alert (verify Discord/Telegram/webhook)")
        print(f"  [0] ↩ back")
        ch = _ask(f"\n  {BOLD}Pick: {RESET}")
        if ch == "0" or not ch: return
        if ch == "1":
            print(f"\n  {CYAN}Starting auto-trader … press Ctrl-C to stop.{RESET}\n")
            subprocess.call([sys.executable, "-m", "live.autotrader"])
        elif ch == "2":
            subprocess.call([sys.executable, "-m", "live.autotrader", "--once"])
        elif ch == "3":
            _add_autotrader_pair()
        elif ch == "4":
            _edit_autotrader_pair(pairs)
        elif ch == "5":
            _remove_autotrader_pair(pairs)
        elif ch == "6":
            _view_live_positions(pairs)
        elif ch == "7":
            _send_test_alert()


def _add_autotrader_pair():
    print(f"\n  {GREY}You do NOT need to set SL/TP manually — bot computes them")
    print(f"  from the model setup AND auto-manages multi-TP + breakeven over")
    print(f"  the lifecycle of the trade (TP1→BE, TP2→trail to TP1, TP3→full close).{RESET}\n")
    sym = _ask(f"  Symbol (e.g. BTC-USD): ").upper()
    if not sym: return
    tf  = _ask(f"  Timeframe (1m/5m/15m/30m/1h/4h/1d): ").lower()
    if tf not in {"1m","3m","5m","15m","30m","1h","4h","1d"}:
        print(f"  {RED}invalid tf{RESET}"); return
    exch = _ask(f"  Exchange [bybit]: ", "bybit").lower()
    lev  = _ask(f"  Leverage [3]: ", "3")
    risk = _ask(f"  Risk % per trade [1.0]: ", "1.0")
    mwin = _ask(f"  Minimum win-prob to enter [0.55]: ", "0.55")
    al   = _ask(f"  Send alerts? (y/N) [y]: ", "y").lower() == "y"
    od   = _ask(f"  Place REAL orders? (y/N) [N]: ", "n").lower() == "y"
    dry  = False
    if od:
        dry = _ask(f"  Dry-run mode (compute size but don't send)? (y/N): ", "n").lower() == "y"
    wk   = _ask(f"  Webhook auth key (for Altrady/Signum, blank=skip): ")
    cfg = {"symbol": sym, "tf": tf, "enabled": True,
           "exchange": exch, "leverage": int(lev or 3),
           "risk_pct": float(risk or 1.0),
           "min_win_prob": float(mwin or 0.55),
           "send_alerts": al, "place_orders": od,
           "dry_run": dry, "webhook_key": wk}
    from live.credentials import upsert_autotrader_pair
    if upsert_autotrader_pair(cfg):
        print(f"  {GREEN}✓ added {sym}@{tf}{RESET}")
    else:
        print(f"  {RED}✗ save failed{RESET}")


def _edit_autotrader_pair(pairs):
    if not pairs: print(f"  {YELLOW}no pairs{RESET}"); return
    idx = _ask(f"  pair # to edit: ")
    try: i = int(idx) - 1
    except: return
    if not (0 <= i < len(pairs)): return
    p = dict(pairs[i])
    print(f"  Current: {p}")
    print(f"  [1] toggle enabled")
    print(f"  [2] toggle send_alerts")
    print(f"  [3] toggle place_orders")
    print(f"  [4] toggle dry_run")
    print(f"  [5] change leverage")
    print(f"  [6] change risk_pct")
    print(f"  [7] change min_win_prob")
    ch = _ask(f"  pick: ")
    if   ch == "1": p["enabled"]      = not p.get("enabled", True)
    elif ch == "2": p["send_alerts"]  = not p.get("send_alerts", True)
    elif ch == "3": p["place_orders"] = not p.get("place_orders", False)
    elif ch == "4": p["dry_run"]      = not p.get("dry_run", False)
    elif ch == "5":
        p["leverage"] = int(_ask(f"  new leverage [{p.get('leverage',3)}]: ",
                                  str(p.get('leverage',3))))
    elif ch == "6":
        p["risk_pct"] = float(_ask(f"  new risk_pct [{p.get('risk_pct',1.0)}]: ",
                                    str(p.get('risk_pct',1.0))))
    elif ch == "7":
        p["min_win_prob"] = float(_ask(f"  new min_win_prob [{p.get('min_win_prob',0.55)}]: ",
                                        str(p.get('min_win_prob',0.55))))
    else: return
    from live.credentials import upsert_autotrader_pair
    if upsert_autotrader_pair(p):
        print(f"  {GREEN}✓ updated: {p}{RESET}")


def _remove_autotrader_pair(pairs):
    if not pairs: print(f"  {YELLOW}no pairs{RESET}"); return
    idx = _ask(f"  pair # to remove: ")
    try: i = int(idx) - 1
    except: return
    if not (0 <= i < len(pairs)): return
    p = pairs[i]
    from live.credentials import remove_autotrader_pair
    if remove_autotrader_pair(p["symbol"], p["tf"]):
        print(f"  {GREEN}✓ removed {p['symbol']}@{p['tf']}{RESET}")


def _view_live_positions(pairs):
    try:
        from live.exchange import get_open_positions, get_balance
    except Exception as e:
        print(f"  {YELLOW}{e}{RESET}"); return
    exchanges = {p.get("exchange") for p in pairs if p.get("exchange")}
    if not exchanges:
        print(f"  {YELLOW}no exchange configured on any pair{RESET}"); return
    for ex in exchanges:
        print(f"\n  {BOLD}━━ {ex.upper()} ━━{RESET}")
        try:
            bal = get_balance(ex)
            print(f"   free USDT: {bal:.2f}")
            pos = get_open_positions(ex)
            if not pos:
                print(f"   (no open positions)")
            for p in pos:
                print(f"   • {p['symbol']:<14} {p['side']:<5} size={p['size']:.6g} "
                      f"entry={p['entry']:.6g} mark={p['mark']:.6g} pnl=${p['pnl']:+.2f}")
        except Exception as e:
            print(f"   {YELLOW}{e}{RESET}")


def _send_test_alert():
    from live.alerts import dispatch_all
    test_signal = {
        "symbol":   SYMBOL, "tf": TF_LABEL,
        "direction": "LONG", "verdict": "TEST_ALERT",
        "win_prob": 0.68, "entry": 100.0, "sl": 98.5, "tp1": 105.0,
        "tp2": 107.0, "tp3": 110.0, "rr1": 3.33,
        "smart_sl_chosen": "test_run",
        "source": "menu-test",
    }
    print(f"\n  {CYAN}Sending TEST signal to all configured channels…{RESET}")
    res = dispatch_all(test_signal)
    print(f"\n  Results: {res}")


# ════════════════════════════════════════════════════════════════════
# MENU 13 — LIVE CREDENTIALS  (exchange keys + webhook URLs)  WhiteDemon_V8.2
# ════════════════════════════════════════════════════════════════════
def menu_live_creds():
    while True:
        from live.credentials import get_creds, save_creds
        creds = get_creds()
        print(f"\n{BOLD}{CYAN}━━ [13] LIVE CREDENTIALS (saved to git, not setup) ━━{RESET}\n")
        exchanges = creds.get("exchanges", {})
        webhooks  = creds.get("webhooks", {})
        tg        = creds.get("telegram", {})
        print(f"  {BOLD}Exchanges:{RESET}")
        for n in ("bybit", "binance", "okx", "kucoin", "bitfinex", "bitget"):
            c = exchanges.get(n, {})
            ok = "✓" if c.get("apiKey") else " "
            mode = "TESTNET" if c.get("testnet") else "live" if c.get("apiKey") else "—"
            print(f"   [{ok}] {n:<10}  {mode}")
        print(f"\n  {BOLD}Webhooks:{RESET}")
        for n in ("discord", "slack", "tradingview"):
            url = webhooks.get(n, "")
            ok = "✓" if url else " "
            display = (url[:35] + "…") if url else "—"
            print(f"   [{ok}] {n:<10}  {display}")
        print(f"   [{'✓' if tg.get('bot_token') else ' '}] telegram     "
              f"chat_id={tg.get('chat_id','—')}")
        print()
        print(f"  [1] Add/Edit EXCHANGE api key (Bybit/Binance/OKX/KuCoin/Bitfinex)")
        print(f"  [2] Add/Edit DISCORD webhook URL")
        print(f"  [3] Add/Edit TELEGRAM bot token + chat_id")
        print(f"  [4] Add/Edit GENERIC WEBHOOK (TradingView/Altrady/Signum/Wundertrading)")
        print(f"  [5] Add/Edit SLACK incoming webhook")
        print(f"  [6] 🧪 Test ALL configured channels with a fake signal")
        print(f"  [7] 🔍 Show RAW creds JSON (sanitized — first 6 chars only)")
        print(f"  [8] 🗑 WIPE all live creds (forces re-entry)")
        print(f"  [0] ↩ back")
        ch = _ask(f"\n  {BOLD}Pick: {RESET}")
        if ch == "0" or not ch: return
        if ch == "1":
            n = _ask(f"  Exchange name (bybit/binance/okx/kucoin/bitfinex/bitget): ").lower()
            if not n: continue
            api = _ask(f"  API key: ")
            sec = _ask(f"  Secret: ")
            pwd = _ask(f"  Password/passphrase (OKX only, blank=skip): ")
            test = _ask(f"  Testnet/sandbox? (y/N) [N]: ", "n").lower() == "y"
            mtype = _ask(f"  Market type (future/spot/swap) [future]: ", "future")
            save_creds({"exchanges": {n: {"apiKey": api, "secret": sec,
                                           "password": pwd, "testnet": test,
                                           "market_type": mtype}}})
            print(f"  {GREEN}✓ saved {n} creds{RESET}")
        elif ch == "2":
            url = _ask(f"  Discord webhook URL (https://discord.com/api/webhooks/...): ")
            save_creds({"webhooks": {"discord": url}})
            print(f"  {GREEN}✓ saved{RESET}")
        elif ch == "3":
            bt = _ask(f"  Telegram BOT TOKEN (from @BotFather): ")
            ci = _ask(f"  Telegram CHAT_ID (your user id or group id): ")
            save_creds({"telegram": {"bot_token": bt, "chat_id": ci}})
            print(f"  {GREEN}✓ saved{RESET}")
        elif ch == "4":
            print(f"  Examples:")
            print(f"    TradingView         : https://yourdomain.com/tv-webhook")
            print(f"    Altrady             : https://api.altrady.com/v1/signal/...")
            print(f"    Wundertrading       : https://api.wundertrading.com/bots/.../trigger")
            print(f"    Signum/Cryptohopper : copy from their dashboard")
            url = _ask(f"  Webhook URL: ")
            save_creds({"webhooks": {"tradingview": url}})
            print(f"  {GREEN}✓ saved (used as 'generic JSON' alert){RESET}")
        elif ch == "5":
            url = _ask(f"  Slack incoming webhook URL: ")
            save_creds({"webhooks": {"slack": url}})
            print(f"  {GREEN}✓ saved{RESET}")
        elif ch == "6":
            _send_test_alert()
        elif ch == "7":
            import json as _j
            def _redact(d):
                if not isinstance(d, dict): return d
                out = {}
                for k, v in d.items():
                    if isinstance(v, dict): out[k] = _redact(v)
                    elif isinstance(v, str) and len(v) > 8 and any(x in k.lower() for x in
                            ("token","secret","key","webhook","password")):
                        out[k] = v[:6] + "…" + v[-3:]
                    else: out[k] = v
                return out
            print(_j.dumps(_redact(creds), indent=2))
        elif ch == "8":
            if not _confirm(f"  {RED}WIPE all live creds? Type 'y': {RESET}"): continue
            save_creds({"exchanges": {}, "webhooks": {}, "telegram": {},
                        "autotrader_pairs": []})
            print(f"  {GREEN}✓ wiped{RESET}")


# ════════════════════════════════════════════════════════════════════
# MENU 14 — ALERTS (per-pair webhook subscriptions, TradingView-style) WhiteDemon_V8.2
# ════════════════════════════════════════════════════════════════════
def menu_alerts():
    while True:
        try:
            from live.alert_subs import (load_subs, upsert_sub, delete_sub,
                                          fire_sub, list_trained_pairs,
                                          _default_template,
                                          enrich_signal_for_template)
        except Exception as e:
            print(f"\n{RED}live/alert_subs unavailable: {e}{RESET}"); return
        subs = load_subs()
        print(f"\n{BOLD}{CYAN}━━ [14] ALERTS · per-pair webhooks ━━{RESET}")
        print(f"  Subscribe an alert to a trained pair → bot runs Fast Mode every bar")
        print(f"  close → fires your JSON template to your webhook URL.\n")
        if subs:
            print(f"   #  | Pair          | TF   | Enabled | Events    | URL (truncated)        | Last fire")
            print(f"   ── | ───────────── | ──── | ─────── | ───────── | ────────────────────── | ──────────────")
            for i, s in enumerate(subs, 1):
                en  = "✓" if s.get("enabled", True) else " "
                ev  = ",".join(s.get("events", ["entry","close"]))
                url = (s.get("webhook_url","") or "")[:22]
                lf  = (s.get("last_fire_at","") or "")[:16] or "never"
                print(f"  {i:>2}  | {s.get('pair','?'):<13} | {s.get('tf','?'):<4} "
                      f"|    {en}    | {ev:<9} | {url:<22} | {lf}")
        else:
            print(f"  {GREY}(no alert subscriptions yet){RESET}")
        print()
        print(f"  [1] ➕ ADD alert subscription for a trained pair")
        print(f"  [2] ✏  EDIT subscription")
        print(f"  [3] 🗑 DELETE subscription")
        print(f"  [4] 🧪 TEST FIRE — send a sample signal to a subscription")
        print(f"  [5] ▶  RUN BAR-CLOSE LOOP NOW (one tick for all enabled subs)")
        print(f"  [6] 📖 View template placeholders (full list)")
        print(f"  [0] ↩ back")
        ch = _ask(f"\n  {BOLD}Pick: {RESET}")
        if ch == "0" or not ch: return

        if ch == "1":
            _add_alert_sub()
        elif ch == "2":
            _edit_alert_sub(subs)
        elif ch == "3":
            _delete_alert_sub(subs)
        elif ch == "4":
            _test_fire_sub(subs)
        elif ch == "5":
            print(f"\n  {CYAN}Running one tick for all alert subscriptions …{RESET}")
            subprocess.call([sys.executable, "-c",
                              "from live.autotrader import run_subscription_pairs_once; "
                              "run_subscription_pairs_once()"])
        elif ch == "6":
            _show_template_help()


def _add_alert_sub():
    from live.alert_subs import list_trained_pairs, upsert_sub, _default_template
    trained = list_trained_pairs()
    if not trained:
        print(f"\n  {YELLOW}No FULLY TRAINED pairs found.{RESET}")
        print(f"  Train at least one pair via Menu 1 first, then come back.")
        return
    print(f"\n  {BOLD}TRAINED pairs:{RESET}")
    for i, p in enumerate(trained, 1):
        last = (p.get("last_update","") or "")[:16]
        print(f"   [{i:>2}] {p['symbol']:<14} {p['tf_label']:<6}  trained {last}")
    print(f"   [0]  cancel")
    idx = _ask(f"\n  Pick pair #: ")
    try: i = int(idx) - 1
    except ValueError: return
    if not (0 <= i < len(trained)): return
    p = trained[i]
    print(f"\n  Selected: {BOLD}{p['symbol']} @ {p['tf_label']}{RESET}\n")

    url = _ask(f"  Webhook URL (Discord/Altrady/Wundertrading/TradingView/custom): ")
    if not url:
        print(f"  {YELLOW}cancelled{RESET}"); return

    print(f"\n  Events to alert on:")
    print(f"   [1] ENTRY only            (just the trade signal)")
    print(f"   [2] ENTRY + ALL EXITS     {GREY}[recommended — includes TP1/TP2/TP3/BE/SL]{RESET}")
    print(f"   [3] ENTRY + breakeven + final close only")
    print(f"   [4] CUSTOM (pick events manually)")
    ev_ch = _ask(f"  Pick [1/2/3/4]: ", "2")
    if ev_ch == "1":
        events = ["entry"]
    elif ev_ch == "3":
        events = ["entry", "breakeven_set", "tp3_hit", "sl_hit"]
    elif ev_ch == "4":
        all_evs = ["entry","tp1_hit","breakeven_set","tp2_hit","tp3_hit","sl_hit"]
        print(f"  Available: {', '.join(all_evs)}")
        picked = _ask(f"  Comma-separated: ", "entry,tp1_hit,sl_hit")
        events = [e.strip() for e in picked.split(",") if e.strip() in all_evs]
        if not events: events = ["entry", "close"]
    else:
        # default = entry + all exit events (alias 'close' expands in fire_sub)
        events = ["entry", "tp1_hit", "breakeven_set", "tp2_hit", "tp3_hit", "sl_hit"]

    print(f"\n  JSON template (use placeholders like {{{{entry}}}} {{{{sl}}}} {{{{symbol}}}}):")
    print(f"  {GREY}Press Enter to use DEFAULT TradingView/Altrady format,")
    print(f"  or paste a SINGLE-LINE JSON, or 'm' for multi-line entry.{RESET}")
    t_ch = _ask(f"  Template [Enter=default / m=multiline / paste single-line]: ")
    if not t_ch:
        template = _default_template()
        print(f"  {GREY}using default template{RESET}")
    elif t_ch == "m":
        print(f"  Paste your JSON template, end with a line containing only 'END':")
        lines = []
        while True:
            try:
                ln = input()
            except (EOFError, KeyboardInterrupt):
                break
            if ln.strip() == "END": break
            lines.append(ln)
        template = "\n".join(lines)
    else:
        template = t_ch

    mwp = _ask(f"\n  Minimum win-prob to fire (0.50 = always, 0.65 = strict) [0.55]: ", "0.55")
    try: mwp = float(mwp)
    except: mwp = 0.55

    sub = {
        "pair":          p["symbol"],
        "tf":            p["tf_label"],
        "webhook_url":   url,
        "json_template": template,
        "events":        events,
        "min_win_prob":  mwp,
        "enabled":       True,
    }
    if upsert_sub(sub):
        print(f"\n  {GREEN}✓ alert subscription saved to git (Firebase + Supabase + GitHub){RESET}")
        print(f"  Next auto-trader tick will fire this sub when conditions hit.")
    else:
        print(f"  {RED}✗ save failed{RESET}")


def _edit_alert_sub(subs):
    if not subs: print(f"  {YELLOW}no subs{RESET}"); return
    idx = _ask(f"  sub # to edit: ")
    try: i = int(idx) - 1
    except: return
    if not (0 <= i < len(subs)): return
    s = dict(subs[i])
    print(f"\n  Current: {s.get('pair')}@{s.get('tf')}  url={(s.get('webhook_url') or '')[:50]}")
    print(f"  [1] toggle enabled  (currently {s.get('enabled', True)})")
    print(f"  [2] change webhook URL")
    print(f"  [3] change JSON template")
    print(f"  [4] change events (entry/close/both)")
    print(f"  [5] change min_win_prob")
    ch = _ask(f"  pick: ")
    if   ch == "1": s["enabled"] = not s.get("enabled", True)
    elif ch == "2": s["webhook_url"] = _ask(f"  new URL: ")
    elif ch == "3":
        print(f"  Paste new template (single line OR end with 'END'):")
        first = _ask(f"  template: ")
        if first.strip() == "m":
            ls = []
            while True:
                try: ln = input()
                except (EOFError, KeyboardInterrupt): break
                if ln.strip() == "END": break
                ls.append(ln)
            s["json_template"] = "\n".join(ls)
        else:
            s["json_template"] = first
    elif ch == "4":
        m = {"1":["entry"],"2":["close"],"3":["entry","close"]}
        s["events"] = m.get(_ask(f"  [1=entry/2=close/3=both]: ", "3"), ["entry","close"])
    elif ch == "5":
        try: s["min_win_prob"] = float(_ask(f"  new min_win_prob: "))
        except: return
    else: return
    from live.alert_subs import upsert_sub
    if upsert_sub(s): print(f"  {GREEN}✓ updated{RESET}")


def _delete_alert_sub(subs):
    if not subs: print(f"  {YELLOW}no subs{RESET}"); return
    idx = _ask(f"  sub # to delete: ")
    try: i = int(idx) - 1
    except: return
    if not (0 <= i < len(subs)): return
    s = subs[i]
    if not _confirm(f"  Delete sub for {s.get('pair')}@{s.get('tf')}? [y/N]: "): return
    from live.alert_subs import delete_sub
    if delete_sub(s["id"]):
        print(f"  {GREEN}✓ deleted{RESET}")


def _test_fire_sub(subs):
    if not subs: print(f"  {YELLOW}no subs{RESET}"); return
    idx = _ask(f"  sub # to test: ")
    try: i = int(idx) - 1
    except: return
    if not (0 <= i < len(subs)): return
    s = subs[i]
    from live.alert_subs import fire_sub, enrich_signal_for_template
    sample = enrich_signal_for_template({
        "symbol":   s.get("pair"), "tf": s.get("tf"),
        "direction": "LONG", "verdict": "TEST_ALERT",
        "win_prob": 0.68,
        "entry":    100.0, "sl": 98.5,
        "tp1":      105.0, "tp2": 107.0, "tp3": 110.0,
        "rr1":      3.33,
        "leverage": 3, "size_pct": 1.0,
        "source":   "menu-14-test",
        "setup":    {"smart_sl_chosen": "test"},
    })
    print(f"\n  {CYAN}Firing test signal to {s.get('webhook_url','')[:60]}…{RESET}")
    ok = fire_sub(s, sample, event="entry")
    print(f"  {'✓ success' if ok else '✗ failed — check URL and template syntax'}")


def _show_template_help():
    print(f"\n{BOLD}{CYAN}━━ TEMPLATE PLACEHOLDERS (WhiteDemon_V8.2) ━━{RESET}\n")
    print(f"  Use {{{{name}}}} inside your JSON template — bot fills at send time.\n")
    print(f"  {BOLD}Pair / market:{RESET}")
    rows = [
        ("symbol",          "BTC-USD"),
        ("symbol_clean",    "BTCUSDT  (no dash, USDT instead of USD)"),
        ("tf",              "15m"),
        ("direction",       "LONG / SHORT"),
        ("side",            "long / short  (lowercase)"),
    ]
    for k, v in rows: print(f"    {{{{{k}}}}}{' '*max(0,22-len(k))} → {v}")
    print(f"\n  {BOLD}Lifecycle event + action:{RESET}")
    rows = [
        ("event",            "entry / tp1_hit / breakeven_set / tp2_hit / tp3_hit / sl_hit"),
        ("verdict",          "TAKE_TRADE / TP1_HIT / TP2_HIT / TP3_HIT / SL_HIT / BREAKEVEN_SET"),
        ("action_for_event", "buy / sell / close_partial_50pct / close_partial_30pct / close_all / move_sl"),
        ("action",           "alias of action_for_event (or buy/sell on entry)"),
        ("close_side",       "sell on LONG exit, buy on SHORT exit (for reduceOnly orders)"),
    ]
    for k, v in rows: print(f"    {{{{{k}}}}}{' '*max(0,22-len(k))} → {v}")
    print(f"\n  {BOLD}Prices:{RESET}")
    rows = [
        ("entry",            "43150.5"),
        ("sl",               "42810.0  (ORIGINAL stop — set at entry, never moves)"),
        ("sl_current",       "42810 then entry then tp1 — TRAILS during lifecycle"),
        ("sl_current_or_sl", "always-set helper — current SL if exists else original"),
        ("new_sl",           "set on breakeven_set/tp2_hit (the new trailed level)"),
        ("tp1 / tp2 / tp3",  "43810.0 / 44100.0 / 44650.0"),
        ("rr1 / rr2 / rr3",  "1.94 / 2.78 / 3.50"),
        ("exit_price",       "actual price the TP/SL triggered at"),
    ]
    for k, v in rows: print(f"    {{{{{k}}}}}{' '*max(0,22-len(k))} → {v}")
    print(f"\n  {BOLD}Sizing / risk:{RESET}")
    rows = [
        ("leverage",         "3"),
        ("size_pct",         "1.0  (% of equity to risk per trade)"),
        ("fraction_closed",  "0.5 / 0.3 / 0.2 / 1.0  (this event's partial close)"),
        ("alloc_tp1 / 2 / 3","0.50 / 0.30 / 0.20  (default allocation plan)"),
    ]
    for k, v in rows: print(f"    {{{{{k}}}}}{' '*max(0,22-len(k))} → {v}")
    print(f"\n  {BOLD}P&L:{RESET}")
    rows = [
        ("win_prob",         "0.682  (committee stack_bull)"),
        ("pnl_R",            "+0.97 (TP1 partial) or -1.0 (SL hit) or blended"),
        ("partial_R",        "this event's contribution only"),
        ("realized_R",       "running sum across the whole lifecycle"),
    ]
    for k, v in rows: print(f"    {{{{{k}}}}}{' '*max(0,22-len(k))} → {v}")
    print(f"\n  {BOLD}Misc:{RESET}")
    rows = [
        ("state",            "OPEN / BE / TRAIL / CLOSED"),
        ("setup.smart_sl_chosen", "wick_buffer / liq_avoid / atr_buffer / …"),
        ("timestamp",        "2026-06-23T11:42:18Z"),
        ("ts",               "1719234138 (unix sec)"),
    ]
    for k, v in rows: print(f"    {{{{{k}}}}}{' '*max(0,22-len(k))} → {v}")

    print(f"\n  {BOLD}{CYAN}━━ EXAMPLE templates ━━{RESET}")
    print(f"\n  {BOLD}Default (handles entire lifecycle automatically):{RESET}")
    print('    (just press Enter when adding — uses the smart default template)')

    print(f"\n  {BOLD}Altrady (entry only — let Altrady manage TPs):{RESET}")
    print('    {')
    print('      "action": "{{action}}",')
    print('      "symbol": "{{symbol_clean}}",')
    print('      "price":  {{entry}},')
    print('      "stop_loss":   {{sl}},')
    print('      "take_profit": {{tp1}},')
    print('      "take_profits":[{{tp1}}, {{tp2}}, {{tp3}}],')
    print('      "key": "your-altrady-secret"')
    print('    }')

    print(f"\n  {BOLD}Lifecycle-aware (event-driven bot like Wundertrading):{RESET}")
    print('    {')
    print('      "action": "{{action_for_event}}",')
    print('      "event":  "{{event}}",')
    print('      "symbol": "{{symbol_clean}}",')
    print('      "side":   "{{side}}",')
    print('      "price":  {{entry}},')
    print('      "sl":     {{sl_current_or_sl}},')
    print('      "tp":     {{tp1}},')
    print('      "fraction": {{fraction_closed}},')
    print('      "new_sl": {{new_sl}}')
    print('    }')

    print(f"\n  {BOLD}Discord (human-readable):{RESET}")
    print('    {"content":"🔔 {{event}} · {{direction}} {{symbol}} @ {{tf}} · entry={{entry}} sl={{sl_current_or_sl}} tp1={{tp1}} (R={{realized_R}})"}')
    print()


# ════════════════════════════════════════════════════════════════════
# MAIN MENU LOOP
# ════════════════════════════════════════════════════════════════════
def interactive_menu():
    _banner()
    # auto keepalive for Kaggle/Colab
    try:
        from core.keepalive import start_keepalive
        start_keepalive(interval=30)
    except Exception: pass

    st = _get_training_status()
    if st["complete"]:
        _status_line = "✅ COMPLETE"
    else:
        _status_line = f"{st['n_done']}/{st['n_total']} models done"
    print(f"\n  Status for {SYMBOL} @ {TF_LABEL}:  {_status_line}")
    if st["complete"]:
        print(f"     → menu [1] now shows a {BOLD}sub-menu{RESET} (re-train all / fast mode)")

    print(f"\n{BOLD}{CYAN}━━ MAIN MENU ━━{RESET}\n")
    label1 = "RESUME" if (st["ck_verdict"] == "TRAIN_INCOMPLETE" or st["n_done"] > 0) and not st["complete"] else "TRAIN"
    if st["complete"]:
        label1 = "TRAINED ✓"

    opts = [
        (f"🛠 {label1} {SYMBOL} @ {TF_LABEL}  (auto resume + save step-by-step)", menu_train_or_resume),
        (f"🔄 CHANGE pair & timeframe  ({len(PAIRS)} pairs)",                     menu_change_pair),
        (f"📈 TRAIN BIT-BY-BIT  (incremental: 10k / 30k / 100k…)",                menu_bit_by_bit),
        (f"🎯 TRAIN SPECIFIC MODELS  (classical / DL / neural / extras / combine)",menu_specific),
        (f"📊 BACKTEST  (specific / all / 10-step bit-by-bit)",                  menu_backtest),
        (f"🗑  WIPE EVERYTHING (double-confirm + type DELETE)",                  menu_wipe_everything),
        (f"🌐 LIVE DASHBOARD  (HTML + push to {STORE.backend_name})",            menu_dashboard),
        (f"📁 SHOW ALL TRAINED PAIRS  (pick → analyze on 4k live)",              menu_show_trained),
        (f"🔥 TEST / CHANGE Firebase + Supabase + GitHub credentials",           menu_test_backends),
        (f"🧩 COLLECT ALL — train EVERY missing model + extras + 4k live + push HTML", menu_collect_all),
        (f"🤖 AUTO-TRADER — 24/7 loop · alerts + optional real orders",          menu_autotrader),
        (f"🔑 LIVE CREDS — exchange API keys + alert webhooks (Discord/Telegram/Altrady/Wundertrading)", menu_live_creds),
        (f"🔔 ALERTS — per-pair webhook (pick TRAINED pair + JSON template, TradingView style)", menu_alerts),
        (f"🚪 EXIT (save all)",                                                  lambda: sys.exit(0)),
    ]
    for i, (lbl, _) in enumerate(opts, 1):
        print(f"  [{i:>2}] {lbl}")

    ch = _ask(f"\n  {BOLD}Choose [1-{len(opts)}]: {RESET}")
    try:
        idx = int(ch) - 1
        if 0 <= idx < len(opts):
            try:
                opts[idx][1]()
            except KeyboardInterrupt:
                print(f"\n{YELLOW}[!] interrupted — back to menu.{RESET}")
            except SystemExit: raise
            except Exception as e:
                print(f"\n{RED}━━ ERROR: {type(e).__name__}: {str(e)[:300]}{RESET}")
                print("  [error] traceback suppressed — see message above", flush=True)
                print(f"\n  {YELLOW}↩ returning to menu — your trained models are safe.{RESET}")
        else:
            print(f"  {RED}invalid choice{RESET}")
    except ValueError:
        print(f"  {YELLOW}(invalid input){RESET}")


def cli():
    args = sys.argv[1:]
    # Direct pair/timeframe override, e.g.:
    #   python run.py --pair SOL-USDT --tf 15m fast
    #   python run.py fast --pair SOL-USD --tf 15m
    try:
        pair_arg = None; tf_arg = None
        cleaned = []
        i = 0
        while i < len(args):
            a = args[i]
            if a in ("--pair", "-p") and i + 1 < len(args):
                pair_arg = args[i+1]; i += 2; continue
            if a in ("--tf", "--timeframe", "-t") and i + 1 < len(args):
                tf_arg = args[i+1]; i += 2; continue
            cleaned.append(a); i += 1
        args = cleaned
        if pair_arg or tf_arg:
            norm_pair = (pair_arg or SYMBOL).upper().replace("/", "-")
            # Project symbols are spot-style *-USD; user may type SOL-USDT.
            if norm_pair.endswith("-USDT"):
                norm_pair = norm_pair[:-5] + "-USD"
            pid = next((p["id"] for p in PAIRS if p["symbol"].upper() == norm_pair), PAIR_ID)
            tid = next((t["id"] for t in TIMEFRAMES if t["label"].lower() == (tf_arg or TF_LABEL).lower()), TF_ID)
            if pid != PAIR_ID or tid != TF_ID:
                _persist_pair_tf(pid, tid)
                print(f"  {GREEN}✓ Direct switch: {norm_pair} @ {tf_arg or TF_LABEL}. Re-launching...{RESET}")
                os.execv(sys.executable, [sys.executable, sys.argv[0]] + args)
    except Exception as _e:
        print(f"  {YELLOW}[cli] pair/tf override ignored: {str(_e)[:120]}{RESET}")
    if not args:
        while True:
            try:
                interactive_menu()
                print(f"\n{GREY}━━ press Enter for menu, Ctrl-C to exit ━━{RESET}")
                try: input()
                except EOFError: break
            except KeyboardInterrupt:
                print(f"\n{YELLOW}Bye!{RESET}"); break
            except EOFError:
                print(f"\n{YELLOW}[!] stdin closed — exiting.{RESET}"); break
        return

    cmd = args[0].lower()
    if cmd == "train":
        menu_train_or_resume()
    elif cmd == "analyze" or cmd == "_analyze_now":
        subprocess.call([sys.executable, "analyze.py"])
    elif cmd == "fast":
        _fast_mode_current()
    elif cmd == "backtest":
        years = args[1] if len(args) > 1 else None
        cmd_args = [sys.executable, "backtest_run.py"]
        if years and years.isdigit(): cmd_args += ["--years", years]
        subprocess.call(cmd_args)
    elif cmd == "server":
        subprocess.call([sys.executable, "server.py"])
    else:
        print(__doc__)


if __name__ == "__main__":
    cli()
