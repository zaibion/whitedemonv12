"""
full_pipeline.py — WhiteDemon_V8.2

ALWAYS audits and trains anything missing. Skips ONLY the specific items
that already exist in cache. Never skips entire stages blindly.

Per user request:
  "do not let them skip missing models — train full pipeline's missing
   components and so on. When we run these menus they will run full
   pipeline · train missing · skip trained"

Steps (with hard timeout per step):
  1. Audit ALL pipeline components (classical/DL × LONG+SHORT + 4 NNs +
     SL-NN + meta-labeler + triple-barrier + stacker + advanced features)
  2. Train missing classical/DL (per-model — skips already trained)
  3. Reassemble committee slim JSONs
  4. Train missing specialized NNs + SL placement NN (only what's missing)
  5. Fetch 4k LIVE candles
  6. Inference-only analyze.py → trade setup → push HTML
"""
from __future__ import annotations
import os, sys, subprocess, time, traceback


def _hdr(n, total, label):
    print(f"\n\033[1;36m━━━━ STEP {n}/{total} · {label} ━━━━\033[0m\n", flush=True)


def _sub(cmd, label, timeout_sec=1800):
    """Subprocess with hard timeout. Streams stdout live so cells don't appear hung."""
    print(f"  ▶ {label}\n    $ {' '.join(cmd)}\n", flush=True)
    t0 = time.time()
    try:
        proc = subprocess.Popen(cmd)
        while True:
            rc = proc.poll()
            if rc is not None:
                if rc != 0:
                    print(f"  \033[33m[warn] step exited rc={rc} after "
                          f"{time.time()-t0:.1f}s — continuing\033[0m", flush=True)
                return rc
            if time.time() - t0 > timeout_sec:
                print(f"  \033[31m[timeout] {time.time()-t0:.0f}s > "
                      f"{timeout_sec}s — killing and continuing\033[0m", flush=True)
                proc.terminate()
                try: proc.wait(timeout=10)
                except subprocess.TimeoutExpired: proc.kill()
                return -1
            time.sleep(2)
    except KeyboardInterrupt:
        try: proc.terminate()
        except Exception: pass
        raise


def main():
    try:
        from core.gpu_setup import enable_gpu; enable_gpu(verbose=True)
    except Exception: pass
    print("\n\033[1;36m╔══════════════════════════════════════════════════════════╗")
    print("║   ⚡ FULL PIPELINE WhiteDemon_V8.2 — audits + trains missing       ║")
    print("╚══════════════════════════════════════════════════════════╝\033[0m",
          flush=True)
    t0 = time.time()
    py = sys.executable

    from core.config import SYMBOL, TF_LABEL, CFG
    from core.storage import STORE
    from core         import per_model_cache as pmc
    from core         import checkpoint as ck_mod
    target = CFG.get("target_total_candles", 100_000)

    print(f"\n  Target: \033[1m{SYMBOL} @ {TF_LABEL}\033[0m  ·  "
          f"target_candles={target:,}  ·  backends={STORE.backend_name}\n",
          flush=True)

    # ── STEP 1 · audit ──
    _hdr(1, 6, "Audit all pipeline components")
    expected_cls = ['lr','knn','rf','et','xgb','lgb','cat','hgb','mlp']
    expected_dl  = ['lstm','bilstm','gru','tcn','wavenet','transformer','cnn1d',
                    'nbeats','mamba','patchtst','itransformer','frets','tft',
                    'mamba_pdf']
    expected_nn  = ['price_reg', 'rl_agent', 'sentiment_nn', 'regime_nn']

    done_l = pmc.list_done(SYMBOL, TF_LABEL, "LONG",  target)
    done_s = pmc.list_done(SYMBOL, TF_LABEL, "SHORT", target)
    done_nn = pmc.list_done(SYMBOL, TF_LABEL, "BOTH", target).get("nn", [])

    missing_l_cls = [m for m in expected_cls if m not in done_l["classical"]]
    missing_l_dl  = [m for m in expected_dl  if m not in done_l["dl"]]
    missing_s_cls = [m for m in expected_cls if m not in done_s["classical"]]
    missing_s_dl  = [m for m in expected_dl  if m not in done_s["dl"]]
    missing_nn    = [m for m in expected_nn  if m not in done_nn]

    # SL NN
    sl_reg = STORE.get_json(f"sl_nn_registry_{SYMBOL.replace('-','_')}_{TF_LABEL}") or {}
    sl_nn_present = bool(sl_reg.get("batches"))

    print(f"  LONG  classical missing : {missing_l_cls or 'none ✓'}")
    print(f"  LONG  DL missing        : {missing_l_dl  or 'none ✓'}")
    print(f"  SHORT classical missing : {missing_s_cls or 'none ✓'}")
    print(f"  SHORT DL missing        : {missing_s_dl  or 'none ✓'}")
    print(f"  Neural NN missing       : {missing_nn   or 'none ✓'}")
    print(f"  SL placement NN cached  : {sl_nn_present}")

    any_committee_missing = bool(missing_l_cls or missing_l_dl or
                                  missing_s_cls or missing_s_dl)
    any_extras_missing    = bool(missing_nn) or not sl_nn_present

    # ── STEP 2 · train missing classical/DL ──
    _hdr(2, 6, "Train missing classical / DL (per-model, skips trained)")
    if any_committee_missing:
        n_missing = (len(missing_l_cls) + len(missing_l_dl) +
                     len(missing_s_cls) + len(missing_s_dl))
        print(f"  {n_missing} model(s) missing — training (per-model save, never skips done)",
              flush=True)
        _sub([py, "train_specific.py", "--missing"],
             "fill committee gaps", timeout_sec=6 * 3600)
    else:
        print(f"  \033[32m✓ all 9+14 committee models present for LONG and SHORT — "
              f"skipping training step\033[0m", flush=True)

    # ── STEP 3 · reassemble slim committee JSONs ──
    _hdr(3, 6, "Reassemble LONG/SHORT slim committee JSONs from cached models")
    _sub([py, "train_specific.py", "--reassemble"],
         "reassemble", timeout_sec=600)

    # ── STEP 4 · ensure neural NNs + SL-NN are trained ──
    _hdr(4, 6, "Train missing extras (specialized NNs + SL placement NN)")
    if any_extras_missing:
        print(f"  missing: nn={missing_nn or 'none'} · sl_nn={'no' if not sl_nn_present else 'yes'}",
              flush=True)
        _sub([py, "ensure_nns.py"], "train missing extras inline",
             timeout_sec=2 * 3600)
    else:
        print("  \033[32m✓ all 4 neural NNs + SL-NN present — skipping\033[0m",
              flush=True)

    # ── STEP 5 · final reassemble (re-runs after any new model trained) ──
    _hdr(5, 6, "Final cache reassemble + checkpoint sync")
    _sub([py, "train_specific.py", "--reassemble"],
         "final reassembly", timeout_sec=600)
    # Mark checkpoint stages done so analyze knows everything's good
    try:
        ck = ck_mod.load(SYMBOL, TF_LABEL)
        for stg in ("long_committee", "short_committee", "long_dl", "short_dl",
                     "specialized_nns", "stacker", "save_dashboard"):
            if stg in ck.get("stages", {}) and not ck["stages"][stg].get("done"):
                # Only mark if the data is actually there
                if stg in ("long_committee", "long_dl"):
                    if not missing_l_cls and not missing_l_dl:
                        ck = ck_mod.mark_done(ck, stg)
                elif stg in ("short_committee", "short_dl"):
                    if not missing_s_cls and not missing_s_dl:
                        ck = ck_mod.mark_done(ck, stg)
                elif stg == "specialized_nns":
                    if not missing_nn:
                        ck = ck_mod.mark_done(ck, stg)
                else:
                    ck = ck_mod.mark_done(ck, stg)
    except Exception as e:
        print(f"  \033[33m[warn] checkpoint sync failed: {e}\033[0m", flush=True)

    # ── STEP 6 · TRUE fast-mode analyze (inference only, ~30s) ──
    _hdr(6, 6, "Fetch 4k LIVE candles + INFERENCE-ONLY analyze.py")
    _sub([py, "analyze.py"], "true fast mode", timeout_sec=900)

    dt = time.time() - t0
    print(f"\n\033[1;32m╔══════════════════════════════════════════════════════════╗")
    print(f"║   ✅ FULL PIPELINE COMPLETE in {dt:6.1f}s ({dt/60:.1f}min)        ║")
    print(f"╚══════════════════════════════════════════════════════════╝\033[0m",
          flush=True)
    print(f"\n  → frontend/dashboard.html (embedded data ready)")
    print(f"  → http://localhost:8000  (after python server.py)\n", flush=True)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n\033[33m[!] interrupted — partial work saved.\033[0m")
