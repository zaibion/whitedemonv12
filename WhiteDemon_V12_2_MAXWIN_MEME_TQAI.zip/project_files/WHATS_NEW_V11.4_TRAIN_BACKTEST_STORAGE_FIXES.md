# WhiteDemon V11.4 — Training / Backtest / Large Model Storage Fixes

Fixes the errors reported after V11.3.

## Fixed: NBEATS too large for GitHub

NBEATS `.pt.gz` can be too large for GitHub as one file. GitHub can reject huge blobs even through the large-file API.

`core/per_model_cache.py` now stores very large model blobs as chunked storage objects:

- chunks are uploaded under `...chunks/part0000`, `part0001`, etc.
- a small manifest is saved next to them
- loading automatically reassembles the chunks
- local disk fallback still exists if remote storage fails

This does not change model math and does not invalidate existing cache.

## Fixed: Backtest feature mismatch

Backtest / bundle inference could fail with errors like:

```text
expecting 44 features, got 43 features
```

`core/committee_bundle.py` now:

- fills missing saved feature names with neutral `0.0`
- safely aligns matrices to saved scaler/model feature counts
- truncates extra columns or pads missing columns instead of crashing
- records metadata:
  - `missing_bundle_features_filled`
  - `scaler_expected_features`

This keeps backtesting running instead of ending with “nothing found”.

## Fixed: train specific models one-by-one

`train_specific.py --missing --direction ... --classical ...` or `--dl ...` previously ignored the model filter when `--missing` was present.

Now `--missing` respects the requested classical/DL list, so one-by-one training works correctly.

Examples:

```bash
python train_specific.py --missing --direction LONG --dl nbeats
python train_specific.py --missing --direction SHORT --classical xgb
python train_specific.py --direction LONG --dl nbeats
```

## No retraining required by this update

This is code hardening only. Existing models are not invalidated.
