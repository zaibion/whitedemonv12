# WhiteDemon V10.2 — Regime/Recency Analog + Drift + Reject Logs

## Added from technical review

### 1) Regime-filtered analog search
Analog matching now tries to restrict historical nearest-neighbor search to the same market regime when enough samples exist.

It reports:
- `regime_filter_used`
- `regime_match_count`
- `current_regime`

### 2) Recency-weighted analogs
Analog matches now use:

```text
weight = distance_weight × recency_weight
```

Recent historical analogs influence the analog win rate more than very old analogs, while very similar old analogs can still contribute.

It reports:
- `recency_halflife_rows`
- `mean_analog_age_rows`

### 3) Feature drift / distribution shift monitoring
Training bundles now save feature median/MAD. FAST MODE compares the latest feature row against that training distribution.

It reports:
- mean absolute z drift
- max drift
- moderate drift share
- severe drift share
- drift level: LOW / MODERATE / SEVERE

The setup can be blocked if drift is too high.

### 4) Rejected trade logging
Every WATCH/NO_TRADE setup is logged locally:

```text
rejected_trades.jsonl
```

and the latest rejected setup is uploaded to GitHub/storage as:

```text
data/rejected_latest_<PAIR>_<TF>.json
```

This lets you later study whether filters are blocking good opportunities or correctly avoiding losers.

### 5) Runtime metrics expanded
Metrics now include:
- analog win rate
- feature drift moderate share
- feature drift severe share

## Important
A new V10.2 training run is needed to create bundles with regime labels, recency indices, and feature drift profiles.

Old bundles may show these checks as unavailable.

## Checks
- compileall passed
- tabnanny passed
- pyflakes syntax/undefined-name scan passed
