# WhiteDemon V9.8 — All-Model FAST MODE Inference

## Why this version exists
V9.7 bundle FAST MODE was using saved full classical committee bundles, but the output could still show `DL 0/0` because DL models are saved separately as state dictionaries.

User wanted:

```text
Models train once, save to GitHub/storage.
FAST MODE fetches latest 4k candles.
All trained ML/DL/neural models analyze the latest candles using their saved training.
No retraining during analyze.
Return one final setup.
```

## What changed

### 1) Bundle FAST MODE now also loads cached DL models
`core/committee_bundle.py` now attempts to:
- load saved classical committee bundle
- load saved DL state_dicts from per-model cache
- reconstruct DL architectures
- feed latest 4k feature sequence through cached DL models
- blend classical + DL current predictions

This is inference only. It does not train DL models during analyze.

### 2) Analyze output now shows DL loaded count
`analyze.py` prints:

```text
[bundle-fast] TRUE all-model bundle inference @ 200,000: LONG=... SHORT=... DL(L/S)=14/14
```

If DL is 0/0, it means valid DL state_dicts were not found for that cache/version.

### 3) Why V9.3 and V9.7 could disagree
- V9.3 used stricter/older decision logic and could be influenced by slim metadata or different gates.
- V9.7 used true classical bundle inference, but not necessarily DL sequence inference.
- V9.8 attempts to include both classical bundle + cached DL sequence inference.

## Important
If you see:

```text
DL(L/S)=0/0
```

then FAST MODE is not using DL yet. You need valid saved DL models in the per-model cache for that pair/timeframe/count.

If you see:

```text
fallback to slim metadata
```

then full model inference could not run and output is weaker.

## Checks
- compileall passed
- tabnanny passed
- pyflakes syntax/undefined-name scan passed
