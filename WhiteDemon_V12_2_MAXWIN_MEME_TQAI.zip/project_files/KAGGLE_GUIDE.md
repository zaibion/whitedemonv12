# 🚀 Crypto Suite v24 — Kaggle Step-by-Step Guide

The ONLY trick: use `%run` not `!python`. That's how Kaggle accepts your input boxes.

---

## STEP 0 — Account setup (3 min, one-time)

1. Sign up at https://www.kaggle.com → Google login
2. Avatar → **Settings** → **Phone Verification** → enter SMS code (required for GPU)

---

## STEP 1 — Upload zip as Dataset (3 min, one-time)

1. Top menu → **Create** → **New Dataset**
2. Drag in `crypto-suite-v24.zip`
3. **Title:** `cryptosuite` (lowercase, no spaces, no punctuation)
4. **Visibility:** Private
5. Create — wait until upload finishes

---

## STEP 2 — Create Notebook (1 min)

1. **Create** → **New Notebook**
2. Right sidebar → **+ Add Input** → **Datasets** → search `cryptosuite` → Add
3. Right sidebar → **Notebook options**:
   - Accelerator: **GPU T4 x2** (or None if you're out of quota)
   - Persistence: **Files only**
   - Internet: ON

---

## STEP 3 — Cell 1: Unzip + install

```python
!cp /kaggle/input/cryptosuite/crypto-suite-v24.zip /kaggle/working/
!cd /kaggle/working && unzip -qo crypto-suite-v24.zip
%cd /kaggle/working/crypto-v23
!pip install -q -r requirements.txt
```

Run with Shift+Enter. Wait ~3-5 min (you'll see lots of "Successfully installed").

---

## STEP 4 — Cell 2: Setup (writes config.py)

**Use `%run`, NOT `!python`** — this is the key.

```python
%run setup.py
```

An input box appears at the BOTTOM of the cell. The wizard asks:

1. Firebase apiKey — paste `AIzaSy...` or just press Enter to skip
2. (other Firebase fields, or Enter for each to use defaults)
3. **GitHub token** — paste `ghp_xxx`
4. **GitHub repo** — type `zaibion/kinapp` (no `.git`)
5. **GitHub branch** — Enter for `main`
6. **PAIR_ID** — type number, e.g. `7` for ADA
   ```
   1=BTC  2=ETH  3=SOL  4=BNB  5=XRP  6=LTC  7=ADA  8=DOGE
   9=AVAX 10=DOT 11=MATIC 12=LINK 13=TRX 14=ATOM 15=NEAR 16=ARB 17=OP 18=SHIB
   ```
7. **TF_ID** — type number, e.g. `5` for 30m
   ```
   1=1m  2=3m  3=5m  4=15m  5=30m  6=1h  7=4h  8=1d
   ```
8. **TARGET_CANDLES** — Enter for 200000 (or 30000 if low RAM)
9. **FAST_CANDLES** — Enter for 4000
10. **LLM API keys** — paste each, or Enter to skip:
    - OPENAI_API_KEY
    - ANTHROPIC_API_KEY
    - GEMINI_API_KEY
    - GROQ_API_KEY
    - DEEPSEEK_API_KEY
    - MISTRAL_API_KEY

Ends with:
```
✅ Setup complete.
  config.py written to /kaggle/working/crypto-v23/config.py
```

**IMPORTANT — Verify the right pair was saved.** Run this cell to double-check:
```python
!cat config.py | head -10
```
You should see `PAIR_ID = 7` and `TF_ID = 5` (or whatever you picked).

---

## STEP 5 — Cell 3: Run the menu

```python
%run run.py
```

You'll see the banner — **confirm pair & TF are correct**:
```
╔══════════════════════════════════════════════════════════╗
║       ⚡  CRYPTO INSTITUTIONAL SUITE v24 — COMMAND       ║
╠══════════════════════════════════════════════════════════╣
║  Current pair  : ADA-USD    TF: 30m     Storage: github  ║
║  PAIR_ID=7   TF_ID=5     ← if wrong, re-run setup.py     ║
╚══════════════════════════════════════════════════════════╝
```

If you see `BTC` or `15m` here when you picked `ADA` / `30m`, your config.py wasn't loaded. See troubleshooting below.

Then the menu appears:
```
[1] ⚡ FAST MODE
[2] 🛠 Train ADA-USD @ 30m
[3] 🛠 Train NEW
[4] 📈 Train INCREMENTAL
[5] 🎯 Train SPECIFIC models (parallelize across cells)
[6] 📊 Per-model status table
[7] 📊 Backtest
[8] 🔁 Force retrain
[9] 🌐 Start web dashboard
[10] 📋 Show status
[11] 📁 Show ALL trained models on storage
[12] 🛡  Colab anti-disconnect JS snippet
[13] 🧩 Per-model training progress
[14] 🔥 Test Firebase / GitHub connection
[15] 🚪 Exit
```

Type a number, press Enter.

**Recommended first run:**
1. Type `14` Enter → verify GitHub/Firebase works
2. Type `6` Enter → see what models are trained/missing
3. Type `2` Enter → start training (wait 30 min - 4 hours)
4. After training: type `1` Enter → FAST MODE for fresh signal

---

## STEP 6 — When training stops or session ends

Kaggle limits sessions to ~9 hours. When it stops:

1. Open the same notebook
2. Re-run Cell 1 (unzip + install) — ~2 min
3. Re-run Cell 2 (`%run setup.py`) — when asked "overwrite?", type `k` Enter to **keep existing config**
4. Re-run Cell 3 (`%run run.py`) → pick option `[2]` → resumes from last saved model. Already-trained models say `[pmc] ⏩ skip ...` and are loaded from GitHub cache instantly.

---

## STEP 7 — If training stops MID-DL (the common problem)

DL phase is RAM-heavy. On Kaggle CPU+16GB this can OOM.

**Use option [5] Train SPECIFIC models** to train DL nets 2-4 at a time:
- After selecting option [5], pick `[1] Pick INDIVIDUAL models`
- For LONG direction, type `lstm,bilstm,gru,tcn` (4 nets, ~10-20 min)
- Wait for completion
- Re-run option [5] with next 4 nets

Repeat until all 14 DL nets done per direction. Saved models survive between runs.

---

## STEP 8 — Common errors and fixes

| Error | Fix |
|---|---|
| `EOFError: EOF when reading a line` | You used `!python`. Switch to `%run`. |
| Input box doesn't appear | You used `!python`. Switch to `%run`. |
| Banner shows BTC but I picked ADA | config.py wasn't loaded. Run `!cat config.py` to verify. If wrong, re-run Cell 2 (`%run setup.py`). |
| `[github] HTTP 401` | Token wrong/expired. New one: github.com/settings/tokens → `repo` scope |
| `[github] HTTP 404` | `GITHUB_REPO` wrong. Format: `owner/repo` (no `.git`) |
| Kernel died / Out of memory | Lower TARGET_CANDLES to 30000. Use option [5] for 2-4 models at a time. |
| DL training stops silently | Same OOM. Use option [5] specific models. |
| `[device] CPU only` but I have GPU | Notebook options → Accelerator → **GPU T4 x2** → Save. Restart kernel. |
| "no module named X" after install | Restart kernel and re-run Cell 1. |
| `RuntimeError: CUDA out of memory` | Restart kernel. Train 2-3 DL nets per run via option [5]. |
| Setup wrote wrong pair | Re-run Cell 2 → input numbers carefully. Then verify with `!cat config.py`. |

---

## STEP 9 — Daily workflow after first successful training

Once everything is trained and pushed to GitHub:

```python
# Cell 1 (every time, ~2 min)
!cp /kaggle/input/cryptosuite/crypto-suite-v24.zip /kaggle/working/
!cd /kaggle/working && unzip -qo crypto-suite-v24.zip
%cd /kaggle/working/crypto-v23
!pip install -q -r requirements.txt
```

```python
# Cell 2 (instant — keep existing config)
%run setup.py
# When prompted "overwrite?" → type: k Enter
```

```python
# Cell 3 (interactive)
%run run.py
# Type: 1 Enter → FAST MODE → pick pair → 30 sec → fresh signal
```

---

## STEP 10 — What's new in v24

- ✅ **Config loading bug fixed** — Kaggle was failing to find `config.py` because of cwd issues. Now config is found in 6 search paths (cwd, project root, `/kaggle/working/`, `/content/`, etc.).
- ✅ **Banner shows PAIR_ID + TF_ID** so you instantly see if wrong pair is loaded.
- ✅ **LLM API keys** in config.py — OpenAI, Anthropic, Gemini, Groq, DeepSeek, Mistral all supported.
- ✅ **setup.py writes config.py to BOTH cwd and project root** to ensure it's always found.
- ✅ **storage.py uses same robust config loader** — no more silent fall-back to defaults.
- ✅ All Tesla/CUDA tweaks removed.
- ✅ Same engine MD5 `bd6aa404fb1a93e2d999f4cd759212f2` — same accuracy guarantee.

---

## TL;DR

```
1. Kaggle account + phone verified
2. Upload zip → Kaggle Dataset named "cryptosuite"
3. New Notebook → Add dataset → Enable GPU
4. Cell 1: !cp + unzip + pip install   (copy-paste, never changes)
5. Cell 2: %run setup.py               (NOT !python — input boxes work)
6. Cell 3: %run run.py                  (NOT !python — menu accepts input)
```

**Remember:** Always `%run`. Never `!python`. That's the magic word for Kaggle input.
