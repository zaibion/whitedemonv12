# 🚀 Google Colab quick-start

## 1️⃣ Open a new Colab notebook

https://colab.research.google.com → **File → New notebook**

## 2️⃣ Cell 1 — upload the ZIP & unpack

```python
from google.colab import files
print("Pick your crypto-suite-v23.zip file →")
uploaded = files.upload()      # browse to your downloaded zip

import zipfile, os
for fn in uploaded:
    with zipfile.ZipFile(fn) as z:
        z.extractall("/content/v23")
%cd /content/v23
!ls
```

You should now see the folder structure (core/, data/, indicators/, etc.).

## 3️⃣ Cell 2 — install dependencies (~2 min)

```python
!pip install -q ccxt rich xgboost lightgbm shap yfinance transformers torch firebase-admin flask
```

## 4️⃣ Cell 3 — create `config.py`

Easiest: paste this and edit the 3 values:

```python
%%writefile config.py
PAIR_ID = 3            # 3 = SOL-USD   (1=BTC 2=ETH 4=BNB 5=XRP ...)
TF_ID   = 5            # 5 = 30m       (4=15m 6=1h 7=4h ...)
TARGET_CANDLES = 200_000
FAST_CANDLES   = 4_000

# GitHub storage (easier than Firebase for Colab):
GITHUB_TOKEN  = "ghp_PASTE_YOUR_TOKEN_HERE"
GITHUB_REPO   = "your-username/crypto-bot-data"   # MUST exist & be private
GITHUB_BRANCH = "main"

# Leave Firebase blank to use GitHub:
FIREBASE_CREDENTIALS = ""
FIREBASE_PROJECT_ID  = ""
FIREBASE_BUCKET      = ""
```

> 🔑 Need a GitHub token? https://github.com/settings/tokens →
> Generate new (classic) → tick `repo` → copy `ghp_…`

## 5️⃣ Cell 4 — TRAIN (one-time, ~10-15 min)

```python
!python train_all.py
```

You'll see:
```
══ TRAIN ALL · SOL-USD @ 30m ══
[1/4] Fetching 200,000 stitched candles …
   bybit → +50,000 bars
   bitget → +50,000 bars
   kucoin → +50,000 bars
   ...
[2/4] Training LONG + SHORT (parallel) … done in 487s
[3/4] Saving to storage backend = github …
[4/4] Building dashboard payload …
✅ TRAIN ALL DONE  ·  VERDICT = TAKE_TRADE  ·  LONG @ 73% confluence
```

## 6️⃣ Cell 5 — VIEW DASHBOARD

### Option A — Quick HTML download

```python
from google.colab import files
files.download("dashboard_data.json")
files.download("frontend/dashboard.html")
```

Open `dashboard.html` in your browser. ⚠️ Won't auto-refresh unless you also
have a server — see Option B.

### Option B — Run the Flask server in Colab (with ngrok tunnel)

```python
!pip install -q pyngrok
from pyngrok import ngrok
ngrok.set_auth_token("YOUR_NGROK_TOKEN")   # https://dashboard.ngrok.com/get-started/your-authtoken
public_url = ngrok.connect(8000)
print(f"\n🌐  Dashboard live at:  {public_url}\n")

!python server.py
```

Click the printed URL. Dashboard opens with live chart + buttons (Train, Analyze, Backtest).

## 7️⃣ Cell 6 — FAST refresh later

After training, just re-run analyze to refresh with fresh prices (~30s):

```python
!python analyze.py
```

Or for auto-refresh every 15 min:

```python
import time
for i in range(96):           # 24h of refreshes
    !python analyze.py
    print(f"\n💤 sleeping 15 min ({i+1}/96)\n")
    time.sleep(15 * 60)
```

## 8️⃣ Cell 7 — BACKTEST (~30-90 min)

```python
!python backtest_run.py --pair SOL-USD --tf 30m
```

Walk-forward year-by-year, with GROSS + NET (after fee) tables.

---

## 🤔 FAQ

**Q. Will Colab disconnect during training?**
A. Free Colab disconnects after ~90 min idle. Training takes 10-15 min so usually OK.
Add this to a separate cell to keep alive:
```python
import time
while True:
    print('.', end='')
    time.sleep(60)
```

**Q. Can I run this on my phone?**
A. Train in Colab (Cell 5), then open `dashboard.html` (or the ngrok URL from Option B)
in any phone browser. Read-only is fine.

**Q. Do I have to upload the engine separately?**
A. No — `_engine.py` is already inside the ZIP.

**Q. What if `train_all.py` fails?**
A. Most common: missing config.py. Re-run Cell 3 with your token + repo filled in.
Paste any error into chat — I'll fix it for you.
