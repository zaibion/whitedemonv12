"""
per_model_cache.py — Save and restore INDIVIDUAL models (classical + DL + NN)
                     as soon as they finish training.

Why
───
The engine's run_ml_committee trains all 9 classical models inside one parallel
batch, then DLEnsemble.train trains all 14 DL models in a sequential loop.
If the Colab cell dies after model #7 finishes, models 1-7 are lost because
nothing was saved.

This module fixes that by providing a thread-safe save/load layer keyed by:
    direction + candle_count + model_name

Storage layout (one blob per model):
    perm/<SYMBOL>/<TF>/<DIR>/<COUNT>/classical/<name>.pkl.gz   (joblib + gzip)
    perm/<SYMBOL>/<TF>/<DIR>/<COUNT>/dl/<name>.pt              (torch.save)

A small JSON index per direction lists the names that are already done so we
can ask "is this model trained?" without downloading the blob.
"""
from __future__ import annotations
import os, io, gzip, pickle, hashlib, threading, time
from typing import Optional, Dict, Any, List

from core.storage import STORE
from core.colors  import GREEN, YELLOW, GREY, RESET, CYAN, RED


_lock = threading.Lock()
MODEL_CACHE_VERSION = "v9.5_no_leakage_honest_calibration"

# V11.4: GitHub rejects very large single blobs (common with NBEATS).
# Save huge model blobs as multiple storage chunks plus a small manifest.
# This keeps existing cache version stable and avoids retraining everything.
REMOTE_CHUNK_THRESHOLD = int(os.environ.get("WHDEMON_CHUNK_THRESHOLD_MB", "45")) * 1024 * 1024
REMOTE_CHUNK_SIZE = int(os.environ.get("WHDEMON_CHUNK_SIZE_MB", "35")) * 1024 * 1024


# ── WhiteDemon_V8.2: local disk cache fallback (used when remote upload fails) ──
def _local_cache_root() -> str:
    """Where on local disk we cache models when GitHub/Firebase fail.
    Survives Kaggle session restart if /kaggle/working/ is persisted."""
    candidates = [
        os.environ.get("CRYPTOSUITE_CACHE"),
        "/kaggle/working/cryptosuite_cache",
        os.path.expanduser("~/.cryptosuite_cache"),
        "/tmp/cryptosuite_cache",
    ]
    for c in candidates:
        if not c: continue
        try:
            os.makedirs(c, exist_ok=True)
            # Verify writable
            t = os.path.join(c, ".write_test")
            with open(t, "w") as f: f.write("ok")
            os.unlink(t)
            return c
        except Exception:
            continue
    return "/tmp"


def _disk_path(key: str) -> str:
    """Local-disk equivalent of STORE blob key."""
    safe = key.replace("/", "__").replace(":", "_")
    return os.path.join(_local_cache_root(), safe)


def _disk_save(key: str, blob: bytes) -> bool:
    try:
        p = _disk_path(key)
        with open(p, "wb") as f: f.write(blob)
        return True
    except Exception as e:
        print(f"  {YELLOW}[pmc-disk] save {key} failed: {e}{RESET}")
        return False


def _disk_load(key: str) -> Optional[bytes]:
    try:
        p = _disk_path(key)
        if os.path.exists(p):
            with open(p, "rb") as f: return f.read()
    except Exception:
        pass
    return None


def _manifest_key(key: str) -> str:
    return f"{key}.chunks_manifest"


def _chunk_key(key: str, i: int) -> str:
    return f"{key}.chunks/part{i:04d}"


def _try_put_blob_chunked(key: str, blob: bytes, msg: str) -> tuple[bool, str]:
    """Store a huge blob as multiple remote chunks.

    GitHub has a hard single-file limit; NBEATS can exceed it. Chunking lets
    the same model persist in GitHub/Firebase/Supabase without changing model
    math. If chunk upload fails, caller still falls back to local disk.
    """
    try:
        size = len(blob)
        sha = hashlib.sha256(blob).hexdigest()
        n = int((size + REMOTE_CHUNK_SIZE - 1) // REMOTE_CHUNK_SIZE)
        print(f"  {CYAN}[pmc] large blob {size/1024/1024:.1f} MB → {n} storage chunks "
              f"({REMOTE_CHUNK_SIZE/1024/1024:.0f} MB each){RESET}", flush=True)
        ok_parts = 0
        for i in range(n):
            part = blob[i*REMOTE_CHUNK_SIZE:(i+1)*REMOTE_CHUNK_SIZE]
            if STORE.put_blob(_chunk_key(key, i), part, compress=False,
                              message=f"{msg} chunk {i+1}/{n}"):
                ok_parts += 1
            else:
                print(f"  {YELLOW}[pmc] chunk {i+1}/{n} upload failed{RESET}", flush=True)
                return False, "none"
        manifest = {
            "chunked": True, "key": key, "n_parts": n,
            "size_bytes": size, "sha256": sha,
            "chunk_size": REMOTE_CHUNK_SIZE,
            "model_cache_version": MODEL_CACHE_VERSION,
        }
        if not STORE.put_json(_manifest_key(key), manifest, message=f"{msg} manifest"):
            print(f"  {YELLOW}[pmc] chunk manifest upload failed{RESET}", flush=True)
            return False, "none"
        return True, "storage_chunks"
    except Exception as e:
        print(f"  {YELLOW}[pmc] chunked upload threw: {str(e)[:200]}{RESET}", flush=True)
        return False, "none"


def _try_get_blob_chunked(key: str) -> Optional[bytes]:
    try:
        man = STORE.get_json(_manifest_key(key))
        if not isinstance(man, dict) or not man.get("chunked"):
            return None
        n = int(man.get("n_parts", 0) or 0)
        if n <= 0:
            return None
        parts = []
        for i in range(n):
            part = STORE.get_blob(_chunk_key(key, i))
            if not part:
                print(f"  {YELLOW}[pmc] missing chunk {i+1}/{n} for {key}{RESET}")
                return None
            parts.append(part)
        blob = b"".join(parts)
        if int(man.get("size_bytes", len(blob))) != len(blob):
            print(f"  {YELLOW}[pmc] chunk size mismatch for {key}{RESET}")
            return None
        sha = man.get("sha256")
        if sha and hashlib.sha256(blob).hexdigest() != sha:
            print(f"  {YELLOW}[pmc] chunk sha mismatch for {key}{RESET}")
            return None
        return blob
    except Exception as e:
        print(f"  {GREY}[pmc] chunked load failed for {key}: {str(e)[:120]}{RESET}")
        return None


def _try_put_blob(key: str, blob: bytes, msg: str) -> tuple[bool, str]:
    """Return (success, where) — where ∈ {"storage", "disk", "none"}.
    Tries remote storage FIRST; if that fails, falls back to local disk so
    the user doesn't lose progress."""
    # Try storage. Very large models (NBEATS) are chunked before remote upload
    # so GitHub never receives a >100MB single file.
    try:
        if len(blob) >= REMOTE_CHUNK_THRESHOLD:
            ok, where = _try_put_blob_chunked(key, blob, msg)
            if ok:
                return True, where
        else:
            ok = STORE.put_blob(key, blob, compress=False, message=msg)
            if ok:
                return True, "storage"
    except Exception as e:
        print(f"  {YELLOW}[pmc] storage put threw: {str(e)[:200]}{RESET}", flush=True)
    # Fallback: local disk
    print(f"  {YELLOW}[pmc] remote upload failed — saving to local disk cache instead{RESET}",
          flush=True)
    if _disk_save(key, blob):
        return True, "disk"
    return False, "none"


def _try_get_blob(key: str) -> Optional[bytes]:
    """Try storage first, then local disk cache."""
    try:
        b = STORE.get_blob(key)
        if b: return b
    except Exception:
        pass
    b = _try_get_blob_chunked(key)
    if b: return b
    return _disk_load(key)


def _root(sym: str, tf: str, direction: str, count: int) -> str:
    return f"perm/{sym.replace('-','_')}/{tf}/{direction.lower()}/{count}"


def _index_key(sym: str, tf: str, direction: str, count: int) -> str:
    # Note: no .json suffix — put_json adds it automatically
    return f"{_root(sym, tf, direction, count)}/_index"


# ────────────────────────────────────────────────────────────────────────
# Index helpers — small JSON tracking which models are already saved
# ────────────────────────────────────────────────────────────────────────
def get_index(sym: str, tf: str, direction: str, count: int) -> Dict[str, Any]:
    """Return {'classical': {name: meta}, 'dl': {name: meta}, 'nn': {...}}."""
    try:
        doc = STORE.get_json(_index_key(sym, tf, direction, count))
        if isinstance(doc, dict):
            doc.setdefault("classical", {})
            doc.setdefault("dl", {})
            doc.setdefault("nn", {})
            return doc
    except Exception:
        pass
    return {"classical": {}, "dl": {}, "nn": {}}


def _save_index(sym: str, tf: str, direction: str, count: int, idx: Dict) -> bool:
    try:
        return STORE.put_json(_index_key(sym, tf, direction, count), idx,
                              message=f"index {sym}/{tf}/{direction}/{count}")
    except Exception as e:
        print(f"  {YELLOW}[pmc] index save failed: {e}{RESET}")
        return False


def update_index(sym: str, tf: str, direction: str, count: int,
                  kind: str, name: str, meta: Dict) -> bool:
    """Atomically add (name, meta) to the index under kind ∈ {classical, dl, nn}."""
    with _lock:
        idx = get_index(sym, tf, direction, count)
        idx.setdefault(kind, {})[name] = {**meta, "model_version": MODEL_CACHE_VERSION, "saved_at": time.time()}
        return _save_index(sym, tf, direction, count, idx)


def is_done(sym: str, tf: str, direction: str, count: int,
             kind: str, name: str) -> bool:
    idx = get_index(sym, tf, direction, count)
    meta = idx.get(kind, {}).get(name)
    return isinstance(meta, dict) and meta.get("model_version") == MODEL_CACHE_VERSION


def list_done(sym: str, tf: str, direction: str, count: int) -> Dict[str, list]:
    idx = get_index(sym, tf, direction, count)
    out = {}
    for k in ("classical", "dl", "nn"):
        out[k] = [name for name, meta in idx.get(k, {}).items()
                  if isinstance(meta, dict) and meta.get("model_version") == MODEL_CACHE_VERSION]
    return out


# ────────────────────────────────────────────────────────────────────────
# Classical (sklearn-style) — pickle + gzip
# ────────────────────────────────────────────────────────────────────────
def save_classical(sym: str, tf: str, direction: str, count: int,
                    name: str, model: Any, meta: Optional[Dict] = None) -> bool:
    key = f"{_root(sym, tf, direction, count)}/classical/{name}.pkl.gz"
    backend = STORE.backend_name
    try:
        raw  = pickle.dumps(model, protocol=4)
        blob = gzip.compress(raw, compresslevel=5)
        print(f"  {CYAN}[pmc] ⏫ uploading {direction}/{name} → {backend} "
              f"({len(blob)/1024:.1f} KB)…{RESET}", flush=True)
        ok, where = _try_put_blob(key, blob,
                                  f"{direction} {name} {sym}/{tf} @ {count}")
        if ok:
            update_index(sym, tf, direction, count, "classical", name,
                          {**(meta or {}), "size_kb": round(len(blob)/1024, 1),
                           "saved_to": where})
            verify = _try_get_blob(key)
            if verify and len(verify) > 0:
                print(f"  {GREEN}[pmc] ✓ {direction}/{name} VERIFIED on {where} "
                      f"({len(blob)/1024:.1f} KB){RESET}", flush=True)
            else:
                print(f"  {YELLOW}[pmc] ⚠ {direction}/{name} upload returned OK but "
                      f"verify-read failed — may not be persisted!{RESET}", flush=True)
        else:
            print(f"  {RED}[pmc] ✗ {direction}/{name} BOTH STORAGE AND DISK FAILED{RESET}",
                  flush=True)
        return ok
    except Exception as e:
        print(f"  {YELLOW}[pmc] save {name} failed: {e}{RESET}", flush=True)
        return False


def load_classical(sym: str, tf: str, direction: str, count: int,
                    name: str) -> Optional[Any]:
    key = f"{_root(sym, tf, direction, count)}/classical/{name}.pkl.gz"
    try:
        blob = _try_get_blob(key)
        if not blob:
            return None
        try: raw = gzip.decompress(blob)
        except OSError: raw = blob
        return pickle.loads(raw)
    except Exception as e:
        print(f"  {GREY}[pmc] load {name} failed: {e}{RESET}")
        return None


# ────────────────────────────────────────────────────────────────────────
# DL (torch) — state_dict + gzip
# ────────────────────────────────────────────────────────────────────────
def save_dl(sym: str, tf: str, direction: str, count: int,
             name: str, model, meta: Optional[Dict] = None) -> bool:
    backend = STORE.backend_name
    try:
        import torch
        buf = io.BytesIO()
        torch.save(model.state_dict(), buf)
        blob = gzip.compress(buf.getvalue(), compresslevel=5)
        key = f"{_root(sym, tf, direction, count)}/dl/{name}.pt.gz"
        print(f"  {CYAN}[pmc] ⏫ uploading DL {direction}/{name} → {backend} "
              f"({len(blob)/1024:.1f} KB)…{RESET}", flush=True)
        ok, where = _try_put_blob(key, blob,
                                  f"{direction} DL {name} {sym}/{tf} @ {count}")
        if ok:
            update_index(sym, tf, direction, count, "dl", name,
                          {**(meta or {}), "size_kb": round(len(blob)/1024, 1),
                           "saved_to": where})
            verify = _try_get_blob(key)
            if verify and len(verify) > 0:
                print(f"  {GREEN}[pmc] ✓ DL {direction}/{name} VERIFIED on {where} "
                      f"({len(blob)/1024:.1f} KB){RESET}", flush=True)
            else:
                print(f"  {YELLOW}[pmc] ⚠ DL {direction}/{name} verify-read failed{RESET}",
                      flush=True)
        else:
            print(f"  {RED}[pmc] ✗ DL {direction}/{name} BOTH STORAGE AND DISK FAILED{RESET}",
                  flush=True)
        return ok
    except Exception as e:
        print(f"  {YELLOW}[pmc] save DL {name} failed: {e}{RESET}", flush=True)
        return False


def load_dl(sym: str, tf: str, direction: str, count: int,
             name: str, model) -> Optional[Any]:
    """Load state_dict into the given model instance and return it. None on miss."""
    try:
        import torch
        key = f"{_root(sym, tf, direction, count)}/dl/{name}.pt.gz"
        blob = _try_get_blob(key)
        if not blob:
            return None
        try: raw = gzip.decompress(blob)
        except OSError: raw = blob
        sd = torch.load(io.BytesIO(raw), map_location="cpu")
        model.load_state_dict(sd)
        return model
    except Exception as e:
        print(f"  {GREY}[pmc] load DL {name} failed: {e}{RESET}")
        return None


# ────────────────────────────────────────────────────────────────────────
# NN (specialised neural nets — PriceReg / RL / SentimentNN / RegimeNN)
# Saves both state_dict AND wrapper-side scalars (trained flag, train_acc,
# n_features, seq_len, scaler if any) as one bundle.
# Direction is shared (these NNs are not direction-specific) — use "BOTH".
# ────────────────────────────────────────────────────────────────────────
def save_nn(sym: str, tf: str, count: int, name: str, wrapper,
            meta: Optional[Dict] = None) -> bool:
    """Save a specialised NN wrapper (PriceRegressionEnsemble / RLTradingAgent /
    SentimentNNWrapper / RegimeDetectorNNWrapper). Skips silently if wrapper
    is disabled or untrained."""
    if not getattr(wrapper, "trained", False) or not getattr(wrapper, "enabled", False):
        return False
    backend = STORE.backend_name
    try:
        import torch
        bundle = {
            "trained":     bool(getattr(wrapper, "trained", False)),
            "train_acc":   float(getattr(wrapper, "train_acc", 0.5) or 0.5),
            "n_features":  int(getattr(wrapper, "n_features", 0) or 0),
            "seq_len":     int(getattr(wrapper, "seq_len", 0) or 0),
        }
        # state_dict (model)
        if getattr(wrapper, "model", None) is not None:
            buf = io.BytesIO()
            torch.save(wrapper.model.state_dict(), buf)
            bundle["model_sd"] = buf.getvalue()
        # scaler (sklearn RobustScaler / StandardScaler — picklable)
        sc = getattr(wrapper, "scaler", None)
        if sc is not None:
            bundle["scaler_pkl"] = pickle.dumps(sc, protocol=4)
        # raw bundle bytes
        raw  = pickle.dumps(bundle, protocol=4)
        blob = gzip.compress(raw, compresslevel=5)
        key  = f"{_root(sym, tf, 'BOTH', count)}/nn/{name}.bundle.gz"
        print(f"  {CYAN}[pmc] ⏫ uploading NN {name} → {backend} "
              f"({len(blob)/1024:.1f} KB)…{RESET}", flush=True)
        ok, where = _try_put_blob(key, blob,
                                  f"NN {name} {sym}/{tf} @ {count}")
        if ok:
            update_index(sym, tf, "BOTH", count, "nn", name,
                         {**(meta or {}), "size_kb": round(len(blob)/1024, 1),
                          "saved_to": where, "train_acc": bundle["train_acc"]})
            verify = _try_get_blob(key)
            if verify and len(verify) > 0:
                print(f"  {GREEN}[pmc] ✓ NN {name} VERIFIED on {where} "
                      f"({len(blob)/1024:.1f} KB){RESET}", flush=True)
            else:
                print(f"  {YELLOW}[pmc] ⚠ NN {name} verify-read failed{RESET}",
                      flush=True)
        else:
            print(f"  {RED}[pmc] ✗ NN {name} BOTH STORAGE AND DISK FAILED{RESET}",
                  flush=True)
        return ok
    except Exception as e:
        print(f"  {YELLOW}[pmc] save NN {name} failed: {e}{RESET}", flush=True)
        return False


def load_nn(sym: str, tf: str, count: int, name: str, wrapper) -> bool:
    """Restore a specialised NN wrapper from cache. Returns True if loaded."""
    try:
        import torch
        key = f"{_root(sym, tf, 'BOTH', count)}/nn/{name}.bundle.gz"
        blob = _try_get_blob(key)
        if not blob:
            return False
        try: raw = gzip.decompress(blob)
        except OSError: raw = blob
        bundle = pickle.loads(raw)
        # Restore model state_dict
        if "model_sd" in bundle and getattr(wrapper, "model", None) is not None:
            sd = torch.load(io.BytesIO(bundle["model_sd"]), map_location="cpu")
            wrapper.model.load_state_dict(sd)
            # move to device
            dev = getattr(wrapper, "device", None)
            if dev is not None:
                try: wrapper.model.to(dev)
                except Exception: pass
        # Restore scaler
        if "scaler_pkl" in bundle:
            try: wrapper.scaler = pickle.loads(bundle["scaler_pkl"])
            except Exception: pass
        # Restore flags
        wrapper.trained   = bool(bundle.get("trained", True))
        wrapper.train_acc = float(bundle.get("train_acc", 0.5))
        return True
    except Exception as e:
        print(f"  {GREY}[pmc] load NN {name} failed: {e}{RESET}")
        return False


def summary_line(sym: str, tf: str, direction: str, count: int) -> str:
    d = list_done(sym, tf, direction, count)
    nn_count = len(d.get('nn', []))
    return (f"{direction}: classical={len(d['classical'])}/9 "
            f"dl={len(d['dl'])}/14 nn={nn_count}/4")
