"""
stderr_filter.py — Suppress noisy OpenBLAS warnings at the OS level.

Kaggle's pre-installed numpy/sklearn are compiled with OpenMP-incompatible
OpenBLAS. When our code uses any nested threads, OpenBLAS prints:
    "OpenBLAS Warning : Detect OpenMP Loop and this application may hang..."
for EVERY matrix operation. Millions of lines → floods Kaggle UI.

Setting OMP_NUM_THREADS=1 doesn't help (env vars are read once at import).
The warning is hard-coded in OpenBLAS's compiled C code.

Solution: pipe stderr through a filter at the OS level. The filter drops
any line containing 'OpenBLAS Warning' or similar known noise patterns,
and forwards everything else.

This MUST run before numpy/sklearn import to be effective.
"""
from __future__ import annotations
import os, sys, threading

# Patterns to drop (case-insensitive substring match).
# Keep this list TIGHT — anything ambiguous goes through so real errors
# (tracebacks, exceptions) are never accidentally filtered.
_NOISE_PATTERNS = [
    "openblas warning : detect openmp loop",
]

_installed = False


def _is_noise(line: str) -> bool:
    low = line.lower()
    return any(p in low for p in _NOISE_PATTERNS)


def install_stderr_filter():
    """Replace stderr with a filtering wrapper. Idempotent.
    Skipped if V24_DISABLE_STDERR_FILTER=1."""
    global _installed
    if _installed:
        return
    if os.environ.get("V24_DISABLE_STDERR_FILTER") == "1":
        return
    _installed = True

    # Save the real stderr file descriptor
    real_stderr_fd = os.dup(2)
    real_stderr = os.fdopen(real_stderr_fd, "wb", buffering=0)

    # Create a pipe; write end goes to fd 2 (where everything writes stderr)
    r_fd, w_fd = os.pipe()
    os.dup2(w_fd, 2)
    os.close(w_fd)

    # Reader thread: read lines from pipe, drop noisy ones, write rest to real stderr
    def _reader():
        buf = b""
        while True:
            try:
                chunk = os.read(r_fd, 65536)
            except OSError:
                break
            if not chunk:
                break
            buf += chunk
            while b"\n" in buf:
                line, buf = buf.split(b"\n", 1)
                try:
                    text = line.decode("utf-8", errors="replace")
                except Exception:
                    text = ""
                if not _is_noise(text):
                    try:
                        real_stderr.write(line + b"\n")
                    except Exception:
                        pass

    t = threading.Thread(target=_reader, daemon=True, name="stderr-filter")
    t.start()
