"""
model_cache.py — Per-direction committee cache (full state, not slim metadata).

The engine's `run_ml_committee` runs ALL classical + DL models inside a single
ThreadPoolExecutor call. It either fully succeeds or fully fails — there's no
per-model resume because the engine is byte-identical to v22.

What we CAN do: cache the entire trained committee (pickled). If the cell
crashes after the committee succeeded, next run loads from disk in <1s instead
of retraining for 10-90 seconds.

Cache key includes the candle count so different training sizes don't collide.
"""
from __future__ import annotations
import os, gzip, pickle, hashlib, time
from typing import Dict, Optional

from core.storage import STORE
from core.colors  import GREEN, YELLOW, CYAN, RESET, GREY


def _key(symbol: str, tf: str, direction: str, candle_count: int) -> str:
    h = hashlib.sha1(f"{symbol}_{tf}_{direction}_{candle_count}".encode()).hexdigest()[:10]
    return f"committee_full_{symbol.replace('-','_')}_{tf}_{direction.lower()}_{candle_count}_{h}"


def save_committee(symbol: str, tf: str, direction: str, candle_count: int,
                    committee: Dict) -> bool:
    """Pickle the entire committee dict (incl. fitted models) and push to storage."""
    if committee is None:
        return False
    key = _key(symbol, tf, direction, candle_count)
    try:
        raw = pickle.dumps(committee, protocol=4)
        compressed = gzip.compress(raw, compresslevel=5)
        # Try push as blob (storage backend handles compression internally)
        ok = STORE.put_blob(key, compressed, compress=False,
                            message=f"committee {direction} {symbol}/{tf} @ {candle_count} candles")
        if ok:
            print(f"  {GREEN}[mcache] saved {direction} committee "
                  f"({len(compressed)/1024:.1f} KB){RESET}")
        return ok
    except Exception as e:
        print(f"  {YELLOW}[mcache] save failed: {e}{RESET}")
        return False


def load_committee(symbol: str, tf: str, direction: str, candle_count: int) -> Optional[Dict]:
    """Try to load a previously trained committee. Returns None on miss / error."""
    key = _key(symbol, tf, direction, candle_count)
    try:
        blob = STORE.get_blob(key)
        if not blob:
            return None
        try:
            raw = gzip.decompress(blob)
        except OSError:
            raw = blob  # not compressed
        committee = pickle.loads(raw)
        print(f"  {GREEN}[mcache] ✓ loaded cached {direction} committee "
              f"({len(blob)/1024:.1f} KB) — skipping retrain{RESET}")
        return committee
    except Exception as e:
        print(f"  {GREY}[mcache] cache miss / load failed ({e}){RESET}")
        return None


def cache_summary(symbol: str, tf: str, candle_count: int) -> str:
    parts = []
    for d in ("LONG", "SHORT"):
        c = load_committee(symbol, tf, d, candle_count) is not None
        parts.append(f"{d}={'cached' if c else '—'}")
    return " · ".join(parts)
