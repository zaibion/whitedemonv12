"""
live_performance.py — V12.2 Live Performance Analytics
Regime / confidence / session breakdown — CIO dashboard
"""
from __future__ import annotations
from typing import Dict, Any
try:
    from core.trade_quality_ai import get_tqai
    HAS_TQ = True
except Exception:
    HAS_TQ = False

def get_live_analytics() -> Dict[str, Any]:
    if not HAS_TQ:
        return {"available": False, "reason": "TQAI not installed"}
    try:
        tq = get_tqai()
        perf = tq.performance_by_bucket()
        # add health summary
        perf["health"] = {
            "status": "green" if perf.get("winrate",0) >= 0.68 else "amber" if perf.get("winrate",0) >= 0.60 else "red",
            "n_trades_30d": min(perf.get("n_trades",0), 999),
            "model": "WhiteDemon V12.2 MAX WIN + TQAI"
        }
        return perf
    except Exception as e:
        return {"available": False, "reason": str(e)[:120]}

def score_live_signal(signal: Dict[str, Any]) -> Dict[str, Any]:
    """Apply Trade Quality AI adjustment to a live signal"""
    try:
        if not HAS_TQ:
            return signal
        tq = get_tqai()
        q = tq.quality_score(signal)
        out = dict(signal)
        # adjust confidence
        base_p = float(out.get("meta_prob_live", out.get("stack_bull",0.5)))
        adj = q.get("quality_adj",1.0)
        adj_p = float(max(0.01, min(0.99, base_p * adj if adj>1 else base_p - (1-adj)*0.15)))
        out["tqai_quality_adj"] = q["quality_adj"]
        out["tqai_learned_winrate"] = q["learned_winrate"]
        out["tqai_n_similar"] = q["n_similar"]
        out["meta_prob_live_tq"] = round(adj_p,4)
        # if learned winrate < 0.60, block
        if q.get("learned_winrate") is not None and q["learned_winrate"] < 0.60 and q["n_similar"] >= 12:
            out["tqai_block"] = True
            out["trade_allowed"] = False
            cbs = out.get("circuit_breakers", [])
            if isinstance(cbs, list):
                cbs.append("TQAI_LOW_HIST_WR")
                out["circuit_breakers"] = cbs
        out["tqai_version"] = "v12.2"
        return out
    except Exception:
        return signal
