"""
position_sizer.py — Institutional Position Sizing
Volatility targeting + Kelly + correlation haircut
"""

from __future__ import annotations
import numpy as np

def atr_size(equity: float, atr_pct: float, risk_per_trade: float = 0.008) -> float:
    """ATR-based notional: risk_per_trade / atr_pct"""
    if atr_pct <= 0: return 0.0
    return float(np.clip(risk_per_trade / atr_pct, 0.01, 0.25))

def kelly_optimal(p_win: float, rr: float = 2.5, fraction: float = 0.35, cap: float = 0.25) -> float:
    p = np.clip(p_win, 0.35, 0.80)
    b = rr
    f_star = (p*b - (1-p)) / b
    return float(np.clip(f_star * fraction, 0.0, cap))

def correlation_haircut(n_correlated_positions: int, avg_rho: float = 0.38) -> float:
    if n_correlated_positions <= 1: return 1.0
    eff_n = n_correlated_positions * (1 - avg_rho) + n_correlated_positions**2 * avg_rho
    eff_n = max(1.0, eff_n)
    return float(np.clip(np.sqrt(n_correlated_positions / eff_n), 0.45, 1.0))
