"""
coin_tuner_v12_1.py — V12.1 MAX WIN coin-specific profiles
CIO approved — 12-coin tuning — no engine bytes changed
Injects per-symbol hyperparams into institutional_v12.INSTITUTIONAL_CFG
before each train_meta_labeler / run_ml_committee call.
"""

from __future__ import annotations
import re

COIN_PROFILES = {
    # majors — institutional tight
    "BTC":  {"meta_threshold":0.65, "meta_min_pass_winrate":0.71, "rr":2.45, "kelly_f_cap":0.22, "prim_proba_min":0.57, "stack_min":0.63, "max_daily_dd":0.030, "vol_target":0.45, "embargo_bars":48},
    "ETH":  {"meta_threshold":0.64, "meta_min_pass_winrate":0.70, "rr":2.5,  "kelly_f_cap":0.23, "prim_proba_min":0.56, "stack_min":0.62, "max_daily_dd":0.032, "vol_target":0.55, "embargo_bars":48},
    "SOL":  {"meta_threshold":0.67, "meta_min_pass_winrate":0.72, "rr":2.65, "kelly_f_cap":0.20, "prim_proba_min":0.59, "stack_min":0.65, "max_daily_dd":0.035, "vol_target":0.72, "embargo_bars":56},
    "BNB":  {"meta_threshold":0.64, "meta_min_pass_winrate":0.70, "rr":2.5,  "kelly_f_cap":0.23, "prim_proba_min":0.56, "stack_min":0.62, "max_daily_dd":0.032, "vol_target":0.50, "embargo_bars":48},
    "XRP":  {"meta_threshold":0.66, "meta_min_pass_winrate":0.71, "rr":2.55, "kelly_f_cap":0.21, "prim_proba_min":0.57, "stack_min":0.64, "max_daily_dd":0.035, "vol_target":0.60, "embargo_bars":52},
    "ADA":  {"meta_threshold":0.65, "meta_min_pass_winrate":0.70, "rr":2.5,  "kelly_f_cap":0.21, "prim_proba_min":0.57, "stack_min":0.63, "max_daily_dd":0.035, "vol_target":0.58, "embargo_bars":50},
    "DOGE": {"meta_threshold":0.68, "meta_min_pass_winrate":0.73, "rr":2.75, "kelly_f_cap":0.18, "prim_proba_min":0.60, "stack_min":0.66, "max_daily_dd":0.038, "vol_target":0.78, "embargo_bars":56},
    "AVAX": {"meta_threshold":0.66, "meta_min_pass_winrate":0.71, "rr":2.6,  "kelly_f_cap":0.20, "prim_proba_min":0.58, "stack_min":0.64, "max_daily_dd":0.036, "vol_target":0.70, "embargo_bars":54},
    "LINK": {"meta_threshold":0.65, "meta_min_pass_winrate":0.70, "rr":2.5,  "kelly_f_cap":0.22, "prim_proba_min":0.57, "stack_min":0.63, "max_daily_dd":0.033, "vol_target":0.62, "embargo_bars":50},
    "LTC":  {"meta_threshold":0.64, "meta_min_pass_winrate":0.69, "rr":2.45, "kelly_f_cap":0.23, "prim_proba_min":0.56, "stack_min":0.62, "max_daily_dd":0.031, "vol_target":0.52, "embargo_bars":48},
    "DOT":  {"meta_threshold":0.65, "meta_min_pass_winrate":0.70, "rr":2.5,  "kelly_f_cap":0.22, "prim_proba_min":0.57, "stack_min":0.63, "max_daily_dd":0.034, "vol_target":0.60, "embargo_bars":50},
    "MATIC":{"meta_threshold":0.66, "meta_min_pass_winrate":0.71, "rr":2.6,  "kelly_f_cap":0.20, "prim_proba_min":0.58, "stack_min":0.64, "max_daily_dd":0.036, "vol_target":0.68, "embargo_bars":54},
    # --- MEME VOLATILE COINS — V12.2 MAX WIN MEME PACK ---
    # tighter meta, higher RR, lower Kelly, longer embargo — survive meme volatility
    "PEPE":  {"meta_threshold":0.70, "meta_min_pass_winrate":0.74, "rr":2.9, "kelly_f_cap":0.15, "prim_proba_min":0.62, "stack_min":0.68, "max_daily_dd":0.040, "vol_target":1.15, "embargo_bars":64, "meme_vol": True},
    "SHIB":  {"meta_threshold":0.69, "meta_min_pass_winrate":0.73, "rr":2.8, "kelly_f_cap":0.16, "prim_proba_min":0.61, "stack_min":0.67, "max_daily_dd":0.038, "vol_target":0.95, "embargo_bars":60, "meme_vol": True},
    "FLOKI": {"meta_threshold":0.70, "meta_min_pass_winrate":0.74, "rr":2.9, "kelly_f_cap":0.15, "prim_proba_min":0.62, "stack_min":0.68, "max_daily_dd":0.040, "vol_target":1.10, "embargo_bars":64, "meme_vol": True},
    "WIF":   {"meta_threshold":0.69, "meta_min_pass_winrate":0.73, "rr":2.85,"kelly_f_cap":0.16, "prim_proba_min":0.61, "stack_min":0.67, "max_daily_dd":0.039, "vol_target":1.05, "embargo_bars":62, "meme_vol": True},
    "BONK":  {"meta_threshold":0.70, "meta_min_pass_winrate":0.74, "rr":2.9, "kelly_f_cap":0.15, "prim_proba_min":0.62, "stack_min":0.68, "max_daily_dd":0.040, "vol_target":1.20, "embargo_bars":64, "meme_vol": True},
    # extra high-beta trending
    "TRUMP":{"meta_threshold":0.71, "meta_min_pass_winrate":0.75, "rr":3.0, "kelly_f_cap":0.14, "prim_proba_min":0.63, "stack_min":0.69, "max_daily_dd":0.042, "vol_target":1.35, "embargo_bars":68, "meme_vol": True},
    "PEPECOIN":{"meta_threshold":0.70, "meta_min_pass_winrate":0.74, "rr":2.9, "kelly_f_cap":0.15, "prim_proba_min":0.62, "stack_min":0.68, "max_daily_dd":0.040, "vol_target":1.15, "embargo_bars":64, "meme_vol": True},
    "DEFAULT": {"meta_threshold":0.65, "meta_min_pass_winrate":0.70, "rr":2.5, "kelly_f_cap":0.22, "prim_proba_min":0.57, "stack_min":0.63, "max_daily_dd":0.034, "vol_target":0.60, "embargo_bars":50},
}

def _normalize_symbol(s: str | None) -> str:
    if not s: return "DEFAULT"
    ss = str(s).upper().replace("-USD","").replace("USD","").replace("USDT","").replace("/","").replace("-PERP","").strip()
    m = re.match(r"([A-Z]{2,6})", ss)
    return m.group(1) if m else "DEFAULT"

def get_profile_for_ctx():
    sym = "DEFAULT"
    try:
        from core.engine_patches import _get_ctx
        s, tf, direction, count = _get_ctx()
        sym = _normalize_symbol(s)
    except Exception:
        pass
    base = COIN_PROFILES.get(sym, COIN_PROFILES["DEFAULT"]).copy()
    base["symbol"] = sym
    return base

_installed = False
def install_coin_tuner():
    global _installed
    if _installed:
        return True
    try:
        import core.institutional_v12 as iv
        _orig_meta = iv.institutional_train_meta_labeler_v22
        _orig_comm = iv.institutional_run_ml_committee
        # also patch risk_overlay thresholds if present
        def meta_wrapped(df, sentiment, train_cutoff, direction="LONG"):
            prof = get_profile_for_ctx()
            # push profile into INSTITUTIONAL_CFG temporarily
            backup = {}
            for k,v in prof.items():
                if k in iv.INSTITUTIONAL_CFG:
                    backup[k] = iv.INSTITUTIONAL_CFG[k]
                    iv.INSTITUTIONAL_CFG[k] = v
                # allow new keys like prim_proba_min / stack_min
                elif k in ("prim_proba_min","stack_min","max_daily_dd","vol_target"):
                    backup[k] = iv.INSTITUTIONAL_CFG.get(k)
                    iv.INSTITUTIONAL_CFG[k] = v
            try:
                out = _orig_meta(df, sentiment, train_cutoff, direction)
                # attach coin tag
                if isinstance(out, dict):
                    out["coin_profile"] = prof.get("symbol","?")
                    out["coin_tuned"] = True
                    out["v12_1"] = True
                return out
            finally:
                # restore
                for k,v in backup.items():
                    if v is None:
                        iv.INSTITUTIONAL_CFG.pop(k, None)
                    else:
                        iv.INSTITUTIONAL_CFG[k] = v
        def comm_wrapped(df, sentiment, train_cutoff, llm_features=None, direction="LONG"):
            prof = get_profile_for_ctx()
            backup = {}
            for k,v in prof.items():
                if k in iv.INSTITUTIONAL_CFG:
                    backup[k] = iv.INSTITUTIONAL_CFG[k]
                    iv.INSTITUTIONAL_CFG[k] = v
            try:
                out = _orig_comm(df, sentiment, train_cutoff, llm_features, direction)
                if isinstance(out, dict):
                    out["coin_profile"] = prof.get("symbol","?")
                    out["coin_tuned"] = True
                    out["v12_1"] = True
                    # expose tuning for transparency
                    out["tuning"] = {kk: prof[kk] for kk in ["meta_threshold","meta_min_pass_winrate","rr","kelly_f_cap","prim_proba_min","stack_min"] if kk in prof}
                return out
            finally:
                for k,v in backup.items():
                    if v is None:
                        iv.INSTITUTIONAL_CFG.pop(k, None)
                    else:
                        iv.INSTITUTIONAL_CFG[k] = v
        iv.institutional_train_meta_labeler_v22 = meta_wrapped
        iv.institutional_run_ml_committee = comm_wrapped
        # also re-point engine exports (they already point to iv.* — but iv.* now wrapped)
        try:
            import _engine as eng
            eng.train_meta_labeler_v22 = meta_wrapped
            eng.run_ml_committee = comm_wrapped
        except Exception:
            pass
        _installed = True
        print("[V12.2 MAX WIN MEME+] ✓ 17-coin profiles active:")
        print("  majors: BTC ETH SOL BNB XRP ADA DOGE AVAX LINK LTC DOT MATIC")
        print("  memes:  PEPE SHIB FLOKI WIF BONK (+TRUMP)")
        print("  SOL: meta 0.67 • WR 0.72 • RR 2.65 • Kelly 0.20 • emb 56")
        print("  MEME: meta 0.69-0.71 • WR 0.73-0.75 • RR 2.8-3.0 • Kelly 0.14-0.16 • emb 60-68")
        return True
    except Exception as e:
        print(f"[V12.1] coin tuner install failed: {e}")
        return False
