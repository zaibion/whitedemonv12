"""
committee_reassembly.py — Build the slim `long_<rid>` / `short_<rid>` JSON
                         from per-model cache after piecemeal training.

train_specific.py trains individual models. Those save to
    perm/<sym>/<tf>/<dir>/<count>/classical/<name>.pkl.gz
    perm/<sym>/<tf>/<dir>/<count>/dl/<name>.pt.gz

But FAST MODE (analyze.py) reads the dashboard slim summary at
    long_<rid> / short_<rid>

This module bridges the two: when all expected models are present in the
per-model cache, generate the slim JSON so FAST MODE works.
"""
from __future__ import annotations
from typing import Dict, Optional

from core.storage   import STORE
from core           import per_model_cache as pmc
from core.colors    import GREEN, YELLOW, GREY, RESET, BOLD, CYAN


CLASSICAL_MODELS = ["lr", "knn", "rf", "et", "xgb", "lgb", "cat", "hgb", "mlp"]
DL_MODELS = ["lstm", "bilstm", "gru", "tcn", "wavenet", "transformer",
              "cnn1d", "nbeats", "mamba", "patchtst", "itransformer",
              "frets", "tft", "mamba_pdf"]


def is_fully_trained(sym: str, tf: str, direction: str, count: int,
                      require_dl: bool = False) -> bool:
    """True if all 9 classical (and optionally all 14 DL) models exist."""
    done = pmc.list_done(sym, tf, direction, count)
    have_cls = set(done.get("classical", []))
    if not all(m in have_cls for m in CLASSICAL_MODELS):
        return False
    if require_dl:
        have_dl = set(done.get("dl", []))
        if not all(m in have_dl for m in DL_MODELS):
            return False
    return True


def build_slim_committee(sym: str, tf: str, direction: str, count: int) -> Dict:
    """Synthesize a slim committee dict from per-model cache metadata.

    Returns a dict that looks like what `train_pipeline._slim(cm)` would
    produce, so analyze.py can read it as if a full committee training had
    just finished.
    """
    idx = pmc.get_index(sym, tf, direction, count)
    cls_meta = idx.get("classical", {})
    dl_meta  = idx.get("dl",        {})

    # WF accuracies → average → coarse "stack_bull" estimate
    wf_accs = {n: float(m.get("wf", 0.5)) for n, m in cls_meta.items()}
    dl_accs = {n: float(m.get("acc", 0.5)) for n, m in dl_meta.items()}

    # Stack-bull estimate: weighted average of classical wf_acc + DL acc,
    # then scaled by 0.5 + 0.5 * mean to map [0,1] → conservative prob.
    all_accs = list(wf_accs.values()) + list(dl_accs.values())
    avg_acc = sum(all_accs) / len(all_accs) if all_accs else 0.5
    stack_bull = max(0.0, min(1.0, avg_acc))   # use mean acc as proxy

    return {
        "stack_bull":        stack_bull,
        "wf_accs":           wf_accs,
        "dl_individual":     dl_accs,
        "preds":             {n: 1 if wf_accs[n] >= 0.5 else 0 for n in wf_accs},
        "probs":             {n: wf_accs[n] for n in wf_accs},
        "n_models":          len(wf_accs) + len(dl_accs),
        "baseline_win_rate": 0.5,
        "reassembled":       True,
        "metadata_only_probability": True,
        "probability_warning": "stack_bull is metadata-derived from cached model accuracy; analyze.py should prefer true cached-model inference",
        "direction":         direction,
    }


def write_slim_for_fast_mode(sym: str, tf: str, count: int,
                              require_dl: bool = False) -> bool:
    """If both LONG and SHORT have all required models cached, write the
    slim summaries so FAST MODE works. Returns True if both written."""
    rid = f"{sym.replace('-','_')}_{tf}"
    wrote = []
    for d in ("LONG", "SHORT"):
        if not is_fully_trained(sym, tf, d, count, require_dl=require_dl):
            done = pmc.list_done(sym, tf, d, count)
            missing_cls = [m for m in CLASSICAL_MODELS if m not in done["classical"]]
            missing_dl  = ([m for m in DL_MODELS if m not in done["dl"]]
                            if require_dl else [])
            print(f"  {YELLOW}[reassembly] {d} not complete: "
                  f"classical missing={missing_cls} dl missing={missing_dl}{RESET}")
            continue
        slim = build_slim_committee(sym, tf, d, count)
        key  = f"{d.lower()}_{rid}"
        try:
            STORE.put_json(key, {"result": slim},
                            message=f"reassembled {d} committee {sym}/{tf}")
            print(f"  {GREEN}[reassembly] ✓ wrote slim {key} (stack_bull={slim['stack_bull']*100:.1f}%){RESET}")
            wrote.append(d)
        except Exception as e:
            print(f"  {YELLOW}[reassembly] failed to write {key}: {e}{RESET}")
    return len(wrote) == 2
