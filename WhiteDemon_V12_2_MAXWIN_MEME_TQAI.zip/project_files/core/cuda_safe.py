"""
cuda_safe.py — Smart CUDA detection: only disable on REAL kernel mismatch.

Critical change in v24.4: previously this disabled CUDA on ANY exception
from the smoke test. That was too aggressive — could falsely flag a working
P100/V100/A100 as broken.

Now: only disables CUDA when the error message matches known kernel-mismatch
patterns ('no kernel image', 'CUDA error: invalid device', etc).
"""
from __future__ import annotations
import os

_CUDA_STATUS = {"verified": False, "usable": False, "reason": "not checked",
                 "device_name": "", "device_cc": "", "mem_gb": 0.0}


# Errors that mean "PyTorch wheel doesn't support this GPU" → fallback to CPU
_KERNEL_MISMATCH_PATTERNS = (
    "no kernel image is available",
    "cudaerrornokernelimage",
    "invalid device function",
    "ptxas",
    "unsupported gnu version",
)


def _is_kernel_mismatch(err_msg: str) -> bool:
    msg = err_msg.lower()
    return any(p in msg for p in _KERNEL_MISMATCH_PATTERNS)


def verify_cuda_works(quiet: bool = False) -> bool:
    """Return True if CUDA is usable. Only disables CUDA on REAL kernel
    mismatch errors (not on OOM, not on transient errors)."""
    global _CUDA_STATUS
    if _CUDA_STATUS["verified"]:
        return _CUDA_STATUS["usable"]

    try:
        import torch
    except ImportError:
        _CUDA_STATUS = {"verified": True, "usable": False, "reason": "torch not installed",
                         "device_name": "", "device_cc": "", "mem_gb": 0.0}
        return False

    if not torch.cuda.is_available():
        _CUDA_STATUS = {"verified": True, "usable": False, "reason": "no CUDA device",
                         "device_name": "", "device_cc": "", "mem_gb": 0.0}
        return False

    # Capture device info first (so even if smoke test fails we can report)
    try:
        gpu_name = torch.cuda.get_device_name(0)
        props    = torch.cuda.get_device_properties(0)
        mem_gb   = props.total_memory / 1024**3
        cc       = f"sm_{props.major}{props.minor}"
        _CUDA_STATUS["device_name"] = gpu_name
        _CUDA_STATUS["device_cc"]   = cc
        _CUDA_STATUS["mem_gb"]      = mem_gb
    except Exception:
        pass

    # Smoke test: simple matmul (the most common op in deep learning).
    # If this works on a given GPU, almost everything else will.
    try:
        x = torch.randn(64, 64, device="cuda")
        y = torch.randn(64, 64, device="cuda")
        z = x @ y
        torch.cuda.synchronize()
        del x, y, z
        torch.cuda.empty_cache()
        _CUDA_STATUS["verified"] = True
        _CUDA_STATUS["usable"] = True
        _CUDA_STATUS["reason"] = "ok"
        if not quiet:
            print(f"  [cuda-safe] ✓ CUDA works: {_CUDA_STATUS['device_name']} "
                  f"({_CUDA_STATUS['device_cc']}, {_CUDA_STATUS['mem_gb']:.1f} GB)")
        return True
    except Exception as e:
        msg = str(e)
        _CUDA_STATUS["verified"] = True
        _CUDA_STATUS["reason"] = msg[:200]

        # ONLY disable CUDA if it's the specific kernel-mismatch error
        if _is_kernel_mismatch(msg):
            _CUDA_STATUS["usable"] = False
            if not quiet:
                print(f"  [cuda-safe] ⚠ CUDA kernel mismatch on "
                      f"{_CUDA_STATUS['device_name']} ({_CUDA_STATUS['device_cc']})")
                print(f"  [cuda-safe] → PyTorch wheel doesn't include code for this GPU.")
                print(f"  [cuda-safe] → forcing CPU mode (no crash)")
            os.environ["CUDA_VISIBLE_DEVICES"] = ""
            try:
                torch.cuda.is_available = lambda: False
                torch.cuda.device_count = lambda: 0
            except Exception:
                pass
            return False

        # Any other error (OOM, transient) — assume CUDA is fine, just this one op failed
        _CUDA_STATUS["usable"] = True
        if not quiet:
            print(f"  [cuda-safe] ⚠ smoke test threw non-kernel error: {msg[:100]}")
            print(f"  [cuda-safe] → assuming CUDA is fine, continuing")
        return True


def is_cuda_usable() -> bool:
    if not _CUDA_STATUS["verified"]:
        verify_cuda_works(quiet=True)
    return _CUDA_STATUS["usable"]


def safe_device() -> str:
    return "cuda" if is_cuda_usable() else "cpu"


def get_status() -> dict:
    return dict(_CUDA_STATUS)


def print_status():
    """Print a clear summary — call from menu to verify GPU state."""
    s = get_status()
    if s["usable"]:
        print(f"  ✅ CUDA active: {s['device_name']} "
              f"({s['device_cc']}, {s['mem_gb']:.1f} GB)")
        print(f"     DL models WILL train on GPU.")
    else:
        print(f"  ❌ CUDA inactive — reason: {s['reason'][:120]}")
        print(f"     Device detected: {s['device_name'] or 'none'}")
        print(f"     DL models will train on CPU (slower but works).")
