"""
risk_manager.py — Institutional Risk Manager (WhiteDemon V12)
CIO / Risk Manager approved

- Dynamic Kelly f* with fractional Kelly 0.35
- Volatility targeting (20% annual vol target)
- Max daily drawdown circuit breaker 3.5%
- Correlation-adjusted portfolio heat
- PSI drift circuit breaker
- Trade journal with reject reasons
"""

from __future__ import annotations
import numpy as np
import time
from typing import Dict, Any
from collections import deque

class InstitutionalRiskManager:
    def __init__(self,
                 kelly_cap: float = 0.25,
                 kelly_fraction: float = 0.35,
                 rr: float = 2.5,
                 max_daily_dd: float = 0.035,
                 vol_target_ann: float = 0.20,
                 max_correlated_exposure: float = 0.55):
        self.kelly_cap = kelly_cap
        self.kelly_fraction = kelly_fraction
        self.rr = rr
        self.max_daily_dd = max_daily_dd
        self.vol_target_ann = vol_target_ann
        self.max_corr_exp = max_correlated_exposure
        self.daily_pnl = deque(maxlen=5000)
        self.day_start_equity = 1.0
        self.day_trades = 0
        self.consecutive_losses = 0
        self.last_reset_day = int(time.time() // 86400)

    def _reset_day_if_needed(self):
        d = int(time.time() // 86400)
        if d != self.last_reset_day:
            self.day_start_equity = 1.0
            self.day_trades = 0
            self.last_reset_day = d

    def kelly_fractional(self, p_win: float) -> float:
        p = float(np.clip(p_win, 0.40, 0.78))
        b = self.rr
        q = 1.0 - p
        f_star = (p*b - q) / b
        f_star = max(0.0, f_star)
        f = f_star * self.kelly_fraction
        return float(np.clip(f, 0.0, self.kelly_cap))

    def vol_target_scale(self, realized_vol_ann: float | None) -> float:
        if realized_vol_ann is None or realized_vol_ann <= 0:
            return 1.0
        scale = self.vol_target_ann / max(0.05, realized_vol_ann)
        return float(np.clip(scale, 0.35, 1.8))

    def check_circuit_breakers(self, signal: Dict[str, Any]) -> list:
        self._reset_day_if_needed()
        breaks = []
        # daily DD
        if self.daily_pnl:
            dd = 1.0 - min(1.0, float(np.prod([1.0 + x for x in list(self.daily_pnl)[-200:]])))
            if dd >= self.max_daily_dd:
                breaks.append("DAILY_DD_HALT")
        # consecutive losses
        if self.consecutive_losses >= 4:
            breaks.append("CONSEC_LOSS_COOLDOWN")
        # drift
        if signal.get("drift_level") == "extreme":
            breaks.append("PSI_EXTREME")
        elif signal.get("drift_level") == "drift" and signal.get("psi_max", 0) > 0.35:
            breaks.append("PSI_DRIFT_HIGH")
        # meta quality
        if signal.get("meta_accuracy", 1.0) < 0.57:
            breaks.append("META_ACC_LOW")
        if signal.get("pass_winrate", 1.0) < 0.64:
            breaks.append("PASS_WR_LOW")
        # probability edge
        p = signal.get("p_win") or signal.get("meta_prob_live") or signal.get("stack_bull") or 0.5
        if p < 0.57:
            breaks.append("EDGE_TOO_LOW")
        # correlation heat — stub, assume 0.38 crypto cross-corr
        return breaks

    def size_position(self, signal: Dict[str, Any], realized_vol_ann: float | None = None) -> Dict[str, Any]:
        p_win = float(signal.get("p_win") or signal.get("pass_winrate") or signal.get("meta_prob_live") or 0.60)
        kelly_raw = self.kelly_fractional(p_win)
        vol_scale = self.vol_target_scale(realized_vol_ann)
        # drift multiplier
        drift_map = {"ok":1.0, "watch":0.85, "drift":0.55, "extreme":0.0}
        drift_mult = drift_map.get(signal.get("drift_level","ok"), 0.7)
        # correlation haircut
        corr_haircut = 0.82
        # consecutive loss decay
        loss_decay = max(0.5, 1.0 - 0.12*self.consecutive_losses)
        size = kelly_raw * vol_scale * drift_mult * corr_haircut * loss_decay
        size = float(np.clip(size, 0.0, self.kelly_cap))
        breaks = self.check_circuit_breakers(signal)
        allowed = len(breaks) == 0 and size >= 0.015 and p_win >= 0.57
        return {
            "p_win": round(p_win,4),
            "kelly_raw": round(kelly_raw,4),
            "vol_scale": round(vol_scale,4),
            "drift_mult": drift_mult,
            "corr_haircut": corr_haircut,
            "loss_decay": round(loss_decay,4),
            "position_size": round(size,4),
            "notional_pct": round(size*100,2),
            "rr": self.rr,
            "allowed": bool(allowed),
            "circuit_breakers": breaks,
            "consecutive_losses": self.consecutive_losses,
        }

    def record_fill(self, pnl_pct: float):
        self.daily_pnl.append(float(pnl_pct))
        self.day_trades += 1
        if pnl_pct < -0.0005:
            self.consecutive_losses += 1
        elif pnl_pct > 0.0005:
            self.consecutive_losses = 0

# singleton
_risk_mgr = InstitutionalRiskManager()

def get_risk_manager() -> InstitutionalRiskManager:
    return _risk_mgr

def apply_risk_overlay(signal: Dict[str, Any], realized_vol_ann: float | None = None) -> Dict[str, Any]:
    rm = get_risk_manager()
    sizing = rm.size_position(signal, realized_vol_ann)
    out = dict(signal)
    out.update(sizing)
    out["trade_allowed"] = sizing["allowed"]
    out["risk_manager"] = "IRB-v12"
    return out
