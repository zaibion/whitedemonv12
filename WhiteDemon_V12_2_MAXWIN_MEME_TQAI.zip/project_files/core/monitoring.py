"""Lightweight monitoring (V9.4).

Writes JSON + Prometheus text files locally and optionally sends StatsD metrics.
No required external service; Prometheus/StatsD compatible when configured.
"""
from __future__ import annotations
from typing import Dict, Any
import os, json, time, socket, datetime

METRICS_JSON = "runtime_metrics.json"
METRICS_PROM = "runtime_metrics.prom"


def _flatten(prefix: str, obj: Any, out: Dict[str, float]):
    if isinstance(obj, dict):
        for k, v in obj.items():
            key = f"{prefix}_{k}" if prefix else str(k)
            _flatten(key, v, out)
    elif isinstance(obj, (int, float, bool)):
        out[prefix] = float(obj)


def emit_metrics(metrics: Dict[str, Any], namespace: str = "whitedemon") -> Dict[str, Any]:
    """Persist metrics and optionally send StatsD gauges.

    Environment for StatsD:
      STATSD_HOST=127.0.0.1
      STATSD_PORT=8125
    """
    payload = {
        "saved_at": datetime.datetime.utcnow().isoformat() + "Z",
        "namespace": namespace,
        **metrics,
    }
    try:
        with open(METRICS_JSON, "w") as f:
            json.dump(payload, f, default=str, indent=2)
    except Exception:
        pass

    flat: Dict[str, float] = {}
    _flatten(namespace, metrics, flat)
    try:
        with open(METRICS_PROM, "w") as f:
            for k, v in sorted(flat.items()):
                safe = "".join(ch if ch.isalnum() or ch == "_" else "_" for ch in k.lower())
                f.write(f"{safe} {v}\n")
    except Exception:
        pass

    host = os.environ.get("STATSD_HOST")
    port = int(os.environ.get("STATSD_PORT", "8125") or 8125)
    if host:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            for k, v in flat.items():
                safe = ".".join(part for part in k.replace("_", ".").split(".") if part)
                sock.sendto(f"{safe}:{v}|g".encode(), (host, port))
            sock.close()
        except Exception:
            pass
    return payload
