"""
Unified storage backend (v25.6 — multi-backend chain).

Priority chain for SAVE (writes to ALL configured backends, never loses data):
  1. Firebase (Web SDK / Pyrebase)  — fastest reads
  2. Supabase (REST API)            — SQL rows
  3. GitHub  (REST API)             — canonical backup; data/blobs can be wiped by Menu 6

Priority chain for READ:
  1. Firebase  → 2. Supabase  → 3. GitHub
  First backend with the key wins.

API:
    STORE = Storage()        # singleton, auto-configured
    STORE.put_json(\"key\", {...})           # small JSON metadata
    STORE.get_json(\"key\")                  # → dict | None
    STORE.put_blob(\"models/long.pkl\", b)   # big binary
    STORE.get_blob(\"models/long.pkl\")      # → bytes | None
    STORE.list(\"prefix/\")                  # → list[str]
"""
from __future__ import annotations
import os, sys, json, base64, gzip, hashlib, datetime, requests
from typing import Optional, Union, List

# Optional Firebase Admin SDK
try:
    import firebase_admin
    from firebase_admin import credentials, firestore, storage as fb_storage
    HAS_FIREBASE = True
except ImportError:
    HAS_FIREBASE = False

# Pyrebase (Web SDK keys — what the user actually has)
try:
    import pyrebase  # pyrebase4
    HAS_PYREBASE = True
except ImportError:
    HAS_PYREBASE = False


# ────────────────────────────────────────────────────────────────────────
# GitHub backend
# ────────────────────────────────────────────────────────────────────────
class GitHubBackend:
    API = "https://api.github.com"
    name = "github"

    def __init__(self, repo: str, token: str, branch: str = "main"):
        if "/" not in repo:
            raise ValueError("GITHUB_REPO must be 'owner/name' (no .git suffix)")
        self.repo, self.token, self.branch = repo, token, branch
        self.headers = {
            "Authorization": f"Bearer {token}",
            "Accept":        "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        }

    def _sha(self, path: str) -> Optional[str]:
        r = requests.get(f"{self.API}/repos/{self.repo}/contents/{path}?ref={self.branch}",
                         headers=self.headers, )
        return r.json().get("sha") if r.status_code == 200 else None

    def put(self, path: str, content_bytes: bytes,
            message: Optional[str] = None) -> bool:
        size = len(content_bytes)
        if size > 5 * 1024 * 1024:
            return self._put_large(path, content_bytes, message)
        return self._put_small(path, content_bytes, message)

    def _put_small(self, path, content_bytes, message=None):
        import time as _t
        for attempt in range(5):
            sha = self._sha(path)
            body = {
                "message": message or f"upload {path} @ {datetime.datetime.utcnow().isoformat()}",
                "content": base64.b64encode(content_bytes).decode(),
                "branch":  self.branch,
            }
            if sha:
                body["sha"] = sha
            r = requests.put(f"{self.API}/repos/{self.repo}/contents/{path}",
                             headers=self.headers, json=body, )
            if r.status_code in (200, 201):
                if "checkpoints/" not in path:
                    print(f"  [github] put {path} ({len(content_bytes)/1024:.1f} KB)")
                return True
            if r.status_code in (409, 422) and attempt < 4:
                _t.sleep(0.3 + attempt * 0.5)
                continue
            if r.status_code in (413, 422) and "too large" in r.text.lower():
                print(f"  [github] file too large for contents API, switching to Git Data API…")
                return self._put_large(path, content_bytes, message)
            print(f"  [github] FAILED {path}: HTTP {r.status_code} {r.text[:200]}")
            return False
        return False

    def _put_large(self, path, content_bytes, message=None):
        size = len(content_bytes)
        print(f"  [github] LARGE FILE upload via Git Data API ({size/1024/1024:.1f} MB)…")
        msg = message or f"upload {path} @ {datetime.datetime.utcnow().isoformat()}"
        try:
            r = requests.get(f"{self.API}/repos/{self.repo}/git/ref/heads/{self.branch}",
                             headers=self.headers, )
            if r.status_code != 200:
                print(f"  [github] could not get branch HEAD: HTTP {r.status_code}")
                return False
            head_commit_sha = r.json()["object"]["sha"]
            r = requests.get(f"{self.API}/repos/{self.repo}/git/commits/{head_commit_sha}",
                             headers=self.headers, )
            if r.status_code != 200:
                print(f"  [github] could not get commit object")
                return False
            base_tree_sha = r.json()["tree"]["sha"]
            r = requests.post(f"{self.API}/repos/{self.repo}/git/blobs",
                              headers=self.headers,
                              json={"content": base64.b64encode(content_bytes).decode(),
                                    "encoding": "base64"},
                              )
            if r.status_code != 201:
                print(f"  [github] blob create failed: HTTP {r.status_code} {r.text[:200]}")
                return False
            blob_sha = r.json()["sha"]
            r = requests.post(f"{self.API}/repos/{self.repo}/git/trees",
                              headers=self.headers,
                              json={"base_tree": base_tree_sha,
                                    "tree": [{"path": path, "mode": "100644",
                                              "type": "blob", "sha": blob_sha}]},
                              )
            if r.status_code != 201:
                print(f"  [github] tree create failed: HTTP {r.status_code} {r.text[:200]}")
                return False
            new_tree_sha = r.json()["sha"]
            r = requests.post(f"{self.API}/repos/{self.repo}/git/commits",
                              headers=self.headers,
                              json={"message": msg, "tree": new_tree_sha,
                                    "parents": [head_commit_sha]},
                              )
            if r.status_code != 201:
                print(f"  [github] commit create failed: HTTP {r.status_code} {r.text[:200]}")
                return False
            new_commit_sha = r.json()["sha"]
            r = requests.patch(f"{self.API}/repos/{self.repo}/git/refs/heads/{self.branch}",
                               headers=self.headers,
                               json={"sha": new_commit_sha, "force": False},
                               )
            if r.status_code not in (200, 201):
                print(f"  [github] ref update failed: HTTP {r.status_code} {r.text[:200]}")
                return False
            print(f"  [github] ✓ LARGE put {path} ({size/1024/1024:.1f} MB) via Git Data API")
            return True
        except Exception as e:
            print(f"  [github] large-file upload threw: {e}")
            return False

    def get(self, path):
        r = requests.get(f"{self.API}/repos/{self.repo}/contents/{path}?ref={self.branch}",
                         headers=self.headers, )
        if r.status_code != 200:
            return None
        meta = r.json()
        b64 = (meta.get("content") or "").replace("\n", "")
        if b64:
            return base64.b64decode(b64)
        dl = meta.get("download_url")
        if dl:
            r2 = requests.get(dl, headers=self.headers, )
            if r2.status_code == 200:
                return r2.content
        sha = meta.get("sha")
        if sha:
            blob_url = f"{self.API}/repos/{self.repo}/git/blobs/{sha}"
            h = dict(self.headers, Accept="application/vnd.github.raw")
            r3 = requests.get(blob_url, headers=h, )
            if r3.status_code == 200:
                return r3.content
        return None

    def list(self, prefix: str = "") -> List[str]:
        url = f"{self.API}/repos/{self.repo}/contents/{prefix.rstrip('/')}?ref={self.branch}"
        r = requests.get(url, headers=self.headers, )
        if r.status_code != 200:
            return []
        return [item["path"] for item in r.json() if "name" in item]

    def _list_recursive(self, prefix: str = "") -> List[str]:
        """Return every file path under prefix from the current branch tree."""
        try:
            r = requests.get(f"{self.API}/repos/{self.repo}/git/ref/heads/{self.branch}",
                             headers=self.headers, )
            if r.status_code != 200:
                return []
            head_commit_sha = r.json()["object"]["sha"]
            r = requests.get(f"{self.API}/repos/{self.repo}/git/commits/{head_commit_sha}",
                             headers=self.headers, )
            if r.status_code != 200:
                return []
            tree_sha = r.json()["tree"]["sha"]
            r = requests.get(f"{self.API}/repos/{self.repo}/git/trees/{tree_sha}",
                             headers=self.headers, params={"recursive": "1"}, )
            if r.status_code != 200:
                return []
            pref = prefix.rstrip("/") + "/" if prefix else ""
            return [x["path"] for x in r.json().get("tree", [])
                    if x.get("type") == "blob" and (not pref or x.get("path", "").startswith(pref))]
        except Exception:
            return []

    def delete(self, path: str, message: Optional[str] = None) -> bool:
        """Delete a single file from the current branch (does not rewrite Git history)."""
        try:
            sha = self._sha(path)
            if not sha:
                return True
            body = {"message": message or f"delete {path} @ {datetime.datetime.utcnow().isoformat()}",
                    "sha": sha, "branch": self.branch}
            r = requests.delete(f"{self.API}/repos/{self.repo}/contents/{path}",
                                headers=self.headers, json=body, )
            if r.status_code in (200, 204):
                print(f"  [github] deleted {path}")
                return True
            print(f"  [github] delete failed {path}: HTTP {r.status_code} {r.text[:200]}")
            return False
        except Exception as e:
            print(f"  [github] delete threw {path}: {str(e)[:150]}")
            return False

    def delete_prefix(self, prefix: str, message: Optional[str] = None) -> int:
        """Remove all current-branch files under prefix in batched commits."""
        paths = self._list_recursive(prefix)
        if not paths:
            return 0
        deleted = 0
        msg = message or f"wipe {prefix} @ {datetime.datetime.utcnow().isoformat()}"
        # Delete via Git Trees API so a global wipe does not create hundreds of commits.
        for off in range(0, len(paths), 500):
            batch = paths[off:off + 500]
            try:
                r = requests.get(f"{self.API}/repos/{self.repo}/git/ref/heads/{self.branch}",
                                 headers=self.headers, )
                if r.status_code != 200:
                    break
                head_commit_sha = r.json()["object"]["sha"]
                r = requests.get(f"{self.API}/repos/{self.repo}/git/commits/{head_commit_sha}",
                                 headers=self.headers, )
                if r.status_code != 200:
                    break
                base_tree_sha = r.json()["tree"]["sha"]
                tree = [{"path": path, "mode": "100644", "type": "blob", "sha": None}
                        for path in batch]
                r = requests.post(f"{self.API}/repos/{self.repo}/git/trees",
                                  headers=self.headers,
                                  json={"base_tree": base_tree_sha, "tree": tree}, )
                if r.status_code != 201:
                    print(f"  [github] delete tree failed: HTTP {r.status_code} {r.text[:200]}")
                    # Fallback to per-file delete for this batch.
                    for path in batch:
                        if self.delete(path, message=msg):
                            deleted += 1
                    continue
                new_tree_sha = r.json()["sha"]
                r = requests.post(f"{self.API}/repos/{self.repo}/git/commits",
                                  headers=self.headers,
                                  json={"message": msg, "tree": new_tree_sha,
                                        "parents": [head_commit_sha]}, )
                if r.status_code != 201:
                    print(f"  [github] delete commit failed: HTTP {r.status_code} {r.text[:200]}")
                    continue
                new_commit_sha = r.json()["sha"]
                r = requests.patch(f"{self.API}/repos/{self.repo}/git/refs/heads/{self.branch}",
                                   headers=self.headers,
                                   json={"sha": new_commit_sha, "force": False}, )
                if r.status_code not in (200, 201):
                    print(f"  [github] delete ref update failed: HTTP {r.status_code} {r.text[:200]}")
                    continue
                deleted += len(batch)
                print(f"  [github] deleted {len(batch)} file(s) under {prefix}")
            except Exception as e:
                print(f"  [github] delete_prefix threw: {str(e)[:150]}")
        return deleted


# ────────────────────────────────────────────────────────────────────────
# Supabase backend (REST + Storage)
# ────────────────────────────────────────────────────────────────────────
class SupabaseBackend:
    """Uses Supabase REST API + Storage. Just needs SUPABASE_URL + SUPABASE_KEY.

    Schema expected (SQL provided in db/supabase_schema.sql):
        TABLE kv_json(key TEXT PRIMARY KEY, value JSONB, updated_at TIMESTAMPTZ)
        STORAGE BUCKET 'cryptosuite' (public read or RLS allowing service-role)
    """
    name = "supabase"

    def __init__(self, url: str, key: str, bucket: str = "cryptosuite"):
        self.url    = url.rstrip("/")
        self.key    = key
        self.bucket = bucket
        self.headers = {
            "apikey":        key,
            "Authorization": f"Bearer {key}",
            "Content-Type":  "application/json",
            "Prefer":        "resolution=merge-duplicates",
        }
        # Ensure bucket exists (best-effort)
        try:
            r = requests.post(f"{self.url}/storage/v1/bucket",
                              headers={**self.headers, "Content-Type": "application/json"},
                              json={"id": self.bucket, "name": self.bucket, "public": True},
                              )
            # 200 created, 400/409 = already exists — both OK
        except Exception:
            pass
        print(f"  [supabase] connected · {self.url} · bucket={self.bucket}")

    def _kv_key(self, path: str) -> str:
        return path  # path is the key

    def put(self, path: str, content_bytes: bytes,
            message: Optional[str] = None) -> bool:
        try:
            if path.endswith(".json") and len(content_bytes) < 5 * 1024 * 1024:
                # JSON → kv_json table (upsert)
                try:
                    doc = json.loads(content_bytes.decode("utf-8"))
                except Exception:
                    doc = {"raw": content_bytes.decode("utf-8", errors="ignore")}
                body = [{"key": self._kv_key(path), "value": doc,
                         "updated_at": datetime.datetime.utcnow().isoformat() + "Z"}]
                r = requests.post(f"{self.url}/rest/v1/kv_json",
                                  headers={**self.headers,
                                           "Prefer": "resolution=merge-duplicates,return=minimal"},
                                  json=body, )
                if r.status_code in (200, 201, 204):
                    print(f"  [supabase] put kv {path} ({len(content_bytes)/1024:.1f} KB)")
                    return True
                print(f"  [supabase] kv put failed HTTP {r.status_code}: {r.text[:200]}")
                return False
            # Binary → Storage bucket
            r = requests.post(f"{self.url}/storage/v1/object/{self.bucket}/{path}",
                              headers={"apikey": self.key,
                                       "Authorization": f"Bearer {self.key}",
                                       "Content-Type": "application/octet-stream",
                                       "x-upsert": "true"},
                              data=content_bytes, )
            if r.status_code in (200, 201):
                print(f"  [supabase] put blob {path} ({len(content_bytes)/1024:.1f} KB)")
                return True
            # 409 conflict: try PUT instead
            if r.status_code == 409:
                r2 = requests.put(f"{self.url}/storage/v1/object/{self.bucket}/{path}",
                                  headers={"apikey": self.key,
                                           "Authorization": f"Bearer {self.key}",
                                           "Content-Type": "application/octet-stream"},
                                  data=content_bytes, )
                if r2.status_code in (200, 201):
                    print(f"  [supabase] PUT blob {path}")
                    return True
            print(f"  [supabase] blob put failed HTTP {r.status_code}: {r.text[:200]}")
            return False
        except Exception as e:
            print(f"  [supabase] put threw: {e}")
            return False

    def get(self, path: str) -> Optional[bytes]:
        try:
            if path.endswith(".json"):
                r = requests.get(
                    f"{self.url}/rest/v1/kv_json",
                    headers=self.headers,
                    params={"key": f"eq.{path}", "select": "value"},
                    
                )
                if r.status_code == 200:
                    rows = r.json()
                    if rows:
                        return json.dumps(rows[0]["value"], default=str).encode("utf-8")
                return None
            # binary from storage
            r = requests.get(f"{self.url}/storage/v1/object/public/{self.bucket}/{path}",
                             )
            if r.status_code == 200:
                return r.content
            # fallback authed
            r2 = requests.get(f"{self.url}/storage/v1/object/authenticated/{self.bucket}/{path}",
                              headers={"apikey": self.key,
                                       "Authorization": f"Bearer {self.key}"},
                              )
            return r2.content if r2.status_code == 200 else None
        except Exception:
            return None

    def list(self, prefix: str = "") -> List[str]:
        try:
            r = requests.post(f"{self.url}/storage/v1/object/list/{self.bucket}",
                              headers=self.headers,
                              json={"prefix": prefix, "limit": 500, "offset": 0},
                              )
            if r.status_code == 200:
                return [item["name"] for item in r.json() if "name" in item]
        except Exception:
            pass
        return []

    def delete(self, path: str, message: Optional[str] = None) -> bool:
        try:
            if path.endswith(".json"):
                r = requests.delete(f"{self.url}/rest/v1/kv_json",
                                    headers=self.headers,
                                    params={"key": f"eq.{path}"}, )
                return r.status_code in (200, 202, 204)
            r = requests.post(f"{self.url}/storage/v1/object/{self.bucket}/remove",
                              headers=self.headers, json={"prefixes": [path]}, )
            return r.status_code in (200, 204)
        except Exception as e:
            print(f"  [supabase] delete threw {path}: {str(e)[:150]}")
            return False

    def _list_storage_recursive(self, prefix: str) -> List[str]:
        out = []
        offset = 0
        while True:
            r = requests.post(f"{self.url}/storage/v1/object/list/{self.bucket}",
                              headers=self.headers,
                              json={"prefix": prefix, "limit": 1000, "offset": offset}, )
            if r.status_code != 200:
                break
            rows = r.json() or []
            if not rows:
                break
            for item in rows:
                name = item.get("name")
                if not name:
                    continue
                full = prefix.rstrip("/") + "/" + name if prefix and not name.startswith(prefix) else name
                # Folders usually have null metadata; recurse into them.
                if item.get("metadata") is None and not full.endswith(".gz") and "." not in name:
                    out.extend(self._list_storage_recursive(full.rstrip("/") + "/"))
                else:
                    out.append(full)
            if len(rows) < 1000:
                break
            offset += 1000
        return out

    def delete_prefix(self, prefix: str, message: Optional[str] = None) -> int:
        n = 0
        try:
            if prefix.startswith("data/") or prefix == "data/":
                r = requests.delete(f"{self.url}/rest/v1/kv_json",
                                    headers=self.headers,
                                    params={"key": f"like.{prefix}%"}, )
                if r.status_code in (200, 202, 204):
                    n += 1
                else:
                    print(f"  [supabase] kv prefix delete failed HTTP {r.status_code}: {r.text[:200]}")
            if prefix.startswith("blobs/") or prefix == "blobs/":
                paths = self._list_storage_recursive(prefix)
                for i in range(0, len(paths), 100):
                    batch = paths[i:i+100]
                    r = requests.post(f"{self.url}/storage/v1/object/{self.bucket}/remove",
                                      headers=self.headers, json={"prefixes": batch}, )
                    if r.status_code in (200, 204):
                        n += len(batch)
                    else:
                        print(f"  [supabase] storage batch delete failed HTTP {r.status_code}: {r.text[:200]}")
        except Exception as e:
            print(f"  [supabase] delete_prefix threw {prefix}: {str(e)[:150]}")
        return n


# ────────────────────────────────────────────────────────────────────────
# Firebase Admin (service-account)
# ────────────────────────────────────────────────────────────────────────
class FirebaseBackend:
    name = "firebase-admin"

    def __init__(self, cred_path, project_id, bucket):
        if not HAS_FIREBASE:
            raise RuntimeError("firebase-admin not installed.")
        if not firebase_admin._apps:
            cred = credentials.Certificate(cred_path)
            firebase_admin.initialize_app(cred, {
                "projectId":    project_id,
                "storageBucket": bucket,
            })
        self.fs     = firestore.client()
        self.bucket = fb_storage.bucket()
        print(f"  [firebase] connected · project={project_id} · bucket={bucket}")

    def put(self, path, content_bytes, message=None):
        try:
            blob = self.bucket.blob(path)
            blob.upload_from_string(content_bytes, content_type="application/octet-stream")
            print(f"  [firebase] put {path} ({len(content_bytes)/1024:.1f} KB)")
            return True
        except Exception as e:
            print(f"  [firebase] put failed: {e}")
            return False

    def get(self, path):
        try:
            blob = self.bucket.blob(path)
            if not blob.exists():
                return None
            return blob.download_as_bytes()
        except Exception:
            return None

    def list(self, prefix=""):
        try:
            return [b.name for b in self.bucket.list_blobs(prefix=prefix)]
        except Exception:
            return []

    def delete(self, path: str, message: Optional[str] = None) -> bool:
        try:
            blob = self.bucket.blob(path)
            if blob.exists():
                blob.delete()
                print(f"  [firebase-admin] deleted {path}")
            return True
        except Exception as e:
            print(f"  [firebase-admin] delete failed {path}: {str(e)[:150]}")
            return False

    def delete_prefix(self, prefix: str, message: Optional[str] = None) -> int:
        n = 0
        try:
            for blob in self.bucket.list_blobs(prefix=prefix):
                blob.delete(); n += 1
            if n:
                print(f"  [firebase-admin] deleted {n} object(s) under {prefix}")
        except Exception as e:
            print(f"  [firebase-admin] delete_prefix failed {prefix}: {str(e)[:150]}")
        return n


# ────────────────────────────────────────────────────────────────────────
# Pyrebase backend (Web SDK keys)
# ────────────────────────────────────────────────────────────────────────
class FirebasePyrebaseBackend:
    name = "firebase-web"

    def __init__(self, fb_config: dict):
        if not HAS_PYREBASE:
            raise RuntimeError("pyrebase4 not installed. pip install pyrebase4")
        required = ["apiKey", "authDomain", "databaseURL", "storageBucket", "projectId"]
        missing  = [k for k in required if not fb_config.get(k)]
        if missing:
            raise RuntimeError(f"Firebase config missing keys: {missing}")
        self.app      = pyrebase.initialize_app(fb_config)
        self.db       = self.app.database()
        self.storage  = self.app.storage()
        self.project  = fb_config["projectId"]
        self.api_key  = fb_config["apiKey"]
        self.bucket_name = fb_config["storageBucket"]
        # Smoke-test the connection so we can fail FAST instead of on every put
        self._perm_ok = True
        try:
            self.db.child("_v25_init_ping").set({"ts": datetime.datetime.utcnow().isoformat()})
        except Exception as e:
            self._perm_ok = False
            print(f"  [firebase-web] ⚠ initial RTDB write FAILED: {str(e)[:200]}")
            print(f"      → Database rules likely BLOCK writes.")
            print(f"      → Fix at: https://console.firebase.google.com/project/{self.project}/database/{self.project}-default-rtdb/rules")
            print(f"      → Paste: {{\"rules\":{{\".read\":true,\".write\":true}}}}  and PUBLISH.")
            print(f"      → Storage rules: https://console.firebase.google.com/project/{self.project}/storage/{self.bucket_name}/rules")
            print(f"      → Paste: rules_version='2'; service firebase.storage{{match /b/{{bucket}}/o{{match /{{path=**}}{{allow read,write:if true;}}}}}}")
            raise   # propagate so Storage() will skip Firebase backend
        print(f"  [firebase-web] connected · project={self.project} · bucket={self.bucket_name}")

    def _safe_key(self, path: str) -> str:
        return path.replace(".", "_").replace("$", "_").replace("#", "_") \
                   .replace("[", "_").replace("]", "_")

    def put(self, path, content_bytes, message=None):
        try:
            if path.endswith(".json") and len(content_bytes) < 10 * 1024 * 1024:
                doc = json.loads(content_bytes.decode("utf-8"))
                key = self._safe_key(path.replace(".json", ""))
                self.db.child(key).set(doc)
                print(f"  [firebase-web] put RTDB {key} ({len(content_bytes)/1024:.1f} KB)")
                return True
            import tempfile
            with tempfile.NamedTemporaryFile(delete=False) as tmp:
                tmp.write(content_bytes); tmp_path = tmp.name
            self.storage.child(path).put(tmp_path)
            os.unlink(tmp_path)
            print(f"  [firebase-web] put Storage {path} ({len(content_bytes)/1024:.1f} KB)")
            return True
        except Exception as e:
            msg = str(e)[:200]
            if "401" in msg or "PERMISSION" in msg.upper() or "permission" in msg.lower():
                print(f"  [firebase-web] PERMISSION DENIED — fix Firebase rules (see setup.py output)")
            else:
                print(f"  [firebase-web] put failed: {msg}")
            return False

    def get(self, path):
        try:
            if path.endswith(".json"):
                key = self._safe_key(path.replace(".json", ""))
                doc = self.db.child(key).get().val()
                if doc is None: return None
                return json.dumps(doc, default=str).encode("utf-8")
            url = self.storage.child(path).get_url(None)
            import urllib.request
            return urllib.request.urlopen(url, ).read()
        except Exception:
            return None

    def list(self, prefix=""):
        try:
            key = self._safe_key(prefix) if prefix else ""
            if key:
                v = self.db.child(key).shallow().get().val() or {}
                return list(v.keys()) if isinstance(v, dict) else []
        except Exception:
            pass
        return []

    def _fb_storage_delete(self, path: str) -> bool:
        try:
            import urllib.parse
            enc = urllib.parse.quote(path, safe="")
            url = f"https://firebasestorage.googleapis.com/v0/b/{self.bucket_name}/o/{enc}"
            r = requests.delete(url, params={"key": self.api_key}, )
            return r.status_code in (200, 204, 404)
        except Exception:
            return False

    def _fb_storage_list(self, prefix: str) -> List[str]:
        try:
            url = f"https://firebasestorage.googleapis.com/v0/b/{self.bucket_name}/o"
            r = requests.get(url, params={"prefix": prefix, "key": self.api_key}, )
            if r.status_code != 200:
                return []
            return [x.get("name") for x in r.json().get("items", []) if x.get("name")]
        except Exception:
            return []

    def delete(self, path: str, message: Optional[str] = None) -> bool:
        try:
            if path.endswith(".json"):
                key = self._safe_key(path.replace(".json", ""))
                self.db.child(key).remove()
                return True
            return self._fb_storage_delete(path)
        except Exception as e:
            print(f"  [firebase-web] delete failed {path}: {str(e)[:150]}")
            return False

    def delete_prefix(self, prefix: str, message: Optional[str] = None) -> int:
        n = 0
        try:
            if prefix.startswith("data/") or prefix == "data/":
                # All JSON rows live below RTDB node 'data'.
                key = self._safe_key(prefix.rstrip("/"))
                self.db.child(key).remove(); n += 1
                print(f"  [firebase-web] removed RTDB node {key}")
            if prefix.startswith("blobs/") or prefix == "blobs/":
                for path in self._fb_storage_list(prefix):
                    if self._fb_storage_delete(path):
                        n += 1
                if n:
                    print(f"  [firebase-web] deleted objects under {prefix}")
        except Exception as e:
            print(f"  [firebase-web] delete_prefix failed {prefix}: {str(e)[:150]}")
        return n


# ────────────────────────────────────────────────────────────────────────
# Unified Storage facade — multi-backend chain
# ────────────────────────────────────────────────────────────────────────
class Storage:
    """Tries Firebase → Supabase → GitHub.
    WRITES go to ALL configured backends (so every backend stays in sync).
    READS try in priority order, return first hit."""

    def __init__(self):
        self.backends: List = []        # ordered list of active backends
        self.backend_name = "none"

        import json, importlib.util
        _SEARCH = [os.getcwd(),
                   os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                   "/kaggle/working/crypto-v23", "/kaggle/working",
                   "/content/crypto-v23", "/content"]

        state = None
        for d in _SEARCH:
            p = os.path.join(d, ".setup_state.json")
            if os.path.exists(p):
                try:
                    with open(p) as f:
                        state = json.load(f)
                    break
                except Exception: pass

        user_cfg = None
        if state is None:
            for p in [os.path.join(d, "config.py") for d in _SEARCH]:
                if os.path.exists(p):
                    try:
                        spec = importlib.util.spec_from_file_location("uc", p)
                        m = importlib.util.module_from_spec(spec)
                        spec.loader.exec_module(m)
                        user_cfg = m
                        break
                    except Exception: pass

        def _cfg(key, default=None):
            v = os.environ.get(key)
            if v: return v
            if state is not None and key in state and state[key]: return state[key]
            if user_cfg: return getattr(user_cfg, key, default)
            return default

        # ─── 1. Firebase (Web SDK) ──────────────────────────────────
        fb_web_cfg = {
            "apiKey":            _cfg("FIREBASE_API_KEY"),
            "authDomain":        _cfg("FIREBASE_AUTH_DOMAIN"),
            "databaseURL":       _cfg("FIREBASE_DATABASE_URL"),
            "storageBucket":     _cfg("FIREBASE_STORAGE_BUCKET") or _cfg("FIREBASE_BUCKET"),
            "projectId":         _cfg("FIREBASE_PROJECT_ID"),
            "appId":             _cfg("FIREBASE_APP_ID", ""),
            "messagingSenderId": _cfg("FIREBASE_MESSAGING_SENDER_ID", ""),
            "measurementId":     _cfg("FIREBASE_MEASUREMENT_ID", ""),
            "serviceAccount":    None,
        }
        if (HAS_PYREBASE and fb_web_cfg["apiKey"] and fb_web_cfg["projectId"]
                and fb_web_cfg["databaseURL"]):
            try:
                self.backends.append(FirebasePyrebaseBackend(fb_web_cfg))
            except Exception as e:
                print(f"  [storage] firebase-web disabled: {str(e)[:200]}")

        # Firebase Admin SDK (service-account)
        fb_cred = _cfg("FIREBASE_CREDENTIALS")
        fb_proj = _cfg("FIREBASE_PROJECT_ID")
        fb_buck = _cfg("FIREBASE_BUCKET") or _cfg("FIREBASE_STORAGE_BUCKET")
        if HAS_FIREBASE and fb_cred and fb_proj and fb_buck and os.path.exists(fb_cred):
            try:
                self.backends.append(FirebaseBackend(fb_cred, fb_proj, fb_buck))
            except Exception as e:
                print(f"  [storage] firebase-admin disabled: {e}")

        # ─── 2. Supabase ───────────────────────────────────────────
        sb_url = _cfg("SUPABASE_URL")
        sb_key = _cfg("SUPABASE_KEY") or _cfg("SUPABASE_SERVICE_KEY") or _cfg("SUPABASE_ANON_KEY")
        sb_bucket = _cfg("SUPABASE_BUCKET", "cryptosuite") or "cryptosuite"
        if sb_url and sb_key:
            try:
                self.backends.append(SupabaseBackend(sb_url, sb_key, sb_bucket))
            except Exception as e:
                print(f"  [storage] supabase disabled: {e}")

        # ─── 3. GitHub (canonical fallback; Menu 6 can wipe data/blobs) ──────────
        gh_token = _cfg("GITHUB_TOKEN")
        gh_repo  = _cfg("GITHUB_REPO")
        gh_br    = _cfg("GITHUB_BRANCH", "main")
        if gh_token and gh_repo:
            try:
                self.backends.append(GitHubBackend(gh_repo, gh_token, gh_br))
            except Exception as e:
                print(f"  [storage] github disabled: {e}")

        if not self.backends:
            print("  [storage] WARNING: no backend configured "
                  "(set FIREBASE_* / SUPABASE_* / GITHUB_* in setup_state.json)")
            self.backend_name = "none"
        else:
            self.backend_name = "+".join(b.name for b in self.backends)
            print(f"  [storage] active chain: {self.backend_name}")

    # ─── helper to expose first backend (for legacy code that pokes .backend) ──
    @property
    def backend(self):
        return self.backends[0] if self.backends else None

    # ─── Public API ────────────────────────────────────────────────────
    def put_json(self, key: str, payload: dict, message: Optional[str] = None) -> bool:
        if not self.backends:
            return False
        payload = dict(payload, _saved_at=datetime.datetime.utcnow().isoformat() + "Z")
        body = json.dumps(payload, default=str, indent=2).encode()
        path = f"data/{key}.json"
        any_ok = False
        for b in self.backends:
            try:
                if b.put(path, body, message):
                    any_ok = True
            except Exception as e:
                print(f"  [storage] {b.name} put_json error: {str(e)[:150]}")
        return any_ok

    def get_json(self, key: str) -> Optional[dict]:
        if not self.backends:
            return None
        path = f"data/{key}.json"
        for b in self.backends:
            try:
                raw = b.get(path)
                if raw is not None:
                    return json.loads(raw.decode())
            except Exception:
                continue
        return None

    def put_blob(self, key: str, blob: bytes,
                 message: Optional[str] = None, compress: bool = True) -> bool:
        if not self.backends:
            return False
        if compress:
            blob = gzip.compress(blob, compresslevel=6)
            if not key.endswith(".gz"):
                key += ".gz"
        path = f"blobs/{key}"
        any_ok = False
        for b in self.backends:
            try:
                if b.put(path, blob, message):
                    any_ok = True
            except Exception as e:
                print(f"  [storage] {b.name} put_blob error: {str(e)[:150]}")
        return any_ok

    def get_blob(self, key: str) -> Optional[bytes]:
        if not self.backends:
            return None
        path = f"blobs/{key}"
        for b in self.backends:
            for try_key in (path + ".gz" if not path.endswith(".gz") else path, path):
                try:
                    raw = b.get(try_key)
                    if raw is not None:
                        if try_key.endswith(".gz"):
                            try:    return gzip.decompress(raw)
                            except: return raw
                        return raw
                except Exception:
                    continue
        return None

    def list(self, prefix: str = "") -> List[str]:
        # Merge from all backends, dedupe
        seen, out = set(), []
        for b in self.backends:
            try:
                for x in b.list(prefix):
                    if x not in seen:
                        seen.add(x); out.append(x)
            except Exception:
                continue
        return out

    def delete(self, path: str, message: Optional[str] = None) -> bool:
        """Delete one raw storage path (example: data/final_X.json or blobs/raw_X.pkl.gz)."""
        if not self.backends:
            return False
        any_ok = False
        for b in self.backends:
            try:
                fn = getattr(b, "delete", None)
                if fn and fn(path, message=message):
                    any_ok = True
            except Exception as e:
                print(f"  [storage] {b.name} delete error: {str(e)[:150]}")
        return any_ok

    def delete_prefix(self, prefix: str, message: Optional[str] = None) -> int:
        """Delete every current object under prefix from every configured backend.

        Used by the global wipe. This removes files/rows from the active DBs and
        from the current GitHub branch. GitHub's old commit history is not
        rewritten (that requires a separate repo-history purge).
        """
        total = 0
        if not self.backends:
            return total
        for b in self.backends:
            try:
                fn = getattr(b, "delete_prefix", None)
                if fn:
                    n = fn(prefix, message=message) or 0
                    total += int(n)
                    print(f"  [storage] {b.name}: deleted {n} under {prefix}")
                else:
                    # Fallback: list + delete known files.
                    paths = b.list(prefix) if hasattr(b, "list") else []
                    n = 0
                    for path in paths:
                        dfn = getattr(b, "delete", None)
                        if dfn and dfn(path, message=message):
                            n += 1
                    total += n
                    print(f"  [storage] {b.name}: deleted {n} under {prefix}")
            except Exception as e:
                print(f"  [storage] {b.name} delete_prefix error: {str(e)[:150]}")
        return total


# Singleton
STORE = Storage()
