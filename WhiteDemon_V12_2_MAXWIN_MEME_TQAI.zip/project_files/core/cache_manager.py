"""
Cache manager — controls "train once per (pair, TF)" logic.

When you ask for analysis on a (pair, TF) combo:
  • Check storage for cached models keyed by `<symbol>_<tf>`
  • If present and force_retrain=False  → reuse, no training prompt
  • If absent OR force_retrain=True     → ask user to confirm training

Used by train_all.py and the web /api/train endpoint.
"""
from __future__ import annotations
from typing import Dict, Optional
import datetime, json

from .storage import STORE
from .config  import SYMBOL, TF_LABEL


def cache_key(symbol: str, tf_label: str) -> str:
    return f"{symbol.replace('-','_')}_{tf_label}"


def is_trained(symbol: str = None, tf_label: str = None) -> bool:
    """Return True if BOTH long+short models exist for this (pair, TF)."""
    symbol = symbol or SYMBOL
    tf_label = tf_label or TF_LABEL
    rid = cache_key(symbol, tf_label)
    long_  = STORE.get_json(f"long_{rid}")
    short_ = STORE.get_json(f"short_{rid}")
    return bool(long_) and bool(short_)


def get_cache_info(symbol: str = None, tf_label: str = None) -> Dict:
    """Return metadata about the cache state — used by the UI."""
    symbol = symbol or SYMBOL
    tf_label = tf_label or TF_LABEL
    rid = cache_key(symbol, tf_label)
    long_  = STORE.get_json(f"long_{rid}")
    short_ = STORE.get_json(f"short_{rid}")
    info = {
        "symbol":     symbol,
        "tf_label":   tf_label,
        "rid":        rid,
        "trained":    bool(long_) and bool(short_),
        "long_saved_at":  (long_  or {}).get("_saved_at"),
        "short_saved_at": (short_ or {}).get("_saved_at"),
    }
    if info["trained"]:
        try:
            saved = datetime.datetime.fromisoformat(
                info["long_saved_at"].replace("Z", "+00:00"))
            age_h = (datetime.datetime.now(saved.tzinfo) - saved).total_seconds() / 3600
            info["age_hours"] = round(age_h, 1)
        except Exception:
            info["age_hours"] = None
    return info


def clear_cache(symbol: str = None, tf_label: str = None) -> Dict:
    """Mark cache as invalid by deleting key files. Returns deletion summary."""
    symbol = symbol or SYMBOL
    tf_label = tf_label or TF_LABEL
    rid = cache_key(symbol, tf_label)
    deleted = []
    for k in (f"long_{rid}", f"short_{rid}", f"nns_{rid}", f"raw_{rid}",
              f"final_{rid}", f"backtest_{rid}"):
        # Best-effort: storage backends may or may not expose delete.
        # We just overwrite with a tombstone so is_trained() returns False.
        try:
            STORE.put_json(k, {"deleted": True}, message=f"clear cache {k}")
            deleted.append(k)
        except Exception:
            pass
    return {"deleted": deleted, "rid": rid}
