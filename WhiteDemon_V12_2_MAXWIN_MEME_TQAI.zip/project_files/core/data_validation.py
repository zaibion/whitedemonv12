"""Market data validation utilities (V9.4).

Fail-safe checks for OHLCV data before indicators/models use it.
No hard dependency on pydantic; pure pandas assertions + repair.
"""
from __future__ import annotations
from typing import Dict, Any, Tuple, List
import math
import pandas as pd
import numpy as np

REQUIRED_OHLC = ["open", "high", "low", "close"]


def validate_ohlcv(df: pd.DataFrame, tf_label: str = "", *,
                   repair: bool = True,
                   max_gap_mult: float = 3.0,
                   max_outlier_return_pct: float = 35.0) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    """Validate and optionally repair OHLCV data.

    Returns (clean_df, report). report["ok"] is False only for serious conditions.
    Repairs are conservative: drop invalid rows, sort/dedupe, forward-fill volume only.
    """
    report: Dict[str, Any] = {
        "ok": True, "warnings": [], "errors": [], "repairs": [],
        "rows_in": int(len(df)) if df is not None else 0,
        "rows_out": 0,
        "tf_label": tf_label,
    }
    if df is None or len(df) == 0:
        report["ok"] = False; report["errors"].append("empty dataframe")
        return pd.DataFrame(), report

    d = df.copy()
    missing_cols = [c for c in REQUIRED_OHLC if c not in d.columns]
    if missing_cols:
        report["ok"] = False; report["errors"].append(f"missing columns: {missing_cols}")
        return d, report

    # Normalize timestamp and sort/dedupe.
    if "open_time" in d.columns:
        try:
            d["open_time"] = pd.to_datetime(d["open_time"], utc=True, errors="coerce")
            before = len(d)
            d = d.dropna(subset=["open_time"])
            if len(d) != before:
                report["repairs"].append(f"dropped {before-len(d)} rows with invalid open_time")
            before = len(d)
            d = d.drop_duplicates("open_time").sort_values("open_time").reset_index(drop=True)
            if len(d) != before:
                report["repairs"].append(f"removed {before-len(d)} duplicate timestamps")
        except Exception as e:
            report["warnings"].append(f"timestamp validation failed: {e}")

    # Numeric conversion.
    for c in REQUIRED_OHLC + (["volume"] if "volume" in d.columns else []):
        d[c] = pd.to_numeric(d[c], errors="coerce")

    before = len(d)
    d = d.dropna(subset=REQUIRED_OHLC).reset_index(drop=True)
    if len(d) != before:
        report["repairs"].append(f"dropped {before-len(d)} rows with NaN OHLC")

    # Positive prices.
    mask_positive = (d[REQUIRED_OHLC] > 0).all(axis=1)
    if not bool(mask_positive.all()):
        n = int((~mask_positive).sum())
        if repair:
            d = d[mask_positive].reset_index(drop=True)
            report["repairs"].append(f"dropped {n} rows with non-positive OHLC")
        else:
            report["ok"] = False; report["errors"].append(f"{n} rows with non-positive OHLC")

    # OHLC consistency.
    if len(d):
        hi_ok = (d["high"] >= d[["open", "close", "low"]].max(axis=1))
        lo_ok = (d["low"] <= d[["open", "close", "high"]].min(axis=1))
        bad = ~(hi_ok & lo_ok)
        if bool(bad.any()):
            n = int(bad.sum())
            if repair:
                idx = bad[bad].index
                d.loc[idx, "high"] = d.loc[idx, ["open", "high", "low", "close"]].max(axis=1)
                d.loc[idx, "low"] = d.loc[idx, ["open", "high", "low", "close"]].min(axis=1)
                report["repairs"].append(f"repaired {n} inconsistent OHLC rows")
            else:
                report["ok"] = False; report["errors"].append(f"{n} inconsistent OHLC rows")

    # Data gaps.
    if "open_time" in d.columns and len(d) > 3:
        deltas = d["open_time"].diff().dropna().dt.total_seconds()
        median_delta = float(deltas.median()) if len(deltas) else 0.0
        if median_delta > 0:
            gaps = deltas[deltas > median_delta * max_gap_mult]
            if len(gaps):
                report["warnings"].append(f"{len(gaps)} timestamp gaps > {max_gap_mult:.1f}x median interval")
                report["max_gap_sec"] = float(gaps.max())
            # Timeframe spacing sanity.
            report["median_interval_sec"] = median_delta

    # Outliers based on close-to-close returns.
    if len(d) > 5:
        ret = d["close"].pct_change().abs() * 100.0
        outliers = ret[ret > max_outlier_return_pct]
        if len(outliers):
            report["warnings"].append(f"{len(outliers)} extreme close returns > {max_outlier_return_pct:.1f}%")
            report["max_return_pct"] = float(outliers.max())

    # Volume sanity.
    if "volume" in d.columns:
        if d["volume"].isna().any():
            n = int(d["volume"].isna().sum())
            d["volume"] = d["volume"].fillna(0.0)
            report["repairs"].append(f"filled {n} NaN volume rows with 0")
        zero_vol = int((d["volume"] <= 0).sum())
        if zero_vol > max(10, len(d) * 0.25):
            report["warnings"].append(f"high zero/negative volume rows: {zero_vol}/{len(d)}")

    report["rows_out"] = int(len(d))
    if len(d) < 500:
        report["ok"] = False; report["errors"].append(f"too few rows after validation: {len(d)}")
    return d.reset_index(drop=True), report


def validation_text(report: Dict[str, Any]) -> str:
    parts: List[str] = []
    parts.append("OK" if report.get("ok") else "FAILED")
    if report.get("repairs"):
        parts.append("repairs=" + "; ".join(report["repairs"][:3]))
    if report.get("warnings"):
        parts.append("warnings=" + "; ".join(report["warnings"][:3]))
    if report.get("errors"):
        parts.append("errors=" + "; ".join(report["errors"][:3]))
    return " | ".join(parts)
