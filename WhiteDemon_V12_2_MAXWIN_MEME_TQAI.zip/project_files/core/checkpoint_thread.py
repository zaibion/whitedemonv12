"""
Background checkpoint thread.

Runs in a daemon thread. Every N seconds (default 60), it:
  1. Snapshots the current checkpoint state to storage
  2. Pushes the latest dashboard_data.json (if it exists locally)

Use:
    from core.checkpoint_thread import start_background_checkpoint, stop_background_checkpoint
    start_background_checkpoint("SOL-USD", "30m", interval=60)
    try:
        ... long training ...
    finally:
        stop_background_checkpoint()
"""
from __future__ import annotations
import threading, time, datetime, os, json
from typing import Optional
from . import checkpoint as ck_mod
from .storage import STORE

_thread: Optional[threading.Thread] = None
_stop_event = threading.Event()
_state = {"symbol": None, "tf_label": None, "interval": 60, "active": False,
           "last_push": None, "push_count": 0}


def _worker():
    """Background loop."""
    while not _stop_event.is_set():
        try:
            ck = ck_mod.load(_state["symbol"], _state["tf_label"])
            # Re-save with fresh timestamp so we know the trainer is alive
            ck["last_heartbeat"] = datetime.datetime.utcnow().isoformat() + "Z"
            ck_mod.save(ck)
            # Also push dashboard_data if it exists locally
            if os.path.exists("dashboard_data.json"):
                try:
                    with open("dashboard_data.json") as f:
                        dash = json.load(f)
                    STORE.put_json("dashboard_data", dash,
                                    message=f"heartbeat dashboard refresh")
                except Exception:
                    pass
            _state["last_push"] = datetime.datetime.utcnow().isoformat() + "Z"
            _state["push_count"] += 1
        except Exception as e:
            print(f"  [ckpt-thread] heartbeat failed (non-fatal): {e}")
        # Wait `interval` seconds OR until stop_event is set
        _stop_event.wait(_state["interval"])


def start_background_checkpoint(symbol: str, tf_label: str,
                                  interval: int = 60):
    """Start the checkpoint thread."""
    global _thread
    if _state["active"]:
        return
    _state["symbol"] = symbol
    _state["tf_label"] = tf_label
    _state["interval"] = interval
    _state["active"] = True
    _state["push_count"] = 0
    _stop_event.clear()
    _thread = threading.Thread(target=_worker, daemon=True,
                                name=f"ckpt-{symbol}-{tf_label}")
    _thread.start()
    print(f"  [ckpt-thread] ✓ started · heartbeat every {interval}s")


def stop_background_checkpoint():
    global _thread
    if not _state["active"]:
        return
    _stop_event.set()
    if _thread:
        _thread.join(timeout=5)
    _state["active"] = False
    pushes = _state["push_count"]
    print(f"  [ckpt-thread] ✓ stopped · pushed {pushes} heartbeats total")
