"""
llm_keys.py — Central place to read LLM API keys.

v25: reads from .setup_state.json (written by setup.py) FIRST,
then config.py, then env vars.
"""
from __future__ import annotations
import os, json, importlib.util


def _load_state_and_cfg():
    SEARCH = [os.getcwd(),
              os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
              "/kaggle/working/crypto-v23", "/kaggle/working",
              "/content/crypto-v23", "/content"]
    state = None
    for d in SEARCH:
        p = os.path.join(d, ".setup_state.json")
        if os.path.exists(p):
            try:
                with open(p) as f: state = json.load(f)
                break
            except Exception: pass
    cfg = None
    if state is None:
        for d in SEARCH:
            p = os.path.join(d, "config.py")
            if os.path.exists(p):
                try:
                    spec = importlib.util.spec_from_file_location("uc", p)
                    m = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(m)
                    cfg = m; break
                except Exception: pass
    return state, cfg


_state, _user_cfg = _load_state_and_cfg()


PROVIDERS = {
    "openrouter": "OPENROUTER_API_KEY",
    "mistral":    "MISTRAL_API_KEY",
    "groq":       "GROQ_API_KEY",
    "openai":     "OPENAI_API_KEY",
    "anthropic":  "ANTHROPIC_API_KEY",
    "gemini":     "GEMINI_API_KEY",
    "google":     "GEMINI_API_KEY",
    "deepseek":   "DEEPSEEK_API_KEY",
    "together":   "TOGETHER_API_KEY",
    "huggingface":"HUGGINGFACE_API_KEY",
}

# Models we know work on each provider (updated 2026-06)
DEFAULT_MODELS = {
    "openrouter": "mistralai/mistral-7b-instruct:free",
    "mistral":    "mistral-large-latest",
    "groq":       "llama-3.3-70b-versatile",
    "openai":     "gpt-4o-mini",
    "anthropic":  "claude-3-5-sonnet-latest",
    "gemini":     "gemini-1.5-flash",
    "deepseek":   "deepseek-chat",
}


def call_llm(prompt: str, max_tokens: int = 512, temperature: float = 0.3) -> str | None:
    """Try providers in order: openrouter → mistral → groq → openai → others.
    Returns the response text or None if no provider works."""
    import requests
    order = ["openrouter", "mistral", "groq", "openai", "anthropic", "gemini", "deepseek"]
    for prov in order:
        key = get_llm_key(prov)
        if not key: continue
        try:
            if prov == "openrouter":
                r = requests.post("https://openrouter.ai/api/v1/chat/completions",
                                  headers={"Authorization": f"Bearer {key}",
                                           "Content-Type": "application/json"},
                                  json={"model": DEFAULT_MODELS[prov],
                                        "messages": [{"role": "user", "content": prompt}],
                                        "max_tokens": max_tokens, "temperature": temperature},
                                  timeout=60)
                if r.status_code == 200:
                    return r.json()["choices"][0]["message"]["content"]
            elif prov == "mistral":
                r = requests.post("https://api.mistral.ai/v1/chat/completions",
                                  headers={"Authorization": f"Bearer {key}",
                                           "Content-Type": "application/json"},
                                  json={"model": DEFAULT_MODELS[prov],
                                        "messages": [{"role": "user", "content": prompt}],
                                        "max_tokens": max_tokens, "temperature": temperature},
                                  timeout=60)
                if r.status_code == 200:
                    return r.json()["choices"][0]["message"]["content"]
            elif prov == "groq":
                r = requests.post("https://api.groq.com/openai/v1/chat/completions",
                                  headers={"Authorization": f"Bearer {key}",
                                           "Content-Type": "application/json"},
                                  json={"model": DEFAULT_MODELS[prov],
                                        "messages": [{"role": "user", "content": prompt}],
                                        "max_tokens": max_tokens, "temperature": temperature},
                                  timeout=60)
                if r.status_code == 200:
                    return r.json()["choices"][0]["message"]["content"]
            # other providers: simple openai-style passthrough
            elif prov in ("openai", "deepseek"):
                base = "https://api.openai.com/v1" if prov == "openai" else "https://api.deepseek.com/v1"
                r = requests.post(f"{base}/chat/completions",
                                  headers={"Authorization": f"Bearer {key}",
                                           "Content-Type": "application/json"},
                                  json={"model": DEFAULT_MODELS[prov],
                                        "messages": [{"role": "user", "content": prompt}],
                                        "max_tokens": max_tokens, "temperature": temperature},
                                  timeout=60)
                if r.status_code == 200:
                    return r.json()["choices"][0]["message"]["content"]
        except Exception:
            continue
    return None


def get_llm_key(provider: str) -> str | None:
    var = PROVIDERS.get(provider.lower())
    if not var:
        return None
    if _state is not None and _state.get(var):
        return _state[var]
    if _user_cfg is not None and hasattr(_user_cfg, var):
        v = getattr(_user_cfg, var)
        if v: return v
    v = os.environ.get(var)
    return v if v else None


def get_all_keys() -> dict:
    out = {}
    for prov, var in PROVIDERS.items():
        k = get_llm_key(prov)
        if k:
            out[prov] = k[:6] + "…" + k[-4:] if len(k) > 12 else "***"
    return out


def set_env_from_config():
    n = 0
    for prov, var in PROVIDERS.items():
        k = get_llm_key(prov)
        if k and var not in os.environ:
            os.environ[var] = k
            n += 1
    return n
