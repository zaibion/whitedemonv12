"""
memory_guard.py — Auto-adjusts target_candles to fit available RAM.

Free Colab gives ~12 GB RAM. With 200k candles × 60 features × dual committee
training, we easily exceed this and Colab kills the process silently. This
module pegs the training data to a safe ceiling.

Estimated RAM cost ≈ 250 MB per 50k candles (training).
"""
from __future__ import annotations
import os

try:
    import psutil
    HAS_PSUTIL = True
except ImportError:
    HAS_PSUTIL = False


def get_available_ram_gb() -> float:
    """Best-effort total RAM in GB. Falls back to 8 GB if psutil missing."""
    if HAS_PSUTIL:
        try:
            return psutil.virtual_memory().total / (1024 ** 3)
        except Exception:
            pass
    # Fallback: read /proc/meminfo on Linux/Colab
    try:
        with open("/proc/meminfo") as f:
            for line in f:
                if line.startswith("MemTotal:"):
                    kb = int(line.split()[1])
                    return kb / (1024 ** 2)
    except Exception:
        pass
    return 8.0


def safe_candle_target(requested: int = 200_000) -> int:
    """Returns a candle count that should NOT OOM the current environment.

    Heuristic:
       12 GB RAM → 100k candles max
        8 GB RAM →  60k candles max
        4 GB RAM →  30k candles max
    """
    ram_gb = get_available_ram_gb()
    if ram_gb >= 24:
        ceiling = 200_000
    elif ram_gb >= 14:
        ceiling = 150_000
    elif ram_gb >= 10:
        ceiling = 100_000
    elif ram_gb >= 6:
        ceiling = 60_000
    else:
        ceiling = 30_000
    capped = min(requested, ceiling)
    if capped < requested:
        print(f"  [memory-guard] RAM={ram_gb:.1f}GB → capping training to "
              f"{capped:,} candles (requested {requested:,}) to avoid OOM")
    return capped
