"""Feature drift / distribution-shift monitoring (WhiteDemon Z.1).

Lightweight, dependency-free drift checks for live FAST MODE inference.
Compares the saved training reference matrix against the most recent live
feature rows after applying the saved scaler.

Metrics:
  * PSI (population stability index) per feature and aggregate
  * mean/std shift summary
  * severity level: ok / watch / drift / extreme

This module intentionally avoids scipy so it works in Colab/Kaggle minimal
installations.
"""
from __future__ import annotations
from typing import Any, Dict, List, Sequence
import numpy as np


def _safe_arr(x) -> np.ndarray:
    a = np.asarray(x, dtype=np.float32)
    return np.nan_to_num(a, nan=0.0, posinf=0.0, neginf=0.0)


def _psi(expected: np.ndarray, actual: np.ndarray, bins: int = 10) -> float:
    """Population Stability Index using quantile bins from expected data."""
    expected = _safe_arr(expected).reshape(-1)
    actual = _safe_arr(actual).reshape(-1)
    if expected.size < 30 or actual.size < 5:
        return 0.0
    try:
        qs = np.linspace(0, 1, bins + 1)
        edges = np.quantile(expected, qs)
        edges = np.unique(edges)
        if edges.size < 3:
            lo = min(float(expected.min()), float(actual.min())) - 1e-6
            hi = max(float(expected.max()), float(actual.max())) + 1e-6
            if hi <= lo:
                return 0.0
            edges = np.linspace(lo, hi, bins + 1)
        else:
            edges[0] = min(edges[0], actual.min()) - 1e-6
            edges[-1] = max(edges[-1], actual.max()) + 1e-6
        e_counts, _ = np.histogram(expected, bins=edges)
        a_counts, _ = np.histogram(actual, bins=edges)
        e_pct = e_counts.astype(float) / max(1.0, float(e_counts.sum()))
        a_pct = a_counts.astype(float) / max(1.0, float(a_counts.sum()))
        eps = 1e-6
        val = np.sum((a_pct - e_pct) * np.log((a_pct + eps) / (e_pct + eps)))
        if not np.isfinite(val):
            return 0.0
        return float(max(0.0, val))
    except Exception:
        return 0.0


def compute_feature_drift(reference_X: Any,
                          current_X: Any,
                          feature_names: Sequence[str] | None = None,
                          *,
                          max_features: int | None = None,
                          psi_watch: float = 0.10,
                          psi_drift: float = 0.25,
                          psi_extreme: float = 0.50) -> Dict[str, Any]:
    """Compare reference vs current feature distributions.

    Args:
        reference_X: saved training feature matrix, usually scaled.
        current_X: recent live feature matrix, scaled with the same scaler.
        feature_names: optional schema names.
        max_features: optional cap for very wide matrices.
    """
    try:
        ref = _safe_arr(reference_X)
        cur = _safe_arr(current_X)
        if ref.ndim != 2 or cur.ndim != 2:
            return {"available": False, "reason": "matrices must be 2D"}
        n_feat = min(ref.shape[1], cur.shape[1])
        if max_features is not None:
            n_feat = min(n_feat, int(max_features))
        if ref.shape[0] < 100 or cur.shape[0] < 10 or n_feat < 3:
            return {"available": False, "reason": "insufficient rows/features for drift"}
        names = list(feature_names or [])
        if len(names) < n_feat:
            names = names + [f"f{i}" for i in range(len(names), n_feat)]

        per: List[Dict[str, Any]] = []
        for j in range(n_feat):
            rj = ref[:, j]
            cj = cur[:, j]
            psi = _psi(rj, cj)
            r_mean = float(np.mean(rj)); c_mean = float(np.mean(cj))
            r_std = float(np.std(rj) + 1e-9); c_std = float(np.std(cj))
            z_shift = abs(c_mean - r_mean) / r_std
            per.append({
                "feature": names[j],
                "psi": round(float(psi), 5),
                "mean_shift_z": round(float(z_shift), 4),
                "ref_mean": round(r_mean, 5),
                "cur_mean": round(c_mean, 5),
                "ref_std": round(r_std, 5),
                "cur_std": round(c_std, 5),
            })

        psis = np.array([p["psi"] for p in per], dtype=float)
        mean_psi = float(np.mean(psis)) if len(psis) else 0.0
        max_psi = float(np.max(psis)) if len(psis) else 0.0
        drifted = int(np.sum(psis >= psi_drift))
        extreme = int(np.sum(psis >= psi_extreme))
        if max_psi >= psi_extreme or mean_psi >= psi_drift or extreme > 0:
            level = "extreme"
        elif max_psi >= psi_drift or mean_psi >= psi_watch or drifted > 0:
            level = "drift"
        elif max_psi >= psi_watch:
            level = "watch"
        else:
            level = "ok"
        top = sorted(per, key=lambda x: x["psi"], reverse=True)[:12]
        return {
            "available": True,
            "level": level,
            "reference_rows": int(ref.shape[0]),
            "current_rows": int(cur.shape[0]),
            "n_features": int(n_feat),
            "psi_mean": round(mean_psi, 5),
            "psi_max": round(max_psi, 5),
            "features_drifted": drifted,
            "features_extreme": extreme,
            "thresholds": {"watch": psi_watch, "drift": psi_drift, "extreme": psi_extreme},
            "top_features": top,
        }
    except Exception as e:
        return {"available": False, "reason": str(e)[:160]}
