"""
execution_quality.py — Slippage, fees, spread guard — institutional
"""
from __future__ import annotations
import numpy as np

INSTITUTIONAL_FEES = {
    "maker": 0.0002,
    "taker": 0.0004,
    "slippage_atr_mult": 0.12,
    "spread_guard_bps": 3.0,
}

def realistic_fill_price(side: str, mid: float, atr: float, spread_bps: float = 2.5) -> float:
    slip = atr * INSTITUTIONAL_FEES["slippage_atr_mult"]
    spread = mid * spread_bps / 10000.0
    if side.upper() == "LONG":
        return mid + spread/2 + slip*0.5
    else:
        return mid - spread/2 - slip*0.5

def round_trip_cost_bps(is_maker: bool = True) -> float:
    fee = INSTITUTIONAL_FEES["maker"] if is_maker else INSTITUTIONAL_FEES["taker"]
    return (fee*2 + 0.00015) * 10000  # ~5.5 bps maker, ~9.5 bps taker

def spread_guard_ok(spread_bps: float) -> bool:
    return spread_bps <= INSTITUTIONAL_FEES["spread_guard_bps"] * 1.8
