"""
engine_patches.py — Per-model save+resume for the byte-identical engine.

GUARANTEE: Engine MD5 unchanged (bd6aa404fb1a93e2d999f4cd759212f2).
GUARANTEE: Training math is IDENTICAL to v22 engine — no AMP, no batch-size
           changes, no hyperparameter overrides. Same loss, same optimizer,
           same epochs, same data, same outputs, same accuracy.

What we add (no math change):
  1. Per-classical-model cache (ThreadPoolExecutor.submit wrapper) —
     if model is already in storage, return it; otherwise train + save.
  2. Per-DL-model cache (DLEnsemble.train replaced with identical code
     plus before-loop cache check and after-loop save hook).
  3. Memory cleanup BETWEEN models (gc.collect / empty_cache) — does not
     touch any tensor that's part of training; only frees optimizer state
     of the just-finished model.

Activation: call apply_engine_patches() at module load. Each direction's
training is wrapped in `with engine_context(sym, tf, "LONG", count): …`.
"""
from __future__ import annotations
import os, threading
from typing import Optional, Dict, Any

from core.colors        import GREEN, YELLOW, CYAN, GREY, RESET, BOLD, RED
from core               import per_model_cache as pmc

# WhiteDemon_V8.2: post-fit isotonic calibration for classical models
def _hf_calibrate_classifier(model, X_val, y_val):
    """Wrap model.predict_proba with isotonic calibration if sklearn available."""
    try:
        from sklearn.calibration import CalibratedClassifierCV
        cal = CalibratedClassifierCV(model, method='isotonic', cv='prefit')
        cal.fit(X_val, y_val)
        return cal
    except Exception:
        return model

# WhiteDemon_V8.2: DL training heartbeat (prints every 30s with detailed progress)
import time as _WhiteDemon_V8_2_time, threading as _WhiteDemon_V8_2_thr
_WhiteDemon_V8_2_dl_hb_stop = None
_WhiteDemon_V8_2_progress = {"model": "None", "idx": 0, "total": 0, "start_t": 0}

def _WhiteDemon_V8_2_start_dl_hb(name, idx, total):
    global _WhiteDemon_V8_2_dl_hb_stop
    _WhiteDemon_V8_2_dl_hb_stop = _WhiteDemon_V8_2_thr.Event()
    _t0 = _WhiteDemon_V8_2_time.time()
    
    def _beat():
        while not _WhiteDemon_V8_2_dl_hb_stop.wait(30):
            elapsed = int(_WhiteDemon_V8_2_time.time() - _t0)
            # Estimate total time based on current model's progress
            # This is a rough guess, but better than nothing
            avg_per_model = elapsed / max(1, _WhiteDemon_V8_2_progress["idx"])
            remaining_models = _WhiteDemon_V8_2_progress["total"] - _WhiteDemon_V8_2_progress["idx"]
            eta_secs = int(avg_per_model * remaining_models)
            eta_min = eta_secs // 60
            
            print(f"  [dl heartbeat] Model {_WhiteDemon_V8_2_progress['idx']}/{_WhiteDemon_V8_2_progress['total']} "
                  f"({_WhiteDemon_V8_2_progress['model']}) training … {elapsed}s elapsed "
                  f"| ETA: ~{eta_min}m", flush=True)
    
    _WhiteDemon_V8_2_thr.Thread(target=_beat, daemon=True).start()

def _WhiteDemon_V8_2_stop_dl_hb():
    global _WhiteDemon_V8_2_dl_hb_stop
    if _WhiteDemon_V8_2_dl_hb_stop: _WhiteDemon_V8_2_dl_hb_stop.set()


# Per-thread context — committee.py sets this before calling the engine,
# the patched functions read it to know which (sym, tf, dir, count) to use.
_ctx_local = threading.local()


# ────────────────────────────────────────────────────────────────────────
# Model filter — when set, ONLY models in the allow-list will train.
# Used by `train_specific.py` so user can train one or two models per cell.
# ────────────────────────────────────────────────────────────────────────
def set_model_filter(classical: Optional[list] = None,
                      dl: Optional[list] = None):
    """Restrict which models train. None = no restriction."""
    _ctx_local.allow_classical = set(classical) if classical is not None else None
    _ctx_local.allow_dl        = set(dl)        if dl is not None        else None


def clear_model_filter():
    for a in ("allow_classical", "allow_dl"):
        if hasattr(_ctx_local, a):
            delattr(_ctx_local, a)


def _allowed(kind: str, name: str) -> bool:
    """True if model `name` of `kind` ∈ {'classical','dl'} is allowed this run."""
    allow = getattr(_ctx_local, f"allow_{kind}", None)
    if allow is None:
        return True   # no filter active → train everything (default behavior)
    return name in allow


def set_context(symbol: str, tf: str, direction: str, count: int):
    _ctx_local.symbol    = symbol
    _ctx_local.tf        = tf
    _ctx_local.direction = direction
    _ctx_local.count     = count


def clear_context():
    for attr in ("symbol", "tf", "direction", "count"):
        if hasattr(_ctx_local, attr):
            delattr(_ctx_local, attr)


def _get_ctx():
    return (getattr(_ctx_local, "symbol",    None),
             getattr(_ctx_local, "tf",        None),
             getattr(_ctx_local, "direction", None),
             getattr(_ctx_local, "count",     None))


# ────────────────────────────────────────────────────────────────────────
# Patch 1 — classical committee (ThreadPoolExecutor.submit wrapper)
# Returns a stub Future with cached model if already trained. Otherwise
# runs the real training function (engine's _train_with_extras) and saves
# the result on success. Training math itself is untouched.
# ────────────────────────────────────────────────────────────────────────
_orig_TPE_submit = None
_patched = False


def _wrap_submit(self, fn, *args, **kwargs):
    sym, tf, direction, count = _get_ctx()
    if not sym or len(args) < 3 or not isinstance(args[0], str):
        return _orig_TPE_submit(self, fn, *args, **kwargs)

    name = args[0]
    needs_sc = args[2]

    from concurrent.futures import Future

    # Cache hit?
    if pmc.is_done(sym, tf, direction, count, "classical", name):
        cached = pmc.load_classical(sym, tf, direction, count, name)
        if cached is not None:
            idx = pmc.get_index(sym, tf, direction, count)
            wf = float(idx.get("classical", {}).get(name, {}).get("wf", 0.5))
            stub = Future()
            stub.set_result((name, cached, needs_sc, wf, None))
            print(f"  {GREEN}[pmc] ⏩ skip {direction}/{name} "
                  f"(cached, wf={wf:.1%}){RESET}", flush=True)
            return stub

    # Filter active and this model NOT in allow-list? → skip without training.
    # Engine treats this as "failed" and continues; user trains it in a later cell.
    if not _allowed("classical", name):
        from concurrent.futures import Future
        stub = Future()
        stub.set_result((name, None, needs_sc, 0.5, "filtered (not in allow-list)"))
        print(f"  {GREY}[pmc] ⊘ skip {direction}/{name} (not in this run's allow-list){RESET}",
              flush=True)
        return stub

    # No cache → run SYNCHRONOUSLY (no nested threads, no OpenBLAS spam)
    # This trains one model at a time inside the engine's "parallel" loop.
    # Same training math, just sequential. Saves each model right after.
    print(f"  {CYAN}[pmc] ▶ training {direction}/{name} (synchronous, no nested threads){RESET}",
          flush=True)
    stub = Future()
    try:
        result = fn(*args, **kwargs)
        try:
            r_name, r_mdl, r_ns, r_wf, r_err = result
            if r_err is None and r_mdl is not None:
                try:
                    pmc.save_classical(sym, tf, direction, count, r_name, r_mdl,
                                        meta={"wf": float(r_wf), "needs_sc": bool(r_ns)})
                except Exception as e:
                    print(f"  {YELLOW}[pmc] save inline failed: {e}{RESET}")
        except Exception:
            pass
        stub.set_result(result)
    except Exception as e:
        # Don't crash the whole engine — return a "failed" tuple
        stub.set_result((name, None, needs_sc, 0.5, str(e)))
        print(f"  {RED}[pmc] {direction}/{name} training failed: {str(e)[:120]}{RESET}",
              flush=True)
    return stub


def _install_tpe_patch():
    global _orig_TPE_submit, _patched
    if _patched:
        return
    from concurrent.futures import ThreadPoolExecutor
    _orig_TPE_submit = ThreadPoolExecutor.submit
    ThreadPoolExecutor.submit = _wrap_submit
    _patched = True


def _uninstall_tpe_patch():
    global _patched
    if not _patched:
        return
    from concurrent.futures import ThreadPoolExecutor
    ThreadPoolExecutor.submit = _orig_TPE_submit
    _patched = False


# ────────────────────────────────────────────────────────────────────────
# Patch 2 — DLEnsemble.train  (BYTE-EQUIVALENT to engine, plus cache hooks)
# This is a verbatim copy of the engine's DLEnsemble.train() with three
# additions only:
#   • before training a net → check cache, skip if present
#   • after training a net → save state_dict to storage
#   • after each net → release optimizer + empty_cache (does not touch the
#     trained model weights)
# NO changes to: loss, optimizer, lr, weight_decay, scheduler, epochs,
# batch_size, dtype (fp32), grad clipping, eval logic, temperature scaling.
# ────────────────────────────────────────────────────────────────────────
_orig_dl_train = None
_dl_patched    = False


def _patched_dl_train(self, X, y):
    if not self.enabled:
        return
    import numpy as np
    import torch
    from torch import nn, optim
    import _engine as eng
    CFG  = eng.CFG
    BLUE  = getattr(eng, "BLUE",  "")
    GREEN_e = getattr(eng, "GREEN", "")
    GREY_e  = getattr(eng, "GREY",  "")
    RESET_e = getattr(eng, "RESET", "")

    # CUDA sanity — fall back to CPU if GPU is broken (kernel mismatch).
    try:
        from core.cuda_safe import verify_cuda_works
        if self.device.type == "cuda" and not verify_cuda_works(quiet=True):
            print(f"  {YELLOW}[v24] CUDA detected but broken — moving DL to CPU{RESET}",
                  flush=True)
            self.device = torch.device("cpu")
            for _m in self.models.values():
                try: _m.to("cpu")
                except Exception: pass
    except Exception:
        pass

    seq, L = self._seq(X)
    if seq is None:
        return
    y_seq = y[L:]
    n = min(len(seq), len(y_seq))
    if n < 64:
        return
    seq = seq[:n]; y_seq = y_seq[:n]
    split = int(n * 0.85)
    # Keep tensors on CPU — move each batch to GPU inside the inner loop.
    # Engine originally moved the whole train+val tensors to GPU at once which
    # OOMs on free Kaggle T4 (~6 GB free) when seq is 90k×256×60. Same math.
    Xtr_cpu = torch.from_numpy(seq[:split])
    ytr_cpu = torch.from_numpy(y_seq[:split].astype(np.float32))
    Xte_cpu = torch.from_numpy(seq[split:])
    yte_np = y_seq[split:]
    # Backwards-compat alias so any code below using Xtr/ytr/Xte still works
    Xtr, ytr, Xte = Xtr_cpu, ytr_cpu, Xte_cpu

    try:
        afl = eng.AsymmetricFocalLoss(fp_weight=4.0, gamma=2.5, confident_wrong_weight=2.0, label_smoothing=0.03)
    except TypeError:
        afl = eng.AsymmetricFocalLoss(fp_weight=4.0, gamma=2.5, confident_wrong_weight=2.0, label_smoothing=0.03)
    afl = afl.to(self.device)

    def _to_prob_1d(raw_out):
        if raw_out.dim() >= 2 and raw_out.shape[-1] == 2:
            return torch.softmax(raw_out, dim=-1)[:, 1]
        return raw_out.squeeze(-1)

    sym, tf, direction, count = _get_ctx()

    # CRITICAL: engine's DLEnsemble.__init__ puts ALL 14 DL nets on GPU at
    # construction (~3 GB just for weights). Free that immediately by moving
    # every untrained net to CPU. We'll move each one back to GPU just-in-time
    # right before it trains. Same models, same weights, just lazy placement.
    if self.device.type == "cuda":
        try:
            # Park ALL DL nets on CPU — bring each to GPU just-in-time
            for _name, _m in self.models.items():
                _m.to("cpu")
            import gc as _gc
            _gc.collect()
            torch.cuda.empty_cache()
            try: torch.cuda.ipc_collect()
            except Exception: pass
            torch.cuda.synchronize()
            free_gb = (torch.cuda.mem_get_info()[0] / 1024**3
                        if hasattr(torch.cuda, "mem_get_info") else 0)
            print(f"  [pmc] all {len(self.models)} DL nets parked on CPU. "
                  f"GPU free: {free_gb:.1f} GB", flush=True)
        except Exception:
            pass

    for i, (name, model) in enumerate(self.models.items(), 1):
        # Update global heartbeat progress
        _WhiteDemon_V8_2_progress.update({"model": name, "idx": i, "total": len(self.models)})
        
        # ── Memory cleanup BEFORE training next model (defensive) ──
        try:
            import gc as _gc
            _gc.collect()
            if self.device.type == "cuda":
                torch.cuda.empty_cache()
                try: torch.cuda.ipc_collect()
                except Exception: pass
                torch.cuda.synchronize()
        except Exception:
            pass

        # Heavy DL nets (TFT, Mamba, Transformer) need ~10+ GB internal
        # tensors. On tight GPUs (T4/P100 with <6 GB free), put them on
        # CPU directly to avoid OOM. Same training math, just slower.
        _target_dev = self.device
        if self.device.type == "cuda":
            try:
                free_gb = torch.cuda.mem_get_info()[0] / 1024**3
                _heavy = name in ("tft", "mamba", "mamba_pdf", "transformer",
                                   "itransformer", "patchtst")
                if _heavy and free_gb < 8:
                    print(f"  [pmc] {name}: only {free_gb:.1f}GB free on GPU "
                          f"(needs ~10GB) → training on CPU instead", flush=True)
                    _target_dev = torch.device("cpu")
            except Exception: pass
        try:
            model.to(_target_dev)
        except Exception:
            pass

        # ── Cache check (skip if already trained) ──
        if sym and pmc.is_done(sym, tf, direction, count, "dl", name):
            try:
                loaded = pmc.load_dl(sym, tf, direction, count, name, model)
                if loaded is not None:
                    idx = pmc.get_index(sym, tf, direction, count)
                    meta = idx.get("dl", {}).get(name, {})
                    self.accs[name]         = float(meta.get("acc", 0.5))
                    self.temperatures[name] = float(meta.get("temp", 1.0))
                    # Move cached model to CPU to free VRAM until predict-time
                    if self.device.type == "cuda":
                        try: model.to("cpu")
                        except Exception: pass
                        try: torch.cuda.empty_cache()
                        except Exception: pass
                    print(f"  {GREEN}[pmc] ⏩ DL skip {direction}/{name} "
                          f"(cached, acc={self.accs[name]:.1%}){RESET}", flush=True)
                    continue
            except RuntimeError as e:
                if "size mismatch" in str(e).lower():
                    print(f"  {YELLOW}[pmc] size mismatch for {name} (features changed) "
                          f"→ forcing retrain{RESET}", flush=True)
                    # We don't 'continue' here, so it falls through to training
                else:
                    print(f"  {YELLOW}[pmc] error loading {name}: {e}{RESET}")

        # ── Filter check (skip if not in user's allow-list) ──
        if not _allowed("dl", name):
            self.accs[name]         = 0.5
            self.temperatures[name] = 1.0
            # Same — free GPU memory occupied by this unused net
            if self.device.type == "cuda":
                try: model.to("cpu")
                except Exception: pass
                try: torch.cuda.empty_cache()
                except Exception: pass
            print(f"  {GREY}[pmc] ⊘ DL skip {direction}/{name} "
                  f"(not in this run's allow-list){RESET}", flush=True)
            continue

        # ════════════════════════════════════════════════════════════════
        # IDENTICAL TO ENGINE'S DLEnsemble.train — DO NOT MODIFY
        # ════════════════════════════════════════════════════════════════
        opt = optim.AdamW(model.parameters(), lr=3e-4, weight_decay=1e-4)  # V8.3 precision LR: lowered for smoother DL convergence
        try:
            if True:  # HF max accuracy
                sched = optim.lr_scheduler.CosineAnnealingWarmRestarts(opt, T_0=20, T_mult=2)
            else:
                sched = optim.lr_scheduler.CosineAnnealingLR(opt, T_max=CFG["dl_epochs"])
        except Exception:
            sched = optim.lr_scheduler.CosineAnnealingLR(opt, T_max=CFG["dl_epochs"])
        bs = CFG["dl_batch"]
        best_acc = 0.5
        best_epoch = 0
        best_state = None
        patience = 0
        _pat_lim = 8
        _min_delta = 5e-4  # require real improvement; printed equal 70.1% will not reset patience
        import time as _time
        _ep_t0 = _time.time()
        # Big visible banner so user can SEE which device DL is using
        _dev_emoji = "🚀 GPU" if self.device.type == "cuda" else "🐢 CPU"
        _gpu_mem_msg = ""
        if self.device.type == "cuda":
            try:
                _alloc = torch.cuda.memory_allocated() / 1024**3
                _gpu_mem_msg = f" · GPU mem={_alloc:.2f}GB"
            except Exception: pass
        print(f"\n  {BLUE}DL training {name:<11}{RESET_e}  {_dev_emoji}  "
              f"(epochs={CFG['dl_epochs']}, seq={CFG['dl_seq_len']}, "
              f"hidden={CFG['dl_hidden']}, batch={bs}{_gpu_mem_msg})", flush=True)
        # ── Eval-batch size: split val tensor into chunks so it never lands
        #    on GPU all at once. Same numerical output as one big forward pass.
        # SAFE SPEEDUP: validation/inference batch can be MUCH larger than
        # training batch. Forward-only passes have no gradient accumulation,
        # so larger batches don't change training math at all. Uses spare VRAM.
        # On a T4 (14 GB), 1024-sample eval batches use ~3 GB and run ~16× faster.
        _eval_bs = 1024 if _target_dev.type == "cuda" else max(16, bs)
        for ep in range(CFG["dl_epochs"]):
            model.train()
            idx = torch.randperm(len(Xtr_cpu))
            tot = 0.0
            for i in range(0, len(Xtr_cpu), bs):
                b = idx[i:i + bs]
                # Move JUST this batch to GPU (CPU → GPU per step)
                xb = Xtr_cpu[b].to(_target_dev, non_blocking=True)
                yb = ytr_cpu[b].to(_target_dev, non_blocking=True)
                opt.zero_grad()
                raw_out = model(xb)
                pred = _to_prob_1d(raw_out)
                try:
                    logits_for_afl = torch.logit(pred.clamp(1e-6, 1 - 1e-6))
                    loss = afl(logits_for_afl, yb)
                except Exception:
                    loss = nn.functional.binary_cross_entropy(
                        pred, yb, reduction="mean")
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                opt.step()
                tot += float(loss.item())
                del xb, yb, raw_out, pred, loss
            sched.step()
            model.eval()
            # Chunked validation so we never push 90k bars to GPU at once
            preds = []
            with torch.no_grad():
                for j in range(0, len(Xte_cpu), _eval_bs):
                    xv = Xte_cpu[j:j + _eval_bs].to(_target_dev, non_blocking=True)
                    pv = _to_prob_1d(model(xv)).cpu().numpy()
                    if pv.ndim > 1: pv = pv[..., -1]
                    preds.append(pv)
                    del xv, pv
            import numpy as _np
            p = _np.concatenate(preds) if preds else _np.array([])
            acc = float(((p >= 0.5).astype(int) == yte_np).mean()) if len(p) else 0.5
            if acc > best_acc + _min_delta:
                best_acc = acc
                best_epoch = ep + 1
                patience = 0
                # Store BEST weights on CPU so later bad epochs cannot overwrite the good model.
                best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            else:
                patience += 1
            # Live progress so user knows it isn't frozen
            _ep_elapsed = _time.time() - _ep_t0
            _avg = _ep_elapsed / (ep + 1)
            _eta = _avg * (CFG["dl_epochs"] - ep - 1)
            print(f"    {GREY}[{name}] ep {ep+1}/{CFG['dl_epochs']} "
                  f"loss={tot:.3f} acc={acc:.1%} best={best_acc:.1%} "
                  f"best_ep={best_epoch} no_improve={patience}/{_pat_lim} "
                  f"({_avg:.1f}s/ep · ETA {_eta:.0f}s){RESET}", flush=True)
            if patience >= _pat_lim:
                print(f"    {GREY}[{name}] early-stop at ep {ep+1} (no improvement for {_pat_lim} epochs){RESET}")
                break
        if best_state is not None:
            model.load_state_dict(best_state)
            print(f"    {GREEN}[{name}] restored BEST weights from epoch {best_epoch} (acc={best_acc:.1%}){RESET}", flush=True)
        self.accs[name] = best_acc
        print(f"  {BLUE}DL {name:<11}{RESET_e} {GREEN}done · acc={best_acc:.1%} · "
              f"best_epoch={best_epoch} · took {_time.time()-_ep_t0:.0f}s{RESET}", flush=True)

        # Temperature scaling — IDENTICAL math, chunked GPU usage
        try:
            model.eval()
            _parts = []
            with torch.no_grad():
                for j in range(0, len(Xte_cpu), _eval_bs):
                    xv = Xte_cpu[j:j + _eval_bs].to(_target_dev, non_blocking=True)
                    _parts.append(_to_prob_1d(model(xv)).cpu())
                    del xv
            raw_val = torch.cat(_parts) if _parts else torch.zeros(0)
            if raw_val.dim() > 1:
                raw_val = raw_val[..., -1]
            raw_val = raw_val.clamp(1e-6, 1 - 1e-6)
            yte_t = torch.from_numpy(yte_np.astype(np.float32))
            best_T, best_nll = 1.0, float("inf")
            for T_cand in np.linspace(0.1, 10.0, 50):
                logits = torch.log(raw_val / (1 - raw_val)) / T_cand
                probs_T = torch.sigmoid(logits)
                nll = -((yte_t * torch.log(probs_T + 1e-9) +
                         (1 - yte_t) * torch.log(1 - probs_T + 1e-9)).mean())
                if nll < best_nll:
                    best_nll = nll; best_T = T_cand
            self.temperatures[name] = float(best_T)
        except Exception:
            self.temperatures[name] = 1.0

        # ── Save this DL model IMMEDIATELY (after training, before next) ──
        if sym:
            try:
                pmc.save_dl(sym, tf, direction, count, name, model,
                             meta={"acc": float(best_acc),
                                   "temp": float(self.temperatures.get(name, 1.0))})
            except Exception as _e:
                print(f"  {YELLOW}[pmc] save DL {name} failed: {_e}{RESET}")

        # ── AGGRESSIVE memory cleanup after each model is saved ──
        # Move trained model back to CPU + clear ALL GPU caches before
        # touching the next model. This is the key to no-OOM training.
        try:
            del opt, sched
            for _p in model.parameters():
                if _p.grad is not None: _p.grad = None
            # ALWAYS move this model to CPU (was on GPU during training)
            try: model.to("cpu")
            except Exception: pass
            import gc as _gc
            _gc.collect()
            # Drain all CUDA caches — empty_cache + ipc_collect + synchronize
            if self.device.type == "cuda" or _target_dev.type == "cuda":
                try: torch.cuda.empty_cache()
                except Exception: pass
                try: torch.cuda.ipc_collect()
                except Exception: pass
                try: torch.cuda.synchronize()
                except Exception: pass
        except Exception:
            pass

    # ── CRITICAL: after training loop, move ALL models BACK to self.device ──
    # The engine's predict_proba_live() puts input on self.device. If models
    # are still on CPU (from our memory-cleanup), inference crashes with
    # "Input and parameter tensors are not at the same device".
    # Solution: restore models to GPU one at a time, with memory pressure check.
    if self.device.type == "cuda":
        try:
            import gc as _gc
            _gc.collect(); torch.cuda.empty_cache(); torch.cuda.synchronize()
            free_gb = (torch.cuda.mem_get_info()[0] / 1024**3
                        if hasattr(torch.cuda, "mem_get_info") else 0)
            print(f"  [pmc] restoring {len(self.models)} DL nets to GPU for inference "
                  f"(free: {free_gb:.1f} GB)…", flush=True)
            for _n, _m in self.models.items():
                try:
                    _m.eval()
                    _m.to(self.device)
                except Exception as _e:
                    # If a heavy net can't fit, keep on CPU — predict_proba_live
                    # will error for that one model but others still work
                    print(f"  [pmc] {_n}: couldn't restore to GPU ({_e}); staying on CPU",
                          flush=True)
        except Exception as _e:
            print(f"  [pmc] restore-to-GPU failed: {_e}", flush=True)


# ────────────────────────────────────────────────────────────────────────
# Patch predict_proba_live to be device-safe: move input to model's device
# (instead of forcing input to self.device which may not match model location)
# ────────────────────────────────────────────────────────────────────────
_orig_predict_proba_live = None
_predict_patched = False


def _patched_predict_proba_live(self, X_all):
    """Same logic as engine, but matches input device to each model's device."""
    if not self.enabled or not self.models:
        return None
    import numpy as _np
    import torch as _t
    L = CFG_PATCH_LOOKUP = None
    try:
        import _engine as eng
        L = eng.CFG["dl_seq_len"]
    except Exception:
        return None
    if len(X_all) < L:
        return None
    # CPU tensor — moved to each model's device per-iteration
    seq_cpu = _t.from_numpy(X_all[-L:].astype(_np.float32)).unsqueeze(0)
    probs, weights = [], []
    indiv = {}
    for name, model in self.models.items():
        try:
            model.eval()
            # Use whatever device the model is actually on
            mdev = next(model.parameters()).device
            seq = seq_cpu.to(mdev)
            with _t.no_grad():
                raw_out = model(seq)
                if raw_out.dim() >= 2 and raw_out.shape[-1] == 2:
                    p_tensor = _t.softmax(raw_out, dim=-1)[:, 1]
                else:
                    p_tensor = raw_out.squeeze(-1)
                p_raw = float(p_tensor.detach().cpu().numpy().reshape(-1)[0])
            # Apply temperature scaling
            p = self._apply_temperature(name, p_raw)
            probs.append(p)
            weights.append(max(0.01, self.accs.get(name, 0.5)))
            indiv[name] = p
            del seq, raw_out, p_tensor
        except Exception as e:
            print(f"  [pmc] {name} predict skipped: {str(e)[:80]}")
            continue
    if not probs:
        return None
    weights = _np.array(weights); weights = weights / weights.sum()
    return float(_np.average(probs, weights=weights)), indiv


def _install_predict_patch():
    global _orig_predict_proba_live, _predict_patched
    if _predict_patched: return
    import _engine as eng
    _orig_predict_proba_live = eng.DLEnsemble.predict_proba_live
    eng.DLEnsemble.predict_proba_live = _patched_predict_proba_live
    _predict_patched = True


def _uninstall_predict_patch():
    global _predict_patched
    if not _predict_patched: return
    import _engine as eng
    eng.DLEnsemble.predict_proba_live = _orig_predict_proba_live
    _predict_patched = False


def _install_dl_patch():
    global _orig_dl_train, _dl_patched
    if _dl_patched:
        return
    import _engine as eng
    _orig_dl_train = eng.DLEnsemble.train
    eng.DLEnsemble.train = _patched_dl_train
    _dl_patched = True


def _uninstall_dl_patch():
    global _dl_patched
    if not _dl_patched: return
    import _engine as eng
    eng.DLEnsemble.train = _orig_dl_train
    _dl_patched = False


# ────────────────────────────────────────────────────────────────────────
# Patch 3 — Serialize run_ml_committee (engine spawns LONG+SHORT in 2 threads)
#
# Engine line 11165-11186: ThreadPoolExecutor(max_workers=2) trains LONG and
# SHORT committees concurrently. User-visible effect: 2× memory pressure +
# CUDA OOM during DL stage.
#
# Fix: wrap run_ml_committee with a global threading.Lock so only one direction
# runs at a time. The two engine threads still spawn, but the second blocks on
# the lock until the first finishes. Same outputs, same models, same accuracy
# — just no concurrent execution. (Engine bytes still unmodified.)
# ────────────────────────────────────────────────────────────────────────
import threading as _v24_threading

_v24_committee_lock = _v24_threading.Lock()
_v24_orig_run_ml_committee = None
_committee_patched = False


def _v24_serialized_run_ml_committee(*args, **kwargs):
    """Wrapper that serializes calls so LONG and SHORT run one after the other."""
    direction = kwargs.get("direction", "?")
    acquired_at_first_try = _v24_committee_lock.acquire(blocking=False)
    if not acquired_at_first_try:
        print(f"  {CYAN}[pmc] {direction} committee waiting for other direction to finish "
              f"(forced sequential — prevents OOM){RESET}", flush=True)
        _v24_committee_lock.acquire()  # blocks here
    try:
        print(f"  {CYAN}[pmc] {direction} committee acquired lock — training NOW{RESET}",
              flush=True)
        result = _v24_orig_run_ml_committee(*args, **kwargs)
        print(f"  {CYAN}[pmc] {direction} committee done — releasing lock{RESET}",
              flush=True)
        return result
    finally:
        _v24_committee_lock.release()


def _install_committee_serialization():
    global _v24_orig_run_ml_committee, _committee_patched
    if _committee_patched:
        return
    import _engine as eng
    _v24_orig_run_ml_committee = eng.run_ml_committee
    eng.run_ml_committee = _v24_serialized_run_ml_committee
    _committee_patched = True


def _uninstall_committee_serialization():
    global _committee_patched
    if not _committee_patched:
        return
    import _engine as eng
    eng.run_ml_committee = _v24_orig_run_ml_committee
    _committee_patched = False


# ────────────────────────────────────────────────────────────────────────
# Patch 4 (WhiteDemon_V8.2) — Cache the 4 specialised NNs so they don't retrain every analyze
# ────────────────────────────────────────────────────────────────────────
_nn_patched = False
_nn_orig_trains: dict = {}   # {class_name: original_train_method}

# Wrappers we patch — each runs `train()`, then we want to save_nn after
_NN_WRAPPERS = ("PriceRegressionEnsemble", "RLTradingAgent",
                "SentimentNNWrapper",      "RegimeDetectorNNWrapper")

_NN_KEY_FOR_CLASS = {
    "PriceRegressionEnsemble":   "price_reg",
    "RLTradingAgent":            "rl_agent",
    "SentimentNNWrapper":        "sentiment_nn",
    "RegimeDetectorNNWrapper":   "regime_nn",
}


def _make_nn_patched_train(orig_train, class_name: str):
    """Wrap a NN wrapper's train() — first try to load from cache, else train + save."""
    nn_name = _NN_KEY_FOR_CLASS.get(class_name, class_name.lower())
    def _patched(self, *args, **kwargs):
        sym, tf, _direction, count = _get_ctx()
        if not (sym and tf and count):
            # No context (probably backtest fold) — train normally
            return orig_train(self, *args, **kwargs)
        # Try to load from cache FIRST
        try:
            from . import per_model_cache as _pmc
            if _pmc.load_nn(sym, tf, count, nn_name, self):
                print(f"  \033[32m[pmc] ✓ NN {nn_name} loaded from cache "
                      f"(train_acc={self.train_acc:.3f}) — skip training\033[0m",
                      flush=True)
                return None
        except Exception as _e:
            print(f"  \033[33m[pmc] NN load probe failed: {_e}\033[0m", flush=True)
        # Cache miss → train, then save
        out = orig_train(self, *args, **kwargs)
        try:
            from . import per_model_cache as _pmc
            _pmc.save_nn(sym, tf, count, nn_name, self,
                          meta={"class": class_name})
        except Exception as _e:
            print(f"  \033[33m[pmc] NN save failed: {_e}\033[0m", flush=True)
        return out
    return _patched


def _install_nn_patch():
    global _nn_patched
    if _nn_patched:
        return
    import _engine as eng
    for cls_name in _NN_WRAPPERS:
        cls = getattr(eng, cls_name, None)
        if cls is None:
            continue
        _nn_orig_trains[cls_name] = cls.train
        cls.train = _make_nn_patched_train(cls.train, cls_name)
    _nn_patched = True


def _uninstall_nn_patch():
    global _nn_patched
    if not _nn_patched:
        return
    import _engine as eng
    for cls_name, orig in _nn_orig_trains.items():
        cls = getattr(eng, cls_name, None)
        if cls is not None:
            cls.train = orig
    _nn_orig_trains.clear()
    _nn_patched = False


# ────────────────────────────────────────────────────────────────────────
# Public API
# ────────────────────────────────────────────────────────────────────────
def apply_engine_patches():
    """Install all monkey patches. Idempotent."""
    _install_tpe_patch()
    _install_dl_patch()
    _install_predict_patch()
    _install_committee_serialization()
    _install_nn_patch()       # WhiteDemon_V8.2: cache the 4 specialised NNs
    # Institutional V12 — CIO / Head Quant approved
    try:
        from core.institutional_v12 import install_institutional_v12
        install_institutional_v12()
    except Exception as _e:
        print(f"  [institutional] patch skipped: {_e}")
    # V12.1 MAX WIN — 12-coin profiles
    try:
        from core.coin_tuner_v12_1 import install_coin_tuner
        install_coin_tuner()
    except Exception as _e2:
        print(f"  [v12.1] coin tuner skipped: {_e2}")

def remove_engine_patches():
    _uninstall_tpe_patch()
    _uninstall_dl_patch()
    _uninstall_committee_serialization()
    _uninstall_nn_patch()


class engine_context:
    """Context manager: sets per-model cache key + ensures patches applied."""
    def __init__(self, symbol: str, tf: str, direction: str, count: int):
        self.args = (symbol, tf, direction, count)

    def __enter__(self):
        apply_engine_patches()
        set_context(*self.args)
        return self

    def __exit__(self, exc_type, exc, tb):
        clear_context()
        return False
