"""
gpu_setup.py — Device detection with CUDA-broken auto-fallback.

Calls verify_cuda_works() to catch the dreaded
"no kernel image is available for execution on the device" error and
silently fall back to CPU.
"""
from __future__ import annotations
import os

_state = {"device": "cpu", "info": "not initialized"}


def enable_gpu(verbose: bool = True) -> str:
    """Returns the active device name ('cuda', 'mps', or 'cpu')."""
    try:
        import torch
    except ImportError:
        _state["device"] = "cpu"
        _state["info"] = "PyTorch not installed"
        if verbose: print(f"[device] CPU only (no torch)")
        return "cpu"

    # CUDA detected? Verify it actually works.
    if torch.cuda.is_available():
        from .cuda_safe import verify_cuda_works
        if verify_cuda_works(quiet=not verbose):
            try:
                gpu_name = torch.cuda.get_device_name(0)
                mem_gb = torch.cuda.get_device_properties(0).total_memory / 1024**3
                _state["device"] = "cuda"
                _state["info"] = f"CUDA · {gpu_name} · {mem_gb:.1f} GB"
            except Exception:
                _state["device"] = "cuda"; _state["info"] = "CUDA"
        else:
            # CUDA detected but broken (kernel mismatch). Force CPU.
            _state["device"] = "cpu"
            _state["info"] = "CPU only (CUDA broken — auto-fallback)"
    elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        _state["device"] = "mps"
        _state["info"] = "Apple Silicon MPS"
    else:
        _state["device"] = "cpu"
        _state["info"] = "CPU only"

    # Hand the device hint to the engine
    try:
        import _engine
        if hasattr(_engine, "CFG"):
            _engine.CFG["torch_device"] = _state["device"]
    except Exception:
        pass

    if verbose:
        try:
            from .colors import RESET, BOLD, GREEN, YELLOW
        except Exception:
            RESET = BOLD = GREEN = YELLOW = ""
        col = GREEN if _state["device"] != "cpu" else YELLOW
        print(f"{BOLD}{col}[device] {_state['info']}{RESET}")

    return _state["device"]


def get_device() -> str:
    return _state["device"]


def get_info() -> dict:
    return dict(_state)
