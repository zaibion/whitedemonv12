"""CFG, PAIRS, TIMEFRAMES — re-exported from the proven engine.

v25: SINGLE SOURCE OF TRUTH = `.setup_state.json` written by setup.py.
No more confusion between setup.py / config.py / env vars.

Loading priority:
  1. .setup_state.json (written by setup.py)   ← PRIMARY
  2. config.py (legacy fallback)
  3. environment variables
  4. defaults
"""
from __future__ import annotations
import os, sys, json, importlib.util

# Make sure project root is on sys.path so `import _engine` works
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

# Load the engine ONCE — every other module just imports from here.
print("[core.config] loading engine …")
import _engine                                # noqa: E402

CFG         = _engine.CFG
PAIRS       = _engine.PAIRS
TIMEFRAMES  = _engine.TIMEFRAMES
FAST_MODE   = _engine.FAST_MODE
apply_selection = _engine.apply_selection

# WhiteDemon_V8.2: inject extra pairs (BTC/ETH/SOL...18 → 100+) for CCXT-backed exchanges
try:
    from . import pairs_ext as _pe
    _pe.inject_pairs(PAIRS)
except Exception as _ex_e:
    print(f"[core.config] pairs_ext inject skipped: {_ex_e}")


# ─────────────────────────────────────────────────────────────────────
# Find the setup state file — try MANY locations (Kaggle/Colab/local)
# ─────────────────────────────────────────────────────────────────────
_SEARCH_DIRS = [
    os.getcwd(),
    _ROOT,
    "/kaggle/working/crypto-v23",
    "/kaggle/working",
    "/content/crypto-v23",
    "/content",
]


def _find(filename: str) -> str | None:
    for d in _SEARCH_DIRS:
        p = os.path.join(d, filename)
        if os.path.exists(p) and os.path.isfile(p):
            return p
    return None


# 1. Try JSON state (written by setup.py — primary source of truth)
_state = None
_state_path = _find(".setup_state.json")
if _state_path:
    try:
        with open(_state_path) as f:
            _state = json.load(f)
        print(f"[core.config] ✓ setup state loaded from: {_state_path}")
    except Exception as _e:
        print(f"[core.config] ⚠ failed to read {_state_path}: {_e}")
        _state = None

# 2. Fallback: load legacy config.py if no JSON found
_user_cfg = None
if _state is None:
    _cfg_path = _find("config.py")
    if _cfg_path:
        try:
            _spec = importlib.util.spec_from_file_location("user_config", _cfg_path)
            _user_cfg = importlib.util.module_from_spec(_spec)
            _spec.loader.exec_module(_user_cfg)
            print(f"[core.config] ✓ legacy config.py loaded from: {_cfg_path}")
        except Exception as _e:
            print(f"[core.config] ⚠ failed to load {_cfg_path}: {_e}")
            _user_cfg = None
    else:
        print(f"[core.config] ⚠ no setup state OR config.py found — run setup.py first!")


def _get(name: str, default):
    """Read from JSON state first, then config.py, then env var, then default."""
    if _state is not None and name in _state:
        return _state[name]
    if _user_cfg is not None and hasattr(_user_cfg, name):
        return getattr(_user_cfg, name)
    if name in os.environ:
        val = os.environ[name]
        try: return type(default)(val) if default is not None else val
        except Exception: return val
    return default


PAIR_ID         = int(_get("PAIR_ID",        1))
TF_ID           = int(_get("TF_ID",          4))
TARGET_CANDLES  = int(_get("TARGET_CANDLES", 200_000))
FAST_CANDLES    = int(_get("FAST_CANDLES",   4_000))

# WhiteDemon_V8.2: smart-SL aggressiveness toggle ("off"|"conservative"|"balanced"|"aggressive")
SMART_SL_AGGR   = str(_get("smart_sl_aggressiveness", "balanced") or "balanced").lower()
CFG["smart_sl_aggressiveness"] = SMART_SL_AGGR


PAIR     = next((p for p in PAIRS      if p["id"] == PAIR_ID), PAIRS[0])
TF       = next((t for t in TIMEFRAMES if t["id"] == TF_ID),   TIMEFRAMES[3])
SYMBOL   = PAIR["symbol"]
TF_LABEL = TF["label"]

# Wire CFG with sensible defaults for production
CFG["target_total_candles"] = TARGET_CANDLES
CFG["cache_fetch_candles"]  = FAST_CANDLES
CFG["cache_max_age_hours"]  = 24 * 14
CFG["cache_max_new_bars"]   = 200_000
CFG["backtest_prompt"]      = False
CFG["run_backtest"]         = False

# Inject pair/tf IDs ONLY for the duration of apply_selection() so the engine
# can read them, then immediately restore the original argv so downstream
# argparse calls don't see them as positional args.
_orig_argv = list(sys.argv)
sys.argv = [sys.argv[0], str(PAIR_ID), str(TF_ID)]
apply_selection(PAIR, TF)
sys.argv = _orig_argv   # restore

print(f"[core.config] ▶ ACTIVE: {SYMBOL} @ {TF_LABEL}  (PAIR_ID={PAIR_ID}, TF_ID={TF_ID})  ·  candles={TARGET_CANDLES:,}")
print(f"[core.config]   (if wrong → re-run setup.py and pick correct pair/TF)")

# v100 SHAP feature pruning
SHAP_PRUNE = True          # prune bottom 20%
SHAP_PRUNE_PCT = 0.20
