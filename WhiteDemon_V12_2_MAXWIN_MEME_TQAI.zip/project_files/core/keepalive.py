"""
keepalive.py — Prevents Colab from disconnecting.

Two layers:
  1. Python: spawns a daemon thread that prints a tiny heartbeat every
     30 seconds. This keeps the Colab cell "active" so it isn't reaped.
  2. Browser JS: a snippet you paste into Colab's browser console that
     auto-clicks the "Connect" button if disconnect ever happens.

Usage:
  from core.keepalive import start_keepalive, JS_SNIPPET, print_js_snippet
  start_keepalive()
  print_js_snippet()         # prints the JS to paste into browser console
"""
from __future__ import annotations
import sys, time, threading, datetime

_running = False
_thread: "threading.Thread | None" = None

def _heartbeat_loop(interval: int):
    global _running
    counter = 0
    while _running:
        try:
            time.sleep(interval)
            if not _running: break
            counter += 1
            ts = datetime.datetime.now().strftime("%H:%M:%S")
            # tiny print — won't spam the log
            sys.stdout.write(f"\r[keepalive {ts} · {counter*interval}s alive]")
            sys.stdout.flush()
        except Exception:
            pass


def start_keepalive(interval: int = 30) -> None:
    """Start a daemon thread that prints a heartbeat every `interval` seconds."""
    global _running, _thread
    if _running:
        return
    _running = True
    _thread = threading.Thread(target=_heartbeat_loop, args=(interval,),
                                daemon=True, name="keepalive")
    _thread.start()
    print(f"  [keepalive] heartbeat thread started ({interval}s interval)")


def stop_keepalive() -> None:
    global _running
    _running = False


# Browser-console JS — paste this into Colab's DevTools console (F12).
# Auto-clicks the "Reconnect" / "Connect" button if disconnected.
JS_SNIPPET = """
// ─── COLAB ANTI-DISCONNECT — paste into browser console (F12) ───
function ClickConnect(){
  console.log("[keepalive] " + new Date().toISOString());
  try {
    // Newer Colab UI
    document.querySelector("colab-toolbar-button#connect")?.click();
    document.querySelector("colab-connect-button")?.shadowRoot?.querySelector("#connect")?.click();
  } catch(e) {}
  try {
    // Click "Yes" on the "you are still there?" prompt
    document.querySelectorAll("paper-button.id-OkButton, paper-button.ok").forEach(b => b.click());
  } catch(e) {}
}
setInterval(ClickConnect, 60000);  // every 60s
console.log("✅ Colab keepalive active — will stay connected.");
"""

def print_js_snippet() -> None:
    print()
    print("━" * 70)
    print("  📌 COLAB ANTI-DISCONNECT — paste this into your browser console")
    print("     (press F12 in Colab tab → Console tab → paste → Enter)")
    print("━" * 70)
    print(JS_SNIPPET)
    print("━" * 70)
    print()
