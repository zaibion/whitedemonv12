"""core/ — shared helpers (config, colors, storage).

CRITICAL ORDER (must run BEFORE engine imports torch/numpy/sklearn):
  1. Install stderr filter → drops OpenBLAS warning noise at OS pipe level
  2. Set thread-count env vars → reduce nested-thread triggers
  3. Run CUDA pre-check → disable broken CUDA before any model goes to GPU
  4. Import config (which imports the engine)
"""
import os as _os

# ── 1. Filter OpenBLAS warning noise at the stderr pipe level ──
# Must happen BEFORE any numpy/sklearn ops. Setting OMP_NUM_THREADS alone
# doesn't help because the warning is compiled into OpenBLAS itself.
try:
    from . import stderr_filter as _sf
    _sf.install_stderr_filter()
except Exception:
    pass

# ── 2. Force single-threaded BLAS (defensive — reduces but doesn't kill spam) ──
for _v in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS",
           "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS",
           "BLIS_NUM_THREADS"):
    _os.environ.setdefault(_v, "1")

# ── 2b. Silence the cosmetic "[!] mistralai not installed" print from engine
# (engine bytes must stay v22-identical — we silence by filtering stdout)
import sys as _sys
_real_stdout_write = _sys.stdout.write
def _filtered_stdout_write(_msg, _orig=_real_stdout_write):
    if isinstance(_msg, str) and "mistralai not installed" in _msg:
        return len(_msg)
    return _orig(_msg)
try:
    _sys.stdout.write = _filtered_stdout_write   # type: ignore
except Exception:
    pass

# ── 3. CUDA pre-check (disables broken CUDA before engine builds nets) ──
from . import cuda_safe as _cuda_safe
_cuda_safe.verify_cuda_works(quiet=True)

# Restore stdout AFTER engine import (so user prints aren't filtered)
def _restore_stdout():
    try: _sys.stdout.write = _real_stdout_write  # type: ignore
    except Exception: pass

# ── 4. Now safe to import config (which imports the engine) ──
from .config import (CFG, PAIRS, TIMEFRAMES, FAST_MODE,
                      PAIR_ID, TF_ID, PAIR, TF, SYMBOL, TF_LABEL,
                      apply_selection)
_restore_stdout()   # engine done importing — restore unfiltered stdout
from .colors import *  # noqa: F401,F403
from .storage import Storage, STORE
