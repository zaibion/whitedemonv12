"""
pairs_ext.py — Extended trading pairs list (CCXT-friendly).

The engine ships with 18 hard-coded PAIRS (BTC..SHIB). This module appends
~85 more pairs available on Binance / Bybit / OKX / KuCoin (free public API).
If CCXT isn't installed OR the chosen pair isn't on any exchange we silently
fall back to Yahoo Finance (which usually only has the top ~30 majors).

USAGE — call `inject_pairs(PAIRS)` ONCE after `from core.config import PAIRS`.
"""
from __future__ import annotations
from typing import List, Dict

# Extra pairs (id > 18 to avoid collision with engine's built-in 1..18)
# Format mirrors engine/_engine.py:PAIRS  ({"id":N, "symbol":"X-USD", "name":"..."})
EXTRA_PAIRS: List[Dict] = [
    # DeFi / Layer-1s
    {"id": 19, "symbol": "UNI-USD",   "name": "Uniswap"},
    {"id": 20, "symbol": "AAVE-USD",  "name": "Aave"},
    {"id": 21, "symbol": "ALGO-USD",  "name": "Algorand"},
    {"id": 22, "symbol": "FIL-USD",   "name": "Filecoin"},
    {"id": 23, "symbol": "ICP-USD",   "name": "Internet Computer"},
    {"id": 24, "symbol": "VET-USD",   "name": "VeChain"},
    {"id": 25, "symbol": "SAND-USD",  "name": "The Sandbox"},
    {"id": 26, "symbol": "MANA-USD",  "name": "Decentraland"},
    {"id": 27, "symbol": "AXS-USD",   "name": "Axie Infinity"},
    {"id": 28, "symbol": "FTM-USD",   "name": "Fantom"},
    {"id": 29, "symbol": "GRT-USD",   "name": "The Graph"},
    {"id": 30, "symbol": "EGLD-USD",  "name": "MultiversX"},
    {"id": 31, "symbol": "HBAR-USD",  "name": "Hedera"},
    {"id": 32, "symbol": "FLOW-USD",  "name": "Flow"},
    {"id": 33, "symbol": "XLM-USD",   "name": "Stellar"},
    {"id": 34, "symbol": "XTZ-USD",   "name": "Tezos"},
    {"id": 35, "symbol": "EOS-USD",   "name": "EOS"},
    {"id": 36, "symbol": "MKR-USD",   "name": "Maker"},
    {"id": 37, "symbol": "COMP-USD",  "name": "Compound"},
    {"id": 38, "symbol": "SUSHI-USD", "name": "SushiSwap"},
    {"id": 39, "symbol": "CRV-USD",   "name": "Curve"},
    {"id": 40, "symbol": "YFI-USD",   "name": "yearn.finance"},
    {"id": 41, "symbol": "SNX-USD",   "name": "Synthetix"},
    {"id": 42, "symbol": "1INCH-USD", "name": "1inch"},
    {"id": 43, "symbol": "DYDX-USD",  "name": "dYdX"},
    {"id": 44, "symbol": "GMX-USD",   "name": "GMX"},
    {"id": 45, "symbol": "RUNE-USD",  "name": "THORChain"},
    {"id": 46, "symbol": "INJ-USD",   "name": "Injective"},
    {"id": 47, "symbol": "SUI-USD",   "name": "Sui"},
    {"id": 48, "symbol": "APT-USD",   "name": "Aptos"},
    {"id": 49, "symbol": "SEI-USD",   "name": "Sei"},
    {"id": 50, "symbol": "TIA-USD",   "name": "Celestia"},
    {"id": 51, "symbol": "STRK-USD",  "name": "Starknet"},
    {"id": 52, "symbol": "JTO-USD",   "name": "Jito"},
    {"id": 53, "symbol": "PYTH-USD",  "name": "Pyth Network"},
    {"id": 54, "symbol": "JUP-USD",   "name": "Jupiter"},
    {"id": 55, "symbol": "WLD-USD",   "name": "Worldcoin"},
    {"id": 56, "symbol": "ORDI-USD",  "name": "ORDI"},
    {"id": 57, "symbol": "ENS-USD",   "name": "Ethereum Name Service"},
    {"id": 58, "symbol": "LDO-USD",   "name": "Lido DAO"},
    {"id": 59, "symbol": "RPL-USD",   "name": "Rocket Pool"},
    {"id": 60, "symbol": "STX-USD",   "name": "Stacks"},

    # Memes
    {"id": 61, "symbol": "PEPE-USD",  "name": "Pepe"},
    {"id": 62, "symbol": "WIF-USD",   "name": "dogwifhat"},
    {"id": 63, "symbol": "BONK-USD",  "name": "Bonk"},
    {"id": 64, "symbol": "FLOKI-USD", "name": "Floki"},
    {"id": 65, "symbol": "BOME-USD",  "name": "Book of Meme"},

    # Privacy / payments
    {"id": 66, "symbol": "XMR-USD",   "name": "Monero"},
    {"id": 67, "symbol": "ZEC-USD",   "name": "Zcash"},
    {"id": 68, "symbol": "DASH-USD",  "name": "Dash"},
    {"id": 69, "symbol": "BCH-USD",   "name": "Bitcoin Cash"},
    {"id": 70, "symbol": "ETC-USD",   "name": "Ethereum Classic"},
    {"id": 71, "symbol": "BSV-USD",   "name": "Bitcoin SV"},

    # Misc large caps
    {"id": 72, "symbol": "QNT-USD",   "name": "Quant"},
    {"id": 73, "symbol": "RNDR-USD",  "name": "Render"},
    {"id": 74, "symbol": "FET-USD",   "name": "Fetch.ai"},
    {"id": 75, "symbol": "AGIX-USD",  "name": "SingularityNET"},
    {"id": 76, "symbol": "OCEAN-USD", "name": "Ocean Protocol"},
    {"id": 77, "symbol": "IMX-USD",   "name": "Immutable X"},
    {"id": 78, "symbol": "GALA-USD",  "name": "Gala"},
    {"id": 79, "symbol": "CHZ-USD",   "name": "Chiliz"},
    {"id": 80, "symbol": "ENJ-USD",   "name": "Enjin Coin"},
    {"id": 81, "symbol": "BAT-USD",   "name": "Basic Attention Token"},
    {"id": 82, "symbol": "ZIL-USD",   "name": "Zilliqa"},
    {"id": 83, "symbol": "IOTA-USD",  "name": "IOTA"},
    {"id": 84, "symbol": "NEO-USD",   "name": "NEO"},
    {"id": 85, "symbol": "WAVES-USD", "name": "Waves"},
    {"id": 86, "symbol": "KSM-USD",   "name": "Kusama"},
    {"id": 87, "symbol": "ROSE-USD",  "name": "Oasis Network"},
    {"id": 88, "symbol": "ZRX-USD",   "name": "0x"},
    {"id": 89, "symbol": "ANKR-USD",  "name": "Ankr"},
    {"id": 90, "symbol": "BAND-USD",  "name": "Band Protocol"},
    {"id": 91, "symbol": "REN-USD",   "name": "Ren"},
    {"id": 92, "symbol": "STORJ-USD", "name": "Storj"},
    {"id": 93, "symbol": "OMG-USD",   "name": "OMG Network"},
    {"id": 94, "symbol": "KAVA-USD",  "name": "Kava"},
    {"id": 95, "symbol": "CELO-USD",  "name": "Celo"},
    {"id": 96, "symbol": "GLMR-USD",  "name": "Moonbeam"},
    {"id": 97, "symbol": "ASTR-USD",  "name": "Astar"},
    {"id": 98, "symbol": "ID-USD",    "name": "Space ID"},
    {"id": 99, "symbol": "BLUR-USD",  "name": "Blur"},
    {"id": 100,"symbol": "ARKM-USD",  "name": "Arkham"},
    {"id": 101,"symbol": "MEME-USD",  "name": "Memecoin"},
    {"id": 102,"symbol": "DOGS-USD",  "name": "Dogs"},
    {"id": 103,"symbol": "NOT-USD",   "name": "Notcoin"},
    {"id": 104,"symbol": "HMSTR-USD", "name": "Hamster Kombat"},
    {"id": 105,"symbol": "TON-USD",   "name": "Toncoin"},
    {"id": 106,"symbol": "KAS-USD",   "name": "Kaspa"},
    {"id": 107,"symbol": "RAY-USD",   "name": "Raydium"},
    {"id": 108,"symbol": "OP-USD-2",  "name": "Optimism (alt)"},  # placeholder
]


def inject_pairs(PAIRS: list) -> list:
    """Append EXTRA_PAIRS to the engine's PAIRS list in-place (idempotent)."""
    have = {p["id"] for p in PAIRS}
    for p in EXTRA_PAIRS:
        if p["id"] not in have:
            PAIRS.append(p)
    return PAIRS


def has_ccxt() -> bool:
    try:
        import ccxt  # noqa
        return True
    except Exception:
        return False


def probe_pair_available(symbol: str) -> tuple[bool, str]:
    """Quick check: is `symbol` actually fetchable?
    Returns (ok, source) where source is one of: 'ccxt', 'yahoo', 'none'."""
    # 1. CCXT — check major exchanges
    if has_ccxt():
        try:
            import ccxt
            base = symbol.replace("-USD", "")
            for ex_name in ("binance", "bybit", "okx", "kucoin"):
                try:
                    ex = getattr(ccxt, ex_name)({"enableRateLimit": True, "timeout": 10000})
                    markets = ex.load_markets()
                    for q in ("USDT", "USD", "USDC", "BUSD"):
                        if f"{base}/{q}" in markets:
                            return True, f"ccxt:{ex_name}"
                except Exception:
                    continue
        except Exception:
            pass
    # 2. Yahoo fallback (only majors really work)
    try:
        import yfinance as yf
        t = yf.Ticker(symbol)
        h = t.history(period="5d", interval="1h")
        if h is not None and len(h) > 0:
            return True, "yahoo"
    except Exception:
        pass
    return False, "none"
