"""
checkpoint.py — Resumable training state.

After every model finishes training, we push a tiny checkpoint to storage
so the next run can resume exactly where we left off. The checkpoint
records WHICH models for WHICH (pair, tf) direction have completed.

Schema saved at  data/checkpoints/<symbol>_<tf>.json :

{
  "symbol": "SOL-USD",
  "tf_label": "30m",
  "started_at": "...",
  "last_update": "...",
  "stages": {
      "fetch_data":          {"done": true,  "at": "..."},
      "indicators":          {"done": true,  "at": "..."},
      "advanced_features":   {"done": true,  "at": "..."},
      "structure":           {"done": true,  "at": "..."},
      "long_committee":      {"done": false, "models_done": ["lr","knn","et"],
                              "models_total": 9, "at": "..."},
      "short_committee":     {"done": false, ...},
      "long_dl":             {"done": false, "models_done": [...]},
      "short_dl":            {"done": false, ...},
      "specialized_nns":     {"done": false, "models_done": ["price_reg","rl_agent"]},
      "stacker":             {"done": false},
      "save_dashboard":      {"done": false},
  },
  "verdict":   "TRAIN_INCOMPLETE | FAST_MODE_READY | NOT_STARTED"
}

`run.py` uses this to decide the menu options dynamically.
"""
from __future__ import annotations
from typing import Dict, List, Optional
import datetime
from .storage import STORE


def _key(symbol: str, tf_label: str) -> str:
    return f"checkpoints/{symbol.replace('-','_')}_{tf_label}"


STAGES = [
    ("fetch_data",        "Fetch candles"),
    ("indicators",        "Indicators + macro"),
    ("advanced_features", "Advanced features (Prophet/OFI/OB/Funding/Liq)"),
    ("structure",         "Market structure (SR/OB/FVG/BOS)"),
    ("long_committee",    "LONG classical ML (8 models)"),
    ("short_committee",   "SHORT classical ML (8 models)"),
    ("long_dl",           "LONG deep learning (14 architectures)"),
    ("short_dl",          "SHORT deep learning (14 architectures)"),
    ("specialized_nns",   "PriceReg + RL + Sentiment + Regime NN"),
    ("stacker",           "Meta-LR stacker"),
    ("save_dashboard",    "Build dashboard JSON + final verdict"),
]


def load(symbol: str, tf_label: str) -> Dict:
    """Returns the current checkpoint (or a fresh empty one)."""
    ck = STORE.get_json(_key(symbol, tf_label))
    if ck is None or ck.get("deleted"):
        return _new(symbol, tf_label)
    # Migrate old/incomplete schemas
    if "stages" not in ck:
        ck = _new(symbol, tf_label)
    return ck


def save(ck: Dict) -> bool:
    """Push the checkpoint to storage."""
    ck["last_update"] = datetime.datetime.utcnow().isoformat() + "Z"
    return STORE.put_json(_key(ck["symbol"], ck["tf_label"]), ck,
                           message=f"checkpoint {ck['symbol']} {ck['tf_label']}")


def _new(symbol: str, tf_label: str) -> Dict:
    return {
        "symbol":      symbol,
        "tf_label":    tf_label,
        "started_at":  datetime.datetime.utcnow().isoformat() + "Z",
        "last_update": datetime.datetime.utcnow().isoformat() + "Z",
        "stages":      {name: {"done": False} for name, _ in STAGES},
        "verdict":     "NOT_STARTED",
    }


def mark_done(ck: Dict, stage: str, extra: Optional[Dict] = None) -> Dict:
    if stage not in [s[0] for s in STAGES]:
        return ck
    ck["stages"][stage] = {
        "done": True,
        "at":   datetime.datetime.utcnow().isoformat() + "Z",
        **(extra or {}),
    }
    # Update overall verdict
    n_done = sum(1 for s in ck["stages"].values() if s.get("done"))
    if n_done == len(STAGES):
        ck["verdict"] = "FAST_MODE_READY"
    elif n_done > 0:
        ck["verdict"] = "TRAIN_INCOMPLETE"
    save(ck)
    return ck


def is_complete(ck: Dict) -> bool:
    return ck.get("verdict") == "FAST_MODE_READY"


def progress_summary(ck: Dict) -> str:
    """Short text like '7/11 stages done — pending: short_dl, stacker, save_dashboard'"""
    done = [s for s, v in ck["stages"].items() if v.get("done")]
    pending = [s for s, v in ck["stages"].items() if not v.get("done")]
    if not pending:
        return f"✅ Complete ({len(done)}/{len(STAGES)})"
    return f"{len(done)}/{len(STAGES)} done · pending: {', '.join(pending[:3])}{'…' if len(pending)>3 else ''}"


def list_all_pending() -> List[Dict]:
    """Scan storage for any incomplete training jobs."""
    pending = []
    for path in STORE.list("data/checkpoints"):
        key = path.replace("data/", "").replace(".json", "")
        if key.startswith("checkpoints/"):
            ck = STORE.get_json(key)
            if ck and not ck.get("deleted") and ck.get("verdict") == "TRAIN_INCOMPLETE":
                pending.append(ck)
    return pending


def list_all_ready() -> List[Dict]:
    """All (pair, tf) combos that have completed training."""
    ready = []
    for path in STORE.list("data/checkpoints"):
        key = path.replace("data/", "").replace(".json", "")
        if key.startswith("checkpoints/"):
            ck = STORE.get_json(key)
            if ck and not ck.get("deleted") and ck.get("verdict") == "FAST_MODE_READY":
                ready.append(ck)
    return ready


def reset(symbol: str, tf_label: str) -> bool:
    """Wipe the checkpoint (used for force retrain)."""
    return STORE.put_json(_key(symbol, tf_label),
                          _new(symbol, tf_label),
                          message=f"reset checkpoint {symbol} {tf_label}")
