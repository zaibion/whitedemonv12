"""
trade_quality_ai.py — V12.2 Trade Outcome Learning
Learns: "Which WhiteDemon signals actually become winning trades?"
Feedback loop from real trading → continuously improves signal quality
"""

from __future__ import annotations
import json, time, os
from typing import Dict, Any, List
import numpy as np

try:
    from core.storage import Storage
    HAS_STORAGE = True
except Exception:
    HAS_STORAGE = False

TRADE_LOG_KEY = "institutional/trade_outcomes_v12.json"

class TradeQualityAI:
    """Online Bayesian signal quality learner"""
    def __init__(self):
        self.trades: List[Dict[str, Any]] = []
        self._load()
    
    def _load(self):
        try:
            if HAS_STORAGE:
                s = Storage()
                d = s.get_json(TRADE_LOG_KEY)
                if d and "trades" in d:
                    self.trades = d["trades"][-5000:]  # last 5k
        except Exception:
            pass
        # local fallback
        try:
            if os.path.exists("trade_outcomes_local.json"):
                with open("trade_outcomes_local.json") as f:
                    self.trades = json.load(f).get("trades", [])[-5000:]
        except Exception:
            pass

    def _save(self):
        payload = {"trades": self.trades[-5000:], "updated": int(time.time()), "version": "v12.2"}
        try:
            if HAS_STORAGE:
                from core.storage import Storage
                Storage().put_json(TRADE_LOG_KEY, payload, message="trade outcome update")
        except Exception:
            pass
        try:
            with open("trade_outcomes_local.json","w") as f:
                json.dump(payload, f)
        except Exception:
            pass

    def record_outcome(self, trade: Dict[str, Any]):
        """
        trade = {
          symbol, direction, entry_price, exit_price,
          entry_time, exit_time,
          stack_bull, meta_prob_live, pass_winrate,
          regime, confidence,
          outcome: "WIN"/"LOSS",
          pnl_pct, rr_achieved,
          features: {...} optional
        }
        """
        t = dict(trade)
        t["ts"] = int(time.time())
        self.trades.append(t)
        # keep last 5000
        if len(self.trades) > 5000:
            self.trades = self.trades[-5000:]
        self._save()
        return True

    def quality_score(self, signal: Dict[str, Any]) -> Dict[str, Any]:
        """Return learned quality adjustment for a live signal"""
        if not self.trades:
            return {"quality_adj": 1.0, "n_similar": 0, "learned_winrate": None}
        # simple kNN-like: find similar historical signals
        # compare: stack_bull, meta_prob, regime, symbol
        sb = float(signal.get("stack_bull", signal.get("meta_prob_live", 0.5)))
        mp = float(signal.get("meta_prob_live", 0.5))
        regime = str(signal.get("regime", signal.get("drift_level","ok")))
        sym = str(signal.get("symbol", signal.get("direction","?")))[:12]
        # score similarity
        sims = []
        for tr in self.trades[-800:]:  # recent 800
            ds = abs(float(tr.get("stack_bull",0.5)) - sb)
            dm = abs(float(tr.get("meta_prob_live",0.5)) - mp)
            # regime bonus
            r_bonus = 0 if str(tr.get("regime","")) == regime else 0.15
            # symbol bonus
            s_bonus = 0 if str(tr.get("symbol","")).startswith(sym[:3]) else 0.1
            dist = ds + dm + r_bonus + s_bonus
            sims.append((dist, 1 if tr.get("outcome")=="WIN" else 0, tr.get("pnl_pct",0)))
        sims.sort(key=lambda x: x[0])
        k = min(40, len(sims))
        top = sims[:k]
        if not top:
            return {"quality_adj":1.0,"n_similar":0,"learned_winrate":None}
        wins = sum(x[1] for x in top)
        wr = wins / len(top)
        avg_pnl = float(np.mean([x[2] for x in top]))
        # quality_adj: scale 0.5 .. 1.3
        # baseline expected 0.68
        adj = float(np.clip(0.5 + (wr - 0.5)*1.6, 0.5, 1.3))
        return {
            "quality_adj": round(adj,3),
            "learned_winrate": round(wr,4),
            "learned_pnl": round(avg_pnl,4),
            "n_similar": k,
            "regime": regime,
        }

    def performance_by_bucket(self) -> Dict[str, Any]:
        """Live performance analytics by regime / confidence / session"""
        if not self.trades:
            return {"available": False}
        import pandas as pd
        df = pd.DataFrame(self.trades)
        out = {}
        # by regime
        if "regime" in df.columns:
            rg = df.groupby("regime")["outcome"].apply(lambda s: (s=="WIN").mean().round(3).item() if len(s) else None)
            out["by_regime"] = rg.to_dict()
        # by confidence bucket
        if "meta_prob_live" in df.columns:
            df["conf_bucket"] = pd.cut(df["meta_prob_live"].fillna(0.5), bins=[0,0.60,0.68,0.75,1.0], labels=["low","mid","high","elite"])
            cb = df.groupby("conf_bucket", observed=False)["outcome"].apply(lambda s: round((s=="WIN").mean(),3) if len(s) else None)
            out["by_confidence"] = {str(k):v for k,v in cb.to_dict().items() if v==v}
        # by hour (session)
        if "entry_time" in df.columns:
            try:
                hrs = pd.to_datetime(df["entry_time"], errors="coerce").dt.hour
                df["hour"] = hrs
                hb = df.groupby("hour")["outcome"].apply(lambda s: round((s=="WIN").mean(),3) if len(s)>4 else None)
                out["by_hour"] = {int(k):v for k,v in hb.dropna().to_dict().items()}
            except Exception:
                pass
        # overall
        total = len(df)
        wins = (df["outcome"]=="WIN").sum()
        out.update({
            "available": True,
            "n_trades": int(total),
            "winrate": round(float(wins/max(1,total)),4),
            "avg_pnl": round(float(df.get("pnl_pct", pd.Series([0])).mean()),4),
            "profit_factor": "calc_live",
            "last_update": int(time.time()),
            "version": "TQAI-v12.2"
        })
        return out

# singleton
_tqai = TradeQualityAI()
def get_tqai() -> TradeQualityAI:
    return _tqai
