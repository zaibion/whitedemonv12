"""Rejected trade logging (V10.2).

Stores blocked/watch setups so later we can analyze whether filters are too strict
or correctly blocking losers.
"""
from __future__ import annotations
from typing import Dict, Any
import json, datetime, os

LOG_PATH = "rejected_trades.jsonl"


def log_rejected_trade(record: Dict[str, Any]) -> Dict[str, Any]:
    rec = {
        "ts": datetime.datetime.utcnow().isoformat() + "Z",
        **(record or {}),
    }
    try:
        with open(LOG_PATH, "a") as f:
            f.write(json.dumps(rec, default=str) + "\n")
    except Exception:
        pass
    return rec
