"""
backtest_checkpoint.py — Save backtest progress per fold.

After each fold completes, dump fold_results + all_trades_global to
storage at key `backtest_ck_<SYMBOL>_<TF>`. On startup the backtest
script looks for this key and asks the user: resume or restart.
"""
from __future__ import annotations
from typing import Dict, List, Optional
import datetime

from core.storage import STORE


def _key(sym: str, tf: str) -> str:
    return f"backtest_ck_{sym.replace('-','_')}_{tf}"


def save(sym: str, tf: str,
          completed_fold_ids: List[int],
          fold_results: List[Dict],
          all_trades: List[Dict],
          total_folds: int,
          args_dict: Dict) -> bool:
    payload = {
        "symbol":              sym,
        "tf_label":            tf,
        "completed_fold_ids":  completed_fold_ids,
        "fold_results":        fold_results,
        "all_trades":          all_trades,
        "total_folds":         total_folds,
        "args":                args_dict,
        "last_update":         datetime.datetime.utcnow().isoformat() + "Z",
    }
    try:
        return STORE.put_json(_key(sym, tf), payload,
                              message=f"backtest checkpoint {sym}/{tf}")
    except Exception as e:
        print(f"  [bt-ckpt] save failed: {e}")
        return False


def load(sym: str, tf: str) -> Optional[Dict]:
    try:
        return STORE.get_json(_key(sym, tf))
    except Exception:
        return None


def reset(sym: str, tf: str) -> bool:
    """Wipe checkpoint by writing an empty marker (idempotent)."""
    try:
        return STORE.put_json(_key(sym, tf), {"completed_fold_ids": [],
                                                "fold_results": [],
                                                "all_trades": [],
                                                "deleted": True})
    except Exception:
        return False
