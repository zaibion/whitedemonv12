"""
v100.1 — Professional Progress & Keepalive Reporter
Prints status every 30 seconds during long operations (DL training, etc.)
"""
import time
import threading
from datetime import datetime, timedelta

class ProgressReporter:
    def __init__(self, interval=30):
        self.interval = interval
        self._stop = False
        self._thread = None
        self.current_task = "Initializing..."
        self.start_time = time.time()
        self.eta_seconds = None

    def set_task(self, task: str, eta_seconds: int = None):
        self.current_task = task
        self.eta_seconds = eta_seconds

    def _print_status(self):
        elapsed = int(time.time() - self.start_time)
        eta_str = ""
        if self.eta_seconds:
            remaining = max(0, self.eta_seconds - elapsed)
            eta_str = f" · ETA {timedelta(seconds=remaining)}"

        print(f"\n[PROGRESS v100.1] {datetime.now().strftime('%H:%M:%S')} | "
              f"{self.current_task} | "
              f"Elapsed: {timedelta(seconds=elapsed)}{eta_str} | "
              f"Still working...")

    def _run(self):
        while not self._stop:
            time.sleep(self.interval)
            if not self._stop:
                self._print_status()

    def start(self):
        if self._thread is None:
            self._thread = threading.Thread(target=self._run, daemon=True)
            self._thread.start()
            print("[PROGRESS v100.1] Status reporter started (every 30s)")

    def stop(self):
        self._stop = True
        if self._thread:
            self._thread.join(timeout=2)

# Global instance
reporter = ProgressReporter(interval=30)
