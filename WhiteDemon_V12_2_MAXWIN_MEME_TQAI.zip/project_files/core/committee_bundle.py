"""Full committee inference bundles (V9.7).

Purpose: FAST MODE should use trained model objects + saved scaler/features, not
just accuracy metadata. This module saves/loads a full classical committee bundle
and can run latest-candle inference without retraining.
"""
from __future__ import annotations
from typing import Any, Dict, Optional, Tuple
import gzip, pickle, time
import numpy as np
import pandas as pd

from core.storage import STORE

BUNDLE_VERSION = "v10.3_z1_point_in_time_hardened_bundle"


def _similarity_check(profile: Dict[str, Any], x_scaled: np.ndarray) -> Dict[str, Any]:
    """Compare current live state to historical winning vs losing states."""
    try:
        if not profile:
            return {"available": False, "reason": "no similarity profile in bundle"}
        win_med = np.asarray(profile.get("win_median"), dtype=np.float32)
        loss_med = np.asarray(profile.get("loss_median"), dtype=np.float32)
        mad = np.asarray(profile.get("win_mad"), dtype=np.float32)
        x = np.asarray(x_scaled, dtype=np.float32).reshape(-1)
        n = min(len(x), len(win_med), len(loss_med), len(mad))
        if n < 5:
            return {"available": False, "reason": "profile dimension mismatch"}
        mad = np.where(np.abs(mad[:n]) < 1e-3, 1.0, mad[:n])
        win_z = np.clip(np.abs((x[:n] - win_med[:n]) / mad), 0, 8)
        loss_z = np.clip(np.abs((x[:n] - loss_med[:n]) / mad), 0, 8)
        win_dist = float(np.nanmean(win_z))
        loss_dist = float(np.nanmean(loss_z))
        # Higher is better: close to winners, far from losers.
        similarity_score = float(1.0 / (1.0 + win_dist))
        advantage = float(loss_dist - win_dist)
        closer = "WINNERS" if win_dist <= loss_dist else "LOSERS"
        return {
            "available": True,
            "similarity_score": round(similarity_score, 4),
            "winner_distance": round(win_dist, 4),
            "loser_distance": round(loss_dist, 4),
            "winner_vs_loser_advantage": round(advantage, 4),
            "closer_to": closer,
            "n_features": int(n),
            "n_win_profile": int(profile.get("n_win", 0) or 0),
            "n_loss_profile": int(profile.get("n_loss", 0) or 0),
        }
    except Exception as e:
        return {"available": False, "reason": str(e)[:160]}





def _expected_n(obj: Any) -> int | None:
    """Best-effort expected feature count for sklearn scalers/models."""
    try:
        n = getattr(obj, "n_features_in_", None)
        if n is not None:
            return int(n)
    except Exception:
        pass
    try:
        n = getattr(obj, "n_features_", None)
        if n is not None:
            return int(n)
    except Exception:
        pass
    return None


def _align_matrix(X: np.ndarray, n_expected: int | None, *, label: str = "features") -> np.ndarray:
    """Pad/truncate feature matrix to an object's saved feature count.

    Backtests can load older bundles where the scaler/model was fit with one
    extra feature (e.g. 44) while current live feature builder emits 43.
    Instead of crashing the whole backtest, align safely and keep an audit note
    in caller logs/metadata. Missing columns are neutral zeros after feature
    engineering/scaling context; extra columns are truncated.
    """
    X = np.asarray(X, dtype=np.float32)
    if X.ndim == 1:
        X = X.reshape(1, -1)
    if not n_expected or n_expected <= 0 or X.shape[1] == n_expected:
        return X
    if X.shape[1] > n_expected:
        return X[:, :n_expected].astype(np.float32)
    pad = np.zeros((X.shape[0], n_expected - X.shape[1]), dtype=np.float32)
    return np.concatenate([X, pad], axis=1).astype(np.float32)


def _safe_transform(scaler: Any, X: np.ndarray) -> np.ndarray:
    n = _expected_n(scaler)
    return scaler.transform(_align_matrix(X, n, label="scaler")).astype(np.float32)


def _safe_predict_proba(mdl: Any, X: np.ndarray):
    n = _expected_n(mdl)
    return mdl.predict_proba(_align_matrix(X, n, label="model"))

def _norm_regime_name(x: Any) -> str:
    txt = str(x or "UNKNOWN").upper()
    if "LOW" in txt and "VOL" in txt:
        return "LOW_VOL"
    if "VOL" in txt:
        return "VOLATILE"
    if "TREND" in txt or "UP" in txt or "DOWN" in txt:
        return "TRENDING"
    if "RANG" in txt or "CHOP" in txt or "UNCLEAR" in txt:
        return "RANGING"
    return txt or "UNKNOWN"


def _analog_pattern_check(bundle: Dict[str, Any], x_scaled: np.ndarray, k: int = 200,
                          *, current_time: Any = None,
                          current_regime: str | None = None) -> Dict[str, Any]:
    """Point-in-time nearest-neighbor analog check (WhiteDemon Z.1).

    Safeguards added vs V10.1:
      * optional strict as-of filtering using saved reference timestamps
      * optional same-regime filtering using saved reference regimes
      * distance + recency weighting
      * configurable metric: euclidean / cosine / mahalanobis_diag

    This asks: among historical training states that were actually available
    before the decision time and in the same regime, how often did this
    direction's execution-aligned/triple-barrier label win?
    """
    try:
        Xref = bundle.get("reference_X_sc")
        yref = bundle.get("reference_y")
        if Xref is None or yref is None:
            return {"available": False, "reason": "no training reference matrix in bundle"}
        Xref = np.asarray(Xref, dtype=np.float32)
        yref = np.asarray(yref, dtype=np.float32).reshape(-1)
        x = np.asarray(x_scaled, dtype=np.float32).reshape(1, -1)
        n_feat = min(Xref.shape[1], x.shape[1])
        n_rows = min(Xref.shape[0], yref.shape[0])
        if n_rows < 100 or n_feat < 5:
            return {"available": False, "reason": "insufficient reference rows/features"}

        valid_mask = np.ones(n_rows, dtype=bool)
        rows_before_time = None
        rows_same_regime = None

        # 1) Point-in-time as-of filter.
        tref = bundle.get("reference_time_ns")
        cutoff_ns = None
        if tref is not None and current_time is not None and bool(bundle.get("reference_time_valid", True)):
            try:
                tref = np.asarray(tref, dtype=np.int64).reshape(-1)[:n_rows]
                cur_ns = int(pd.Timestamp(current_time).tz_convert("UTC").value
                             if pd.Timestamp(current_time).tzinfo else
                             pd.Timestamp(current_time).tz_localize("UTC").value)
                hbars = int(bundle.get("reference_horizon_bars", 0) or 0)
                bar_sec = float(bundle.get("reference_bar_seconds", 0.0) or 0.0)
                embargo_ns = int(max(0.0, hbars * bar_sec) * 1_000_000_000)
                cutoff_ns = cur_ns - embargo_ns
                valid_mask &= (tref < cutoff_ns)
                rows_before_time = int(valid_mask.sum())
            except Exception:
                cutoff_ns = None

        # 2) Same-regime filter.
        rref = bundle.get("reference_regime")
        strict_regime = bool(bundle.get("analog_strict_regime", True))
        cur_reg_norm = _norm_regime_name(current_regime)
        if strict_regime and rref is not None and current_regime is not None:
            try:
                rref = np.asarray(rref, dtype=object).reshape(-1)[:n_rows]
                rnorm = np.asarray([_norm_regime_name(v) for v in rref], dtype=object)
                same = (rnorm == cur_reg_norm)
                rows_same_regime = int((valid_mask & same).sum())
                valid_mask &= same
            except Exception:
                rows_same_regime = None

        kept = int(valid_mask.sum())
        min_needed = int(max(100, min(k, n_rows)))
        if kept < min_needed:
            return {
                "available": False,
                "reason": f"insufficient point-in-time/same-regime analogs ({kept} < {min_needed})",
                "reference_rows": int(n_rows),
                "rows_after_time_filter": rows_before_time,
                "rows_same_regime": rows_same_regime,
                "current_regime": cur_reg_norm,
                "strict_regime": strict_regime,
            }

        X = np.nan_to_num(Xref[:n_rows, :n_feat][valid_mask], nan=0.0, posinf=0.0, neginf=0.0)
        y = yref[:n_rows][valid_mask]
        xv = np.nan_to_num(x[:, :n_feat], nan=0.0, posinf=0.0, neginf=0.0)

        # 3) Configurable distance metric.
        metric = str(bundle.get("analog_metric", "euclidean") or "euclidean").lower()
        k = int(max(25, min(k, len(y))))
        dists = np.empty(len(y), dtype=np.float32)
        chunk = 50000
        if metric in ("cosine", "cos"):
            xv_norm = xv / (np.linalg.norm(xv, axis=1, keepdims=True) + 1e-9)
            for i in range(0, len(y), chunk):
                Xi = X[i:i+chunk]
                Xi = Xi / (np.linalg.norm(Xi, axis=1, keepdims=True) + 1e-9)
                dists[i:i+chunk] = (1.0 - np.sum(Xi * xv_norm, axis=1)).astype(np.float32)
        elif metric in ("mahalanobis", "mahalanobis_diag", "diag_mahalanobis"):
            # Diagonal Mahalanobis in scaled feature space = variance-normalized
            # Euclidean. Full covariance inverse is avoided for stability/memory.
            var = np.nanvar(X, axis=0).astype(np.float32)
            var = np.where(var < 1e-6, 1.0, var)
            for i in range(0, len(y), chunk):
                diff = X[i:i+chunk] - xv
                dists[i:i+chunk] = np.mean((diff * diff) / var[None, :], axis=1)
        else:
            metric = "euclidean"
            for i in range(0, len(y), chunk):
                diff = X[i:i+chunk] - xv
                dists[i:i+chunk] = np.mean(diff * diff, axis=1)

        idx = np.argpartition(dists, k-1)[:k]
        nn_y = y[idx]
        nn_d = dists[idx]

        # 4) Distance + recency weighting.
        w = 1.0 / (np.sqrt(np.maximum(nn_d, 0.0)) + 1e-6)
        recency_used = False
        half_life_days = float(bundle.get("analog_recency_half_life_days", 365.0) or 365.0)
        if tref is not None and current_time is not None and half_life_days > 0 and bool(bundle.get("reference_time_valid", True)):
            try:
                # Map filtered timestamps to the filtered X/y rows, then nearest idx.
                tref_all = np.asarray(bundle.get("reference_time_ns"), dtype=np.int64).reshape(-1)[:n_rows]
                tref_kept = tref_all[valid_mask]
                cur_ns = int(pd.Timestamp(current_time).tz_convert("UTC").value
                             if pd.Timestamp(current_time).tzinfo else
                             pd.Timestamp(current_time).tz_localize("UTC").value)
                age_days = np.maximum(0.0, (cur_ns - tref_kept[idx]).astype(np.float64) / 86_400_000_000_000.0)
                rw = np.power(0.5, age_days / half_life_days)
                w = w * rw.astype(np.float32)
                recency_used = True
            except Exception:
                recency_used = False
        w = w / max(1e-12, float(w.sum()))
        analog_wr = float(np.sum(w * nn_y))
        unweighted_wr = float(np.mean(nn_y))
        return {
            "available": True,
            "k": k,
            "reference_rows": int(n_rows),
            "rows_after_filters": int(kept),
            "rows_after_time_filter": rows_before_time,
            "rows_same_regime": rows_same_regime,
            "reference_features": int(n_feat),
            "analog_win_rate": round(analog_wr, 4),
            "analog_win_rate_unweighted": round(unweighted_wr, 4),
            "nearest_mean_distance": round(float(np.mean(np.sqrt(np.maximum(nn_d, 0.0)))), 4),
            "nearest_min_distance": round(float(np.min(np.sqrt(np.maximum(nn_d, 0.0)))), 4),
            "metric": metric,
            "current_regime": cur_reg_norm,
            "strict_regime": strict_regime,
            "recency_weighted": recency_used,
            "recency_half_life_days": half_life_days,
            "time_cutoff_ns": int(cutoff_ns) if cutoff_ns is not None else None,
        }
    except Exception as e:
        return {"available": False, "reason": str(e)[:160]}

def _rid(sym: str, tf: str, direction: str, count: int) -> str:
    return f"perm/{sym.replace('-','_')}/{tf}/{direction.lower()}/{count}/committee_bundle.pkl.gz"


def save_committee_bundle(sym: str, tf: str, direction: str, count: int, bundle: Dict[str, Any]) -> bool:
    """Save a full inference bundle to GitHub/storage."""
    try:
        payload = dict(bundle)
        payload["bundle_version"] = BUNDLE_VERSION
        payload["saved_at"] = time.time()
        raw = pickle.dumps(payload, protocol=4)
        blob = gzip.compress(raw, compresslevel=5)
        return STORE.put_blob(_rid(sym, tf, direction, count), blob, compress=False,
                              message=f"committee bundle {sym}/{tf}/{direction}/{count}")
    except Exception as e:
        print(f"  [bundle] save failed {direction}: {str(e)[:160]}", flush=True)
        return False


def load_committee_bundle(sym: str, tf: str, direction: str, count: int) -> Optional[Dict[str, Any]]:
    try:
        blob = STORE.get_blob(_rid(sym, tf, direction, count))
        if not blob:
            return None
        try:
            raw = gzip.decompress(blob)
        except OSError:
            raw = blob
        obj = pickle.loads(raw)
        if not isinstance(obj, dict) or obj.get("bundle_version") != BUNDLE_VERSION:
            return None
        return obj
    except Exception as e:
        print(f"  [bundle] load failed {direction}: {str(e)[:160]}", flush=True)
        return None


def infer_committee_bundle(bundle: Dict[str, Any], df: pd.DataFrame, sentiment: float,
                           regime: str = "RANGING", sym: str = None, tf: str = None,
                           count: int = None, include_dl: bool = True) -> Dict[str, Any]:
    """Run latest-candle inference from a saved full committee bundle.

    No training happens here. Uses saved fitted models + saved scaler + saved feature list.
    """
    import _engine as eng

    fitted = bundle.get("fitted", {}) or {}
    needs_sc = bundle.get("needs_sc", {}) or {}
    scaler = bundle.get("scaler")
    feat_list = list(bundle.get("feat_list") or [])
    brier_scores = bundle.get("brier_scores", {}) or {}
    wf_accs = bundle.get("wf_accs", {}) or {}
    direction = bundle.get("direction", "LONG")

    if not fitted or scaler is None or not feat_list:
        raise RuntimeError("bundle missing fitted models/scaler/features")

    full = eng.build_features(df.copy(), sentiment)
    # V11.4: tolerate old bundles/current feature-builder drift. If a saved
    # bundle names a feature no longer emitted, add a neutral column instead
    # of crashing backtest/fast inference with "expecting 44 got 43".
    missing_feats = [f for f in feat_list if f not in full.columns]
    for _f in missing_feats:
        full[_f] = 0.0
    live_rows = full.dropna(subset=feat_list).copy()
    if len(live_rows) == 0:
        raise RuntimeError("no live row with complete bundle features")
    live = live_rows.tail(1)
    Xl_raw = live[feat_list].values.astype(np.float32)

    # Match engine's regime-weighted inference path.
    try:
        rw = eng.get_regime_feature_weights(regime, feat_list)
        Xl_raw_rw = Xl_raw * rw[None, :]
    except Exception:
        Xl_raw_rw = Xl_raw
    Xl_sc_rw = _safe_transform(scaler, Xl_raw_rw)
    try:
        Xl_sc_plain = _safe_transform(scaler, Xl_raw)
    except Exception:
        Xl_sc_plain = Xl_sc_rw
    try:
        _live_time = live["open_time"].iloc[-1] if "open_time" in live.columns else None
    except Exception:
        _live_time = None
    current_similarity = _similarity_check(bundle.get("similarity_profile", {}), Xl_sc_plain[0])
    current_analog = _analog_pattern_check(
        bundle, Xl_sc_plain[0], k=int(bundle.get("analog_k", 200) or 200),
        current_time=_live_time, current_regime=regime)

    # Z.1 feature drift monitor: compare saved scaled training reference with
    # recent live rows transformed by the same saved scaler.
    current_drift = {"available": False, "reason": "not computed"}
    try:
        from core.drift_monitor import compute_feature_drift
        recent_rows = live_rows.tail(int(bundle.get("drift_recent_rows", 500) or 500))
        recent_raw = recent_rows[feat_list].values.astype(np.float32)
        recent_sc = _safe_transform(scaler, recent_raw)
        current_drift = compute_feature_drift(bundle.get("reference_X_sc"), recent_sc, feat_list)
    except Exception as _e:
        current_drift = {"available": False, "reason": str(_e)[:160]}

    preds, probs = {}, {}
    bull_probs_w, weights_w = [], []
    for name, mdl in fitted.items():
        ns = bool(needs_sc.get(name, False))
        Xin = Xl_sc_rw if ns else Xl_raw_rw
        Xin = np.nan_to_num(np.asarray(Xin, dtype=np.float32), nan=0.0, posinf=0.0, neginf=0.0)
        try:
            p1 = float(_safe_predict_proba(mdl, Xin)[0][1])
            pred = int(p1 >= 0.5)
            preds[name] = pred
            probs[name] = p1 if pred == 1 else 1.0 - p1
            bull_probs_w.append(p1)
            bs = float(brier_scores.get(name, 0.25))
            weights_w.append(max(0.001, (0.25 - bs) / 0.25))
        except Exception:
            preds[name] = 0
            probs[name] = 0.5

    if bull_probs_w:
        w = np.asarray(weights_w, dtype=float)
        w = w / max(1e-12, w.sum())
        classical_stack_bull = float(np.average(np.asarray(bull_probs_w), weights=w))
    else:
        classical_stack_bull = 0.5

    # V9.8: also load cached DL state_dicts and run them on the latest 4k-feature sequence.
    # This is inference only; no DL training happens here.
    dl_bull = None
    dl_indiv: Dict[str, float] = {}
    dl_loaded_names = []
    if include_dl and sym and tf and count:
        try:
            import torch
            from core import per_model_cache as pmc
            dl_done = pmc.list_done(sym, tf, direction, int(count)).get("dl", [])
            if dl_done:
                # Force CPU for stable inference: avoids loading 14 nets onto T4 VRAM at once.
                old_dl_enabled = eng.CFG.get("dl_enabled", False)
                eng.CFG["dl_enabled"] = True
                dl_ens = eng.DLEnsemble(len(feat_list))
                dl_ens.device = torch.device("cpu")
                for _m in dl_ens.models.values():
                    try: _m.to("cpu")
                    except Exception: pass
                loaded_models = {}
                idx = pmc.get_index(sym, tf, direction, int(count))
                for name in list(dl_ens.models.keys()):
                    if name not in dl_done:
                        continue
                    model = dl_ens.models[name]
                    loaded = pmc.load_dl(sym, tf, direction, int(count), name, model)
                    if loaded is not None:
                        try: loaded.to("cpu")
                        except Exception: pass
                        loaded_models[name] = loaded
                        meta = idx.get("dl", {}).get(name, {})
                        dl_ens.accs[name] = float(meta.get("acc", 0.5))
                        dl_ens.temperatures[name] = float(meta.get("temp", 1.0))
                eng.CFG["dl_enabled"] = old_dl_enabled
                if loaded_models:
                    dl_ens.models = loaded_models
                    dl_ens.enabled = True
                    full_rows = full.dropna(subset=feat_list).copy()
                    X_all_raw = full_rows[feat_list].values.astype(np.float32)
                    X_all_sc = _safe_transform(scaler, X_all_raw)
                    res = dl_ens.predict_proba_live(X_all_sc)
                    if res is not None:
                        dl_bull, dl_indiv = res
                        dl_loaded_names = list(loaded_models.keys())
                        preds["dl"] = 1 if dl_bull >= 0.5 else 0
                        probs["dl"] = dl_bull if dl_bull >= 0.5 else 1.0 - dl_bull
                        wf_accs = dict(wf_accs)
                        wf_accs["dl"] = round(float(np.mean(list(dl_ens.accs.values()))), 4) if dl_ens.accs else 0.5
        except Exception as e:
            # non-fatal: classical bundle inference remains valid
            dl_bull = None
            dl_indiv = {}

    if dl_bull is not None:
        # Blend classical and DL current predictions. Classical still anchors the stack,
        # DL adds sequence-pattern evidence from the same latest candles.
        model_stack = float(0.65 * classical_stack_bull + 0.35 * float(dl_bull))
    else:
        model_stack = classical_stack_bull

    # Blend in nearest-neighbor analog evidence from all saved training states.
    # This is the "today's weather" check: current features must resemble
    # historical winning states, not just the training baseline.
    if current_analog.get("available"):
        analog_wr = float(current_analog.get("analog_win_rate", 0.5))
        stack_bull = float(0.75 * model_stack + 0.25 * analog_wr)
    else:
        stack_bull = model_stack

    preds["stack"] = 1 if stack_bull >= 0.5 else 0
    probs["stack"] = stack_bull if stack_bull >= 0.5 else 1.0 - stack_bull
    wf_accs = dict(wf_accs)
    wf_accs.setdefault("stack", float(np.mean([v for k, v in wf_accs.items() if isinstance(v, (int, float))])) if wf_accs else 0.5)

    baseline_wr = float(bundle.get("baseline_win_rate", 0.5))
    return {
        "preds": preds,
        "probs": probs,
        "wf_accs": wf_accs,
        "stack_bull": stack_bull,
        "classical_stack_bull": classical_stack_bull,
        "dl_stack_bull": dl_bull,
        "live_edge_over_baseline": float(stack_bull - baseline_wr),
        "current_market_similarity": current_similarity,
        "current_analog_pattern": current_analog,
        "current_feature_drift": current_drift,
        "model_stack_before_analog": model_stack,
        "meta_stack_bull": None,
        "weighted_stack_bull": stack_bull,
        "dl_individual": dl_indiv,
        "n_models": len(preds),
        "baseline_win_rate": baseline_wr,
        "direction": direction,
        "true_bundle_inference": True,
        "metadata_only_probability": False,
        "bundle_version": bundle.get("bundle_version"),
        "feature_count": len(feat_list),
        "missing_bundle_features_filled": missing_feats,
        "scaler_expected_features": _expected_n(scaler),
        "trained_model_names": list(fitted.keys()),
        "dl_loaded_names": dl_loaded_names,
        "all_model_inference_note": "classical bundle + cached DL sequence inference" if dl_loaded_names else "classical bundle only; no cached DL loaded",
    }
