# WhiteDemon V10.4 — Direct Pair CLI + Small Mode Forecast

## 1) Direct run.py pair/timeframe override
You can now run `run.py` directly for a pair/timeframe without manually changing setup first.

Examples:

```bash
python run.py --pair SOL-USDT --tf 15m fast
python run.py --pair SOL-USD --tf 15m analyze
python run.py fast --pair SOL-USDT --tf 15m
```

Note: internally the project uses `SOL-USD`; user input `SOL-USDT` is automatically mapped to `SOL-USD` for crypto exchange fetching.

## 2) Small Mode forecast
Analyze now adds a micro path forecast for the next 3–4 candles under the main setup.

It reports:
- expected path: `DIRECT_UP`, `DIRECT_DOWN`, `PULLBACK_THEN_UP`, `BOUNCE_THEN_DOWN`, or `CHOP_FLAT`
- next 4 candle estimated closes/highs/lows
- percent move from current price
- whether the micro path aligns with the selected setup

Example:

```text
Small mode: possible small pullback (-0.12%) before upside attempt (+0.28% by candle 4). aligns_with_setup=True
```

This is not a separate trade signal. It explains possible near-term path while the main setup is active.

## 3) No retraining required
This update does not change cache/model versioning. Existing V10.3 trained models/bundles remain usable.

## Checks
- compileall passed
- tabnanny passed
- pyflakes syntax/undefined-name scan passed
