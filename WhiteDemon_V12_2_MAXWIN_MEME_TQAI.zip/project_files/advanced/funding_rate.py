"""
Funding rate + open interest features aggregated across multiple exchanges.

Pulls funding rate from each of bybit / bitget / kucoin / okx / gate (for the
perpetual contract of the same coin) and computes:

  • funding_8ex_avg   — mean funding rate across exchanges
  • funding_8ex_skew  — std dev (high = exchange disagreement = uncertainty)
  • funding_max_ex    — highest funding exchange (potential carry trade)
  • oi_change_24h     — 24h % change in aggregated open interest
"""
from __future__ import annotations
from typing import Dict
import time

try:
    import ccxt
    HAS_CCXT = True
except ImportError:
    HAS_CCXT = False


def fetch_funding_features_multi(yahoo_symbol: str,
                                   exchanges: tuple = ("bybit","bitget","kucoinfutures","okx","gate")) -> Dict[str, float]:
    defaults = {
        "funding_8ex_avg":   0.0,
        "funding_8ex_skew":  0.0,
        "funding_max_ex":    "none",
        "funding_max_rate":  0.0,
        "oi_change_24h":     0.0,
        "n_exchanges":       0,
    }
    if not HAS_CCXT:
        return defaults
    base = yahoo_symbol.split("-")[0].upper()
    rates = []
    ex_rates = {}
    for ex_name in exchanges:
        try:
            ex = getattr(ccxt, ex_name)({"timeout": 15000, "enableRateLimit": True,
                                          "options": {"defaultType": "swap"}})
            sym = f"{base}/USDT:USDT"
            try:
                fr = ex.fetch_funding_rate(sym)
                rate = fr.get("fundingRate", 0)
                if rate is not None:
                    rates.append(float(rate))
                    ex_rates[ex_name] = float(rate)
            except Exception:
                pass
        except Exception:
            continue
    if not rates:
        return defaults
    import numpy as np
    avg = float(np.mean(rates))
    skew = float(np.std(rates))
    max_ex = max(ex_rates, key=ex_rates.get)
    return {
        "funding_8ex_avg":   avg,
        "funding_8ex_skew":  skew,
        "funding_max_ex":    max_ex,
        "funding_max_rate":  ex_rates[max_ex],
        "oi_change_24h":     0.0,    # left for future expansion
        "n_exchanges":       len(rates),
    }
