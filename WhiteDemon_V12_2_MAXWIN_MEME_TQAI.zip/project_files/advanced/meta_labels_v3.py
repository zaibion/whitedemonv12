"""
Meta-Labeling v3 (Lopez de Prado, Advances in Financial ML, ch. 3).

Improvements over the v22 in-engine meta-labeler:
  • Uses BOTH triple-barrier outcome AND realised return as side-feature
  • Trains an HGB classifier (better with NaNs + categoricals than the LR in v22)
  • Returns calibrated probability AND confidence band

Drop-in: doesn't replace anything in the engine — it ADDS a feature that
flows into the confluence gate.
"""
from __future__ import annotations
from typing import Optional, Dict
import numpy as np
import pandas as pd

try:
    from sklearn.ensemble import HistGradientBoostingClassifier
    from sklearn.calibration import CalibratedClassifierCV
    from sklearn.preprocessing import RobustScaler
    HAS_SK = True
except ImportError:
    HAS_SK = False


class MetaLabelerV3:
    """Trains on the engine's triple-barrier outcomes + adds proba feature.

    Usage:
        ml = MetaLabelerV3()
        ml.fit(df, triple_barrier_outcomes, FEATURES)
        proba = ml.predict_live(latest_features_row)
    """

    def __init__(self):
        self.model       = None
        self.scaler      = None
        self.calibrated  = None
        self.feature_names = []
        self.ready       = False

    def fit(self, X: np.ndarray, y: np.ndarray,
            sample_weight: Optional[np.ndarray] = None) -> Dict[str, float]:
        if not HAS_SK or len(X) < 200:
            return {"trained": False, "reason": "insufficient data"}
        try:
            self.scaler = RobustScaler()
            Xs = np.nan_to_num(self.scaler.fit_transform(X), nan=0.,
                                posinf=0., neginf=0.)
            y = np.nan_to_num(y.astype(int), nan=0)
            split = int(len(Xs) * 0.80)
            base = HistGradientBoostingClassifier(
                max_iter=120, max_depth=5, learning_rate=0.05,
                class_weight="balanced", random_state=42)
            if split >= 100 and len(Xs) - split >= 50 and len(np.unique(y[split:])) >= 2:
                sw_train = sample_weight[:split] if sample_weight is not None and len(sample_weight) == len(y) else None
                base.fit(Xs[:split], y[:split], sample_weight=sw_train)
                self.model = base
                try:
                    method = "sigmoid" if (len(Xs) - split) < 1000 else "isotonic"
                    self.calibrated = CalibratedClassifierCV(base, method=method, cv="prefit")
                    self.calibrated.fit(Xs[split:], y[split:])
                except Exception:
                    self.calibrated = base
            else:
                base.fit(Xs, y, sample_weight=sample_weight)
                self.model = base
                self.calibrated = base
            self.ready = True
            return {"trained": True, "samples": len(X)}
        except Exception as e:
            return {"trained": False, "reason": str(e)}

    def predict_live(self, X_row: np.ndarray) -> Dict[str, float]:
        if not self.ready or X_row is None or len(X_row) == 0:
            return {"proba": 0.5, "confidence_band": 0.0}
        try:
            X_row = np.asarray(X_row, dtype=np.float32).reshape(1, -1)
            X_row = np.nan_to_num(self.scaler.transform(X_row), nan=0.,
                                    posinf=0., neginf=0.)
            proba = float(self.calibrated.predict_proba(X_row)[0][1])
            # Pseudo-confidence: distance from 0.5
            conf = float(abs(proba - 0.5) * 2)
            return {"proba": proba, "confidence_band": conf}
        except Exception:
            return {"proba": 0.5, "confidence_band": 0.0}
