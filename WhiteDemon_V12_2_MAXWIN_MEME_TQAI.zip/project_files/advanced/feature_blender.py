"""
Blends all advanced features into the engine's standard feature row.

Called by train_all.py and analyze.py just before ML/DL training/inference.
"""
from __future__ import annotations
from typing import Dict, Optional
import pandas as pd

from .prophet_forecaster import prophet_forecast
from .order_flow         import compute_ofi_features
from .orderbook          import fetch_orderbook_imbalance
from .funding_rate       import fetch_funding_features_multi
from .liquidations       import fetch_liquidation_cascade


def blend_advanced_features(df: pd.DataFrame, symbol: str,
                              skip_live: bool = False) -> Dict[str, float]:
    """Compute every advanced feature for the LATEST bar.

    Set skip_live=True during back-tests (since live order book / funding aren't
    available historically).
    """
    feats: Dict[str, float] = {}

    # Prophet — heavy, only call if we have enough data
    feats.update(prophet_forecast(df))

    # OFI from OHLCV
    feats.update(compute_ofi_features(df))

    # Liquidation cascade from OHLCV pattern
    feats.update(fetch_liquidation_cascade(df))

    # Live-only features
    if not skip_live:
        feats.update(fetch_orderbook_imbalance(symbol))
        feats.update(fetch_funding_features_multi(symbol))
    else:
        feats.update({
            "ob_imbalance": 1.0, "ob_depth_ratio": 1.0,
            "ob_spread_bps": 0.0, "ob_source": "skipped",
            "funding_8ex_avg": 0.0, "funding_8ex_skew": 0.0,
            "funding_max_ex": "none", "funding_max_rate": 0.0,
            "oi_change_24h": 0.0, "n_exchanges": 0,
        })

    return feats
