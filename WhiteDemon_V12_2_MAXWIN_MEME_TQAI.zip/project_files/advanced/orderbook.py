"""
Live order-book imbalance from ccxt-supported exchanges.

Pulls the top 20 levels and computes:
  • bid_volume / ask_volume         (>1 = bid-heavy, <1 = ask-heavy)
  • cumulative depth ratio          (within 0.5% of mid)
  • spread (bps)
"""
from __future__ import annotations
from typing import Dict, Optional
import time

try:
    import ccxt
    HAS_CCXT = True
except ImportError:
    HAS_CCXT = False


def fetch_orderbook_imbalance(yahoo_symbol: str,
                                exchanges: tuple = ("bybit", "bitget", "kucoin"),
                                depth: int = 20,
                                near_mid_pct: float = 0.5) -> Dict[str, float]:
    """Returns averaged imbalance across the first responding exchange."""
    defaults = {
        "ob_imbalance":     1.0,    # 1.0 = neutral
        "ob_depth_ratio":   1.0,
        "ob_spread_bps":    0.0,
        "ob_source":        "none",
    }
    if not HAS_CCXT:
        return defaults
    base = yahoo_symbol.split("-")[0].upper()
    for ex_name in exchanges:
        try:
            ex = getattr(ccxt, ex_name)({"timeout": 15000, "enableRateLimit": True})
            ex.load_markets()
            sym = f"{base}/USDT"
            if sym not in ex.markets:
                continue
            ob = ex.fetch_order_book(sym, depth)
            bids = ob.get("bids", [])[:depth]
            asks = ob.get("asks", [])[:depth]
            if not bids or not asks:
                continue
            mid = (bids[0][0] + asks[0][0]) / 2
            spread_bps = (asks[0][0] - bids[0][0]) / mid * 10_000
            bid_vol = sum(b[1] for b in bids)
            ask_vol = sum(a[1] for a in asks)
            imbalance = bid_vol / (ask_vol + 1e-9)
            # Depth ratio near the mid
            near_th = mid * near_mid_pct / 100
            bid_near = sum(b[1] for b in bids if b[0] >= mid - near_th)
            ask_near = sum(a[1] for a in asks if a[0] <= mid + near_th)
            depth_ratio = bid_near / (ask_near + 1e-9)
            return {
                "ob_imbalance":     float(min(max(imbalance,   0.01), 100)),
                "ob_depth_ratio":   float(min(max(depth_ratio, 0.01), 100)),
                "ob_spread_bps":    float(spread_bps),
                "ob_source":        ex_name,
            }
        except Exception:
            continue
    return defaults
