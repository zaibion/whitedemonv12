"""
Facebook Prophet — trend + change-points + seasonality.
Drop-in feature: returns (trend_slope, days_since_changepoint, weekly_seasonality)
for use as additional ML features.

Falls back to neutral values if Prophet isn't installed.
"""
from __future__ import annotations
from typing import Optional, Dict
import warnings

import numpy as np
import pandas as pd

try:
    from prophet import Prophet
    HAS_PROPHET = True
except ImportError:
    HAS_PROPHET = False


def prophet_forecast(df: pd.DataFrame,
                       horizon_bars: int = 24,
                       cap_history: int = 5_000) -> Dict[str, float]:
    """Run Prophet on the closing prices and return key features:

      • prophet_trend       — slope of the trend over last 100 bars (positive = up)
      • prophet_changepoint — bars since the last detected change-point
      • prophet_seasonality — current weekly-seasonality component (-1..+1 normalised)
      • prophet_forecast_24h_pct — projected % change over next `horizon_bars`

    Returns zeros if Prophet isn't installed or fitting fails.
    """
    defaults = {
        "prophet_trend":             0.0,
        "prophet_changepoint":       0.0,
        "prophet_seasonality":       0.0,
        "prophet_forecast_24h_pct":  0.0,
    }
    if not HAS_PROPHET or df is None or len(df) < 500:
        return defaults

    try:
        sub = df.tail(cap_history)[["open_time", "close"]].copy()
        sub.columns = ["ds", "y"]
        sub["ds"] = pd.to_datetime(sub["ds"]).dt.tz_localize(None)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            m = Prophet(
                changepoint_prior_scale=0.1,
                seasonality_prior_scale=2.0,
                interval_width=0.80,
                weekly_seasonality=True,
                daily_seasonality=False,
                yearly_seasonality=False,
            )
            m.fit(sub)
            future = m.make_future_dataframe(periods=horizon_bars, freq="H")
            fcst = m.predict(future)

        # Trend slope over last 100 bars
        trend = fcst["trend"].values
        slope = (trend[-1] - trend[-100]) / max(abs(trend[-100]), 1e-9)

        # Days since last changepoint
        cps = m.changepoints
        last_cp = cps.iloc[-1] if len(cps) else sub["ds"].iloc[0]
        bars_since_cp = (sub["ds"].iloc[-1] - last_cp).total_seconds() / 3600

        # Weekly seasonality (current value)
        ws = fcst["weekly"].iloc[-1] if "weekly" in fcst.columns else 0.0
        seasonality_norm = float(ws / max(abs(fcst["weekly"].std()), 1e-9))

        # 24h forecast % change
        cur = sub["y"].iloc[-1]
        fut = fcst["yhat"].iloc[-1]
        pct = (fut - cur) / cur * 100

        return {
            "prophet_trend":             float(np.clip(slope, -1, 1)),
            "prophet_changepoint":       float(min(bars_since_cp, 720)),  # clamp 30d
            "prophet_seasonality":       float(np.clip(seasonality_norm, -1, 1)),
            "prophet_forecast_24h_pct":  float(np.clip(pct, -20, 20)),
        }
    except Exception as e:
        # Silent: feature engineering must never crash the engine
        return defaults
