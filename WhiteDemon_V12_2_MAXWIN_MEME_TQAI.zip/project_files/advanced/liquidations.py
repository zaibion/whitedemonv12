"""
Liquidation cascade indicator.

Most retail APIs don't expose liquidation feeds directly. We approximate
"liquidation pressure" from the candle pattern:

  Long liquidation cascade  =  high-volume bearish candle with long upper wick
  Short liquidation cascade =  high-volume bullish candle with long lower wick

These map to forced-close moves visible in OHLCV.
"""
from __future__ import annotations
from typing import Dict
import numpy as np
import pandas as pd


def fetch_liquidation_cascade(df: pd.DataFrame, lookback: int = 96) -> Dict[str, float]:
    """Returns scalar features describing recent liquidation pressure."""
    defaults = {
        "liq_long_cascade":  0.0,
        "liq_short_cascade": 0.0,
        "liq_total_24h":     0.0,
        "liq_imbalance":     0.0,    # +ve = more shorts liquidated, -ve = more longs
    }
    if df is None or len(df) < lookback:
        return defaults
    try:
        sub = df.tail(lookback).copy()
        body = (sub["close"] - sub["open"]).abs()
        upper_wick = sub["high"] - sub[["open","close"]].max(axis=1)
        lower_wick = sub[["open","close"]].min(axis=1) - sub["low"]
        vol_z = (sub["volume"] - sub["volume"].rolling(50, min_periods=10).mean()) \
                / (sub["volume"].rolling(50, min_periods=10).std() + 1e-9)

        # Long-liquidation candles: bearish + large upper wick + high vol
        is_bear = (sub["close"] < sub["open"])
        long_liq_mask = (is_bear & (upper_wick > 2 * body) & (vol_z > 1.5))
        # Short-liquidation candles: bullish + large lower wick + high vol
        is_bull = (sub["close"] > sub["open"])
        short_liq_mask = (is_bull & (lower_wick > 2 * body) & (vol_z > 1.5))

        long_liq_n  = int(long_liq_mask.sum())
        short_liq_n = int(short_liq_mask.sum())
        total       = long_liq_n + short_liq_n
        imbalance   = (short_liq_n - long_liq_n) / max(total, 1)

        return {
            "liq_long_cascade":  float(long_liq_n  / lookback),
            "liq_short_cascade": float(short_liq_n / lookback),
            "liq_total_24h":     float(total / lookback),
            "liq_imbalance":     float(imbalance),
        }
    except Exception:
        return defaults
