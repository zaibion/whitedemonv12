"""
advanced/ — high-value extensions on top of the v22 engine.

  • prophet_forecaster.py   — Facebook Prophet trend + change-points
  • meta_labels_v3.py       — Lopez de Prado triple-barrier meta-labeling v3
  • order_flow.py           — Order-Flow Imbalance (OFI) features from L2 book
  • orderbook.py            — Live order-book imbalance from exchanges
  • funding_rate.py         — Funding rate + open-interest features (8-exchange agg)
  • liquidations.py         — Liquidation cascade indicator
  • feature_blender.py      — Combines all advanced features into the engine's feature set

All modules are OPTIONAL — if a dependency isn't installed, the feature
silently returns neutral values so the main engine never fails.
"""
from .prophet_forecaster import prophet_forecast, HAS_PROPHET
from .meta_labels_v3     import MetaLabelerV3
from .order_flow         import compute_ofi_features
from .orderbook          import fetch_orderbook_imbalance
from .funding_rate       import fetch_funding_features_multi
from .liquidations       import fetch_liquidation_cascade
from .feature_blender    import blend_advanced_features

ADVANCED_FEATURES = [
    "prophet_trend", "prophet_changepoint", "prophet_seasonality",
    "ofi_5", "ofi_15", "ofi_30",
    "ob_imbalance", "ob_depth_ratio",
    "funding_8ex_avg", "funding_8ex_skew", "oi_change_24h",
    "liq_long_cascade", "liq_short_cascade", "liq_total_24h",
    "meta_label_v3_proba",
]
