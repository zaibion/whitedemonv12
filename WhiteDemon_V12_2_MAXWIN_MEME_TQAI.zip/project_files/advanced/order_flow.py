"""
Order-Flow Imbalance (OFI) — approximated from OHLCV when L2 book isn't available.

Standard OFI requires tick-by-tick L2 updates. Crypto retail APIs don't
give us that, but we can APPROXIMATE OFI from volume + range using the
Tick Rule (Lee & Ready 1991) on the candle level:

    buy_volume[t]  = volume[t] * (close[t] - low[t]) / (high[t] - low[t] + ε)
    sell_volume[t] = volume[t] * (high[t] - close[t]) / (high[t] - low[t] + ε)
    OFI[t]         = buy_volume[t] - sell_volume[t]

Returns OFI integrated over recent windows.
"""
from __future__ import annotations
from typing import Dict
import numpy as np
import pandas as pd


def compute_ofi_features(df: pd.DataFrame) -> Dict[str, float]:
    """Return dict of OFI features for the latest bar."""
    defaults = {"ofi_5": 0.0, "ofi_15": 0.0, "ofi_30": 0.0, "ofi_z": 0.0}
    if df is None or len(df) < 30:
        return defaults
    try:
        sub = df.tail(200).copy()
        rng = (sub["high"] - sub["low"]).replace(0, np.nan)
        buy_v  = sub["volume"] * (sub["close"] - sub["low"])  / rng
        sell_v = sub["volume"] * (sub["high"]  - sub["close"]) / rng
        ofi    = (buy_v - sell_v).fillna(0).values
        ofi5  = float(ofi[-5:].sum())
        ofi15 = float(ofi[-15:].sum())
        ofi30 = float(ofi[-30:].sum())
        # Z-score normalisation
        ofi_norm = ofi / (np.std(ofi[-100:]) + 1e-9)
        ofi_z = float(ofi_norm[-1])
        return {
            "ofi_5":   float(np.clip(ofi5 / (sub["volume"].iloc[-5:].sum()  + 1), -1, 1)),
            "ofi_15":  float(np.clip(ofi15 / (sub["volume"].iloc[-15:].sum() + 1), -1, 1)),
            "ofi_30":  float(np.clip(ofi30 / (sub["volume"].iloc[-30:].sum() + 1), -1, 1)),
            "ofi_z":   float(np.clip(ofi_z, -3, 3)),
        }
    except Exception:
        return defaults
